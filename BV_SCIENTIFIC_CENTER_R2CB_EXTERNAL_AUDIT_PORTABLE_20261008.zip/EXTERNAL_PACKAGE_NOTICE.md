# EXTERNAL PACKAGE NOTICE

This is a **sanitized external audit variant** of the BV Centro Científico &
Mapa Clínico module (R2C-B). It is NOT the original scientific corpus.

- Restricted-license abstracts were removed (see `SANITIZATION.md`).
- Behavioural test coverage was recovered with an explicit `SYNTHETIC_TEST_FIXTURE`
  and the redistributable CC BY source (see `EXTERNAL_TEST_COMPATIBILITY.md`).
- Twelve tests are skipped with reason `RESTRICTED_SOURCE_REDACTED` (see
  `JUSTIFIED_SKIPS.md`).
- Test counts here are not equivalent to the canonical 392 PASS baseline.
- No clinical use. No formula is approved or operational. No real patient data.
