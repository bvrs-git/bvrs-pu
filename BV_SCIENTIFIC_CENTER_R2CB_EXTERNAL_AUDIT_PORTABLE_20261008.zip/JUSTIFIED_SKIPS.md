# Justified skips — external portable package

Reason for every skip: **RESTRICTED_SOURCE_REDACTED**.

Restricted sources removed for licensing (no permissive license):
- 10.1016/j.clnu.2018.10.010
- 10.20960/nh.03161

| Test | Required source | Skip reason |
| --- | --- | --- |
| tests/test_r2cb_extraction.py::test_extracted_values_are_verbatim_spans | clnu, nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_extraction.py::test_automated_extraction_is_never_human_reviewed | clnu, nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_extraction.py::test_key_fields_grounded | nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_extraction.py::test_ungrounded_fields_are_insufficient | clnu | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_extraction.py::test_no_numeric_results_fabricated | clnu, nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_extraction.py::test_extraction_is_idempotent | clnu, nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_extraction.py::test_source_hash_matches_stored_abstract | clnu, nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_content.py::test_abstracts_acquired_with_provenance | clnu, nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_dossiers.py::test_dossier_index_lists_all_selected | clnu, nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_matrices.py::test_methodology_sheet_is_conservative | clnu | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_matrices.py::test_rob_instrument_is_suggested_never_assigned | clnu | RESTRICTED_SOURCE_REDACTED |
| tests/test_r2cb_adversarial.py::test_extraction_never_marks_human_reviewed | clnu, nh | RESTRICTED_SOURCE_REDACTED |
| tests/test_online_integration.py::* (3) | network | online opt-in (BV_RUN_ONLINE=1) |

No other test is skipped. All remaining tests execute and pass.
