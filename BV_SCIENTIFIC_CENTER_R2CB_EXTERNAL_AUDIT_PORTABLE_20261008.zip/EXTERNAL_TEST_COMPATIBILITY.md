# External portable package — test compatibility report

## Baseline

Canonical baseline (this project): **392 passed / 3 skipped** (3 online opt-in).

Sanitized external package (previous): 380 passed / **12 failed** / 3 skipped.

## GATE 1 — analysis of the 12 failures

Every failure was reproduced with full tracebacks and traced to the absence of the
two restricted-license abstracts removed by sanitization. **No category D
(unexplained/real failure)** and **no category C** among the 12 (the security and
integrity suite is fully executed and passes; it is not skipped).

| # | Test | Cause (demonstrated) | Category | Decision |
| --- | --- | --- | --- | --- |
| 1 | test_r2cb_extraction.py::test_extracted_values_are_verbatim_spans | `extraction is None` for CLNU/NH | A/B | skip original + recovered synthetic |
| 2 | test_r2cb_extraction.py::test_automated_extraction_is_never_human_reviewed | `NoneType` subscription for CLNU/NH | B | skip original + recovered synthetic |
| 3 | test_r2cb_extraction.py::test_key_fields_grounded | asserts real NH values ("1,040", "skinfold thickness") | A | skip original (documentary) |
| 4 | test_r2cb_extraction.py::test_ungrounded_fields_are_insufficient | CLNU extraction None | B | skip original + recovered synthetic |
| 5 | test_r2cb_extraction.py::test_no_numeric_results_fabricated | CLNU/NH extraction None | B | skip original + recovered synthetic |
| 6 | test_r2cb_extraction.py::test_extraction_is_idempotent | asserts count == 3; only 1 abstract present | B | skip original + recovered synthetic |
| 7 | test_r2cb_extraction.py::test_source_hash_matches_stored_abstract | no stored abstract for CLNU/NH | B | skip original + recovered synthetic |
| 8 | test_r2cb_content.py::test_abstracts_acquired_with_provenance | loop over CLNU/NH with no abstract | B | skip original + recovered (CC BY) |
| 9 | test_r2cb_dossiers.py::test_dossier_index_lists_all_selected | asserts extraction count == 3; only 1 present | B | skip original + recovered |
| 10 | test_r2cb_matrices.py::test_methodology_sheet_is_conservative | asserts real CLNU method string | A | skip original |
| 11 | test_r2cb_matrices.py::test_rob_instrument_is_suggested_never_assigned | needs extracted design from CLNU abstract | A/B | skip original + recovered synthetic |
| 12 | test_r2cb_adversarial.py::test_extraction_never_marks_human_reviewed | CLNU/NH extraction None | B | skip original + recovered synthetic |

Categories: A = documentary dependence on the removed abstract; B = behaviour,
recoverable with a permitted fixture; C = mandatory security/integrity (none among
the 12); D = unexplained real failure (none).

## GATE 2 — recovered coverage (external only)

`tests/test_external_recovered_behavior.py` recovers the *behavioural* purposes
using an explicit `SYNTHETIC_TEST_FIXTURE` (never real evidence) and the
redistributable CC BY source. Recovered properties: verbatim grounding, no
automatic `HUMAN_REVIEWED`, ungrounded fields = `INSUFFICIENT_INFORMATION`,
no invented numeric results, extraction idempotency, SHA-256 source integrity,
fail-closed on absent source, and dossier-index consistency.

The synthetic fixture is labelled `SYNTHETIC_TEST_FIXTURE` in the title, venue and
storage note, and its reference origin is `SYNTHETIC_TEST`.

## GATE 3 — justified skips

The 12 original tests are skipped **only** by an explicit, conditional hook in the
external `tests/conftest.py` (reason `RESTRICTED_SOURCE_REDACTED`), and only while
the restricted abstracts are absent from `data/seed/europepmc_corpus.json`. If the
source is restored, the tests execute again. No generic exception-based skipping is
used, and no canonical test file is modified.

## Interpretation

This package is a **sanitized audit variant**, not the original scientific corpus.
Test counts here are not equivalent to the canonical 392 PASS while any test is
skipped. Restoring full coverage requires authorized access to the providers
(`freeze-content`) under the appropriate licensing.
