"""R2C-A - candidate/review UI is read-only with no approval route."""

from __future__ import annotations

import threading
import urllib.error
import urllib.request

import pytest

from bv_scientific_center.ui.server import make_server


@pytest.fixture
def server(r2ca_app):
    srv = make_server(r2ca_app, port=0)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    yield srv
    srv.shutdown()
    srv.server_close()


def _get(server, path):
    host, port = server.server_address
    try:
        with urllib.request.urlopen(f"http://{host}:{port}{path}", timeout=10) as r:
            return r.status, r.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8")


def test_candidate_routes_read_only(server):
    for path in (
        "/knowledge/candidates",
        "/knowledge/candidate/SCI-CAND-FMI",
        "/knowledge/human-review",
    ):
        status, _ = _get(server, path)
        assert status == 200, path


def test_candidate_page_marks_non_operational(server):
    status, body = _get(server, "/knowledge/candidate/SCI-CAND-FMI")
    assert status == 200
    assert "Non-operational" in body
    assert "operational: <strong>no</strong>" in body


def test_no_approval_route_for_candidates(server):
    for path in (
        "/knowledge/candidate/SCI-CAND-FMI/approve",
        "/knowledge/human-review/approve",
    ):
        status, _ = _get(server, path)
        assert status == 404, path
