"""R1.2 GATE 6 - historical reproducibility and logical identity."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.context import EvaluationContext
from bv_scientific_center.errors import IngestionConflictError
from bv_scientific_center.observations.refs import ProjectionIngestor
from bv_scientific_center.contracts.inputs import LabObservationProjection
from bv_scientific_center.seed.synthetic import (
    SYNTHETIC_PATIENT_ID,
    synthetic_patient_context,
    synthetic_projections,
)


def _ctx():
    return EvaluationContext.from_patient_context(synthetic_patient_context())


def test_execution_identity_differs_but_logical_identity_matches(seeded_app):
    first = seeded_app.reproduce_run(SYNTHETIC_PATIENT_ID, context=_ctx())
    second = seeded_app.reproduce_run(SYNTHETIC_PATIENT_ID, context=_ctx())
    assert first.run_id != second.run_id
    assert first.logical_fingerprint() == second.logical_fingerprint()


def test_stored_run_rebuild_matches_recomputation(seeded_app):
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    rebuilt = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    recomputed = seeded_app.reproduce_run(SYNTHETIC_PATIENT_ID, context=_ctx())
    assert rebuilt.logical_fingerprint() == recomputed.logical_fingerprint()


def test_recomputation_does_not_modify_history(seeded_app):
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    before = seeded_app.runs.get(record["run_id"])
    seeded_app.reproduce_run(SYNTHETIC_PATIENT_ID, context=_ctx())
    seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=_ctx())
    after = seeded_app.runs.get(record["run_id"])
    assert before["completed_at"] == after["completed_at"]
    assert before["status"] == after["status"]
    assert before["input_snapshot"] == after["input_snapshot"]


def test_reconstruction_is_independent_of_mutable_state(seeded_app):
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    fingerprint_before = seeded_app.rebuild_run(
        SYNTHETIC_PATIENT_ID, record["run_id"]
    ).logical_fingerprint()

    # Attempt a divergent correction of an input: refused, so the stored state is
    # unchanged and reconstruction is stable.
    ref = ProjectionIngestor().ingest(
        LabObservationProjection(
            patient_id=SYNTHETIC_PATIENT_ID,
            source_entity_id="lab-1",
            concept="GLUCOSE_FASTING",
            value=999.0,
            unit="mg/dL",
            effective_at="2026-03-01T08:00:00+00:00",
        )
    )[0]
    with pytest.raises(IngestionConflictError):
        seeded_app.observations.save(ref)

    fingerprint_after = seeded_app.rebuild_run(
        SYNTHETIC_PATIENT_ID, record["run_id"]
    ).logical_fingerprint()
    assert fingerprint_before == fingerprint_after


def test_reconstruction_refuses_without_evidence(seeded_app):
    with pytest.raises(KeyError):
        seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, "run_does_not_exist")


def test_reconstruction_preserves_provenance_links(seeded_app):
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    rebuilt = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    for metric in rebuilt.metrics:
        if metric.is_valid:
            assert metric.input_refs
            assert all("observation_ref_id" in r for r in metric.input_refs)
            assert metric.metric_definition_version >= 1
