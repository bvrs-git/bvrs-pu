"""R2B GATE 4 - initial controlled biomedical corpus."""

from __future__ import annotations

from bv_scientific_center.bibliography.corpus import DEFAULT_CORPUS_PATH, load_corpus
from bv_scientific_center.core.enums import BibliographicVerification
from bv_scientific_center.knowledge.scientific import CurationStatus
from bv_scientific_center.seed.scientific_seed import pilot_references


def test_corpus_snapshot_is_controlled_and_verifiable():
    snapshot, records = load_corpus(DEFAULT_CORPUS_PATH)
    assert snapshot["domain"] == "ANTHROPOMETRY_BODY_COMPOSITION_NUTRITION"
    assert snapshot["inclusion_criteria"] and snapshot["exclusion_criteria"]
    assert 12 <= len(records) <= 20
    for record in records:
        assert record.doi, "every corpus record must carry a DOI"
        assert record.provider == "CROSSREF"
        assert record.title and record.year


def test_corpus_is_imported_but_never_approved(scientific_app):
    _, records = load_corpus(DEFAULT_CORPUS_PATH)
    dois = {r.doi for r in records}
    imported = [r for r in scientific_app.references.list() if r.doi in dois]
    assert len(imported) >= 12
    for reference in imported:
        assert reference.curation_status is not CurationStatus.APPROVED
        assert reference.bibliographic_status is BibliographicVerification.VERIFIED
    assert scientific_app.curation.active_references() == []


def test_corpus_import_is_idempotent(scientific_app):
    before = len(scientific_app.references.list())
    scientific_app.bootstrap_scientific()  # re-import
    after = len(scientific_app.references.list())
    assert after == before


def test_corpus_carries_acquisition_provenance(scientific_app):
    _, records = load_corpus(DEFAULT_CORPUS_PATH)
    from bv_scientific_center.bibliography.service import reference_id_for

    reference_id = reference_id_for(records[0])
    rows = scientific_app.acquisitions.for_reference(reference_id)
    assert rows and len(rows[0]["payload_sha256"]) == 64


def test_pilot_references_are_part_of_the_corpus_and_unapproved(scientific_app):
    for pilot in pilot_references():
        stored = scientific_app.references.get(pilot.reference_id)
        assert stored is not None
        assert stored.curation_status is not CurationStatus.APPROVED
