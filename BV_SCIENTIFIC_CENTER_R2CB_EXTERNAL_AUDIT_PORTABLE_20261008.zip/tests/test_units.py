"""Unit registry and conversion safety."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.units import (
    convert,
    dimension_of,
    is_known,
    normalize_unit,
    same_dimension,
)
from bv_scientific_center.errors import UnitConversionError, UnknownUnitError


def test_micro_and_superscript_normalisation():
    assert normalize_unit("µg/dL") == "ug/dL"
    assert normalize_unit("kg/m²") == "kg/m^2"
    assert normalize_unit("10^3/µL") == "10^3/uL"


def test_same_dimension_mass_concentration():
    assert same_dimension("ng/dL", "pg/mL")
    assert dimension_of("ng/dL") == dimension_of("pg/mL")


def test_cross_unit_conversion_is_explicit_and_deterministic():
    # 1 ng/dL == 10 pg/mL
    assert convert(1.0, "ng/dL", "pg/mL") == pytest.approx(10.0)
    assert convert(1000.0, "ng/dL", "ng/mL") == pytest.approx(10.0)
    assert convert(1.0, "m", "cm") == pytest.approx(100.0)


def test_temperature_is_affine():
    assert convert(32.0, "F", "degC") == pytest.approx(0.0)
    assert convert(212.0, "F", "degC") == pytest.approx(100.0)


def test_incompatible_dimensions_raise():
    with pytest.raises(UnitConversionError):
        convert(1.0, "IU", "ug")
    with pytest.raises(UnitConversionError):
        convert(1.0, "mg/dL", "mmol/L")


def test_unknown_unit_raises():
    assert is_known("mg/dL")
    with pytest.raises(UnknownUnitError):
        dimension_of("bananas")
