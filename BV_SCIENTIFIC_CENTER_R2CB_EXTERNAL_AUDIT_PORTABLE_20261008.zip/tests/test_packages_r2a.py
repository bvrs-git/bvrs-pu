"""R2A GATE 5 - knowledge package governance and versioning."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import KnowledgeOrigin, PackageReviewStatus
from bv_scientific_center.errors import ImmutablePublishError, PackageValidationError
from bv_scientific_center.knowledge.packages import KnowledgePackage


def _package(**overrides) -> KnowledgePackage:
    defaults = dict(
        package_id="PKG-R2A",
        name="R2A package",
        version="1",
        domain="BODY_COMPOSITION",
        author="author-1",
        reviewer="reviewer-1",
        scientific_reference_ids=("REF-PILOT-FMI-FFMI-CANCER",),
        evidence_ids=("EV-SYN-001",),
        dependencies=({"package_id": "PKG-BASE", "version": "1"},),
        provenance={"origin_note": "curated"},
        origin=KnowledgeOrigin.IMPORTED,
    )
    defaults.update(overrides)
    return KnowledgePackage(**defaults)


def test_synthetic_package_cannot_be_approved():
    package = _package(
        origin=KnowledgeOrigin.SYNTHETIC_TEST,
        review_status=PackageReviewStatus.APPROVED,
    )
    with pytest.raises(PackageValidationError):
        package.validate()


def test_approved_package_requires_author_and_reviewer():
    package = _package(author=None, review_status=PackageReviewStatus.APPROVED)
    with pytest.raises(PackageValidationError):
        package.validate()


def test_dependencies_require_version():
    package = _package(dependencies=({"package_id": "PKG-BASE"},))
    with pytest.raises(PackageValidationError):
        package.validate()


def test_integrity_summary_and_hash():
    package = _package()
    summary = package.describe_integrity()
    assert summary["content_hash"]
    assert summary["scientific_reference_ids"] == ["REF-PILOT-FMI-FFMI-CANCER"]
    assert summary["evidence_ids"] == ["EV-SYN-001"]
    assert package.hash() == _package().hash()


def test_import_is_idempotent_and_detects_conflicts(scientific_app):
    package = _package()
    scientific_app.import_package(package)
    scientific_app.import_package(package)  # identical -> idempotent

    conflict = _package(name="Different name")
    with pytest.raises(ImmutablePublishError):
        scientific_app.import_package(conflict)


def test_package_roundtrip_preserves_r2a_fields():
    package = _package()
    restored = KnowledgePackage.from_dict(package.to_payload())
    assert restored.author == "author-1"
    assert restored.reviewer == "reviewer-1"
    assert restored.dependencies == package.dependencies
    assert restored.origin is KnowledgeOrigin.IMPORTED
    assert restored.scientific_reference_ids == package.scientific_reference_ids
