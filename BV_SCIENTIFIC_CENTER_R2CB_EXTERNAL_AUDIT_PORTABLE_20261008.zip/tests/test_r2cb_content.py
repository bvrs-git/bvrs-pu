"""R2C-B GATE 1/2/3 - content acquisition, licensing and identifier safety."""

from __future__ import annotations

import json

from bv_scientific_center.bibliography.content import (
    classify_license,
    decide_availability,
    sha256_text,
)
from bv_scientific_center.bibliography.europepmc import EuropePmcAdapter
from bv_scientific_center.bibliography.transport import HttpResponse
from bv_scientific_center.core.enums import ContentAvailability, ContentType
from _biblio_helpers import FakeTransport

IJERPH = "10.3390/ijerph16111920"          # OA, CC BY, abstract + full text
CLNU = "10.1016/j.clnu.2018.10.010"        # abstract only, restricted
NH = "10.20960/nh.03161"                   # abstract only, restricted
CIRCJ = "10.1253/circj.cj-10-0583"         # found, no abstract, restricted
MISSING = "10.1097/01823246-199001010-00008"  # not in Europe PMC


def _ref(app, doi: str):
    ref = app.references.find_by_identifier("doi", doi)
    assert ref is not None, doi
    return ref


def _rows(app, doi: str) -> list[dict]:
    return app.content.for_reference(_ref(app, doi).reference_id)


def test_abstracts_acquired_with_provenance(r2cb_app):
    for doi in (IJERPH, CLNU, NH):
        rows = [r for r in _rows(r2cb_app, doi) if r["content_type"] == ContentType.ABSTRACT.value]
        stored = [r for r in rows if r["text"]]
        assert stored, doi
        row = stored[0]
        assert row["sha256"] == sha256_text(row["text"])
        assert row["storage_permitted"] is True
        assert row["locator"] == "abstract"
        assert row["queried_at"]


def test_full_text_stored_only_when_license_permits(r2cb_app):
    ijerph = [r for r in _rows(r2cb_app, IJERPH) if r["content_type"] == ContentType.FULL_TEXT_XML.value]
    assert ijerph and ijerph[0]["text"]
    assert ijerph[0]["license"].lower().startswith("cc by")
    assert ijerph[0]["storage_permitted"] is True
    # Restricted publications never store structural full text.
    for doi in (CLNU, NH, CIRCJ):
        assert not [
            r for r in _rows(r2cb_app, doi) if r["content_type"] == ContentType.FULL_TEXT_XML.value
        ]


def test_restricted_access_is_recorded_not_ignored(r2cb_app):
    clnu = _rows(r2cb_app, CLNU)
    assert clnu[0]["availability"] == ContentAvailability.FULL_TEXT_ACCESS_RESTRICTED.value
    circj = _rows(r2cb_app, CIRCJ)
    assert circj[0]["availability"] == ContentAvailability.FULL_TEXT_ACCESS_RESTRICTED.value
    assert circj[0]["text"] is None


def test_unavailable_source_is_explicit(r2cb_app):
    rows = _rows(r2cb_app, MISSING)
    assert len(rows) == 1
    assert rows[0]["availability"] == ContentAvailability.SOURCE_UNAVAILABLE.value
    assert rows[0]["storage_permitted"] is False
    assert rows[0]["text"] is None


def test_acquisition_is_idempotent(r2cb_app):
    conn = r2cb_app.database.knowledge
    before = conn.execute("SELECT COUNT(*) c FROM acquired_content").fetchone()["c"]
    r2cb_app.bootstrap_r2cb_offline()
    after = conn.execute("SELECT COUNT(*) c FROM acquired_content").fetchone()["c"]
    assert before == after == 9


def test_snapshot_replay_is_deterministic(r2cb_app):
    first = r2cb_app.content.count_by_availability()
    r2cb_app.bootstrap_r2cb_offline()
    assert r2cb_app.content.count_by_availability() == first


# -- identifier verification (GATE 1: never associate by title) -------------
def _core(doi: str, *, title: str, abstract: str | None = None, license: str | None = None) -> dict:
    core = {
        "id": "999999",
        "source": "MED",
        "doi": doi,
        "pmid": "999999",
        "title": title,
        "authorString": "A, B",
        "pubYear": "2020",
        "abstractText": abstract,
        "isOpenAccess": "N",
        "inPMC": "N",
        "inEPMC": "N",
        "publicationStatus": "ppublish",
    }
    if license:
        core["license"] = license
    return core


def _adapter(core: dict) -> EuropePmcAdapter:
    def responder(url, params):
        body = json.dumps({"resultList": {"result": [core]}}).encode("utf-8")
        return HttpResponse(200, url, {}, body)

    return EuropePmcAdapter(FakeTransport(responder), cache=None)


def test_identifier_mismatch_is_not_associated(scientific_app):
    # Same-looking title, different DOI -> must never be linked.
    core = _core("10.9999/wrong", title="Limitations of Body Mass Index to Assess Body Fat")
    scientific_app.bibliography.europepmc = _adapter(core)
    ref = scientific_app.references.find_by_identifier("doi", "10.3928/21650799-20140514-04")
    scientific_app.bibliography.acquire_content(ref.reference_id, doi=ref.doi)
    rows = scientific_app.content.for_reference(ref.reference_id)
    assert rows[0]["availability"] == ContentAvailability.SOURCE_UNAVAILABLE.value
    assert "identifier mismatch" in rows[0]["storage_note"]
    assert all(not r["text"] for r in rows)


def test_matching_identifier_is_associated(scientific_app):
    core = _core("10.3390/ijerph16111920", title="X", abstract="Plain abstract.", license="cc by")
    scientific_app.bibliography.europepmc = _adapter(core)
    ref = scientific_app.references.find_by_identifier("doi", "10.3390/ijerph16111920")
    scientific_app.bibliography.acquire_content(ref.reference_id, doi=ref.doi)
    rows = scientific_app.content.for_reference(ref.reference_id)
    assert any(r["text"] == "Plain abstract." for r in rows)


# -- classification unit rules ---------------------------------------------
def test_license_classification():
    assert classify_license("cc by")[0] is True
    assert classify_license("cc by-nc")[1] is False
    assert classify_license(None)[0] is False
    assert classify_license("all rights reserved")[0] is False


def test_availability_decision():
    assert decide_availability(
        abstract="a", is_open_access="Y", in_pmc="Y", license_value="cc by", has_full_text_urls=True
    )[0] is ContentAvailability.FULL_TEXT_REUSE_PERMITTED
    assert decide_availability(
        abstract="a", is_open_access="Y", in_pmc="Y", license_value=None, has_full_text_urls=True
    )[0] is ContentAvailability.FULL_TEXT_LICENSE_UNKNOWN
    assert decide_availability(
        abstract="a", is_open_access="N", in_pmc="N", license_value=None, has_full_text_urls=False
    )[0] is ContentAvailability.ABSTRACT_AVAILABLE
    assert decide_availability(
        abstract=None, is_open_access="N", in_pmc="N", license_value=None, has_full_text_urls=False
    )[0] is ContentAvailability.SOURCE_UNAVAILABLE
