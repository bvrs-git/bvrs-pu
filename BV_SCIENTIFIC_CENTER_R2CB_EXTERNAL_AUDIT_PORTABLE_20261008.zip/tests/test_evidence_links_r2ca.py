"""R2C-A GATE 7 - differentiated evidence links with justification and version."""

from __future__ import annotations

from bv_scientific_center.knowledge.scientific import (
    CurationSubjectType,
    EvidenceRelation,
    LinkTargetType,
)


def test_seeded_links_have_relation_and_justification(r2ca_app):
    links = r2ca_app.evidence_links.for_target(
        LinkTargetType.FORMULA_CANDIDATE, "SCI-CAND-FMI"
    )
    assert links
    for link in links:
        assert link.relation in {
            EvidenceRelation.METHODOLOGICAL_FOUNDATION,
            EvidenceRelation.DERIVATION_ORIGINAL,
            EvidenceRelation.INTERNAL_VALIDATION,
            EvidenceRelation.EXTERNAL_VALIDATION,
            EvidenceRelation.CLINICAL_APPLICATION,
            EvidenceRelation.LIMITATION,
            EvidenceRelation.CONTRADICTORY_EVIDENCE,
        }
        assert link.justification
        assert link.link_version >= 1


def test_new_relations_are_available_and_legacy_preserved():
    values = {r.value for r in EvidenceRelation}
    assert {
        "DERIVATION_ORIGINAL",
        "METHODOLOGICAL_FOUNDATION",
        "INTERNAL_VALIDATION",
        "EXTERNAL_VALIDATION",
        "CLINICAL_APPLICATION",
        "LIMITATION",
        "CONTRADICTORY_EVIDENCE",
    } <= values
    # Legacy R2A values remain.
    assert {"FOUNDATIONAL", "VALIDATION", "DISCUSSION"} <= values


def test_link_records_justification(r2ca_app):
    link = r2ca_app.linking.link(
        subject_type=CurationSubjectType.REFERENCE,
        subject_id="REF-PILOT-FMI-FFMI-CANCER",
        target_type=LinkTargetType.FORMULA_CANDIDATE,
        target_id="SCI-CAND-FMI",
        relation=EvidenceRelation.CONTRADICTORY_EVIDENCE,
        actor="reviewer-1",
        justification="Reports disagreement in a subgroup.",
        verification_status="UNVERIFIED",
    )
    assert link.justification.startswith("Reports disagreement")
    stored = r2ca_app.evidence_links.for_target(LinkTargetType.FORMULA_CANDIDATE, "SCI-CAND-FMI")
    assert any(l.relation is EvidenceRelation.CONTRADICTORY_EVIDENCE for l in stored)


def test_retraction_propagates_without_rewriting_history(r2ca_app):
    view_before = r2ca_app.candidate_view("SCI-CAND-FMI")
    links_before = len(view_before["evidence_links"])
    reference_id = view_before["references"][0]["reference_id"]

    r2ca_app.editorial_alerts.add(
        reference_id=reference_id,
        alert_type="RETRACTION",
        source="TEST",
        details="retracted",
        is_retraction=True,
    )
    view_after = r2ca_app.candidate_view("SCI-CAND-FMI")
    assert len(view_after["evidence_links"]) == links_before  # history preserved
    assert view_after["editorial_alerts"]  # impact surfaced


def test_candidate_links_are_distinct_from_operational_formulas(r2ca_app):
    # A candidate id must not be present in the operational formula registry.
    operational = {f.definition_id for f in r2ca_app.formulas.all_latest()}
    for candidate in r2ca_app.formula_candidates.all_latest():
        assert candidate.candidate_id not in operational
