"""R1.2 GATE 3 - transactional atomicity of the synthesis cycle."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.context import EvaluationContext
from bv_scientific_center.core.enums import SynthesisRunStatus
from bv_scientific_center.seed.synthetic import (
    SYNTHETIC_PATIENT_ID,
    synthetic_patient_context,
    synthetic_projections,
)


def _ctx():
    return EvaluationContext.from_patient_context(synthetic_patient_context())


def test_rollback_on_mid_persist_failure(seeded_app):
    obs_before = len(seeded_app.observations.list_for_patient(SYNTHETIC_PATIENT_ID))

    def boom(*args, **kwargs):
        raise RuntimeError("injected write failure")

    seeded_app.runner.metrics.save = boom
    try:
        with pytest.raises(RuntimeError):
            seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=_ctx())
    finally:
        del seeded_app.runner.metrics.save

    # Nothing from the failed run persisted; previous state intact.
    assert len(seeded_app.observations.list_for_patient(SYNTHETIC_PATIENT_ID)) == obs_before
    runs = seeded_app.runs.list_for_patient(SYNTHETIC_PATIENT_ID)
    assert runs[0]["status"] == SynthesisRunStatus.FAILED.value


def test_no_partial_run_appears_complete(seeded_app):
    def boom(*args, **kwargs):
        raise RuntimeError("injected")

    seeded_app.runner.signals.save = boom
    try:
        with pytest.raises(RuntimeError):
            seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=_ctx())
    finally:
        del seeded_app.runner.signals.save

    # Every stored run for this patient is either COMPLETED from before or FAILED;
    # no half-written COMPLETED run appears for the failed attempt.
    statuses = [r["status"] for r in seeded_app.runs.list_for_patient(SYNTHETIC_PATIENT_ID)]
    assert statuses[0] == SynthesisRunStatus.FAILED.value


def test_single_transaction_persists_correlated_rows(app):
    from bv_scientific_center.seed.synthetic import (
        register_synthetic_formulas,
        register_synthetic_rules,
        register_synthetic_scores,
    )

    register_synthetic_formulas(app.formulas)
    register_synthetic_scores(app.scores)
    register_synthetic_rules(app.rules)
    result = app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=_ctx())

    run = app.runs.get(result.run_id)
    assert run["status"] == SynthesisRunStatus.COMPLETED.value
    # A completed run has its correlated rows present.
    assert app.metrics.list_for_run(SYNTHETIC_PATIENT_ID, result.run_id)
    assert app.score_results.list_for_run(SYNTHETIC_PATIENT_ID, result.run_id)


def test_failed_run_does_not_duplicate_finalization(seeded_app):
    def boom(*args, **kwargs):
        raise RuntimeError("injected")

    seeded_app.runner.metrics.save = boom
    try:
        with pytest.raises(RuntimeError):
            seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=_ctx())
    finally:
        del seeded_app.runner.metrics.save
    runs = [r for r in seeded_app.runs.list_for_patient(SYNTHETIC_PATIENT_ID)]
    failed = [r for r in runs if r["status"] == SynthesisRunStatus.FAILED.value]
    assert len(failed) == 1
