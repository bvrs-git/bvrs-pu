"""R2B GATE 3 - bibliographic verification vs scientific content review."""

from __future__ import annotations

from bv_scientific_center.core.enums import (
    BibliographicVerification,
    ContentReviewStatus,
)
from bv_scientific_center.knowledge.scientific import CurationStatus


def test_states_are_independent(scientific_app):
    reference = scientific_app.references.get("REF-PILOT-FMI-FFMI-CANCER")
    # Verified bibliographic metadata AND not-yet-reviewed content.
    assert reference.bibliographic_status is BibliographicVerification.VERIFIED
    assert reference.content_review_status is ContentReviewStatus.NOT_REVIEWED
    # And still unapproved editorially.
    assert reference.curation_status is CurationStatus.IMPORTED_UNVERIFIED


def test_content_review_does_not_change_curation(scientific_app):
    scientific_app.set_content_review(
        "REF-PILOT-FMI-FFMI-CANCER", "ABSTRACT_REVIEWED", reviewer="dr.reviewer"
    )
    reference = scientific_app.references.get("REF-PILOT-FMI-FFMI-CANCER")
    assert reference.content_review_status is ContentReviewStatus.ABSTRACT_REVIEWED
    # Still not approved: content review is not approval.
    assert reference.curation_status is CurationStatus.IMPORTED_UNVERIFIED


def test_full_review_can_be_recorded_without_approval(scientific_app):
    scientific_app.set_content_review(
        "REF-PILOT-BMI-FMI-FFMI-KOREAN", "FULL_TEXT_REVIEWED", reviewer="dr.reviewer"
    )
    reference = scientific_app.references.get("REF-PILOT-BMI-FMI-FFMI-KOREAN")
    assert reference.content_review_status is ContentReviewStatus.FULL_TEXT_REVIEWED
    assert reference.curation_status is not CurationStatus.APPROVED


def test_insufficient_information_state_available(scientific_app):
    scientific_app.set_content_review(
        "REF-PILOT-WHTR-MULTIMORBIDITY", "INSUFFICIENT_INFORMATION", reviewer="dr.reviewer"
    )
    reference = scientific_app.references.get("REF-PILOT-WHTR-MULTIMORBIDITY")
    assert reference.content_review_status is ContentReviewStatus.INSUFFICIENT_INFORMATION
