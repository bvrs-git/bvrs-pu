"""Clinical map: layered projection, provenance and "why connected?"."""

from __future__ import annotations

import pytest

from bv_scientific_center.clinical_map.builder import validate_projection
from bv_scientific_center.contracts.outputs import (
    ClinicalMapMetadata,
    ClinicalMapProjectionV1,
    MapNodeProjection,
    Provenance,
)
from bv_scientific_center.core.enums import EdgeType, MapLayer, NodeType
from bv_scientific_center.errors import ProvenanceError
from bv_scientific_center.seed.synthetic import SYNTHETIC_PATIENT_ID


@pytest.fixture
def projection(seeded_app):
    run = seeded_app.reproduce_run(SYNTHETIC_PATIENT_ID)
    return seeded_app.build_map(run)


def test_projection_contract_and_provenance(projection):
    assert projection.contract_version == "ClinicalMapProjectionV1"
    node_ids = {n.node_id for n in projection.nodes}
    for node in projection.nodes:
        assert node.provenance.is_traceable(), node.node_id
    for edge in projection.edges:
        assert edge.source_node_id in node_ids
        assert edge.target_node_id in node_ids
        assert edge.provenance.is_traceable()


def test_derived_and_signal_nodes_are_system_derived(projection):
    derived = [n for n in projection.nodes if n.node_type is NodeType.DERIVED_METRIC]
    assert derived, "expected derived metric nodes"
    assert all(n.authority == "SYSTEM_DERIVED" for n in derived)
    signals = [n for n in projection.nodes if n.node_type is NodeType.CLINICAL_SIGNAL]
    assert signals
    assert all(n.authority == "SYSTEM_DERIVED" for n in signals)


def test_measured_nodes_are_not_derived(projection):
    measured = [n for n in projection.nodes if n.layer is MapLayer.OBJECTIVE]
    assert measured
    assert all(n.authority in {"MEASURED", "CLINICIAN_CONFIRMED"} for n in measured)


def test_layer_filtering(seeded_app):
    run = seeded_app.reproduce_run(SYNTHETIC_PATIENT_ID)
    layers = [MapLayer.DERIVED, MapLayer.SIGNALS]
    filtered = seeded_app.build_map(run, layers=layers)
    assert filtered.nodes
    assert all(n.layer in layers for n in filtered.nodes)
    assert filtered.metadata.layers_enabled == sorted(l.value for l in layers)


def test_why_connected_is_never_opaque(projection):
    assert projection.edges
    for edge in projection.edges:
        why = edge.why_connected()
        assert why["relation"]
        assert why["causal"] is False or edge.relation is EdgeType.CAUSAL_MODEL_SUPPORTED
        assert why["explanation"]


def test_derived_from_edges_link_metric_to_inputs(projection):
    derived_edges = [e for e in projection.edges if e.relation is EdgeType.DERIVED_FROM]
    assert derived_edges
    for edge in derived_edges:
        assert edge.provenance.formula_id


def test_orphan_node_is_rejected():
    orphan = MapNodeProjection(
        node_id="node:x",
        node_type=NodeType.LAB_MARKER,
        layer=MapLayer.OBJECTIVE,
        label="Mystery",
        authority="MEASURED",
        provenance=Provenance(),
    )
    projection = ClinicalMapProjectionV1(
        contract_version="ClinicalMapProjectionV1",
        metadata=ClinicalMapMetadata(patient_id="P", generation_time="2026-01-01T00:00:00+00:00"),
        nodes=[orphan],
        edges=[],
    )
    with pytest.raises(ProvenanceError):
        validate_projection(projection)


def test_temporal_as_of_filter(seeded_app):
    from bv_scientific_center.core.timeutil import parse_dt

    run = seeded_app.reproduce_run(SYNTHETIC_PATIENT_ID)
    early = seeded_app.build_map(run, as_of=parse_dt("2025-01-01T00:00:00+00:00"))
    assert early.nodes == []
