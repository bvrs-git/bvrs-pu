"""R2C-A GATE 6 - applicability profiles and APPLICABILITY_NOT_ESTABLISHED."""

from __future__ import annotations

from bv_scientific_center.knowledge.applicability import (
    APPLICABILITY_NOT_ESTABLISHED,
    APPLICABLE,
    NOT_APPLICABLE,
    ApplicabilityProfile,
)


def a_profile() -> ApplicabilityProfile:
    return ApplicabilityProfile(
        applicable_populations=("ADULT",),
        not_validated_populations=("PEDIATRIC", "PREGNANT"),
        contraindications=("EDEMA_ASCITES",),
        device_requirements=("BIA_X",),
    )


def test_adult_is_applicable():
    result = a_profile().evaluate(population="ADULT", device="BIA_X")
    assert result["status"] == APPLICABLE


def test_unlisted_population_is_not_established():
    result = a_profile().evaluate(population="ATHLETE", device="BIA_X")
    assert result["status"] == APPLICABILITY_NOT_ESTABLISHED


def test_contraindication_is_not_applicable():
    result = a_profile().evaluate(population="EDEMA_ASCITES", device="BIA_X")
    assert result["status"] == NOT_APPLICABLE


def test_device_requirement_enforced():
    assert a_profile().evaluate(population="ADULT")["status"] == NOT_APPLICABLE
    assert a_profile().evaluate(population="ADULT", device="OTHER")["status"] == NOT_APPLICABLE


def test_absence_of_evidence_is_not_evidence_of_absence():
    # PEDIATRIC is not validated -> explicit marker, not a false claim of no effect.
    result = a_profile().evaluate(population="PEDIATRIC", device="BIA_X")
    assert result["status"] == APPLICABILITY_NOT_ESTABLISHED


def test_profile_roundtrip():
    profile = a_profile()
    restored = ApplicabilityProfile.from_dict(profile.to_dict())
    assert restored.contraindications == profile.contraindications
    assert restored.device_requirements == profile.device_requirements
