"""R2A GATE 2 - curation workflow, state machine and human approval."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import KnowledgeOrigin
from bv_scientific_center.errors import (
    CurationApprovalError,
    CurationTransitionError,
    EvidenceGovernanceError,
)
from bv_scientific_center.knowledge.scientific import (
    CurationStatus,
    CurationSubjectType,
    MetadataSource,
    PublicationType,
    ScientificEvidence,
    ScientificReference,
    StudyDesign,
    VerificationStatus,
)

REF = CurationSubjectType.REFERENCE
EV = CurationSubjectType.EVIDENCE


def _verified_reference(reference_id="REF-CUR"):
    return ScientificReference(
        reference_id=reference_id,
        title="Verified curated reference",
        publication_year=2022,
        venue="Journal",
        doi=f"10.5555/{reference_id}",
        metadata_source=MetadataSource.CROSSREF,
        verification_status=VerificationStatus.VERIFIED,
        origin=KnowledgeOrigin.IMPORTED,
    )


def test_allowed_path_screen_curate_approve(scientific_app):
    scientific_app.ingest_reference(_verified_reference())
    cur = scientific_app.curation
    cur.screen(REF, "REF-CUR", actor="reviewer-1")
    cur.curate(REF, "REF-CUR", actor="reviewer-1", justification="methodology checked")
    outcome = cur.approve(
        REF, "REF-CUR", reviewer="reviewer-1", justification="eligible"
    )
    assert outcome.to_status is CurationStatus.APPROVED
    assert scientific_app.curation.is_clinically_usable(REF, "REF-CUR") is True


def test_illegal_transition_is_rejected(scientific_app):
    scientific_app.ingest_reference(_verified_reference())
    with pytest.raises(CurationTransitionError):
        scientific_app.curation.transition(
            REF, "REF-CUR", CurationStatus.APPROVED, actor="r", justification="j"
        )


def test_approval_requires_reviewer_and_justification(scientific_app):
    scientific_app.ingest_reference(_verified_reference())
    cur = scientific_app.curation
    cur.screen(REF, "REF-CUR", actor="r")
    cur.curate(REF, "REF-CUR", actor="r", justification="ok")
    with pytest.raises(CurationApprovalError):
        cur.approve(REF, "REF-CUR", reviewer="", justification="ok")
    with pytest.raises(CurationApprovalError):
        cur.approve(REF, "REF-CUR", reviewer="r", justification="")


def test_synthetic_reference_can_never_be_approved(scientific_app):
    # REF-SYN-001 is synthetic (seeded).
    cur = scientific_app.curation
    cur.screen(REF, "REF-SYN-001", actor="r")
    cur.curate(REF, "REF-SYN-001", actor="r", justification="j")
    with pytest.raises(EvidenceGovernanceError):
        cur.approve(REF, "REF-SYN-001", reviewer="r", justification="j")


def test_unverified_reference_cannot_be_approved(scientific_app):
    reference = ScientificReference(
        reference_id="REF-PENDING",
        title="Pending",
        verification_status=VerificationStatus.VERIFY_PENDING,
    )
    scientific_app.ingest_reference(reference)
    cur = scientific_app.curation
    cur.screen(REF, "REF-PENDING", actor="r")
    cur.curate(REF, "REF-PENDING", actor="r", justification="j")
    with pytest.raises(EvidenceGovernanceError):
        cur.approve(REF, "REF-PENDING", reviewer="r", justification="j")


def test_audit_history_records_actor_and_justification(scientific_app):
    scientific_app.ingest_reference(_verified_reference())
    cur = scientific_app.curation
    cur.screen(REF, "REF-CUR", actor="reviewer-1", justification="screened")
    history = cur.history(REF, "REF-CUR")
    assert len(history) == 1
    assert history[0]["to_status"] == "SCREENED"
    assert history[0]["actor"] == "reviewer-1"
    assert history[0]["justification"] == "screened"


def test_rejected_is_not_clinically_usable(scientific_app):
    scientific_app.ingest_reference(_verified_reference())
    cur = scientific_app.curation
    cur.screen(REF, "REF-CUR", actor="r")
    cur.reject(REF, "REF-CUR", actor="r", justification="not relevant")
    assert cur.is_clinically_usable(REF, "REF-CUR") is False


def test_retraction_requires_reason_and_blocks_use(scientific_app):
    scientific_app.ingest_reference(_verified_reference())
    cur = scientific_app.curation
    cur.screen(REF, "REF-CUR", actor="r")
    cur.curate(REF, "REF-CUR", actor="r", justification="j")
    cur.approve(REF, "REF-CUR", reviewer="r", justification="j")
    with pytest.raises(CurationApprovalError):
        cur.retract(REF, "REF-CUR", actor="r", reason="")
    cur.retract(REF, "REF-CUR", actor="r", reason="retracted by journal")
    stored = scientific_app.references.get("REF-CUR")
    assert stored.curation_status is CurationStatus.RETRACTED
    assert stored.retraction_reason == "retracted by journal"
    assert cur.is_clinically_usable(REF, "REF-CUR") is False


def test_claims_impacted_by_retraction(scientific_app):
    # EV-SYN-002 is referenced by CLAIM-SYN-001 (seeded).
    impacts = scientific_app.curation.claims_impacted_by_retraction("EV-SYN-002")
    assert impacts == []  # not retracted yet
    scientific_app.curation.retract(EV, "EV-SYN-002", actor="r", reason="withdrawn")
    impacts = scientific_app.retraction_impacts("EV-SYN-002")
    assert impacts and impacts[0]["claim_id"] == "CLAIM-SYN-001"
    assert "retracted" in impacts[0]["warning"]


def test_reapproval_same_status_is_rejected(scientific_app):
    scientific_app.ingest_reference(_verified_reference())
    cur = scientific_app.curation
    cur.screen(REF, "REF-CUR", actor="r")
    with pytest.raises(CurationTransitionError):
        cur.screen(REF, "REF-CUR", actor="r")
