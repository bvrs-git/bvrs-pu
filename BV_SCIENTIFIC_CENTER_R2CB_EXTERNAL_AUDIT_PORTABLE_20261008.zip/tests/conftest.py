"""Shared pytest fixtures. The package is importable via pyproject's pythonpath."""

from __future__ import annotations

import json
import pathlib

import pytest

from bv_scientific_center.app import ScientificCenterApp
from bv_scientific_center.bibliography.transport import HttpResponse
from bv_scientific_center.core import ids
from bv_scientific_center.core.enums import FastingStatus, MapLayer, ObservationAuthority
from bv_scientific_center.core.timeutil import parse_dt
from bv_scientific_center.observations.refs import ScientificObservationRef

FIXTURES_DIR = pathlib.Path(__file__).parent / "fixtures"

DEFAULT_TIME = "2026-03-01T08:00:00+00:00"


@pytest.fixture
def make_ref():
    def _make(
        concept: str,
        value: float | None,
        unit: str,
        *,
        when: str = DEFAULT_TIME,
        authority: ObservationAuthority = ObservationAuthority.LAB_CONFIRMED,
        module: str = "LAB",
        entity_type: str = "LabObservation",
        entity_id: str | None = None,
        fasting: FastingStatus = FastingStatus.UNKNOWN,
        provenance: dict | None = None,
        patient_id: str = "P1",
    ) -> ScientificObservationRef:
        layer = (
            MapLayer.PATIENT_REPORTED
            if module in {"INTEGRATIVA", "PATIENT_AREA"}
            else MapLayer.OBJECTIVE
        )
        return ScientificObservationRef(
            observation_ref_id=ids.observation_ref_id(),
            patient_id=patient_id,
            concept=concept,
            value=value,
            unit=unit,
            effective_at=parse_dt(when),
            source_module=module,
            source_entity_type=entity_type,
            source_entity_id=entity_id or ids.new_id("ent"),
            source_version="1",
            authority=authority,
            layer=layer,
            provenance=provenance or {},
            fasting_status=fasting,
        )

    return _make


@pytest.fixture
def app():
    application = ScientificCenterApp(memory=True)
    yield application
    application.close()


@pytest.fixture
def seeded_app():
    application = ScientificCenterApp(memory=True)
    application.bootstrap_synthetic()
    yield application
    application.close()


@pytest.fixture
def scientific_app():
    application = ScientificCenterApp(memory=True)
    application.bootstrap_scientific()
    yield application
    application.close()


@pytest.fixture
def fixtures_dir() -> pathlib.Path:
    return FIXTURES_DIR


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES_DIR / name).read_text(encoding="utf-8"))


class FakeTransport:
    """Deterministic transport for offline tests; records calls."""

    def __init__(self, responder) -> None:
        self._responder = responder
        self.calls: list[tuple[str, dict | None]] = []

    def get(self, url: str, params: dict | None = None) -> HttpResponse:
        self.calls.append((url, params))
        return self._responder(url, params)


def make_json_transport(payload: dict | str, *, status: int = 200, headers: dict | None = None) -> FakeTransport:
    body = payload.encode("utf-8") if isinstance(payload, str) else json.dumps(payload).encode("utf-8")

    def responder(url, params):
        return HttpResponse(status, url, headers or {}, body)

    return FakeTransport(responder)


@pytest.fixture
def biblio_app():
    """Scientific app with real network adapters disabled (offline)."""
    application = ScientificCenterApp(memory=True)
    application.bootstrap_scientific()
    application.bibliography.pubmed = None
    application.bibliography.crossref = None
    yield application
    application.close()


@pytest.fixture
def r2ca_app():
    """Scientific app with the R2C-A candidate registry seeded (offline)."""
    application = ScientificCenterApp(memory=True)
    application.bootstrap_scientific()
    application.bibliography.pubmed = None
    application.bibliography.crossref = None
    application.bootstrap_r2ca()
    yield application
    application.close()


@pytest.fixture
def r2cb_app():
    """Scientific app with R2C-B content acquired from the frozen snapshot (offline).

    Uses the real acquisition code path via the snapshot adapter; no network.
    """
    application = ScientificCenterApp(memory=True)
    application.bootstrap_scientific()
    application.bootstrap_r2ca()
    application.bibliography.pubmed = None
    application.bibliography.crossref = None
    application.bootstrap_r2cb_offline()
    yield application
    application.close()


@pytest.fixture
def europepmc_snapshot() -> dict:
    from bv_scientific_center.bibliography.snapshot import load_content_snapshot

    return load_content_snapshot()


# ==========================================================================
# EXTERNAL PORTABLE PACKAGE ONLY — justified, conditional skips.
# This hook is NOT part of the canonical project and is applied only to the
# external distribution. It skips, with an explicit reason, the nominal list of
# tests whose required bibliographic source was removed for licensing reasons
# (RESTRICTED_SOURCE_REDACTED). If the source is present again (e.g. after
# `python -m bv_scientific_center freeze-content`), the tests run normally.
# ==========================================================================
_EXTERNAL_RESTRICTED_DOIS = (
    "10.1016/j.clnu.2018.10.010",
    "10.20960/nh.03161",
)
_EXTERNAL_RESTRICTED_NODEIDS = {
    "test_r2cb_extraction.py::test_extracted_values_are_verbatim_spans",
    "test_r2cb_extraction.py::test_automated_extraction_is_never_human_reviewed",
    "test_r2cb_extraction.py::test_key_fields_grounded",
    "test_r2cb_extraction.py::test_ungrounded_fields_are_insufficient",
    "test_r2cb_extraction.py::test_no_numeric_results_fabricated",
    "test_r2cb_extraction.py::test_extraction_is_idempotent",
    "test_r2cb_extraction.py::test_source_hash_matches_stored_abstract",
    "test_r2cb_content.py::test_abstracts_acquired_with_provenance",
    "test_r2cb_dossiers.py::test_dossier_index_lists_all_selected",
    "test_r2cb_matrices.py::test_methodology_sheet_is_conservative",
    "test_r2cb_matrices.py::test_rob_instrument_is_suggested_never_assigned",
    "test_r2cb_adversarial.py::test_extraction_never_marks_human_reviewed",
}


def _external_missing_restricted_sources() -> list[str]:
    import json as _json
    from pathlib import Path as _Path

    snapshot = _Path(__file__).resolve().parent.parent / "data" / "seed" / "europepmc_corpus.json"
    try:
        records = _json.loads(snapshot.read_text(encoding="utf-8")).get("records", [])
    except Exception:
        return list(_EXTERNAL_RESTRICTED_DOIS)
    present = {
        (r.get("doi") or "").lower(): bool((r.get("core") or {}).get("abstractText"))
        for r in records
    }
    return [doi for doi in _EXTERNAL_RESTRICTED_DOIS if not present.get(doi.lower(), False)]


def pytest_collection_modifyitems(config, items):
    missing = _external_missing_restricted_sources()
    if not missing:
        return
    reason = "RESTRICTED_SOURCE_REDACTED: abstract(s) excluded from the external package: " + ", ".join(missing)
    for item in items:
        tail = item.nodeid.split("tests/", 1)[-1]
        if tail in _EXTERNAL_RESTRICTED_NODEIDS:
            item.add_marker(pytest.mark.skip(reason=reason))
