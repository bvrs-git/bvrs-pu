"""Rule engine: explainable signal candidates, never diagnoses."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import (
    DefinitionStatus,
    Severity,
    SignalType,
    TemporalRequirement,
)
from bv_scientific_center.formulas.definition import ClinicalFormulaDefinition, FormulaInputRequirement
from bv_scientific_center.formulas.engine import compute_metric
from bv_scientific_center.rules.definition import (
    DERIVED_METRIC,
    OBSERVATION,
    RuleInput,
    RuleSeverityEscalation,
    ScientificClinicalRule,
)
from bv_scientific_center.rules.engine import evaluate_rule
from bv_scientific_center.rules.registry import RuleRegistry


def a_rule(**overrides) -> ScientificClinicalRule:
    defaults = dict(
        definition_id="TEST_RULE",
        name="TEST_RULE fixture",
        version=1,
        status=DefinitionStatus.VALIDATED_FOR_USE,
        evidence_refs=("SYNTHETIC_FIXTURE",),
        inputs=(RuleInput("vitamin_d", "VITAMIN_D_25OH", OBSERVATION, "ng/mL"),),
        conditions=("vitamin_d < 30",),
        signal_type=SignalType.OBSERVATION_FLAG,
        severity=Severity.MODERATE,
        explanation_template="Vitamin D {vitamin_d} {vitamin_d_unit}",
        category="Micronutrient",
        test_rule=True,
    )
    defaults.update(overrides)
    return ScientificClinicalRule(**defaults)


def test_signal_is_explainable_and_flagged(make_ref):
    obs = {"VITAMIN_D_25OH": [make_ref("VITAMIN_D_25OH", 22.0, "ng/mL")]}
    evaluation = evaluate_rule(a_rule(), patient_id="P1", observations_by_concept=obs)
    assert evaluation.matched and evaluation.signal is not None
    signal = evaluation.signal
    assert signal.severity is Severity.MODERATE
    assert signal.authority.value == "SYSTEM_DERIVED"
    why = signal.why()
    assert why["rule"] == "TEST_RULE" and why["rule_version"] == 1
    assert why["inputs"][0]["concept"] == "VITAMIN_D_25OH"
    assert "not a diagnosis" in why["disclaimer"].lower()
    assert signal.supporting_refs


def test_severity_escalation(make_ref):
    obs = {"VITAMIN_D_25OH": [make_ref("VITAMIN_D_25OH", 15.0, "ng/mL")]}
    rule = a_rule(severity_escalations=(RuleSeverityEscalation("vitamin_d < 20", Severity.HIGH),))
    evaluation = evaluate_rule(rule, patient_id="P1", observations_by_concept=obs)
    assert evaluation.signal is not None
    assert evaluation.signal.severity is Severity.HIGH


def test_no_signal_when_conditions_not_met(make_ref):
    obs = {"VITAMIN_D_25OH": [make_ref("VITAMIN_D_25OH", 45.0, "ng/mL")]}
    evaluation = evaluate_rule(a_rule(), patient_id="P1", observations_by_concept=obs)
    assert evaluation.evaluated is True
    assert evaluation.matched is False
    assert evaluation.signal is None


def test_missing_input_skips_rule_without_raising():
    evaluation = evaluate_rule(a_rule(), patient_id="P1", observations_by_concept={})
    assert evaluation.evaluated is False
    assert evaluation.signal is None
    assert "missing required input" in evaluation.reason


def test_rule_can_consume_derived_metric(make_ref):
    formula = ClinicalFormulaDefinition(
        definition_id="TEST_RATIO",
        name="ratio",
        version=1,
        status=DefinitionStatus.VALIDATED_FOR_USE,
        inputs=(
            FormulaInputRequirement("a", "CONCEPT_A", "ng/dL"),
            FormulaInputRequirement("b", "CONCEPT_B", "pg/mL"),
        ),
        output_unit="1",
        expression="a / b",
        temporal_requirement=TemporalRequirement.SAME_DAY,
    )
    metric = compute_metric(
        formula,
        {
            "CONCEPT_A": [make_ref("CONCEPT_A", 480.0, "ng/dL")],
            "CONCEPT_B": [make_ref("CONCEPT_B", 28.0, "pg/mL")],
        },
        patient_id="P1",
    )
    assert metric.is_valid

    rule = a_rule(
        inputs=(RuleInput("te_ratio", "TEST_RATIO", DERIVED_METRIC, "1"),),
        conditions=("te_ratio > 15",),
    )
    evaluation = evaluate_rule(
        rule, patient_id="P1", metrics_by_definition={"TEST_RATIO": [metric]}
    )
    assert evaluation.matched
    assert evaluation.signal is not None
    assert evaluation.signal.supporting_refs[0]["ref_kind"] == DERIVED_METRIC


def test_rule_registry_rejects_undeclared_condition_input():
    from bv_scientific_center.errors import ExpressionError

    registry = RuleRegistry()
    with pytest.raises(ExpressionError):
        registry.publish(a_rule(conditions=("unknown_input > 1",)))
