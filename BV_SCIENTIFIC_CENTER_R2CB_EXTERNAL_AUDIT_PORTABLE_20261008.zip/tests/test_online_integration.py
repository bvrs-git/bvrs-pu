"""R2B online integration tests (opt-in; excluded from the default run).

Enable with:  BV_RUN_ONLINE=1 python -m pytest -o addopts="" -q tests/test_online_integration.py

These tests hit Crossref/PubMed and are therefore separated from the offline
regression suite (which never depends on provider availability).
"""

from __future__ import annotations

import os

import pytest

pytestmark = pytest.mark.skipif(
    os.environ.get("BV_RUN_ONLINE") != "1",
    reason="online integration tests disabled (set BV_RUN_ONLINE=1 to enable)",
)


def test_crossref_real_lookup_by_known_doi():
    from bv_scientific_center.bibliography.crossref import CrossrefAdapter
    from bv_scientific_center.bibliography.transport import RateLimiter, UrllibTransport

    adapter = CrossrefAdapter(
        UrllibTransport(rate_limiter=RateLimiter(1.0)),
    )
    record = adapter.fetch_by_doi("10.3390/ijerph16111920")
    assert record is not None
    assert record.doi and record.title


def test_corpus_acquisition_is_frozen_locally():
    from bv_scientific_center.bibliography.corpus import DEFAULT_CORPUS_PATH, load_corpus

    snapshot, records = load_corpus(DEFAULT_CORPUS_PATH)
    assert records
    assert snapshot["provider"] == "CROSSREF"


def test_europepmc_real_abstract_and_license():
    from bv_scientific_center.bibliography.europepmc import EuropePmcAdapter
    from bv_scientific_center.bibliography.transport import RateLimiter, UrllibTransport

    adapter = EuropePmcAdapter(UrllibTransport(rate_limiter=RateLimiter(1.0)))
    fetched = adapter.fetch_by_doi("10.3390/ijerph16111920")
    assert fetched is not None
    item, _record = fetched
    assert item.get("abstractText")
    assert (item.get("license") or "").lower().startswith("cc by")
