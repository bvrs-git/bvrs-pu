"""R2C-B GATE 9 - adversarial scenarios (offline, deterministic)."""

from __future__ import annotations

import json

from _biblio_helpers import FakeTransport
from bv_scientific_center.bibliography.content import sha256_text
from bv_scientific_center.bibliography.europepmc import EuropePmcAdapter
from bv_scientific_center.bibliography.transport import HttpResponse
from bv_scientific_center.core.enums import ContentAvailability

IJERPH = "10.3390/ijerph16111920"


def _ref(app, doi):
    return app.references.find_by_identifier("doi", doi)


def _core(doi, *, abstract=None, license=None, title="T"):
    core = {
        "id": "1",
        "source": "MED",
        "doi": doi,
        "pmid": "1",
        "title": title,
        "authorString": "A",
        "pubYear": "2020",
        "abstractText": abstract,
        "isOpenAccess": "N",
        "inPMC": "N",
        "inEPMC": "N",
        "publicationStatus": "ppublish",
    }
    if license:
        core["license"] = license
    return core


def _adapter(core):
    def responder(url, params):
        return HttpResponse(200, url, {}, json.dumps({"resultList": {"result": [core]}}).encode())

    return EuropePmcAdapter(FakeTransport(responder), cache=None)


# -- injection & malformed input -------------------------------------------
def test_malicious_doi_does_not_reach_sql(r2cb_app):
    payload = "10.1/x'; DROP TABLE scientific_references;--"
    assert r2cb_app.references.find_by_identifier("doi", payload) is None
    # Table still intact.
    assert r2cb_app.database.knowledge.execute(
        "SELECT COUNT(*) c FROM scientific_references"
    ).fetchone()["c"] > 0


def test_malformed_provider_response_fails_closed(r2cb_app):
    def responder(url, params):
        return HttpResponse(200, url, {}, b"<not json>")

    r2cb_app.bibliography.europepmc = EuropePmcAdapter(FakeTransport(responder), cache=None)
    ref = _ref(r2cb_app, IJERPH)
    rows = r2cb_app.bibliography.acquire_content(ref.reference_id, doi=IJERPH)
    assert all(r.availability is ContentAvailability.SOURCE_UNAVAILABLE for r in rows)


def test_transport_failure_fails_closed(r2cb_app):
    def responder(url, params):
        raise RuntimeError("network down")

    r2cb_app.bibliography.europepmc = EuropePmcAdapter(FakeTransport(responder), cache=None)
    ref = _ref(r2cb_app, IJERPH)
    rows = r2cb_app.bibliography.acquire_content(ref.reference_id, doi=IJERPH)
    assert rows and rows[0].availability is ContentAvailability.SOURCE_UNAVAILABLE


def test_duplicate_doi_import_is_idempotent(scientific_app):
    before = len(scientific_app.references.list())
    # Re-importing the same corpus (same DOIs) must not duplicate references.
    scientific_app.bootstrap_scientific()
    assert len(scientific_app.references.list()) == before
    matches = [r for r in scientific_app.references.list() if (r.doi or "").lower() == IJERPH]
    assert len(matches) == 1


def test_conflicting_doi_metadata_is_refused(scientific_app):
    from bv_scientific_center.bibliography.models import BibliographicRecord
    from bv_scientific_center.core.timeutil import now_utc
    from bv_scientific_center.errors import MetadataConflictError

    conflicting = BibliographicRecord(
        provider="CROSSREF",
        provider_record_id="y",
        endpoint="e",
        request_params={},
        queried_at=now_utc(),
        doi=IJERPH,
        title="A completely different title for the same DOI",
    )
    import pytest

    with pytest.raises(MetadataConflictError):
        scientific_app.bibliography.import_record(conflicting)


# -- content history & idempotency -----------------------------------------
def test_changed_source_preserves_history(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    before = r2cb_app.content.for_reference(ref.reference_id)
    r2cb_app.bibliography.europepmc = _adapter(_core(IJERPH, abstract="A revised abstract."))
    r2cb_app.bibliography.acquire_content(ref.reference_id, doi=IJERPH)
    rows = r2cb_app.content.for_reference(ref.reference_id)
    texts = {r["sha256"] for r in rows if r["content_type"] == "ABSTRACT"}
    # Old snapshot retained, new one added.
    assert sha256_text("A revised abstract.") in texts
    assert len(texts) >= 2
    assert len(before) <= len(rows)


def test_exact_reingest_is_idempotent(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    r2cb_app.bibliography.acquire_content(ref.reference_id, doi=IJERPH)
    first = len(r2cb_app.content.for_reference(ref.reference_id))
    r2cb_app.bibliography.acquire_content(ref.reference_id, doi=IJERPH)
    assert len(r2cb_app.content.for_reference(ref.reference_id)) == first


# -- epistemic separation ---------------------------------------------------
def test_no_patient_data_in_knowledge_library(r2cb_app):
    conn = r2cb_app.database.knowledge
    cols = [r[1] for r in conn.execute("PRAGMA table_info(acquired_content)").fetchall()]
    assert "patient_id" not in cols
    assert "patient_id" not in [r[1] for r in conn.execute("PRAGMA table_info(content_extractions)").fetchall()]
    from bv_scientific_center.seed.synthetic import SYNTHETIC_PATIENT_ID

    blob = "\n".join(
        str(r["text"] or "") for r in conn.execute("SELECT text FROM acquired_content").fetchall()
    )
    assert SYNTHETIC_PATIENT_ID not in blob


def test_content_acquisition_does_not_touch_synthesis(r2cb_app):
    runs_before = r2cb_app.database.clinical.execute("SELECT COUNT(*) c FROM synthesis_runs").fetchone()["c"]
    obs_before = r2cb_app.database.clinical.execute("SELECT COUNT(*) c FROM observations").fetchone()["c"]
    r2cb_app.bootstrap_r2cb_offline()
    assert r2cb_app.database.clinical.execute("SELECT COUNT(*) c FROM synthesis_runs").fetchone()["c"] == runs_before
    assert r2cb_app.database.clinical.execute("SELECT COUNT(*) c FROM observations").fetchone()["c"] == obs_before


# -- activation / approval guards ------------------------------------------
def test_review_decision_cannot_activate_formula(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    r2cb_app.record_review_decision(
        ref.reference_id, "ACCEPT_FOR_CONSIDERATION", actor="dr.x", justification="j"
    )
    assert all(c["operational"] is False for c in r2cb_app.formula_candidates_list())


def test_extraction_never_marks_human_reviewed(r2cb_app):
    for extraction in (
        r2cb_app.extractions.latest(_ref(r2cb_app, d).reference_id)
        for d in ("10.3390/ijerph16111920", "10.1016/j.clnu.2018.10.010", "10.20960/nh.03161")
    ):
        assert all(
            f["provenance"] != "HUMAN_REVIEWED" for f in extraction["fields"].values()
        )


# -- editorial distinctions -------------------------------------------------
def test_errata_is_not_a_retraction(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    r2cb_app.editorial_alerts.add(
        reference_id=ref.reference_id,
        alert_type="ERRATUM",
        source="CROSSREF",
        details="Erratum in figure 2.",
        is_retraction=False,
    )
    assert r2cb_app.editorial_alerts.has_retraction(ref.reference_id) is False
    outcome = r2cb_app.check_currency(ref.reference_id)
    assert outcome["retracted"] is False
    assert outcome["outcome"] == "ALERTS_PRESENT"


def test_restricted_text_is_never_stored(r2cb_app):
    conn = r2cb_app.database.knowledge
    rows = conn.execute(
        "SELECT text, storage_permitted, availability FROM acquired_content"
    ).fetchall()
    for row in rows:
        if row["text"]:
            assert row["storage_permitted"] == 1


def test_offline_replay_after_acquisition(r2cb_app):
    # Adapters are disabled, yet frozen content remains consultable.
    r2cb_app.bibliography.europepmc = None
    r2cb_app.bibliography.crossref = None
    assert r2cb_app.content.count_by_availability()
    assert r2cb_app.extraction_for(_ref(r2cb_app, IJERPH).reference_id) is not None
