"""Synthesis runs: orchestration, persistence, reproducibility and events."""

from __future__ import annotations

from bv_scientific_center.core.context import EvaluationContext
from bv_scientific_center.core.enums import SynthesisRunStatus
from bv_scientific_center.seed.synthetic import (
    SYNTHETIC_PATIENT_ID,
    synthetic_patient_context,
    synthetic_projections,
)


def test_bootstrap_produces_metrics_scores_and_signals(seeded_app):
    overview = seeded_app.patient_overview(SYNTHETIC_PATIENT_ID)
    assert overview["counts"]["observations"] > 0
    assert overview["counts"]["valid_metrics"] > 0
    assert overview["counts"]["scores"] == 1
    assert overview["counts"]["signals"] >= 1


def test_run_record_is_reproducible(seeded_app):
    run = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    assert run is not None
    assert run["status"] == SynthesisRunStatus.COMPLETED.value
    assert run["input_snapshot"], "input snapshot must be recorded"
    assert "TESTOSTERONE_ESTRADIOL_RATIO" in run["formula_versions"]
    assert run["completed_at"] is not None


def test_reproduction_matches_stored_results(seeded_app):
    stored = {
        m.metric_definition_id: round(m.value, 6)
        for m in seeded_app.metrics.list_for_patient(SYNTHETIC_PATIENT_ID)
        if m.is_valid
    }
    context = EvaluationContext.from_patient_context(synthetic_patient_context())
    reproduced = seeded_app.reproduce_run(SYNTHETIC_PATIENT_ID, context=context)
    for metric in reproduced.valid_metrics:
        assert round(metric.value, 6) == stored[metric.metric_definition_id]


def test_events_are_published(seeded_app):
    types = {event.event_type for event in seeded_app.event_bus.events}
    assert "SynthesisRunCompleted" in types
    assert "DerivedMetricComputed" in types
    assert "ClinicalSignalGenerated" in types
    # Map rendering must NOT be published as an event.
    assert all("Map" not in t for t in types)


def test_rerun_is_a_new_run_not_a_rewrite(seeded_app):
    first = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)["run_id"]
    context = EvaluationContext.from_patient_context(synthetic_patient_context())
    seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=context)
    latest = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)["run_id"]
    assert latest != first
    # History retained.
    assert len(seeded_app.runs.list_for_patient(SYNTHETIC_PATIENT_ID)) >= 2
