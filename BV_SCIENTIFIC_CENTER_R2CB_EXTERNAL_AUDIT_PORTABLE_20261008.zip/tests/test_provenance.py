"""R1.1 GATE 2A - scientific provenance: clinical date vs ingestion date."""

from __future__ import annotations

from bv_scientific_center.seed.synthetic import SYNTHETIC_PATIENT_ID


def test_observation_ref_carries_both_dates(make_ref):
    ref = make_ref("GLUCOSE_FASTING", 102.0, "mg/dL", when="2026-03-01T08:00:00+00:00")
    # Ingestion happens after the clinical measurement.
    assert ref.ingested_at >= ref.effective_at
    snapshot = ref.snapshot()
    assert "effective_at" in snapshot and "ingested_at" in snapshot
    assert snapshot["effective_at"] != snapshot["ingested_at"]


def test_derived_metric_records_clinical_and_ingestion_dates(seeded_app):
    metrics = [m for m in seeded_app.metrics.list_for_patient(SYNTHETIC_PATIENT_ID) if m.is_valid]
    assert metrics
    metric = metrics[0]
    # The metric has its own clinical anchor and computation moment.
    assert metric.effective_at is not None
    assert metric.computed_at is not None
    assert metric.computed_at >= metric.effective_at
    # Each input snapshot distinguishes clinical date from ingestion date.
    for ref in metric.input_refs:
        assert "effective_at" in ref
        assert "ingested_at" in ref
        assert ref["ingested_at"] is not None


def test_input_resolution_records_original_and_normalized(seeded_app):
    metric = next(
        m
        for m in seeded_app.metrics.list_for_patient(SYNTHETIC_PATIENT_ID)
        if m.is_valid and m.metric_definition_id == "BMI"
    )
    resolutions = {r.name: r for r in metric.input_resolutions}
    height = resolutions["height_m"]
    # Source is in cm; the formula required m -> explicit conversion recorded.
    assert height.original_unit == "cm"
    assert height.normalized_unit == "m"
    assert height.conversion_applied is True
    assert height.conversion_ref == "cm->m"
    assert height.observation_ref_id


def test_refused_metric_explains_why(seeded_app):
    # Synthetic rules allow all formulas to be valid; build a refusal explicitly.
    from bv_scientific_center.core.context import EvaluationContext
    from bv_scientific_center.core.enums import CalculationStatus
    from bv_scientific_center.formulas.engine import compute_metric

    formula = seeded_app.formulas.get("TESTOSTERONE_ESTRADIOL_RATIO", 1)
    metric = compute_metric(formula, {}, patient_id="P1", context=EvaluationContext())
    assert metric.calculation_status is CalculationStatus.INSUFFICIENT_INPUT
    assert metric.refusal_reason
    assert metric.value is None
    assert metric.missing_inputs
