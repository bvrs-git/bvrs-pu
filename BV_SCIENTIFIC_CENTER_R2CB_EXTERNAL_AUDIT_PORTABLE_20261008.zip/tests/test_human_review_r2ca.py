"""R2C-A GATE 8 - human review queue and dossiers."""

from __future__ import annotations

import json


def test_human_review_queue_has_three_sections(r2ca_app):
    queue = r2ca_app.human_review_queue()
    assert set(queue) == {"references_pending", "claims_pending", "formula_candidates_pending"}
    assert queue["references_pending"]
    assert queue["claims_pending"]
    assert queue["formula_candidates_pending"]


def test_candidates_in_queue_are_non_operational(r2ca_app):
    for item in r2ca_app.human_review_queue()["formula_candidates_pending"]:
        assert item["operational"] is False


def test_dossier_json(r2ca_app):
    payload = r2ca_app.export_candidate_dossier("SCI-CAND-FFMI", "json")
    data = json.loads(payload)
    assert data["candidate"]["candidate_id"] == "SCI-CAND-FFMI"
    assert data["candidate"]["operational"] is False
    assert data["candidate"]["expression"] == "fat_free_mass_kg / (height_m * height_m)"
    assert "references" in data and "evidence_links" in data


def test_dossier_markdown(r2ca_app):
    payload = r2ca_app.export_candidate_dossier("SCI-CAND-FFMI", "md")
    assert payload.startswith("# Formula candidate dossier")
    assert "Non-operational" in payload
    assert "fat_free_mass_kg / (height_m * height_m)" in payload


def test_dossier_unknown_format(r2ca_app):
    import pytest

    with pytest.raises(ValueError):
        r2ca_app.export_candidate_dossier("SCI-CAND-FFMI", "pdf")


def test_pending_decisions_are_not_recorded_as_approved(r2ca_app):
    # No candidate or claim is approved; the queue is pending only.
    statuses = {c.review_status.value for c in r2ca_app.formula_candidates.all_latest()}
    assert "APPROVED" not in statuses
