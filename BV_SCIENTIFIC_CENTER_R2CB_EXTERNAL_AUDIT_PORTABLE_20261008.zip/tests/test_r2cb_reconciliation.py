"""R2C-B GATE 0 - bibliographic reconciliation across phases (no data altered)."""

from __future__ import annotations

from bv_scientific_center.seed.r2ca_seed import SELECTED_DOIS

SHARED_DOI = "10.15857/ksep.2009.18.2.256"  # appears in both pilot and corpus


def test_reconciliation_counts(r2cb_app):
    recon = r2cb_app.reconciliation()
    assert recon["total"] == 21
    assert recon["real"] == 18
    assert recon["synthetic"] == 3
    # 19 R2B imports (4 pilot + 15 corpus) collapse to 18 by DOI-derived id.
    assert 4 + 15 - 1 == recon["real"]


def test_reconciliation_has_no_duplicate_identities(r2cb_app):
    recon = r2cb_app.reconciliation()
    assert recon["duplicate_dois"] == []


def test_shared_doi_present_once(r2cb_app):
    recon = r2cb_app.reconciliation()
    matches = [r for r in recon["rows"] if r["doi"] == SHARED_DOI]
    assert len(matches) == 1


def test_selected_references_all_resolve(r2cb_app):
    for doi in SELECTED_DOIS:
        assert r2cb_app.references.find_by_identifier("doi", doi) is not None


def test_synthetic_is_separated_from_real(r2cb_app):
    recon = r2cb_app.reconciliation()
    synthetic = [r for r in recon["rows"] if r["origin"] == "SYNTHETIC_TEST"]
    assert {r["reference_id"] for r in synthetic} == {"REF-SYN-001", "REF-SYN-002", "REF-SYN-003"}


def test_candidates_remain_non_operational(r2cb_app):
    candidates = r2cb_app.formula_candidates_list()
    assert len(candidates) == 7
    assert all(c["operational"] is False for c in candidates)
