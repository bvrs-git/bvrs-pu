"""Recovered behavioural coverage for the EXTERNAL portable package (R2C-B).

For the external distribution only, these tests exercise the behaviour of tests
that depended on restricted-license abstracts, using an explicitly synthetic
fixture (SYNTHETIC_TEST_FIXTURE) and the redistributable CC BY source
(10.3390/ijerph16111920). They are NOT real scientific evidence.
"""

from __future__ import annotations

import re

from _external_compat import install_synthetic_source
from bv_scientific_center.core.enums import AppraisalFieldProvenance

CC_BY_DOI = "10.3390/ijerph16111920"


def _normalize(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", text)).strip()


def _stored_abstract(app, reference_id: str) -> str:
    rows = app.content.for_reference(reference_id)
    return next(r["text"] for r in rows if r["content_type"] == "ABSTRACT" and r["text"])


# -- synthetic-fixture behaviour -------------------------------------------
def test_synthetic_fixture_is_labelled(r2cb_app):
    rid = install_synthetic_source(r2cb_app)
    ref = r2cb_app.references.get(rid)
    assert ref.origin.value == "SYNTHETIC_TEST"
    assert "SYNTHETIC_TEST_FIXTURE" in ref.title


def test_recovered_verbatim_grounding(r2cb_app):
    rid = install_synthetic_source(r2cb_app)
    extraction = r2cb_app.extractions.latest(rid)
    source = _normalize(_stored_abstract(r2cb_app, rid))
    assert extraction is not None
    for name, field in extraction["fields"].items():
        if field["value"]:
            assert field["verbatim"] in source, name
            assert field["provenance"] == AppraisalFieldProvenance.EXTRACTED_UNVERIFIED.value


def test_recovered_no_human_reviewed(r2cb_app):
    rid = install_synthetic_source(r2cb_app)
    extraction = r2cb_app.extractions.latest(rid)
    assert all(
        f["provenance"] != AppraisalFieldProvenance.HUMAN_REVIEWED.value
        for f in extraction["fields"].values()
    )


def test_recovered_ungrounded_fields_insufficient(r2cb_app):
    rid = install_synthetic_source(r2cb_app)
    extraction = r2cb_app.extractions.latest(rid)
    for name in ("outcomes", "quantitative_results", "confidence_intervals", "limitations"):
        assert extraction["fields"][name]["value"] is None
        assert extraction["fields"][name]["provenance"] == AppraisalFieldProvenance.INSUFFICIENT_INFORMATION.value
        assert extraction["fields"][name]["note"]


def test_recovered_no_invented_numbers(r2cb_app):
    rid = install_synthetic_source(r2cb_app)
    extraction = r2cb_app.extractions.latest(rid)
    assert extraction["fields"]["quantitative_results"]["value"] is None
    assert extraction["fields"]["confidence_intervals"]["value"] is None


def test_recovered_extraction_is_idempotent(r2cb_app):
    rid = install_synthetic_source(r2cb_app)
    conn = r2cb_app.database.knowledge
    before = conn.execute("SELECT COUNT(*) c FROM content_extractions").fetchone()["c"]
    first_id = r2cb_app.extractions.latest(rid)["extraction_id"]
    r2cb_app.extract_reference(rid)  # same source + version -> same row
    after = conn.execute("SELECT COUNT(*) c FROM content_extractions").fetchone()["c"]
    assert before == after
    assert r2cb_app.extractions.latest(rid)["extraction_id"] == first_id


def test_recovered_source_hash_integrity(r2cb_app):
    rid = install_synthetic_source(r2cb_app)
    extraction = r2cb_app.extractions.latest(rid)
    from bv_scientific_center.bibliography.content import sha256_text
    assert extraction["source_sha256"] == sha256_text(_stored_abstract(r2cb_app, rid))


def test_recovered_rejects_absent_source(r2cb_app):
    # Fail-closed: a reference with no stored abstract yields no extraction.
    ref = r2cb_app.references.find_by_identifier("doi", "10.1097/01823246-199001010-00008")
    assert ref is not None
    assert r2cb_app.extraction_for(ref.reference_id) is None


def test_recovered_dossier_index_covers_all_selected(r2cb_app):
    index = r2cb_app.dossier_index()
    assert len(index) == 8
    available = sum(1 for e in index if e["abstract_available"])
    extracted = sum(1 for e in index if e["extraction_available"])
    # Extraction is available exactly for references whose abstract is available.
    assert extracted == available


# -- real, redistributable (CC BY) source ----------------------------------
def test_ccby_source_grounding(r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", CC_BY_DOI)
    extraction = r2cb_app.extractions.latest(ref.reference_id)
    source = _normalize(_stored_abstract(r2cb_app, ref.reference_id))
    assert extraction is not None
    for name, field in extraction["fields"].items():
        if field["value"]:
            assert field["verbatim"] in source, name


def test_ccby_source_no_invented_numbers(r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", CC_BY_DOI)
    extraction = r2cb_app.extractions.latest(ref.reference_id)
    assert extraction["fields"]["quantitative_results"]["value"] is None
