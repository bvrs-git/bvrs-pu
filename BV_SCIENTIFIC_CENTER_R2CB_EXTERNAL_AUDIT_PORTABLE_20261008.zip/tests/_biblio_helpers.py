"""Shared helpers for R2B bibliography tests (offline, deterministic)."""

from __future__ import annotations

import json
import pathlib

from bv_scientific_center.bibliography.transport import HttpResponse

FIXTURES_DIR = pathlib.Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES_DIR / name).read_text(encoding="utf-8"))


class FakeTransport:
    def __init__(self, responder) -> None:
        self._responder = responder
        self.calls: list[tuple[str, dict | None]] = []

    def get(self, url: str, params: dict | None = None) -> HttpResponse:
        self.calls.append((url, params))
        return self._responder(url, params)


def json_transport(payload, *, status: int = 200, headers: dict | None = None) -> FakeTransport:
    if isinstance(payload, str):
        body = payload.encode("utf-8")
    else:
        body = json.dumps(payload).encode("utf-8")

    def responder(url, params):
        return HttpResponse(status, url, headers or {}, body)

    return FakeTransport(responder)


def routed_transport(routes: dict) -> FakeTransport:
    """Routes by substring match on the URL, else 404."""

    def responder(url, params):
        for needle, payload in routes.items():
            if needle in url:
                body = payload if isinstance(payload, bytes) else json.dumps(payload).encode("utf-8")
                return HttpResponse(200, url, {}, body)
        return HttpResponse(404, url, {}, b"not found")

    return FakeTransport(responder)
