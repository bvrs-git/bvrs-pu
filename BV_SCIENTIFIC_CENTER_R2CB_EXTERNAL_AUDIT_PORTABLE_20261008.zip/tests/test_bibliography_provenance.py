"""R2B GATE 2 - acquisition provenance, offline cache and reconciliation."""

from __future__ import annotations

from _biblio_helpers import json_transport, load_fixture, routed_transport
from bv_scientific_center.bibliography.cache import BibliographyCache
from bv_scientific_center.bibliography.crossref import CrossrefAdapter
from bv_scientific_center.bibliography.pubmed import PubMedAdapter
from bv_scientific_center.bibliography.reconcile import reconcile
from bv_scientific_center.bibliography.transport import RateLimited
from bv_scientific_center.core.enums import BibliographicVerification


def test_import_records_provenance(scientific_app):
    adapter = CrossrefAdapter(json_transport(load_fixture("crossref_work.json")))
    record = adapter.fetch_by_doi("10.1234/abc.2019")
    reference = scientific_app.bibliography.import_record(record)
    rows = scientific_app.acquisitions.for_reference(reference.reference_id)
    assert len(rows) == 1
    row = rows[0]
    assert row["provider"] == "CROSSREF"
    assert len(row["payload_sha256"]) == 64
    assert row["processing_version"]
    assert row["queried_at"]


def test_provenance_params_are_sanitized():
    from bv_scientific_center.bibliography.models import BibliographicRecord

    record = BibliographicRecord(
        provider="CROSSREF",
        provider_record_id="10.1234/x",
        endpoint="e",
        request_params={"mailto": "person@example.com", "api_key": "secret", "doi": "10.1234/x"},
    )
    cleaned = record.sanitized_params()
    assert cleaned["mailto"] == "<redacted>"
    assert cleaned["api_key"] == "<redacted>"
    assert cleaned["doi"] == "10.1234/x"


def test_offline_cache_serves_without_transport(scientific_app):
    cache = BibliographyCache(scientific_app.database)
    fetch_adapter = CrossrefAdapter(json_transport(load_fixture("crossref_work.json")), cache=cache)
    first = fetch_adapter.fetch_by_doi("10.1234/abc.2019")
    assert first is not None
    assert cache.count() == 1

    def boom(url, params):
        raise RateLimited(url, None)

    from _biblio_helpers import FakeTransport

    offline_adapter = CrossrefAdapter(FakeTransport(boom), cache=cache)
    second = offline_adapter.fetch_by_doi("10.1234/abc.2019")
    assert second is not None and second.doi == first.doi  # served from cache


def test_reconciliation_verified_when_providers_agree():
    crossref = CrossrefAdapter(json_transport(load_fixture("crossref_work.json"))).fetch_by_doi(
        "10.1234/abc.2019"
    )
    pubmed_adapter = PubMedAdapter(
        routed_transport({"esummary": load_fixture("pubmed_esummary.json")})
    )
    pubmed = pubmed_adapter.fetch_by_pmid("12345678")
    results = reconcile([crossref, pubmed])
    assert len(results) == 1
    assert results[0].status is BibliographicVerification.VERIFIED
    assert set(results[0].providers) == {"CROSSREF", "PUBMED"}


def test_reconciliation_detects_divergence():
    base = load_fixture("crossref_work.json")
    crossref = CrossrefAdapter(json_transport(base)).fetch_by_doi("10.1234/abc.2019")
    diverging = load_fixture("pubmed_esummary.json")
    diverging["result"]["12345678"]["pubdate"] = "2011 Jan"  # different year
    pubmed = PubMedAdapter(routed_transport({"esummary": diverging})).fetch_by_pmid("12345678")
    results = reconcile([crossref, pubmed])
    assert results[0].status is BibliographicVerification.CONFLICT
    assert "year" in results[0].divergences


def test_preprint_keeps_its_own_identity():
    from bv_scientific_center.bibliography.models import BibliographicRecord

    preprint = BibliographicRecord(
        provider="CROSSREF",
        provider_record_id="10.21203/pre",
        endpoint="x",
        doi="10.21203/pre",
        title="Preprint",
        publication_type="posted-content",
    )
    article = BibliographicRecord(
        provider="CROSSREF",
        provider_record_id="10.1234/pub",
        endpoint="x",
        doi="10.1234/pub",
        title="Published",
        publication_type="journal-article",
    )
    results = reconcile([preprint, article])
    assert len(results) == 2  # different identities, never merged
    assert preprint.is_preprint
