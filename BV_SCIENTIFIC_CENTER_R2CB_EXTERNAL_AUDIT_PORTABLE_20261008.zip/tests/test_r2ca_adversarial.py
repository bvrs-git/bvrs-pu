"""R2C-A GATE 9 - adversarial tests."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import (
    FormulaCandidateStatus,
    FormulaCandidateType,
    InputSemantics,
    TemporalRequirement,
)
from bv_scientific_center.errors import (
    ContractViolation,
    EvidenceGovernanceError,
    ExpressionError,
)
from bv_scientific_center.knowledge.candidate_math import evaluate_candidate_prototype
from bv_scientific_center.knowledge.formula_candidates import (
    CandidateVariable,
    FormulaCandidate,
    ScientificFormulaCandidateRegistryV1,
)
from bv_scientific_center.knowledge.input_semantics import device_estimate, measurement
from bv_scientific_center.knowledge.methodology import MethodologicalAssessment, suggest_assessment
from bv_scientific_center.knowledge.scientific import (
    CertaintyLevel,
    CurationSubjectType,
    EvidenceRelation,
    LinkTargetType,
    StudyDesign,
)
from bv_scientific_center.seed.synthetic import (
    SYNTHETIC_PATIENT_ID,
    synthetic_patient_context,
    synthetic_projections,
)


def _candidate(**overrides) -> FormulaCandidate:
    defaults = dict(
        candidate_id="C-ADV", name="adv", display_name="adv", version=1,
        candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX, expression="a / (b * b)",
        output_unit="kg/m^2",
        variables=(CandidateVariable("a", "kg"), CandidateVariable("b", "m")),
        reference_ids=("REF-PILOT-FMI-FFMI-CANCER",),
        review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW,
    )
    defaults.update(overrides)
    return FormulaCandidate(**defaults)


# 1. dimensionally invalid ---------------------------------------------------
def test_dimensional_mismatch_refused():
    result = evaluate_candidate_prototype(
        _candidate(),
        {"a": measurement("a", 70.0, "kg"), "b": measurement("b", 175.0, "kg")},
    )
    assert result.status == "UNIT_INCOMPATIBLE"


# 2. unsafe expression -------------------------------------------------------
def test_unsafe_expression_rejected():
    with pytest.raises(ExpressionError):
        _candidate(expression="__import__('os').system('x')").validate()


# 3. incompatible unit -------------------------------------------------------
def test_unknown_unit_refused():
    with pytest.raises(EvidenceGovernanceError):
        _candidate(output_unit="widgets").validate()


# 4. division by zero --------------------------------------------------------
def test_division_by_zero():
    candidate = _candidate(expression="a / b", variables=(CandidateVariable("a", "kg"), CandidateVariable("b", "kg")))
    result = evaluate_candidate_prototype(
        candidate, {"a": measurement("a", 1.0, "kg"), "b": measurement("b", 0.0, "kg")}
    )
    assert result.status == "DIVISION_BY_ZERO"


# 5. missing input -----------------------------------------------------------
def test_missing_input():
    result = evaluate_candidate_prototype(_candidate(), {"a": measurement("a", 70.0, "kg")})
    assert result.status == "INSUFFICIENT_INPUT"


# 6. device estimate treated as measured ------------------------------------
def test_device_estimate_cannot_be_measured():
    result = evaluate_candidate_prototype(
        _candidate(),
        {"a": device_estimate("a", 70.0, "kg", device="scale"), "b": measurement("b", 1.75, "m")},
    )
    assert result.status == "SEMANTICS_MISMATCH"


# 7/8. applicability unknown / unvalidated population -----------------------
def test_applicability_not_established(r2ca_app):
    result = evaluate_candidate_prototype(
        r2ca_app.formula_candidates.get("SCI-CAND-BMI"),
        {"weight_kg": measurement("weight_kg", 70.0, "kg"), "height_m": measurement("height_m", 1.75, "m")},
        population="ATHLETE",
    )
    assert result.status == "APPLICABILITY_NOT_ESTABLISHED"


# 9. distinct patients in one run -------------------------------------------
def test_mixing_patients_is_refused(seeded_app):
    from bv_scientific_center.contracts.inputs import LabObservationProjection

    foreign = LabObservationProjection(
        patient_id="OTHER", source_entity_id="x", concept="GLUCOSE_FASTING",
        value=1.0, unit="mg/dL", effective_at="2026-03-01T08:00:00+00:00",
    )
    with pytest.raises(ContractViolation):
        seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, [foreign])


# 10. incompatible clinical dates -------------------------------------------
def test_incompatible_clinical_dates():
    candidate = _candidate(
        expression="a + b", output_unit="kg",
        variables=(CandidateVariable("a", "kg"), CandidateVariable("b", "kg")),
        temporal_requirement=TemporalRequirement.SAME_DAY,
    )
    result = evaluate_candidate_prototype(
        candidate,
        {
            "a": measurement("a", 1.0, "kg", effective_at="2026-01-01T08:00:00+00:00"),
            "b": measurement("b", 2.0, "kg", effective_at="2024-01-01T08:00:00+00:00"),
        },
    )
    assert result.status == "TEMPORALLY_INCOMPATIBLE"


# 11. formula without reference ---------------------------------------------
def test_formula_without_reference_must_be_draft():
    with pytest.raises(EvidenceGovernanceError):
        _candidate(reference_ids=()).validate()
    _candidate(reference_ids=(), review_status=FormulaCandidateStatus.DRAFT).validate()


# 12. candidate linked exclusively to a retracted reference -----------------
def test_candidate_linked_to_retracted_reference_is_flagged(r2ca_app):
    view = r2ca_app.candidate_view("SCI-CAND-BMI")
    reference_id = view["references"][0]["reference_id"]
    r2ca_app.editorial_alerts.add(
        reference_id=reference_id, alert_type="RETRACTION", source="TEST",
        details="retracted", is_retraction=True,
    )
    flagged = r2ca_app.candidate_view("SCI-CAND-BMI")
    assert flagged["editorial_alerts"]


# 13. contradictory evidence must be representable --------------------------
def test_contradictory_evidence_link(r2ca_app):
    r2ca_app.linking.link(
        subject_type=CurationSubjectType.REFERENCE,
        subject_id="REF-PILOT-FMI-FFMI-CANCER",
        target_type=LinkTargetType.FORMULA_CANDIDATE,
        target_id="SCI-CAND-FFMI",
        relation=EvidenceRelation.CONTRADICTORY_EVIDENCE,
        actor="r", justification="subgroup disagreement",
    )
    links = r2ca_app.evidence_links.for_target(LinkTargetType.FORMULA_CANDIDATE, "SCI-CAND-FFMI")
    assert any(l.relation is EvidenceRelation.CONTRADICTORY_EVIDENCE for l in links)


# 14. version change without traceability -----------------------------------
def test_version_change_requires_new_version():
    registry = ScientificFormulaCandidateRegistryV1()
    registry.publish(_candidate(version=1))
    with pytest.raises(EvidenceGovernanceError):
        registry.publish(_candidate(version=1, expression="a * b"))
    registry.publish(_candidate(version=2, expression="a * b"))
    assert registry.get("C-ADV", 1).expression == "a / (b * b)"  # history preserved


# 15. attempted automatic clinical activation -------------------------------
def test_candidate_is_not_in_operational_registry(r2ca_app):
    from bv_scientific_center.formulas.registry import FormulaRegistry

    with pytest.raises(KeyError):
        FormulaRegistry().get("SCI-CAND-BMI")
    for candidate in r2ca_app.formula_candidates.all_latest():
        assert candidate.operational is False


# 16. automatic assessment presented as human review ------------------------
def test_suggestion_is_not_human_review(r2ca_app):
    from bv_scientific_center.core.enums import KnowledgeOrigin
    from bv_scientific_center.knowledge.scientific import ScientificEvidence

    evidence = ScientificEvidence(evidence_id="EV-ADV", title="t", study_design=StudyDesign.COHORT,
                                  origin=KnowledgeOrigin.SYNTHETIC_TEST)
    suggestion = suggest_assessment(evidence, references_present=False)
    assert suggestion["auto_certainty"] is False
    assert suggestion["suggested_certainty"] is None
    with pytest.raises(ValueError):
        MethodologicalAssessment(certainty=CertaintyLevel.MODERATE, assessed_by=None, human_applied=False).validate()


# 17. recomputation alters historical synthesis -----------------------------
def test_recomputation_preserves_history(seeded_app):
    from bv_scientific_center.core.context import EvaluationContext

    ctx = EvaluationContext.from_patient_context(synthetic_patient_context())
    seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=ctx)
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    before = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"]).logical_fingerprint()
    seeded_app.bootstrap_scientific()
    seeded_app.bootstrap_r2ca()
    after = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"]).logical_fingerprint()
    assert before == after


# 18. duplicate import -------------------------------------------------------
def test_duplicate_candidate_import_is_idempotent(r2ca_app):
    before = len(r2ca_app.formula_candidates_list())
    r2ca_app.bootstrap_r2ca()
    assert len(r2ca_app.formula_candidates_list()) == before


# 19. transactional failure --------------------------------------------------
def test_failed_transition_leaves_state_unchanged(scientific_app):
    from bv_scientific_center.errors import CurationTransitionError

    with pytest.raises(CurationTransitionError):
        scientific_app.curation.transition(
            CurationSubjectType.REFERENCE, "REF-PILOT-FMI-FFMI-CANCER", "APPROVED",
            actor="r", justification="j",
        )
    reference = scientific_app.references.get("REF-PILOT-FMI-FFMI-CANCER")
    assert reference.curation_status.value == "IMPORTED_UNVERIFIED"


# 20. offline reconstruction ------------------------------------------------
def test_offline_candidate_reconstruction(r2ca_app):
    from bv_scientific_center.knowledge.formula_candidates import ScientificFormulaCandidateRegistryV1

    fresh = ScientificFormulaCandidateRegistryV1()
    loaded = r2ca_app.formula_candidate_repo.load_all_into(fresh)
    assert loaded >= 6
    assert fresh.get("SCI-CAND-FMI").expression == "fat_mass_kg / (height_m * height_m)"
