"""R1.2 GATE 2 - observation identity, idempotency and conflict handling."""

from __future__ import annotations

import pytest

from bv_scientific_center.contracts.inputs import LabObservationProjection
from bv_scientific_center.errors import IngestionConflictError
from bv_scientific_center.observations.refs import ProjectionIngestor


def _ref(value=100.0, *, when="2026-03-01T08:00:00+00:00", pid="P1", eid="e1", sv="1", concept="GLUCOSE_FASTING"):
    projection = LabObservationProjection(
        patient_id=pid,
        source_entity_id=eid,
        concept=concept,
        value=value,
        unit="mg/dL",
        effective_at=when,
        source_version=sv,
    )
    return ProjectionIngestor().ingest(projection)[0]


def test_exact_duplicate_is_idempotent_and_preserves_metadata(app):
    ref = _ref()
    app.observations.save(ref)
    first = app.observations.get(ref.observation_ref_id)
    app.observations.save(_ref())  # exact re-send
    stored = app.observations.list_for_patient("P1")
    assert len(stored) == 1
    assert stored[0].observation_ref_id == first.observation_ref_id


def test_new_observation_with_equal_value_is_preserved_separately(app):
    # Numerically equal value but a *different* source identity -> distinct rows.
    app.observations.save(_ref(value=100.0, eid="e1"))
    app.observations.save(_ref(value=100.0, eid="e2"))
    assert len(app.observations.list_for_patient("P1")) == 2


def test_divergent_content_is_refused_and_preserved(app):
    app.observations.save(_ref(value=100.0))
    divergent = _ref(value=200.0)  # same natural key, different value
    with pytest.raises(IngestionConflictError):
        app.observations.save(divergent)
    stored = app.observations.list_for_patient("P1")
    assert len(stored) == 1
    assert stored[0].value == 100.0  # original never overwritten


def test_source_version_bump_is_the_versioned_correction_path(app):
    app.observations.save(_ref(value=100.0, sv="1"))
    # A genuine correction must bump source_version -> new identity, no conflict.
    app.observations.save(_ref(value=200.0, sv="2"))
    stored = sorted(app.observations.list_for_patient("P1"), key=lambda r: r.source_version)
    assert [r.value for r in stored] == [100.0, 200.0]
    assert len({r.observation_ref_id for r in stored}) == 2


def test_explicit_revision_preserves_original(app):
    original = _ref(value=100.0)
    app.observations.save(original)
    revised = app.observations.save(_ref(value=200.0), on_conflict="REVISE")
    stored = app.observations.list_for_patient("P1")
    assert len(stored) == 2
    assert {r.value for r in stored} == {100.0, 200.0}
    assert revised.provenance.get("revision_of") == original.observation_ref_id


def test_no_cascade_deletes_on_reingestion(app):
    # Observations have no child tables; repeated ingestion must not delete rows.
    for _ in range(3):
        app.observations.save(_ref())
    assert len(app.observations.list_for_patient("P1")) == 1


def test_conflict_does_not_break_existing_references(app):
    original = _ref(value=100.0)
    app.observations.save(original)
    with pytest.raises(IngestionConflictError):
        app.observations.save(_ref(value=999.0))
    # The original reference still resolves.
    assert app.observations.get(original.observation_ref_id).value == 100.0
