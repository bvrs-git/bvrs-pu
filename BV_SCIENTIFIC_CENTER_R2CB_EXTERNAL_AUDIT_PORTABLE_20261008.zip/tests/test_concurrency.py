"""R1.2 GATE 5 - concurrency and isolation on the shared SQLite connection."""

from __future__ import annotations

import threading

from bv_scientific_center.contracts.inputs import LabObservationProjection
from bv_scientific_center.observations.refs import ProjectionIngestor


def _refs(pid: str, n: int = 5):
    return ProjectionIngestor().ingest_many(
        [
            LabObservationProjection(
                patient_id=pid,
                source_entity_id=f"{pid}-{i}",
                concept="GLUCOSE_FASTING",
                value=90.0 + i,
                unit="mg/dL",
                effective_at="2026-03-01T08:00:00+00:00",
            )
            for i in range(n)
        ]
    )


def test_concurrent_reingestion_has_no_duplicates(app):
    refs = _refs("PZ")
    errors: list[Exception] = []

    def worker():
        try:
            app.observations.save_many(refs)
        except Exception as exc:  # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors
    stored = app.observations.list_for_patient("PZ")
    assert len(stored) == 5
    assert len({r.observation_ref_id for r in stored}) == 5


def test_concurrent_runs_for_different_patients(app):
    from bv_scientific_center.seed.synthetic import (
        register_synthetic_formulas,
        register_synthetic_rules,
        register_synthetic_scores,
    )

    register_synthetic_formulas(app.formulas)
    register_synthetic_scores(app.scores)
    register_synthetic_rules(app.rules)

    results: dict[str, object] = {}
    errors: list[Exception] = []

    def worker(pid: str):
        try:
            results[pid] = app.run_synthesis(pid, observation_refs=_refs(pid))
        except Exception as exc:  # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=worker, args=(f"CONC-{i}",)) for i in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors
    for pid in results:
        overview = app.patient_overview(pid)
        assert all(r.patient_id == pid for r in overview["observations"])


def test_read_while_writing_is_consistent(app):
    refs = _refs("PR", 20)
    stop = threading.Event()
    read_errors: list[Exception] = []

    def reader():
        while not stop.is_set():
            try:
                app.observations.list_for_patient("PR")
            except Exception as exc:  # noqa: BLE001
                read_errors.append(exc)

    reader_thread = threading.Thread(target=reader, daemon=True)
    reader_thread.start()
    for _ in range(20):
        app.observations.save_many(refs)
    stop.set()
    reader_thread.join(timeout=5)

    assert not read_errors
    assert len(app.observations.list_for_patient("PR")) == 20


def test_indexes_and_constraints_intact(app):
    app.observations.save_many(_refs("PI", 3))
    indexes = {
        row["name"]
        for row in app.database.clinical.execute(
            "SELECT name FROM sqlite_master WHERE type='index'"
        )
    }
    assert "idx_observations_patient_concept" in indexes
    # Primary key constraint still enforced.
    duplicate = _refs("PI", 3)
    app.observations.save_many(duplicate)  # idempotent, no IntegrityError
    assert len(app.observations.list_for_patient("PI")) == 3
