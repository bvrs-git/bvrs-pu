"""External-package compatibility helpers (NOT part of the canonical project).

* ``RESTRICTED_SOURCE_REDACTED`` — justified skip reason for tests whose required
  bibliographic source was removed for licensing reasons.
* ``SYNTHETIC_TEST_FIXTURE`` — explicitly synthetic content used to recover
  behavioural coverage. It is NOT real evidence and must never be promoted to it.
"""

from __future__ import annotations

SYNTHETIC_TEST_FIXTURE = True
SYNTHETIC_DOI = "10.0000/synthetic.test-fixture"

# Clearly synthetic, deterministic, and labelled as such everywhere.
SYNTHETIC_ABSTRACT = (
    "<h4>Objective</h4>To exercise the extraction pipeline on a clearly synthetic fixture."
    "<h4>Methods</h4>A cross-sectional study of 1234 synthetic participants. "
    "Weight and height were measured using a standardized measuring protocol."
    "<h4>Results</h4>Synthetic outcome text; no real findings are claimed."
    "<h4>Conclusion</h4>Synthetic fixture conclusion."
)


def install_synthetic_source(app, *, abstract: str = SYNTHETIC_ABSTRACT, doi: str = SYNTHETIC_DOI) -> str:
    """Create a synthetic reference + acquired abstract and extract it."""
    from bv_scientific_center.bibliography.content import ContentSnapshot, sha256_text
    from bv_scientific_center.core import ids
    from bv_scientific_center.core.enums import (
        ContentAvailability,
        ContentType,
        KnowledgeOrigin,
    )
    from bv_scientific_center.core.timeutil import now_utc
    from bv_scientific_center.knowledge.scientific import (
        MetadataSource,
        PublicationType,
        ScientificReference,
        VerificationStatus,
    )

    reference_id = ids.stable_id("REF-SYN-FIXTURE", doi)
    app.references.save(
        ScientificReference(
            reference_id=reference_id,
            title="SYNTHETIC_TEST_FIXTURE - extraction behaviour fixture",
            authors=("SYNTHETIC_TEST_FIXTURE",),
            venue="SYNTHETIC_TEST_FIXTURE (not a real source)",
            publication_type=PublicationType.OTHER,
            doi=doi,
            metadata_source=MetadataSource.SYNTHETIC,
            verification_status=VerificationStatus.VERIFY_PENDING,
            origin=KnowledgeOrigin.SYNTHETIC_TEST,
        )
    )
    digest = sha256_text(abstract)
    app.content.save(
        ContentSnapshot(
            content_id=ids.stable_id(
                "content", reference_id, ContentType.ABSTRACT.value, digest,
                ContentAvailability.ABSTRACT_AVAILABLE.value, "abstract",
            ),
            reference_id=reference_id,
            source="SYNTHETIC_TEST_FIXTURE",
            endpoint="synthetic",
            queried_at=now_utc(),
            content_type=ContentType.ABSTRACT,
            sha256=digest,
            availability=ContentAvailability.ABSTRACT_AVAILABLE,
            storage_permitted=True,
            storage_note="SYNTHETIC_TEST_FIXTURE - not real evidence",
            locator="abstract",
            text=abstract,
        )
    )
    app.extract_reference(reference_id)
    return reference_id
