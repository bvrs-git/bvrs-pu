"""R2C-A GATE 1/2 - scientific review: honest appraisal fields and metrics."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import AppraisalFieldProvenance
from bv_scientific_center.knowledge.methodology import (
    MethodologicalAssessment,
    ValidationMetrics,
    design_assessment_template,
)
from bv_scientific_center.knowledge.scientific import CertaintyLevel, StudyDesign
from bv_scientific_center.seed.r2ca_seed import SELECTED_DOIS


def test_selected_references_have_appraisals(r2ca_app):
    assert 6 <= len(SELECTED_DOIS) <= 8
    for doi in SELECTED_DOIS:
        reference = r2ca_app.references.find_by_identifier("doi", doi)
        assert reference is not None
        appraisals = r2ca_app.appraisals.for_reference(reference.reference_id)
        assert appraisals, doi


def test_appraisal_fields_are_honest_and_pending(r2ca_app):
    doi = SELECTED_DOIS[0]
    reference = r2ca_app.references.find_by_identifier("doi", doi)
    appraisal = r2ca_app.appraisals.for_reference(reference.reference_id)[0]
    # Metadata verified; scientific fields explicitly insufficient.
    assert appraisal["field_provenance"]["doi"] == AppraisalFieldProvenance.SOURCE_VERIFIED.value
    assert (
        appraisal["field_provenance"]["scientific_question"]
        == AppraisalFieldProvenance.INSUFFICIENT_INFORMATION.value
    )
    assert "scientific_question" in appraisal["pending_fields"]
    # No numbers were invented.
    assert appraisal["quantitative_results"] == {}
    assert appraisal["content_review_status"] == "INSUFFICIENT_INFORMATION"
    assert appraisal["reviewer"] is None  # no human review performed


def test_validation_metrics_cannot_contain_unreported_numbers():
    metrics = ValidationMetrics(correlation="r = 0.9", reported_by_source=False)
    with pytest.raises(ValueError):
        metrics.validate()
    # With source attribution it is allowed.
    ValidationMetrics(correlation="r = 0.9", reported_by_source=True).validate()
    # Empty metrics are fine without attribution.
    ValidationMetrics().validate()


def test_design_templates_are_design_specific():
    validation = design_assessment_template(StudyDesign.INSTRUMENT_VALIDATION)
    assert "reference_method_adequacy" in validation["domains"]
    synthesis = design_assessment_template(StudyDesign.META_ANALYSIS)
    assert "publication_bias" in synthesis["domains"]


def test_certainty_requires_human_assessor():
    with pytest.raises(ValueError):
        MethodologicalAssessment(certainty=CertaintyLevel.HIGH, assessed_by=None, human_applied=False).validate()
