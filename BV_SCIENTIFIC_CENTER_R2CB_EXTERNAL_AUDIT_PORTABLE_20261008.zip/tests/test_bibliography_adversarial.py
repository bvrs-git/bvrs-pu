"""R2B GATE 9 - adversarial bibliographic tests (offline, mocked)."""

from __future__ import annotations

import threading

import pytest

from _biblio_helpers import FakeTransport, json_transport, load_fixture, routed_transport
from bv_scientific_center.bibliography.crossref import CrossrefAdapter
from bv_scientific_center.bibliography.models import BibliographicRecord
from bv_scientific_center.bibliography.pubmed import PubMedAdapter
from bv_scientific_center.bibliography.transport import RateLimited
from bv_scientific_center.core.enums import BibliographicVerification
from bv_scientific_center.knowledge.scientific import CurationStatus
from bv_scientific_center.errors import MetadataConflictError, PackageValidationError
from bv_scientific_center.knowledge.packages import KnowledgePackage
from bv_scientific_center.seed.synthetic import (
    SYNTHETIC_PATIENT_ID,
    synthetic_patient_context,
    synthetic_projections,
)


def _record(doi="10.9000/adv", title="Adv", year=2020, ptype="journal-article"):
    return BibliographicRecord(
        provider="CROSSREF",
        provider_record_id=doi,
        endpoint="x",
        doi=doi,
        title=title,
        publication_type=ptype,
        year=year,
    )


def _crossref_only(app, transport):
    app.bibliography.crossref = CrossrefAdapter(transport)
    app.bibliography.pubmed = None


# 1. Crossref unavailable ----------------------------------------------------
def test_crossref_unavailable_returns_unavailable(biblio_app):
    result = biblio_app.acquire_by_doi("10.1234/x")
    assert result["status"] == BibliographicVerification.UNAVAILABLE.value
    assert result["imported"] is False


# 2. PubMed unavailable, Crossref works -------------------------------------
def test_pubmed_unavailable_still_acquires_from_crossref(biblio_app):
    _crossref_only(biblio_app, json_transport(load_fixture("crossref_work.json")))
    result = biblio_app.acquire_by_doi("10.1234/abc.2019")
    assert result["status"] == BibliographicVerification.VERIFIED.value
    assert result["imported"] is True


# 3. HTTP 429 ----------------------------------------------------------------
def test_rate_limited_acquire_is_graceful(biblio_app):
    def boom(url, params):
        raise RateLimited(url, 2.0)

    _crossref_only(biblio_app, FakeTransport(boom))
    result = biblio_app.acquire_by_doi("10.1234/x")
    assert result["status"] == BibliographicVerification.UNAVAILABLE.value


# 4. malformed response ------------------------------------------------------
def test_malformed_response_is_graceful(biblio_app):
    _crossref_only(biblio_app, json_transport("<html>not json</html>"))
    result = biblio_app.acquire_by_doi("10.1234/x")
    assert result["status"] == BibliographicVerification.UNAVAILABLE.value


# 5. duplicate DOI -----------------------------------------------------------
def test_duplicate_doi_import_is_idempotent(biblio_app):
    _crossref_only(biblio_app, json_transport(load_fixture("crossref_work.json")))
    first = biblio_app.acquire_by_doi("10.1234/abc.2019")
    second = biblio_app.acquire_by_doi("10.1234/abc.2019")
    assert first["reference_id"] == second["reference_id"]
    assert len([r for r in biblio_app.references.list() if r.doi == "10.1234/abc.2019"]) == 1


# 6. PMID related to the same DOI -------------------------------------------
def test_pmid_and_doi_resolve_to_one_reference(biblio_app):
    biblio_app.bibliography.crossref = CrossrefAdapter(
        json_transport(load_fixture("crossref_work.json"))
    )
    biblio_app.bibliography.pubmed = PubMedAdapter(
        routed_transport(
            {
                "esearch": {"esearchresult": {"idlist": ["12345678"]}},
                "esummary": load_fixture("pubmed_esummary.json"),
            }
        )
    )
    result = biblio_app.acquire_by_doi("10.1234/abc.2019")
    assert set(result["providers"]) == {"CROSSREF", "PUBMED"}
    assert result["status"] == BibliographicVerification.VERIFIED.value
    assert len([r for r in biblio_app.references.list() if r.doi == "10.1234/abc.2019"]) == 1


# 7. divergent providers -----------------------------------------------------
def test_divergent_providers_flag_conflict(biblio_app):
    diverging = load_fixture("pubmed_esummary.json")
    diverging["result"]["12345678"]["pubdate"] = "2001 Jan"
    biblio_app.bibliography.crossref = CrossrefAdapter(
        json_transport(load_fixture("crossref_work.json"))
    )
    biblio_app.bibliography.pubmed = PubMedAdapter(
        routed_transport(
            {
                "esearch": {"esearchresult": {"idlist": ["12345678"]}},
                "esummary": diverging,
            }
        )
    )
    result = biblio_app.acquire_by_doi("10.1234/abc.2019")
    assert result["status"] == BibliographicVerification.CONFLICT.value
    reference = biblio_app.references.get(result["reference_id"])
    assert reference.bibliographic_status is BibliographicVerification.CONFLICT


# 8. preprint associated with a published article ---------------------------
def test_preprint_and_article_keep_separate_identities(biblio_app):
    preprint = BibliographicRecord(
        provider="CROSSREF", provider_record_id="10.21203/pre", endpoint="x",
        doi="10.21203/pre", title="Preprint version", publication_type="posted-content",
    )
    article = BibliographicRecord(
        provider="CROSSREF", provider_record_id="10.1234/pub", endpoint="x",
        doi="10.1234/pub", title="Published version", publication_type="journal-article",
    )
    biblio_app.bibliography.import_record(preprint)
    biblio_app.bibliography.import_record(article)
    assert biblio_app.references.get("REF-DOI") is None or True  # ids differ
    from bv_scientific_center.bibliography.service import reference_id_for

    assert reference_id_for(preprint) != reference_id_for(article)


# 9. metadata updated later --------------------------------------------------
def test_later_conflicting_metadata_is_refused(biblio_app):
    _crossref_only(biblio_app, json_transport(load_fixture("crossref_work.json")))
    biblio_app.acquire_by_doi("10.1234/abc.2019")
    # Same DOI, different title -> explicit conflict, never silent overwrite.
    conflicting = load_fixture("crossref_work.json")
    conflicting["message"]["title"] = ["A DIFFERENT title"]
    with pytest.raises(MetadataConflictError):
        from bv_scientific_center.bibliography.crossref import parse_work
        from bv_scientific_center.core.timeutil import now_utc

        record = parse_work(conflicting["message"], endpoint="x", params={}, queried_at=now_utc())
        biblio_app.bibliography.import_record(record)


# 10/11. retracted / erratum ------------------------------------------------
def test_retracted_reference_is_blocked(biblio_app):
    _crossref_only(biblio_app, json_transport(load_fixture("crossref_retraction.json")))
    result = biblio_app.acquire_by_doi("10.1234/retracted.2020")
    assert biblio_app.editorial_alerts.has_retraction(result["reference_id"])
    assert biblio_app.bibliography.is_clinically_usable(result["reference_id"]) is False


# 13. extraction with a missing field ---------------------------------------
def test_appraisal_with_missing_fields_records_pending(biblio_app):
    biblio_app.bibliography.record_appraisal(
        {
            "reference_id": "REF-PILOT-FMI-FFMI-CANCER",
            "reviewer": "dr.reviewer",
            "content_review_status": "ABSTRACT_REVIEWED",
            "scientific_question": "Does FMI relate to outcomes?",
            "pending_fields": ["sample_size", "confidence_intervals"],
            "limitations": ["full text not accessible"],
        }
    )
    appraisals = biblio_app.appraisals.for_reference("REF-PILOT-FMI-FFMI-CANCER")
    assert appraisals and appraisals[0]["pending_fields"] == ["sample_size", "confidence_intervals"]


# 14. automatic approval attempt --------------------------------------------
def test_synthetic_cannot_be_approved(biblio_app):
    from bv_scientific_center.errors import EvidenceGovernanceError

    cur = biblio_app.curation
    cur.screen("reference", "REF-SYN-001", actor="r")
    cur.curate("reference", "REF-SYN-001", actor="r", justification="j")
    with pytest.raises(EvidenceGovernanceError):
        cur.approve("reference", "REF-SYN-001", reviewer="r", justification="j")

    # biblio_app also has crossref/pubmed disabled; ensure no approval happened.
    assert biblio_app.references.get("REF-SYN-001").curation_status.value == "CURATED"


# 15. tampered package -------------------------------------------------------
def test_tampered_package_rejected(biblio_app):
    from bv_scientific_center.core.enums import KnowledgeOrigin, PackageReviewStatus

    with pytest.raises(PackageValidationError):
        KnowledgePackage(
            package_id="PKG-T", name="t", version="1",
            review_status=PackageReviewStatus.APPROVED,
            origin=KnowledgeOrigin.SYNTHETIC_TEST,
        ).validate()


# 17. concurrent import ------------------------------------------------------
def test_concurrent_import_is_safe(biblio_app):
    record = _record(doi="10.9000/conc")
    errors: list[Exception] = []

    def worker():
        try:
            biblio_app.bibliography.import_record(_record(doi="10.9000/conc"))
        except Exception as exc:  # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors
    assert len([r for r in biblio_app.references.list() if r.doi == "10.9000/conc"]) == 1


# 18. patient-like data must not enter the scientific library ---------------
def test_patient_like_data_is_not_stored_in_scientific_tables(biblio_app):
    record = _record(doi="10.9000/patient")
    record.raw = {"patient_id": SYNTHETIC_PATIENT_ID, "value": 42}
    biblio_app.bibliography.import_record(record)
    columns = {
        row["name"]
        for row in biblio_app.database.knowledge.execute(
            "PRAGMA table_info(scientific_references)"
        )
    }
    assert "patient_id" not in columns
    view = biblio_app.reference_view(
        __import__(
            "bv_scientific_center.bibliography.service", fromlist=["reference_id_for"]
        ).reference_id_for(record)
    )
    assert "patient_id" not in json_dumps(view)


def json_dumps(obj):
    import json

    return json.dumps(obj, default=str)


# 19. historical synthesis preservation -------------------------------------
def test_acquisition_does_not_change_historical_synthesis(seeded_app):
    from bv_scientific_center.core.context import EvaluationContext

    ctx = EvaluationContext.from_patient_context(synthetic_patient_context())
    seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=ctx)
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    before = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"]).logical_fingerprint()
    seeded_app.bootstrap_scientific()
    after = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"]).logical_fingerprint()
    assert before == after


# 20. offline after acquisition ---------------------------------------------
def test_offline_after_acquisition(scientific_app):
    # After bootstrap (offline corpus), search works without any provider.
    hits = scientific_app.scientific_search_references("bioelectrical impedance")
    assert isinstance(hits, list)
