"""R2C-B GATE 3 - citation-grounded extraction (never human review)."""

from __future__ import annotations

import re

from bv_scientific_center.core.enums import AppraisalFieldProvenance
from bv_scientific_center.knowledge.extraction import extract_from_abstract

IJERPH = "10.3390/ijerph16111920"
CLNU = "10.1016/j.clnu.2018.10.010"
NH = "10.20960/nh.03161"
MISSING = "10.1097/01823246-199001010-00008"


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", text)).strip()


def _abstract(app, doi: str) -> str:
    ref = app.references.find_by_identifier("doi", doi)
    rows = app.content.for_reference(ref.reference_id)
    return next(r["text"] for r in rows if r["content_type"] == "ABSTRACT" and r["text"])


def test_extracted_values_are_verbatim_spans(r2cb_app):
    for doi in (IJERPH, CLNU, NH):
        ref = r2cb_app.references.find_by_identifier("doi", doi)
        extraction = r2cb_app.extractions.latest(ref.reference_id)
        source = _clean(_abstract(r2cb_app, doi))
        assert extraction is not None
        for name, field in extraction["fields"].items():
            if field["value"]:
                assert field["verbatim"] in source, (doi, name)
                assert field["provenance"] == AppraisalFieldProvenance.EXTRACTED_UNVERIFIED.value


def test_automated_extraction_is_never_human_reviewed(r2cb_app):
    for extraction in (
        r2cb_app.extractions.latest(r2cb_app.references.find_by_identifier("doi", d).reference_id)
        for d in (IJERPH, CLNU, NH)
    ):
        assert all(
            f["provenance"] != AppraisalFieldProvenance.HUMAN_REVIEWED.value
            for f in extraction["fields"].values()
        )


def test_key_fields_grounded(r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", NH)
    extraction = r2cb_app.extractions.latest(ref.reference_id)
    fields = extraction["fields"]
    assert fields["study_design"]["value"] == "CROSS_SECTIONAL"
    assert fields["sample_size"]["value"] == "1,040"
    assert fields["reference_method"]["value"] == "skinfold thickness"
    ijerph = r2cb_app.extractions.latest(
        r2cb_app.references.find_by_identifier("doi", IJERPH).reference_id
    )["fields"]
    assert ijerph["sample_size"]["value"] == "1036"
    assert ijerph["reference_method"]["value"] == "standardized measuring protocol"


def test_ungrounded_fields_are_insufficient(r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", CLNU)
    extraction = r2cb_app.extractions.latest(ref.reference_id)
    for name in ("outcomes", "quantitative_results", "confidence_intervals", "limitations"):
        assert extraction["fields"][name]["value"] is None
        assert (
            extraction["fields"][name]["provenance"]
            == AppraisalFieldProvenance.INSUFFICIENT_INFORMATION.value
        )
        assert extraction["fields"][name]["note"]


def test_no_numeric_results_fabricated(r2cb_app):
    for doi in (IJERPH, CLNU, NH):
        ref = r2cb_app.references.find_by_identifier("doi", doi)
        extraction = r2cb_app.extractions.latest(ref.reference_id)
        assert extraction["fields"]["quantitative_results"]["value"] is None
        assert extraction["fields"]["confidence_intervals"]["value"] is None


def test_extraction_is_idempotent(r2cb_app):
    conn = r2cb_app.database.knowledge
    before = conn.execute("SELECT COUNT(*) c FROM content_extractions").fetchone()["c"]
    r2cb_app.bootstrap_r2cb_offline()
    after = conn.execute("SELECT COUNT(*) c FROM content_extractions").fetchone()["c"]
    assert before == after == 3


def test_source_hash_matches_stored_abstract(r2cb_app):
    for doi in (IJERPH, CLNU, NH):
        ref = r2cb_app.references.find_by_identifier("doi", doi)
        extraction = r2cb_app.extractions.latest(ref.reference_id)
        stored = [
            r
            for r in r2cb_app.content.for_reference(ref.reference_id)
            if r["content_type"] == "ABSTRACT" and r["text"]
        ][0]
        assert extraction["source_sha256"] == stored["sha256"]


def test_no_abstract_no_extraction(r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", MISSING)
    assert r2cb_app.extractions.latest(ref.reference_id) is None


def test_extractor_does_not_claim_unsupported_design():
    from bv_scientific_center.bibliography.content import sha256_text

    abstract = "A narrative essay about wellness with no described study design."
    extraction = extract_from_abstract(
        "REF-X", abstract, content_id=None, source_sha256=sha256_text(abstract)
    )
    assert extraction.fields["study_design"].value is None
    assert (
        extraction.fields["study_design"].provenance
        is AppraisalFieldProvenance.INSUFFICIENT_INFORMATION
    )
