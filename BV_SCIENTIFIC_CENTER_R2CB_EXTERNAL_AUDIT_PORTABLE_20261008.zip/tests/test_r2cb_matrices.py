"""R2C-B GATE 4/5/6 - methodology, evidence links and applicability matrices."""

from __future__ import annotations

from bv_scientific_center.knowledge.applicability import POPULATIONS

CLNU = "10.1016/j.clnu.2018.10.010"


def test_formula_evidence_matrix_surfaces_gaps(r2cb_app):
    matrix = r2cb_app.formula_evidence_matrix()
    assert len(matrix) == 7
    for row in matrix:
        assert row["expression"]
        assert row["operational"] is False
        assert row["links"], row["candidate_id"]
        # No validation evidence was imported; gaps must be explicit.
        assert row["has_validation_evidence"] is False
        assert "no_validation_evidence" in row["gaps"]
        assert row["has_contradictory_evidence"] is False


def test_formula_evidence_links_carry_status(r2cb_app):
    matrix = {row["candidate_id"]: row for row in r2cb_app.formula_evidence_matrix()}
    bmi = matrix["SCI-CAND-BMI"]
    for link in bmi["links"]:
        assert link["justification"]
        assert link["curation_status"] == "IMPORTED_UNVERIFIED"
        assert link["retracted"] is False


def test_applicability_matrix_never_auto_validates(r2cb_app):
    matrix = {row["candidate_id"]: row for row in r2cb_app.applicability_matrix()}
    assert len(matrix) == 7
    for row in matrix.values():
        contexts = {c["context"]: c["status"] for c in row["contexts"]}
        assert set(contexts) == set(POPULATIONS)
        # No context may be declared validated without human review.
        assert "VALIDATED_FOR_CONTEXT" not in contexts.values()
    bmi = {c["context"]: c["status"] for c in matrix["SCI-CAND-BMI"]["contexts"]}
    assert bmi["ADULT"] == "VALIDATION_PENDING"
    assert bmi["PEDIATRIC"] == "NOT_VALIDATED_FOR_CONTEXT"
    assert bmi["ELDERLY"] == "EVIDENCE_INSUFFICIENT"


def test_methodology_sheet_is_conservative(r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", CLNU)
    sheet = r2cb_app.body_composition_sheet(ref.reference_id)
    assert sheet["reference_method"] == "bioelectrical impedance analysis"
    assert sheet["risk_of_bias"]["status"] == "UNASSESSED"
    assert sheet["risk_of_bias"]["assigned_tool"] is None
    # Not-supported fields are explicitly insufficient, never guessed.
    for name in ("device_brand", "equation_used", "agreement", "limits_of_agreement"):
        assert sheet["fields"][name]["value"] is None
        assert sheet["fields"][name]["provenance"] == "INSUFFICIENT_INFORMATION"


def test_methodology_policy_distinguishes_checklists_from_rob(r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", CLNU)
    sheet = r2cb_app.body_composition_sheet(ref.reference_id)
    assert "STROBE" in sheet["policy"]["reporting_checklists"]
    assert "not risk-of-bias tools" in sheet["policy"]["note"]
    assert "correlation" in sheet["policy"]["correlation_not_agreement"]


def test_rob_instrument_is_suggested_never_assigned(r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", CLNU)
    rob = r2cb_app.body_composition_sheet(ref.reference_id)["risk_of_bias"]
    # Cross-sectional -> a design-appropriate tool is suggested, never applied.
    assert rob["assigned_tool"] is None
    assert rob["status"] == "UNASSESSED"
    assert "JBI" in (rob["suggested_tool"] or "")
    # Reporting checklists are not returned as risk-of-bias tools.
    assert "STROBE" not in (rob["suggested_tool"] or "")


def test_rob_instrument_mapping_unit():
    from bv_scientific_center.knowledge.methodology import suggested_rob_instrument
    from bv_scientific_center.knowledge.scientific import StudyDesign

    assert suggested_rob_instrument(StudyDesign.RCT)["suggested_tool"] == "RoB 2"
    assert suggested_rob_instrument(StudyDesign.DIAGNOSTIC_ACCURACY)["suggested_tool"] == "QUADAS-2"
    unknown = suggested_rob_instrument(StudyDesign.OTHER)
    assert unknown["suggested_tool"] is None and unknown["auto_applied"] is False
