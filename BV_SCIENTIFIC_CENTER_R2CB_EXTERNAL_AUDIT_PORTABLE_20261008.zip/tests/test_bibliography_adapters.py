"""R2B GATE 1 - Crossref and PubMed adapters (offline, mocked)."""

from __future__ import annotations

import pytest

from _biblio_helpers import json_transport, load_fixture, routed_transport
from bv_scientific_center.bibliography.crossref import CrossrefAdapter
from bv_scientific_center.bibliography.pubmed import PubMedAdapter
from bv_scientific_center.bibliography.transport import (
    HttpResponse,
    RateLimited,
    RateLimiter,
    RetryPolicy,
)


def test_crossref_parsing_normalizes_metadata():
    adapter = CrossrefAdapter(json_transport(load_fixture("crossref_work.json")))
    record = adapter.fetch_by_doi("10.1234/abc.2019")
    assert record is not None
    # DOI normalized to lowercase.
    assert record.doi == "10.1234/abc.2019"
    assert record.title == "A test article on body composition"
    assert record.authors == ("Smith, John", "Doe, Jane")
    assert record.journal == "Test Journal of Body Composition"
    assert record.issn == ("1111-2222", "3333-4444")
    assert record.year == 2019
    assert record.publication_type == "journal-article"
    assert record.payload_sha256


def test_pubmed_esearch_and_esummary():
    routes = {
        "esearch": {"esearchresult": {"idlist": ["12345678"]}},
        "esummary": load_fixture("pubmed_esummary.json"),
    }
    adapter = PubMedAdapter(routed_transport(routes))
    records = adapter.search("body composition")
    assert len(records) == 1
    record = records[0]
    assert record.pmid == "12345678"
    assert record.doi == "10.1234/abc.2019"
    assert record.year == 2019
    assert "Journal Article" in (record.publication_type or "")


def test_pubmed_fetch_by_doi_uses_doi_query():
    transport = routed_transport(
        {
            "esearch": {"esearchresult": {"idlist": ["12345678"]}},
            "esummary": load_fixture("pubmed_esummary.json"),
        }
    )
    record = PubMedAdapter(transport).fetch_by_doi("10.1234/abc.2019")
    assert record is not None and record.pmid == "12345678"
    # The DOI query was issued.
    assert any("10.1234%2Fabc.2019" in (p or {}).get("term", "") or "[DOI]" in (p or {}).get("term", "")
               for _, p in transport.calls)


def test_rate_limiter_spaces_requests():
    limiter = RateLimiter(max_per_second=1000.0)
    limiter.acquire()
    limiter.acquire()  # must not raise; interval is tiny


def test_retry_policy_backoff_and_retry_after():
    policy = RetryPolicy(base_delay=1.0, max_delay=10.0)
    assert policy.delay_for(0) == 1.0
    assert policy.delay_for(1) == 2.0
    assert policy.delay_for(2) == 4.0
    assert policy.delay_for(3) == 8.0
    assert policy.delay_for(0, retry_after=3.0) == 3.0
    assert policy.delay_for(9, retry_after=999.0) == 10.0


def test_rate_limited_propagates():
    def responder(url, params):
        raise RateLimited(url, 5.0)

    from _biblio_helpers import FakeTransport

    adapter = CrossrefAdapter(FakeTransport(responder))
    with pytest.raises(RateLimited):
        adapter._get("https://example/works", {})


def test_malformed_response_returns_none():
    adapter = CrossrefAdapter(json_transport("<not json>"))
    # A malformed provider response is handled, never propagated as a value.
    assert adapter.fetch_by_doi("10.1234/x") is None


def test_crossref_missing_message_returns_none():
    adapter = CrossrefAdapter(json_transport({"status": "ok"}))
    assert adapter.fetch_by_doi("10.1234/x") is None


def test_transport_user_agent_identifiable():
    from bv_scientific_center.bibliography.transport import UrllibTransport

    transport = UrllibTransport()
    assert "BVScientificCenter" in transport.user_agent
