"""R1.1 GATE 4 - knowledge governance and separation by origin."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import KnowledgeOrigin, KnowledgeStatus
from bv_scientific_center.errors import CitationRequiredError, KnowledgeGovernanceError
from bv_scientific_center.knowledge.models import ScientificKnowledgeItem


def an_item(**overrides) -> ScientificKnowledgeItem:
    defaults = dict(
        knowledge_id="KNOW-GOV",
        title="Governance fixture",
        citation="Journal 2021;1(1):1.",
        publication_year=2021,
        journal="Journal",
        origin=KnowledgeOrigin.CURATED,
    )
    defaults.update(overrides)
    return ScientificKnowledgeItem(**defaults)


def test_curated_item_with_citation_can_be_approved(app):
    app.knowledge.save_item(an_item(status=KnowledgeStatus.APPROVED))
    assert app.knowledge.get_item("KNOW-GOV").status is KnowledgeStatus.APPROVED


def test_synthetic_item_can_never_be_approved(app):
    item = an_item(origin=KnowledgeOrigin.SYNTHETIC_TEST, status=KnowledgeStatus.APPROVED)
    with pytest.raises(KnowledgeGovernanceError):
        app.knowledge.save_item(item)


def test_curated_item_without_citation_cannot_be_approved(app):
    item = an_item(citation="", doi=None, journal=None, url=None, publication_year=None)
    item.status = KnowledgeStatus.APPROVED
    with pytest.raises(CitationRequiredError):
        app.knowledge.save_item(item)


def test_seeded_knowledge_is_synthetic_and_unapproved(seeded_app):
    items = seeded_app.knowledge.list_items()
    assert items
    assert all(i.origin is KnowledgeOrigin.SYNTHETIC_TEST for i in items)
    assert all(i.status is not KnowledgeStatus.APPROVED for i in items)
    assert seeded_app.knowledge_by_origin() == {"SYNTHETIC_TEST": len(items)}


def test_package_activation_keeps_synthetic_items_unapproved(seeded_app):
    items = seeded_app.knowledge.list_items()
    assert items
    # Even after package activation, synthetic items are not clinically approved.
    with pytest.raises(KnowledgeGovernanceError):
        seeded_app.knowledge.set_status(items[0].knowledge_id, KnowledgeStatus.APPROVED)
