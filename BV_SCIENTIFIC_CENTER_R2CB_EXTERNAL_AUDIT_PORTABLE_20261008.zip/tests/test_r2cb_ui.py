"""R2C-B GATE 6 - dossier UI is read-only; decisions are never executed over HTTP."""

from __future__ import annotations

import threading
import urllib.error
import urllib.request

import pytest

from bv_scientific_center.ui.server import make_server

IJERPH = "10.3390/ijerph16111920"


@pytest.fixture
def server(r2cb_app):
    srv = make_server(r2cb_app, port=0)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    yield srv
    srv.shutdown()
    srv.server_close()


def _get(server, path):
    host, port = server.server_address
    try:
        with urllib.request.urlopen(f"http://{host}:{port}{path}", timeout=10) as r:
            return r.status, r.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8")


def test_dossier_routes_read_only(server, r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", IJERPH)
    status, body = _get(server, "/knowledge/dossiers")
    assert status == 200
    assert "Medical dossiers" in body
    status, body = _get(server, f"/knowledge/dossier/{ref.reference_id}")
    assert status == 200
    assert "prepared, not executed" in body
    assert "not authentication" in body


def test_dossier_detail_shows_extraction_provenance(server, r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", IJERPH)
    _, body = _get(server, f"/knowledge/dossier/{ref.reference_id}")
    assert "EXTRACTED_UNVERIFIED" in body
    assert "Structured extraction" in body


def test_no_decision_route_over_http(server, r2cb_app):
    ref = r2cb_app.references.find_by_identifier("doi", IJERPH)
    for path in (
        f"/knowledge/dossier/{ref.reference_id}/decision",
        f"/knowledge/dossier/{ref.reference_id}/approve",
        "/knowledge/dossier/approve",
    ):
        status, _ = _get(server, path)
        assert status == 404, path


def test_unknown_dossier_returns_404(server):
    status, _ = _get(server, "/knowledge/dossier/REF-DOES-NOT-EXIST")
    assert status == 404
