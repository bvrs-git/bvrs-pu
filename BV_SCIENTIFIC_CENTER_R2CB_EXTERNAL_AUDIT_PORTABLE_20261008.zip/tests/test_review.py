"""Physician review actions and promotion drafts never create diagnoses."""

from __future__ import annotations

from bv_scientific_center.core.enums import SignalStatus
from bv_scientific_center.seed.synthetic import SYNTHETIC_PATIENT_ID


def test_signal_review_actions(seeded_app):
    signal = seeded_app.signals.list_for_patient(SYNTHETIC_PATIENT_ID)[0]
    signal_id = signal["signal_id"]

    seeded_app.review.review_signal(signal_id, "ACKNOWLEDGE", reviewer="dr.test")
    assert seeded_app.signals.get(signal_id)["status"] == SignalStatus.REVIEWED.value

    seeded_app.review.review_signal(
        signal_id, "ACCEPT_AS_RELEVANT", note="relevant", reviewer="dr.test"
    )
    updated = seeded_app.signals.get(signal_id)
    assert updated["status"] == SignalStatus.ACCEPTED.value
    # Acceptance does not create a diagnosis anywhere.
    assert "diagnosis" not in updated

    seeded_app.review.review_signal(signal_id, "DISMISS", reviewer="dr.test")
    assert seeded_app.signals.get(signal_id)["status"] == SignalStatus.DISMISSED.value
    assert seeded_app.signals.reviews_for(signal_id)


def test_annotation_does_not_mutate_source(seeded_app):
    before = [
        (r.observation_ref_id, r.value)
        for r in seeded_app.observations.list_for_patient(SYNTHETIC_PATIENT_ID)
    ]
    seeded_app.review.annotate(
        patient_id=SYNTHETIC_PATIENT_ID,
        target_type="OBSERVATION",
        target_id="obs:whatever",
        text="clinician note",
        author="dr.test",
    )
    after = [
        (r.observation_ref_id, r.value)
        for r in seeded_app.observations.list_for_patient(SYNTHETIC_PATIENT_ID)
    ]
    assert before == after
    assert seeded_app.annotations.list_for_patient(SYNTHETIC_PATIENT_ID)


def test_promotion_draft_is_not_a_diagnosis(seeded_app):
    signal_id = seeded_app.signals.list_for_patient(SYNTHETIC_PATIENT_ID)[0]["signal_id"]
    draft = seeded_app.review.build_prontuario_promotion_draft(signal_id, author="dr.test")
    assert draft["requires_clinician_review"] is True
    assert draft["creates_diagnosis_automatically"] is False
    assert draft["target_module"] == "PRONTUARIO"


def test_pin(seeded_app):
    pin_id = seeded_app.review.pin(
        patient_id=SYNTHETIC_PATIENT_ID, target_type="METRIC", target_id="metric:x"
    )
    assert pin_id
    assert seeded_app.pins.list_for_patient(SYNTHETIC_PATIENT_ID)
