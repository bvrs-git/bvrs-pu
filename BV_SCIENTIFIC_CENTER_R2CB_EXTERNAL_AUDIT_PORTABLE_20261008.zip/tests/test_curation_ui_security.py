"""R2A GATE 6 - curation interface is read-only over HTTP."""

from __future__ import annotations

import threading
import urllib.error
import urllib.request

import pytest

from bv_scientific_center.ui.server import make_server


@pytest.fixture
def server(scientific_app):
    srv = make_server(scientific_app, port=0)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    yield srv
    srv.shutdown()
    srv.server_close()


def _request(server, path: str, method: str = "GET"):
    host, port = server.server_address
    url = f"http://{host}:{port}{path}"
    data = b"" if method == "POST" else None
    try:
        with urllib.request.urlopen(url, data=data, timeout=10) as response:
            return response.status, response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8")


def test_reference_routes_are_readable(server):
    for path in (
        "/knowledge",
        "/knowledge/references",
        "/knowledge/curation",
        "/knowledge/reference/REF-PILOT-FMI-FFMI-CANCER",
    ):
        status, _ = _request(server, path)
        assert status == 200, path


def test_reference_search_filters_render(server):
    status, body = _request(server, "/knowledge/references?q=fat+mass+index&year=2009")
    assert status == 200
    assert "Scientific references" in body


def test_no_approval_endpoint_over_http(server):
    # Approval paths are not routed.
    for path in (
        "/knowledge/reference/REF-PILOT-FMI-FFMI-CANCER/approve",
        "/knowledge/curation/approve",
        "/curation/approve",
    ):
        status, _ = _request(server, path)
        assert status == 404, path


def test_post_is_not_supported(server):
    status, _ = _request(server, "/knowledge/references", method="POST")
    assert status in {501, 405}


def test_reference_page_has_no_approve_form(server):
    status, body = _request(server, "/knowledge/reference/REF-PILOT-FMI-FFMI-CANCER")
    assert status == 200
    lowered = body.lower()
    assert "method=\"post\"" not in lowered
    assert "action=\"/approve" not in lowered
    # The page explicitly states approval is not available here.
    assert "approval" in lowered and "read-only" in lowered


def test_user_is_not_treated_as_authenticated(server):
    # The curation dashboard must not expose an authorized-only action.
    status, body = _request(server, "/knowledge/curation")
    assert status == 200
    assert "read-only" in body.lower()
