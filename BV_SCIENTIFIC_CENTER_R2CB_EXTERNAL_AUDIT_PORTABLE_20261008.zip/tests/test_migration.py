"""R1.1 GATE 6 - additive, non-destructive schema migration."""

from __future__ import annotations

import sqlite3

from bv_scientific_center.storage.database import Database

_LEGACY_OBSERVATIONS = """
CREATE TABLE observations (
    observation_ref_id TEXT PRIMARY KEY,
    patient_id TEXT, concept TEXT, value REAL, unit TEXT, effective_at TEXT,
    source_module TEXT, source_entity_type TEXT, source_entity_id TEXT,
    source_version TEXT, authority TEXT, layer TEXT, provenance TEXT,
    fasting_status TEXT, context TEXT, labels TEXT, created_at TEXT
)
"""

_LEGACY_KNOWLEDGE = """
CREATE TABLE knowledge_items (
    knowledge_id TEXT PRIMARY KEY, title TEXT, topic TEXT, subtopic TEXT, summary TEXT,
    key_points TEXT, source_type TEXT, publication_year INTEGER, authors TEXT, journal TEXT,
    doi TEXT, url TEXT, citation TEXT, evidence_level TEXT, evidence_framework TEXT,
    evidence_grade TEXT, certainty TEXT, reviewer TEXT, target_type TEXT, tags TEXT,
    status TEXT, package_id TEXT, package_version TEXT, created_at TEXT, reviewed_at TEXT
)
"""


def test_legacy_derived_db_gains_ingested_at(tmp_path):
    conn = sqlite3.connect(tmp_path / "derived.db")
    conn.execute(_LEGACY_OBSERVATIONS)
    conn.execute(
        "INSERT INTO observations VALUES "
        "('o1','P1','GLUCOSE_FASTING',102.0,'mg/dL','2026-03-01T08:00:00.000000+0000',"
        "'LAB','LabObservation','e1','1','LAB_CONFIRMED','OBJECTIVE','{}','UNKNOWN','{}','{}',"
        "'2026-03-01T09:00:00.000000+0000')"
    )
    conn.commit()
    conn.close()

    db = Database(tmp_path).initialize()
    columns = {row["name"] for row in db.clinical.execute("PRAGMA table_info(observations)")}
    assert "ingested_at" in columns
    # Existing data preserved (migration is additive only).
    count = db.clinical.execute("SELECT COUNT(*) AS c FROM observations").fetchone()["c"]
    assert count == 1
    ref = db.clinical.execute(
        "SELECT observation_ref_id, ingested_at, created_at FROM observations"
    ).fetchone()
    assert ref["observation_ref_id"] == "o1"
    assert ref["ingested_at"] is None  # legacy row: column added empty
    db.close()


def test_legacy_knowledge_db_gains_origin(tmp_path):
    conn = sqlite3.connect(tmp_path / "knowledge.db")
    conn.execute(_LEGACY_KNOWLEDGE)
    conn.execute(
        "INSERT INTO knowledge_items (knowledge_id, title, status) VALUES ('k1','Legacy','DRAFT')"
    )
    conn.commit()
    conn.close()

    db = Database(tmp_path).initialize()
    columns = {row["name"] for row in db.knowledge.execute("PRAGMA table_info(knowledge_items)")}
    assert "origin" in columns
    count = db.knowledge.execute("SELECT COUNT(*) AS c FROM knowledge_items").fetchone()["c"]
    assert count == 1
    db.close()
