"""R2A GATE 6 - scientific search filters and FTS fallback."""

from __future__ import annotations


def test_search_by_title_term(scientific_app):
    hits = scientific_app.scientific_search_references("fat mass index")
    dois = {h["doi"] for h in hits}
    assert "10.1080/01635581.2025.2581336" in dois


def test_search_by_author(scientific_app):
    hits = scientific_app.scientific_search_references("", author="Tian")
    assert len(hits) == 1
    assert hits[0]["reference_id"] == "REF-PILOT-FMI-FFMI-CANCER"


def test_filter_by_year_and_type(scientific_app):
    hits_2013 = scientific_app.scientific_search_references("", year=2013)
    assert all(h["publication_year"] == 2013 for h in hits_2013)

    articles = scientific_app.scientific_search_references("", publication_type="JOURNAL_ARTICLE")
    assert all(h["publication_type"] == "JOURNAL_ARTICLE" for h in articles)
    assert len(articles) >= 3


def test_filter_by_curation_status(scientific_app):
    approved = scientific_app.scientific_search_references("", status="APPROVED")
    assert approved == []
    unverified = scientific_app.scientific_search_references("", status="IMPORTED_UNVERIFIED")
    assert len(unverified) >= 7


def test_search_returns_doi_and_pmid_fields(scientific_app):
    hits = scientific_app.scientific_search_references("waist-to-height")
    assert hits
    assert "doi" in hits[0] and "pmid" in hits[0]


def test_fts_fallback_is_safe(scientific_app):
    # Terms that FTS may not match still fall back to LIKE without error.
    hits = scientific_app.scientific_search_references("nonexistentterm-xyz")
    assert hits == []


def test_search_injection_is_safe(scientific_app):
    evil = '"; DROP TABLE scientific_references; --'
    hits = scientific_app.scientific_search_references(evil)
    assert isinstance(hits, list)
    names = {
        row["name"]
        for row in scientific_app.database.knowledge.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    assert "scientific_references" in names
