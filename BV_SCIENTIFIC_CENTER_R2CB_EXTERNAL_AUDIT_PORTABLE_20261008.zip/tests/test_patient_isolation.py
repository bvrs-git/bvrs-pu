"""R1.1 GATE 3 - patient isolation (fail-closed)."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.context import EvaluationContext
from bv_scientific_center.core.enums import SynthesisRunStatus
from bv_scientific_center.errors import ContractViolation
from bv_scientific_center.seed.synthetic import (
    SYNTHETIC_PATIENT_ID,
    synthetic_patient_context,
    synthetic_projections,
)


def test_mismatched_patient_is_refused(seeded_app):
    ctx = EvaluationContext.from_patient_context(synthetic_patient_context())
    with pytest.raises(ContractViolation):
        # Projections carry patient SYNTH-0001 but the run targets another patient.
        seeded_app.run_synthesis("OTHER-PATIENT", synthetic_projections(), context=ctx)


def test_refused_run_leaves_no_derived_data(seeded_app):
    ctx = EvaluationContext.from_patient_context(synthetic_patient_context())
    with pytest.raises(ContractViolation):
        seeded_app.run_synthesis("OTHER-PATIENT", synthetic_projections(), context=ctx)
    # No derived/observed data leaked to the other patient.
    overview = seeded_app.patient_overview("OTHER-PATIENT")
    assert overview["counts"]["observations"] == 0
    assert overview["counts"]["valid_metrics"] == 0
    # The failure is auditable.
    runs = seeded_app.runs.list_for_patient("OTHER-PATIENT")
    assert runs and runs[0]["status"] == SynthesisRunStatus.FAILED.value


def test_two_patients_do_not_cross_contaminate(seeded_app):
    from bv_scientific_center.contracts.inputs import LabObservationProjection

    other = LabObservationProjection(
        patient_id="OTHER-PATIENT",
        source_entity_id="other-1",
        concept="GLUCOSE_FASTING",
        value=90.0,
        unit="mg/dL",
        effective_at="2026-03-01T08:00:00+00:00",
    )
    seeded_app.run_synthesis("OTHER-PATIENT", [other])

    a = seeded_app.patient_overview(SYNTHETIC_PATIENT_ID)
    b = seeded_app.patient_overview("OTHER-PATIENT")
    assert all(r.patient_id == SYNTHETIC_PATIENT_ID for r in a["observations"])
    assert all(r.patient_id == "OTHER-PATIENT" for r in b["observations"])
    assert {r.concept for r in b["observations"]} == {"GLUCOSE_FASTING"}


def test_refs_by_concept_is_patient_scoped(seeded_app):
    from bv_scientific_center.contracts.inputs import LabObservationProjection

    seeded_app.run_synthesis(
        "OTHER-PATIENT",
        [
            LabObservationProjection(
                patient_id="OTHER-PATIENT",
                source_entity_id="o1",
                concept="HDL_CHOLESTEROL",
                value=55.0,
                unit="mg/dL",
                effective_at="2026-03-01T08:00:00+00:00",
            )
        ],
    )
    grouped = seeded_app.observations.refs_by_concept("OTHER-PATIENT")
    assert set(grouped) == {"HDL_CHOLESTEROL"}
