"""R2B GATE 0 - RR-7 regression: content_hash method is never shadowed."""

from __future__ import annotations

from bv_scientific_center.core.enums import KnowledgeOrigin
from bv_scientific_center.knowledge.scientific import (
    ClinicalClaim,
    ScientificEvidence,
    ScientificReference,
    StudyDesign,
)


def test_reference_content_hash_not_shadowed(scientific_app):
    reference = scientific_app.references.get("REF-PILOT-FMI-FFMI-CANCER")
    # The method is still callable after reading from the database.
    assert callable(reference.content_hash)
    # The stored hash is a dedicated field, not an attribute shadowing the method.
    assert isinstance(reference.content_hash_value, str) and len(reference.content_hash_value) == 64
    assert reference.content_hash() == reference.content_hash_value


def test_evidence_and_claim_hash_fields(scientific_app):
    evidence = ScientificEvidence(
        evidence_id="EV-RR7", title="t", study_design=StudyDesign.COHORT,
        origin=KnowledgeOrigin.SYNTHETIC_TEST,
    )
    scientific_app.register_evidence(evidence)
    stored = scientific_app.evidence_records.get("EV-RR7")
    assert callable(stored.content_hash)
    assert stored.content_hash() == stored.content_hash_value

    claim = ClinicalClaim(claim_id="CL-RR7", text="x", origin=KnowledgeOrigin.SYNTHETIC_TEST)
    scientific_app.register_claim(claim)
    stored_claim = scientific_app.claims.get("CL-RR7")
    assert callable(stored_claim.content_hash)
    assert stored_claim.content_hash() == stored_claim.content_hash_value


def test_hash_is_stable_across_roundtrip(scientific_app):
    reference = ScientificReference(
        reference_id="REF-RR7", title="Stable", doi="10.5555/rr7", publication_year=2020
    )
    first = reference.content_hash()
    scientific_app.ingest_reference(reference)
    stored = scientific_app.references.get("REF-RR7")
    assert stored.content_hash() == first
