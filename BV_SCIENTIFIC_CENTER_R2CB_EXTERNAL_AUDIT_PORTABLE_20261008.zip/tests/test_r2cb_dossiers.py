"""R2C-B GATE 7 - medical dossiers, index and local (non-executed) decisions."""

from __future__ import annotations

import json

import pytest

from bv_scientific_center.knowledge.scientific import CurationStatus

IJERPH = "10.3390/ijerph16111920"
MISSING = "10.1097/01823246-199001010-00008"


def _ref(app, doi):
    return app.references.find_by_identifier("doi", doi)


def test_dossier_index_lists_all_selected(r2cb_app):
    index = r2cb_app.dossier_index()
    assert len(index) == 8
    assert sum(1 for i in index if i["extraction_available"]) == 3
    assert all(i["reference_id"] for i in index)


def test_dossier_json_has_required_sections(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    data = json.loads(r2cb_app.export_dossier(ref.reference_id, "json"))
    for key in (
        "reference",
        "editorial",
        "content_accessed",
        "structured_extraction",
        "methodology",
        "linked_formula_candidates",
        "decision_form",
        "review_decisions",
    ):
        assert key in data
    assert data["decision_form"]["executed"] is False
    assert "ACCEPT_FOR_CONSIDERATION" in data["decision_form"]["allowed_decisions"]


def test_dossier_md_is_prepared_not_executed(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    md = r2cb_app.export_dossier(ref.reference_id, "md")
    assert "Medical decision (prepared, not executed)" in md
    assert "Structured extraction" in md
    assert "does NOT approve any formula for clinical use" in md


def test_dossier_without_abstract_is_explicit(r2cb_app):
    ref = _ref(r2cb_app, MISSING)
    data = json.loads(r2cb_app.export_dossier(ref.reference_id, "json"))
    assert data["abstract_available"] is False
    assert data["structured_extraction"] is None
    assert data["unverified_fields"]


def test_unknown_dossier_format_rejected(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    with pytest.raises(ValueError):
        r2cb_app.export_dossier(ref.reference_id, "pdf")


def test_review_decision_requires_actor_and_justification(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    with pytest.raises(ValueError):
        r2cb_app.record_review_decision(ref.reference_id, "ACCEPT_FOR_CONSIDERATION", actor="", justification="x")
    with pytest.raises(ValueError):
        r2cb_app.record_review_decision(ref.reference_id, "ACCEPT_FOR_CONSIDERATION", actor="dr.x", justification="")


def test_review_decision_is_recorded_not_executed(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    before = r2cb_app.references.get(ref.reference_id).curation_status
    assert before is CurationStatus.IMPORTED_UNVERIFIED
    decision_id = r2cb_app.record_review_decision(
        ref.reference_id, "ACCEPT_FOR_CONSIDERATION", actor="dr.reviewer", justification="Relevant to FMI reference values."
    )
    assert decision_id
    decisions = r2cb_app.review_decisions.for_reference(ref.reference_id)
    assert len(decisions) == 1
    assert decisions[0]["actor"] == "dr.reviewer"
    # Accepting for consideration is not an approval.
    after = r2cb_app.references.get(ref.reference_id).curation_status
    assert after is CurationStatus.IMPORTED_UNVERIFIED
    assert not r2cb_app.bibliography.is_clinically_usable(ref.reference_id)


def test_dossier_reflects_recorded_decision(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    r2cb_app.record_review_decision(
        ref.reference_id, "KEEP_PENDING", actor="dr.reviewer", justification="Awaiting full text."
    )
    data = json.loads(r2cb_app.export_dossier(ref.reference_id, "json"))
    assert len(data["review_decisions"]) == 1
    assert data["review_decisions"][0]["decision"] == "KEEP_PENDING"
