"""R1.1 GATE 3 - UI loopback binding, input handling and SQL/FTS safety."""

from __future__ import annotations

import inspect
import threading
import urllib.error
import urllib.request

import pytest

from bv_scientific_center.ui.server import make_server


@pytest.fixture
def server(seeded_app):
    srv = make_server(seeded_app, port=0)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    yield srv
    srv.shutdown()
    srv.server_close()


def _get(server, path: str) -> tuple[int, str]:
    host, port = server.server_address
    try:
        with urllib.request.urlopen(f"http://{host}:{port}{path}", timeout=10) as response:
            return response.status, response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8")


def test_default_host_is_loopback():
    default_host = inspect.signature(make_server).parameters["host"].default
    assert default_host == "127.0.0.1"


def test_unknown_route_returns_404(server):
    status, _ = _get(server, "/does-not-exist")
    assert status == 404


def test_unknown_signal_returns_404(server):
    status, _ = _get(server, "/signal/signal_missing")
    assert status == 404


def test_known_routes_return_200(server):
    for path in (
        "/",
        "/patient",
        "/patient/SYNTH-0001",
        "/patient/SYNTH-0001/map",
        "/patient/SYNTH-0001/metrics",
        "/patient/SYNTH-0001/timeline",
        "/knowledge",
        "/knowledge/packages",
    ):
        status, _ = _get(server, path)
        assert status == 200, path


@pytest.mark.parametrize(
    "payload",
    [
        "%22%3B%20DROP%20TABLE%20knowledge_items%3B%20--",
        "cortisol%27%20OR%20%271%27%3D%271",
        "%22%20OR%20%22%22%3D%22",
    ],
)
def test_search_injection_is_safe(server, seeded_app, payload):
    status, _ = _get(server, f"/knowledge/search?q={payload}")
    assert status == 200
    # Knowledge tables remain intact after adversarial queries.
    rows = seeded_app.database.knowledge.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()
    names = {row["name"] for row in rows}
    assert "knowledge_items" in names and "knowledge_fts" in names


def test_invalid_layer_returns_error_not_crash(server):
    status, _ = _get(server, "/patient/SYNTH-0001/map?layers=BOGUS")
    assert status == 500  # handled, not a connection drop
