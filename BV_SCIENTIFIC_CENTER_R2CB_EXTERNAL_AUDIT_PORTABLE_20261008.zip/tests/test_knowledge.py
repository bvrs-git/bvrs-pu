"""Knowledge repository: citations, search, packages, security and rollback."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import KnowledgeStatus, PackageReviewStatus
from bv_scientific_center.errors import (
    CitationRequiredError,
    ImmutablePublishError,
    PackageSecurityError,
    PackageValidationError,
)
from bv_scientific_center.knowledge.models import KnowledgeReference, ScientificKnowledgeItem
from bv_scientific_center.knowledge.packages import KnowledgePackage
from bv_scientific_center.seed.knowledge_seed import build_synthetic_package


def an_item(**overrides) -> ScientificKnowledgeItem:
    defaults = dict(
        knowledge_id="KNOW-TEST",
        title="Cortisol and DHEA relationship",
        topic="Adrenal",
        summary="Fixture discussion of cortisol and DHEA.",
        key_points=("collection time matters",),
        citation="Some Journal 2020;1(1):1-10.",
        publication_year=2020,
        journal="Some Journal",
        tags=("cortisol", "dhea"),
    )
    defaults.update(overrides)
    return ScientificKnowledgeItem(**defaults)


def test_item_without_citation_cannot_be_approved(app):
    item = an_item(citation="", doi=None, journal=None, url=None, publication_year=None)
    item.status = KnowledgeStatus.APPROVED
    with pytest.raises(CitationRequiredError):
        app.knowledge.save_item(item)


def test_item_with_citation_can_be_approved(app):
    item = an_item(status=KnowledgeStatus.APPROVED)
    app.knowledge.save_item(item)
    assert app.knowledge.get_item("KNOW-TEST").status is KnowledgeStatus.APPROVED


def test_full_text_search(app):
    app.knowledge.save_item(an_item())
    app.knowledge.save_item(an_item(knowledge_id="KNOW-2", title="Selenium status", tags=("selenio",)))
    hits = app.knowledge.search("cortisol DHEA")
    assert any(hit["knowledge_id"] == "KNOW-TEST" for hit in hits)


def test_repository_has_no_patient_data(app):
    item = an_item()
    assert not hasattr(item, "patient_id")


def test_package_rejects_scripts(app):
    package = build_synthetic_package()
    package.metadata = {"note": "<script>alert(1)</script>"}
    with pytest.raises(PackageSecurityError):
        app.import_package(package)


def test_package_rejects_paths(app):
    package = build_synthetic_package()
    package.source_manifest = ({"path": "../../etc/passwd"},)
    with pytest.raises(PackageSecurityError):
        app.import_package(package)


def test_package_requires_version(app):
    package = KnowledgePackage(package_id="PKG", name="pkg", version="")
    with pytest.raises(PackageValidationError):
        app.import_package(package)


def test_package_version_is_immutable(app):
    app.import_package(build_synthetic_package(version="1"))
    changed = build_synthetic_package(version="1")
    changed.name = "Different name"
    with pytest.raises(ImmutablePublishError):
        app.import_package(changed)


def test_package_activation_and_rollback(app):
    app.import_package(build_synthetic_package(version="1"))
    activated = app.activate_package("BV_SYNTHETIC_TEST_PACKAGE", "1")
    assert activated["is_active"] is True
    assert activated["review_status"] == PackageReviewStatus.ACTIVATED.value
    # Definitions registered from the package.
    assert "TESTOSTERONE_ESTRADIOL_RATIO" in [f.definition_id for f in app.formulas.all_latest()]
    # Rollback.
    app.packages.deactivate("BV_SYNTHETIC_TEST_PACKAGE", "1")
    assert app.packages.active_package() is None
    # Historical records (run snapshots) keep their provenance.
    run = app.latest_run("SYNTH-0001")
    assert run is None  # nothing run yet in a fresh app


def test_reference_citation_gate():
    reference = KnowledgeReference(reference_id="R1")
    assert reference.has_minimum_citation() is False
    good = KnowledgeReference(
        reference_id="R2", citation="J 2021", year=2021, url="https://example.org"
    )
    assert good.has_minimum_citation() is True
