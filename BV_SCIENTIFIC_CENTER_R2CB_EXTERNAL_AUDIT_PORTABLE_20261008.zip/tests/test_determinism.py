"""R1.1 GATE 5 - deterministic reconstruction of stored syntheses."""

from __future__ import annotations

from bv_scientific_center.seed.synthetic import SYNTHETIC_PATIENT_ID


def _node_ids(projection):
    return {n.node_id for n in projection.nodes}


def _edge_ids(projection):
    return {e.edge_id for e in projection.edges}


def test_rebuild_is_deterministic(seeded_app):
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    run_a = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    run_b = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    map_a = seeded_app.build_map(run_a)
    map_b = seeded_app.build_map(run_b)
    assert _node_ids(map_a) == _node_ids(map_b)
    assert _edge_ids(map_a) == _edge_ids(map_b)


def test_rebuild_preserves_values(seeded_app):
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    stored = {
        m.metric_definition_id: round(m.value, 6)
        for m in seeded_app.metrics.list_for_run(SYNTHETIC_PATIENT_ID, record["run_id"])
        if m.is_valid
    }
    rebuilt = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    assert stored
    for metric in rebuilt.valid_metrics:
        assert round(metric.value, 6) == stored[metric.metric_definition_id]


def test_rebuild_uses_persisted_metric_ids(seeded_app):
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    stored_ids = {
        m.metric_id
        for m in seeded_app.metrics.list_for_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    }
    rebuilt = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    assert {m.metric_id for m in rebuilt.metrics} == stored_ids


def test_rebuild_contract_is_stable(seeded_app):
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    projection = seeded_app.build_map(
        seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    )
    assert projection.contract_version == "ClinicalMapProjectionV1"
    assert projection.metadata.run_id == record["run_id"]
    assert all(n.provenance.is_traceable() for n in projection.nodes)


def test_rebuild_isolates_by_patient(seeded_app):
    import pytest

    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    with pytest.raises(KeyError):
        seeded_app.rebuild_run("OTHER-PATIENT", record["run_id"])
