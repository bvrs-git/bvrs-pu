"""R2A GATE 7 - real-reference pilot (verified metadata, never auto-approved)."""

from __future__ import annotations

from bv_scientific_center.core.enums import KnowledgeOrigin
from bv_scientific_center.knowledge.scientific import (
    CurationStatus,
    PublicationType,
    VerificationStatus,
)
from bv_scientific_center.seed.scientific_seed import pilot_references


def test_pilot_references_are_imported_and_verified(scientific_app):
    for reference in pilot_references():
        stored = scientific_app.references.get(reference.reference_id)
        assert stored is not None, reference.reference_id
        assert stored.verification_status is VerificationStatus.VERIFIED
        assert stored.metadata_source.value == "CROSSREF"
        assert stored.origin is KnowledgeOrigin.IMPORTED
        assert stored.doi


def test_pilot_metadata_matches_source(scientific_app):
    stored = scientific_app.references.get("REF-PILOT-FMI-FFMI-CANCER")
    assert stored.doi == "10.1080/01635581.2025.2581336"
    assert stored.publication_year == 2025
    assert stored.venue == "Nutrition and Cancer"
    assert stored.publication_type is PublicationType.JOURNAL_ARTICLE

    preprint = scientific_app.references.get("REF-PILOT-WHTR-MULTIMORBIDITY")
    assert preprint.publication_type is PublicationType.PREPRINT
    assert preprint.doi == "10.21203/rs.3.rs-137388/v1"


def test_no_reference_is_auto_approved(scientific_app):
    for reference in scientific_app.references.list():
        assert reference.curation_status is not CurationStatus.APPROVED
    assert scientific_app.curation.active_references() == []


def test_pilot_has_stable_identifier_but_stays_unapproved(scientific_app):
    stored = scientific_app.references.get("REF-PILOT-FMI-FFMI-CANCER")
    # Verified metadata + identifier means it *can* be approved by a human,
    # but it is not approved automatically.
    assert stored.stable_identifier() == ("doi", "10.1080/01635581.2025.2581336")
    assert stored.can_approve() is True
    assert stored.curation_status is CurationStatus.IMPORTED_UNVERIFIED


def test_synthetic_references_are_not_approvable(scientific_app):
    synthetic = scientific_app.references.get("REF-SYN-001")
    assert synthetic.origin is KnowledgeOrigin.SYNTHETIC_TEST
    assert synthetic.can_approve() is False
