"""R2A GATE 3 - methodological taxonomy and non-automatic assessment."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import KnowledgeOrigin
from bv_scientific_center.knowledge.methodology import (
    MethodologicalAssessment,
    suggest_assessment,
    taxonomy,
)
from bv_scientific_center.knowledge.scientific import (
    CertaintyFramework,
    CertaintyLevel,
    ScientificEvidence,
    StudyDesign,
)


def test_taxonomy_is_configurable_and_complete():
    tax = taxonomy()
    assert "SYSTEMATIC_REVIEW" in tax["study_designs"]
    assert "META_ANALYSIS" in tax["study_designs"]
    assert "RCT" in tax["study_designs"]
    assert "INSTRUMENT_VALIDATION" in tax["study_designs"]
    assert "PROGNOSIS" in tax["question_types"]
    assert "risk_of_bias" in tax["assessment_domains"]


def test_suggestion_never_assigns_certainty():
    evidence = ScientificEvidence(
        evidence_id="EV-1",
        title="Cohort study",
        study_design=StudyDesign.COHORT,
        origin=KnowledgeOrigin.SYNTHETIC_TEST,
    )
    suggestion = suggest_assessment(evidence, references_present=True)
    assert suggestion["auto_certainty"] is False
    assert suggestion["suggested_certainty"] is None
    assert suggestion["suggested_framework"] == "GRADE"
    assert "human" in suggestion["notice"].lower()


def test_assessment_certainty_requires_human_assessor():
    # Certainty with a human assessor is fine.
    MethodologicalAssessment(
        framework=CertaintyFramework.GRADE,
        certainty=CertaintyLevel.MODERATE,
        assessed_by="reviewer-1",
        human_applied=True,
    ).validate()
    # Certainty without an assessor is refused (GRADE is never automatic).
    with pytest.raises(ValueError):
        MethodologicalAssessment(
            framework=CertaintyFramework.GRADE,
            certainty=CertaintyLevel.HIGH,
            assessed_by=None,
            human_applied=False,
        ).validate()


def test_suggestion_flags_missing_reference():
    evidence = ScientificEvidence(
        evidence_id="EV-2",
        title="No reference yet",
        study_design=StudyDesign.RCT,
        origin=KnowledgeOrigin.SYNTHETIC_TEST,
    )
    suggestion = suggest_assessment(evidence, references_present=False)
    assert any("verification pending" in note.lower() for note in suggestion["notes"])
