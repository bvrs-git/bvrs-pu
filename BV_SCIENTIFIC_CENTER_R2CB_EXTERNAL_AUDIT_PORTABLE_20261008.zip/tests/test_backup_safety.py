"""R2A GATE 0 - safe, verified SQLite backup."""

from __future__ import annotations

import sqlite3

import pytest

from bv_scientific_center.errors import BackupVerificationError
from bv_scientific_center.storage.backup import (
    restore_to,
    safe_backup,
    sha256_file,
    verify_database,
)


def _make_db(path, *, wal: bool = False) -> None:
    conn = sqlite3.connect(str(path))
    if wal:
        conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)")
    conn.execute("INSERT INTO t (v) VALUES ('a'), ('b')")
    conn.commit()
    conn.close()


def test_backup_is_verified_and_hashed(tmp_path):
    source = tmp_path / "derived.db"
    _make_db(source)
    report = safe_backup(source, tmp_path / "backup", label="test")
    assert report["ok"] is True
    assert report["integrity_check"] == "ok"
    assert report["foreign_key_violations"] == 0
    assert len(report["sha256"]) == 64
    assert report["sha256"] == sha256_file(report["destination"])


def test_backup_of_wal_database_is_consistent(tmp_path):
    source = tmp_path / "derived.db"
    _make_db(source, wal=True)
    # Extra committed row lives in the WAL until checkpoint.
    conn = sqlite3.connect(str(source))
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("INSERT INTO t (v) VALUES ('wal-row')")
    conn.commit()
    conn.close()

    report = safe_backup(source, tmp_path / "backup")
    assert report["ok"] is True
    conn = sqlite3.connect(report["destination"])
    values = {row[0] for row in conn.execute("SELECT v FROM t").fetchall()}
    conn.close()
    # The consistent snapshot includes the committed WAL row.
    assert "wal-row" in values


def test_original_is_preserved(tmp_path):
    source = tmp_path / "derived.db"
    _make_db(source)
    before = sha256_file(source)
    safe_backup(source, tmp_path / "backup")
    assert sha256_file(source) == before


def test_restore_drill(tmp_path):
    source = tmp_path / "derived.db"
    _make_db(source)
    report = safe_backup(source, tmp_path / "backup")
    restored = restore_to(report["destination"], tmp_path / "restored.db")
    assert restored["ok"] is True
    conn = sqlite3.connect(tmp_path / "restored.db")
    assert conn.execute("SELECT COUNT(*) FROM t").fetchone()[0] == 2
    conn.close()


def test_invalid_source_fails_explicitly(tmp_path):
    bogus = tmp_path / "not_a_db.db"
    bogus.write_text("this is not a sqlite database")
    with pytest.raises(BackupVerificationError):
        safe_backup(bogus, tmp_path / "backup")
    # No unusable artifact left behind.
    assert list((tmp_path / "backup").glob("*.db")) == []


def test_missing_source_fails(tmp_path):
    with pytest.raises(BackupVerificationError):
        safe_backup(tmp_path / "nope.db", tmp_path / "backup")


def test_backup_never_overwrites_existing(tmp_path):
    source = tmp_path / "derived.db"
    _make_db(source)

    from bv_scientific_center.storage import backup as backup_module

    real_datetime = backup_module.datetime

    class _FrozenDatetime(real_datetime):
        @classmethod
        def now(cls, tz=None):
            return real_datetime(2020, 1, 1, tzinfo=tz)

    backup_module.datetime = _FrozenDatetime  # type: ignore[assignment]
    try:
        first = safe_backup(source, tmp_path / "backup", label="fixed")
        # Same label within the same frozen second would collide -> explicit failure.
        with pytest.raises(BackupVerificationError):
            safe_backup(source, tmp_path / "backup", label="fixed")
    finally:
        backup_module.datetime = real_datetime  # type: ignore[assignment]
    assert first["destination"]


def test_verify_database_reports_invalid(tmp_path):
    bogus = tmp_path / "x.db"
    bogus.write_text("garbage")
    report = verify_database(bogus)
    assert report["ok"] is False
