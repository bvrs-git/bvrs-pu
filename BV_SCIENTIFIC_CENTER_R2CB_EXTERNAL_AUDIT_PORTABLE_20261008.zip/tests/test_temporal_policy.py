"""R1.2 GATE 4 - clinical dates, ingestion dates and timezone policy."""

from __future__ import annotations

import pytest

from bv_scientific_center.contracts.inputs import LabObservationProjection
from bv_scientific_center.core.enums import SynthesisRunStatus
from bv_scientific_center.core.timeutil import parse_clinical_dt, parse_dt
from bv_scientific_center.errors import NaiveTimestampError
from bv_scientific_center.observations.refs import ProjectionIngestor


def _projection(when, pid="PT"):
    return LabObservationProjection(
        patient_id=pid,
        source_entity_id="pt-1",
        concept="GLUCOSE_FASTING",
        value=95.0,
        unit="mg/dL",
        effective_at=when,
    )


def test_naive_clinical_timestamp_is_rejected(app):
    with pytest.raises(NaiveTimestampError):
        ProjectionIngestor().ingest(_projection("2026-03-01T08:00:00"))


def test_naive_timestamp_run_is_failed_not_fabricated(app):
    with pytest.raises(NaiveTimestampError):
        app.run_synthesis("PT", [_projection("2026-03-01T08:00:00")])
    assert app.observations.list_for_patient("PT") == []
    runs = app.runs.list_for_patient("PT")
    assert runs and runs[0]["status"] == SynthesisRunStatus.FAILED.value


def test_equivalent_offsets_normalize_to_same_instant():
    a = parse_clinical_dt("2026-03-01T08:00:00+00:00")
    b = parse_clinical_dt("2026-03-01T05:00:00-03:00")
    assert a == b


def test_parse_clinical_dt_rejects_naive_datetime_object():
    import datetime as dt

    with pytest.raises(NaiveTimestampError):
        parse_clinical_dt(dt.datetime(2026, 3, 1, 8, 0, 0))


def test_ingested_at_is_not_derived_from_effective_at(app):
    ref = ProjectionIngestor().ingest(_projection("2026-03-01T08:00:00+00:00"))[0]
    app.observations.save(ref)
    stored = app.observations.get(ref.observation_ref_id)
    assert stored.effective_at.isoformat() != stored.ingested_at.isoformat()
    assert stored.ingested_at >= stored.effective_at


def test_legacy_null_ingested_at_preserved(tmp_path):
    import sqlite3

    from bv_scientific_center.storage.database import Database

    conn = sqlite3.connect(tmp_path / "derived.db")
    conn.execute(
        "CREATE TABLE observations (observation_ref_id TEXT PRIMARY KEY, patient_id TEXT, "
        "concept TEXT, value REAL, unit TEXT, effective_at TEXT, source_module TEXT, "
        "source_entity_type TEXT, source_entity_id TEXT, source_version TEXT, authority TEXT, "
        "layer TEXT, provenance TEXT, fasting_status TEXT, context TEXT, labels TEXT, created_at TEXT)"
    )
    conn.execute(
        "INSERT INTO observations VALUES ('o1','P1','C',1.0,'mg/dL',"
        "'2026-03-01T08:00:00.000000+0000','LAB','LabObservation','e1','1',"
        "'LAB_CONFIRMED','OBJECTIVE','{}','UNKNOWN','{}','{}','2026-05-01T00:00:00.000000+0000')"
    )
    conn.commit()
    conn.close()

    db = Database(tmp_path).initialize()
    from bv_scientific_center.storage.repositories import ObservationRepository

    ref = ObservationRepository(db).get("o1")
    # Unknown stays UNKNOWN: not retro-filled from created_at.
    assert ref.ingested_at is None
    assert ref.effective_at.isoformat() == "2026-03-01T08:00:00+00:00"
    db.close()


def test_longitudinal_ordering_is_stable(app):
    refs = ProjectionIngestor().ingest_many(
        [
            _projection("2026-03-01T08:00:00+00:00", pid="PL"),
            _projection("2026-01-01T08:00:00+00:00", pid="PL"),
            _projection("2026-02-01T08:00:00+00:00", pid="PL"),
        ]
    )
    # distinct source ids so rows are preserved separately
    refs = [
        r.__class__(**{**r.__dict__, "source_entity_id": f"pl-{i}", "observation_ref_id": r.observation_ref_id + f"-{i}"})
        for i, r in enumerate(refs)
    ]
    app.observations.save_many(refs)
    stored = app.observations.list_for_patient("PL")
    effective = [r.effective_at for r in stored]
    assert effective == sorted(effective)


def test_parse_dt_permissive_for_storage_roundtrip():
    # Storage round-trips are always written with offsets; the permissive parser
    # still exists for internal use and must not raise on naive input.
    assert parse_dt("2026-03-01T08:00:00") is not None
