"""R1.1 GATE 3 - fail-closed behavior on invalid input and persistence."""

from __future__ import annotations

import pytest

from bv_scientific_center.contracts.inputs import LabObservationProjection
from bv_scientific_center.core.enums import SynthesisRunStatus
from bv_scientific_center.errors import ContractViolation


def _bad_projection() -> LabObservationProjection:
    return LabObservationProjection(
        patient_id="PX",
        source_entity_id="x",
        concept="GLUCOSE_FASTING",
        value=1.0,
        unit="mg/dL",
        effective_at=None,
        collection_at=None,
    )


def test_invalid_projection_aborts_and_records_failure(app):
    with pytest.raises(ContractViolation):
        app.run_synthesis("PX", [_bad_projection()])
    runs = app.runs.list_for_patient("PX")
    assert runs and runs[0]["status"] == SynthesisRunStatus.FAILED.value
    assert runs[0]["meta"].get("error_type") == "ContractViolation"
    # Nothing partially persisted.
    assert app.observations.list_for_patient("PX") == []
    assert app.metrics.list_for_patient("PX") == []


def test_successful_run_is_marked_completed(app):
    projection = LabObservationProjection(
        patient_id="PY",
        source_entity_id="y",
        concept="GLUCOSE_FASTING",
        value=88.0,
        unit="mg/dL",
        effective_at="2026-03-01T08:00:00+00:00",
    )
    app.run_synthesis("PY", [projection])
    runs = app.runs.list_for_patient("PY")
    assert runs and runs[0]["status"] == SynthesisRunStatus.COMPLETED.value


def test_failure_does_not_persist_computation(app):
    # Invalid projection fails during ingestion; no run data must be written.
    with pytest.raises(ContractViolation):
        app.run_synthesis("PX", [_bad_projection()])
    assert app.score_results.list_for_patient("PX") == []
    assert app.signals.list_for_patient("PX") == []
