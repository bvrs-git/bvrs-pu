"""R2C-A GATE 3 - formula candidate registry (non-operational)."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import FormulaCandidateStatus, FormulaCandidateType
from bv_scientific_center.errors import EvidenceGovernanceError, ExpressionError
from bv_scientific_center.knowledge.formula_candidates import (
    CandidateVariable,
    FormulaCandidate,
    ScientificFormulaCandidateRegistryV1,
)


def a_candidate(**overrides) -> FormulaCandidate:
    defaults = dict(
        candidate_id="C-TEST",
        name="Test index",
        display_name="Test",
        version=1,
        candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX,
        expression="a / (b * b)",
        output_unit="kg/m^2",
        variables=(CandidateVariable("a", "kg"), CandidateVariable("b", "m")),
        reference_ids=("REF-PILOT-FMI-FFMI-CANCER",),
        review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW,
    )
    defaults.update(overrides)
    return FormulaCandidate(**defaults)


def test_registry_publishes_and_versions():
    registry = ScientificFormulaCandidateRegistryV1()
    registry.publish(a_candidate())
    registry.publish(a_candidate(version=2, expression="a / (b * b)"))
    assert registry.versions("C-TEST") == [1, 2]
    assert registry.get("C-TEST").version == 2
    assert registry.get("C-TEST", 1).version == 1


def test_identical_republish_is_idempotent_but_divergent_is_refused():
    registry = ScientificFormulaCandidateRegistryV1()
    registry.publish(a_candidate())
    registry.publish(a_candidate())  # idempotent
    with pytest.raises(EvidenceGovernanceError):
        registry.publish(a_candidate(expression="a * b"))


def test_candidates_are_never_operational():
    for candidate in ScientificFormulaCandidateRegistryV1().all_latest():
        assert candidate.operational is False
    registry = ScientificFormulaCandidateRegistryV1()
    candidate = a_candidate()
    registry.publish(candidate)
    assert candidate.operational is False


def test_expression_must_use_declared_variables():
    with pytest.raises(ExpressionError):
        a_candidate(expression="a / (undeclared * undeclared)").validate()


def test_unknown_unit_is_refused():
    with pytest.raises(EvidenceGovernanceError):
        a_candidate(output_unit="bananas").validate()


def test_candidate_without_reference_must_stay_draft():
    with pytest.raises(EvidenceGovernanceError):
        a_candidate(reference_ids=(), validation_evidence_ids=(),
                    review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW).validate()
    # As DRAFT it is allowed (and flagged by the review queue).
    a_candidate(reference_ids=(), review_status=FormulaCandidateStatus.DRAFT).validate()


def test_dto_roundtrip_and_hash(r2ca_app):
    candidate = r2ca_app.formula_candidates.get("SCI-CAND-FMI")
    restored = FormulaCandidate.from_dict(candidate.to_dict())
    assert restored.expression == candidate.expression
    assert restored.content_hash() == candidate.content_hash()
    assert candidate.operational is False


def test_seeded_candidates_present(r2ca_app):
    ids = {c.candidate_id for c in r2ca_app.formula_candidates.all_latest()}
    assert {"SCI-CAND-BMI", "SCI-CAND-FMI", "SCI-CAND-FFMI", "SCI-CAND-WHTR"} <= ids
    assert len(ids) >= 6


def test_interpretive_criterion_has_no_cutoff(r2ca_app):
    candidate = r2ca_app.formula_candidates.get("SCI-CAND-WHTR-CUTOFF-PLACEHOLDER")
    assert candidate.candidate_type is FormulaCandidateType.INTERPRETIVE_CRITERION
    assert candidate.metadata.get("cutoff_defined") is False
