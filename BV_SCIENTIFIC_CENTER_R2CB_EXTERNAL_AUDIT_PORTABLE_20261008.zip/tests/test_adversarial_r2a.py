"""R2A GATE 8 - adversarial tests."""

from __future__ import annotations

import threading

import pytest

from bv_scientific_center.core.enums import KnowledgeOrigin, PackageReviewStatus
from bv_scientific_center.errors import (
    CurationTransitionError,
    EvidenceGovernanceError,
    MetadataConflictError,
    PackageValidationError,
)
from bv_scientific_center.knowledge.packages import KnowledgePackage
from bv_scientific_center.knowledge.scientific import (
    ClinicalClaim,
    CurationStatus,
    CurationSubjectType,
    MetadataSource,
    PublicationType,
    ScientificEvidence,
    ScientificReference,
    StudyDesign,
    VerificationStatus,
)
from bv_scientific_center.seed.synthetic import (
    SYNTHETIC_PATIENT_ID,
    synthetic_patient_context,
    synthetic_projections,
)

REF = CurationSubjectType.REFERENCE
EV = CurationSubjectType.EVIDENCE
CLAIM = CurationSubjectType.CLAIM


def _reference(reference_id="REF-ADV", doi="10.9999/adv", **kw):
    defaults = dict(
        reference_id=reference_id,
        title="Adversarial reference",
        doi=doi,
        publication_year=2020,
        venue="Journal",
        metadata_source=MetadataSource.CROSSREF,
        verification_status=VerificationStatus.VERIFIED,
        origin=KnowledgeOrigin.IMPORTED,
    )
    defaults.update(kw)
    return ScientificReference(**defaults)


# --- duplicate identifiers -------------------------------------------------
def test_duplicate_doi_identical_is_idempotent(scientific_app):
    scientific_app.ingest_reference(_reference())
    scientific_app.ingest_reference(_reference(reference_id="REF-ADV-2"))
    with_doi = scientific_app.references.find_by_identifier("doi", "10.9999/adv")
    assert with_doi is not None
    assert len([r for r in scientific_app.references.list() if r.doi == "10.9999/adv"]) == 1


def test_conflicting_doi_metadata_is_refused(scientific_app):
    scientific_app.ingest_reference(_reference())
    conflicting = _reference(reference_id="REF-ADV-2", title="Different title")
    with pytest.raises(MetadataConflictError):
        scientific_app.ingest_reference(conflicting)


# --- claim governance ------------------------------------------------------
def test_claim_without_reference_cannot_be_approved(scientific_app):
    claim = ClinicalClaim(claim_id="CL-1", text="Unsupported statement")
    scientific_app.register_claim(claim)
    cur = scientific_app.curation
    cur.screen(CLAIM, "CL-1", actor="r")
    cur.curate(CLAIM, "CL-1", actor="r", justification="j")
    with pytest.raises(EvidenceGovernanceError):
        cur.approve(CLAIM, "CL-1", reviewer="r", justification="j")


# --- retraction / unauthorised transitions --------------------------------
def test_retracted_reference_cannot_be_approved_and_is_not_usable(scientific_app):
    scientific_app.ingest_reference(_reference())
    cur = scientific_app.curation
    cur.screen(REF, "REF-ADV", actor="r")
    cur.curate(REF, "REF-ADV", actor="r", justification="j")
    cur.approve(REF, "REF-ADV", reviewer="r", justification="j")
    cur.retract(REF, "REF-ADV", actor="r", reason="retracted")
    assert cur.is_clinically_usable(REF, "REF-ADV") is False
    # APPROVED is not reachable from RETRACTED.
    with pytest.raises(CurationTransitionError):
        cur.approve(REF, "REF-ADV", reviewer="r", justification="j")


def test_unauthorised_status_change_is_rejected(scientific_app):
    scientific_app.ingest_reference(_reference())
    with pytest.raises(CurationTransitionError):
        scientific_app.curation.transition(
            REF, "REF-ADV", CurationStatus.APPROVED, actor="r", justification="j"
        )


def test_failed_transition_does_not_change_status(scientific_app):
    scientific_app.ingest_reference(_reference())
    with pytest.raises(CurationTransitionError):
        scientific_app.curation.transition(
            REF, "REF-ADV", CurationStatus.APPROVED, actor="r", justification="j"
        )
    stored = scientific_app.references.get("REF-ADV")
    assert stored.curation_status is CurationStatus.IMPORTED_UNVERIFIED
    assert scientific_app.curation.history(REF, "REF-ADV") == []


# --- package tampering -----------------------------------------------------
def test_tampered_and_partial_packages_are_rejected(scientific_app):
    package = KnowledgePackage(
        package_id="PKG-ADV", name="pkg", version="1", origin=KnowledgeOrigin.IMPORTED
    )
    partial = KnowledgePackage(
        package_id="PKG-PARTIAL",
        name="pkg",
        version="1",
        formulas=({"definition_id": "X"},),  # missing version
    )
    with pytest.raises(PackageValidationError):
        scientific_app.import_package(partial)
    with pytest.raises(PackageValidationError):
        KnowledgePackage(
            package_id="PKG-SYN",
            name="pkg",
            version="1",
            review_status=PackageReviewStatus.APPROVED,
            origin=KnowledgeOrigin.SYNTHETIC_TEST,
        ).validate()
    scientific_app.import_package(package)


# --- concurrency -----------------------------------------------------------
def test_concurrent_reference_import_is_safe(scientific_app):
    reference = _reference(reference_id="REF-CONC", doi="10.9999/conc")
    errors: list[Exception] = []

    def worker():
        try:
            scientific_app.references.save(_reference(reference_id="REF-CONC", doi="10.9999/conc"))
        except Exception as exc:  # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors
    rows = [r for r in scientific_app.references.list() if r.reference_id == "REF-CONC"]
    assert len(rows) == 1


# --- isolation between knowledge and patient data --------------------------
def test_knowledge_tables_contain_no_patient_data(scientific_app):
    columns = {
        row["name"]
        for row in scientific_app.database.knowledge.execute(
            "PRAGMA table_info(scientific_references)"
        )
    }
    assert "patient_id" not in columns
    evidence_columns = {
        row["name"]
        for row in scientific_app.database.knowledge.execute(
            "PRAGMA table_info(scientific_evidence)"
        )
    }
    assert "patient_id" not in evidence_columns
    # A patient id must never appear as a reference identifier.
    assert scientific_app.references.find_by_identifier("url", SYNTHETIC_PATIENT_ID) is None


# --- historical reconstruction after scientific review --------------------
def test_historical_reconstruction_after_scientific_review(seeded_app):
    seeded_app.bootstrap_scientific()
    context = seeded_app.runner  # noqa: F841
    from bv_scientific_center.core.context import EvaluationContext

    ctx = EvaluationContext.from_patient_context(synthetic_patient_context())
    seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=ctx)
    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    before = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"]).logical_fingerprint()

    # Scientific curation changes must not alter clinical calculations.
    seeded_app.curation.retract(EV, "EV-SYN-001", actor="r", reason="withdrawn")
    after = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"]).logical_fingerprint()
    assert before == after
