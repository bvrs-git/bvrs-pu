"""Score engine: interpretation bands built on the formula safety machinery."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import CalculationStatus, DefinitionStatus, TemporalRequirement
from bv_scientific_center.scores.definition import (
    ClinicalScoreDefinition,
    ScoreBand,
    ScoreInput,
)
from bv_scientific_center.scores.engine import compute_score
from bv_scientific_center.scores.registry import ScoreRegistry


def a_score(**overrides) -> ClinicalScoreDefinition:
    defaults = dict(
        definition_id="TEST_SCORE",
        name="Test score",
        version=1,
        status=DefinitionStatus.VALIDATED_FOR_USE,
        inputs=(
            ScoreInput("triglycerides", "TRIGLYCERIDES", "mg/dL"),
            ScoreInput("hdl", "HDL_CHOLESTEROL", "mg/dL"),
        ),
        output_unit="1",
        expression="triglycerides / hdl",
        bands=(
            ScoreBand("low", None, 2.0, "low band"),
            ScoreBand("mid", 2.0, 4.0, "mid band"),
            ScoreBand("high", 4.0, None, "high band"),
        ),
        temporal_requirement=TemporalRequirement.SAME_DAY,
    )
    defaults.update(overrides)
    return ClinicalScoreDefinition(**defaults)


def test_score_band_assignment(make_ref):
    data = {
        "TRIGLYCERIDES": [make_ref("TRIGLYCERIDES", 190.0, "mg/dL")],
        "HDL_CHOLESTEROL": [make_ref("HDL_CHOLESTEROL", 38.0, "mg/dL")],
    }
    result = compute_score(a_score(), data, patient_id="P1")
    assert result.calculation_status is CalculationStatus.VALID
    assert result.value == pytest.approx(5.0)
    assert result.band == "high"
    assert result.band_interpretation == "high band"
    assert result.authority.value == "SYSTEM_DERIVED"


def test_score_missing_input_has_no_band(make_ref):
    data = {"TRIGLYCERIDES": [make_ref("TRIGLYCERIDES", 190.0, "mg/dL")]}
    result = compute_score(a_score(), data, patient_id="P1")
    assert result.calculation_status is CalculationStatus.INSUFFICIENT_INPUT
    assert result.value is None
    assert result.band is None


def test_score_registry_validates_output_unit():
    from bv_scientific_center.errors import UnknownUnitError

    registry = ScoreRegistry()
    with pytest.raises(UnknownUnitError):
        registry.publish(a_score(output_unit="wagons"))
