"""R2C-A GATE 4 - input semantics (measurement vs estimate vs derived)."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import InputSemantics
from bv_scientific_center.errors import EvidenceGovernanceError
from bv_scientific_center.knowledge.input_semantics import (
    InputValue,
    assert_no_semantics_upgrade,
    clinician_assessed,
    derived,
    device_estimate,
    measurement,
    semantics_allows,
)


def test_measurement_and_device_estimate_are_distinct():
    weight = measurement("weight", 70.0, "kg")
    fat_mass = device_estimate("fat_mass", 20.0, "kg", device="BIA-X", model="M1", algorithm="vendor-v3")
    assert weight.semantics is InputSemantics.MEASURED
    assert fat_mass.semantics is InputSemantics.DEVICE_ESTIMATED
    assert fat_mass.device == "BIA-X" and fat_mass.algorithm == "vendor-v3"


def test_derived_keeps_traceability_to_original():
    fat_mass = device_estimate("fat_mass", 20.0, "kg", device="BIA-X")
    height = measurement("height", 1.75, "m")
    fmi = derived("fmi", 20.0 / (1.75 * 1.75), "kg/m^2", parents=(fat_mass, height))
    assert fmi.semantics is InputSemantics.FORMULA_DERIVED
    assert set(fmi.derived_from) == {"fat_mass", "height"}


def test_derived_cannot_upgrade_an_estimate_to_a_measurement():
    fat_mass = device_estimate("fat_mass", 20.0, "kg")
    # Claiming MEASURED for a value derived from an estimate is forbidden.
    with pytest.raises(EvidenceGovernanceError):
        assert_no_semantics_upgrade((fat_mass,), InputSemantics.MEASURED)
    # The proper path keeps FORMULA_DERIVED.
    value = derived("x", 1.0, "kg", parents=(fat_mass,))
    assert value.semantics is InputSemantics.FORMULA_DERIVED


def test_semantics_allows_direction():
    assert semantics_allows(InputSemantics.MEASURED, InputSemantics.MEASURED)
    assert semantics_allows(InputSemantics.MEASURED, InputSemantics.DEVICE_ESTIMATED)
    assert not semantics_allows(InputSemantics.DEVICE_ESTIMATED, InputSemantics.MEASURED)


def test_missing_value_stays_none():
    value = measurement("weight", None, "kg")
    assert value.is_missing()
    assert value.value is None


def test_clinician_assessed_is_its_own_semantics():
    value = clinician_assessed("pubertal_stage", 3.0, "1")
    assert value.semantics is InputSemantics.CLINICIAN_ASSESSED
