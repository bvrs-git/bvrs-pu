"""Constrained expression sandbox."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.expression import compile_expression, evaluate
from bv_scientific_center.errors import ExpressionError


def test_basic_arithmetic_and_boolean():
    assert evaluate("a / b", {"a": 480.0, "b": 28.0}) == pytest.approx(17.142857, rel=1e-5)
    assert evaluate("a >= 100 and b >= 10", {"a": 102, "b": 12}) is True
    assert evaluate("glucose * insulin / 405", {"glucose": 102, "insulin": 12}) > 0


def test_whitelisted_functions():
    assert evaluate("clamp(x, 0, 10)", {"x": 15}) == 10
    assert evaluate("max(a, b)", {"a": 1, "b": 2}) == 2


@pytest.mark.parametrize(
    "source",
    [
        "__import__('os').system('echo hi')",
        "open('/etc/passwd')",
        "a.__class__",
        "(lambda: 1)()",
        "[x for x in range(3)]",
        "os.system('ls')",
        "exec('x=1')",
    ],
)
def test_forbidden_constructs_are_rejected(source):
    with pytest.raises(ExpressionError):
        compile_expression(source)


def test_unknown_function_rejected():
    with pytest.raises(ExpressionError):
        compile_expression("danger(a)")


def test_exponent_is_bounded():
    with pytest.raises(ExpressionError):
        compile_expression("a ** b")
    with pytest.raises(ExpressionError):
        compile_expression("a ** 100")


def test_undefined_variable_raises_at_evaluation():
    compiled = compile_expression("a + b")
    with pytest.raises(ExpressionError):
        compiled.evaluate({"a": 1})


def test_compiled_reports_names():
    compiled = compile_expression("a + b * c")
    assert compiled.names == {"a", "b", "c"}
