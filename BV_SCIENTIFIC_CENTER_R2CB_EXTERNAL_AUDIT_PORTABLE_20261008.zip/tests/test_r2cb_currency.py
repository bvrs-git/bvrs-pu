"""R2C-B GATE 8 - editorial currency and retraction handling."""

from __future__ import annotations

IJERPH = "10.3390/ijerph16111920"


def _ref(app, doi):
    return app.references.find_by_identifier("doi", doi)


def test_no_currency_check_before_first_run(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    assert r2cb_app.currency_for(ref.reference_id) is None


def test_offline_currency_is_unknown_not_fabricated(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    outcome = r2cb_app.check_currency(ref.reference_id)
    assert outcome["currency_known"] is False
    assert outcome["provider"] == "CROSSREF"
    stored = r2cb_app.currency_for(ref.reference_id)
    assert stored is not None
    assert stored["currency_known"] is False


def test_confirmed_retraction_blocks_current_use(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    r2cb_app.editorial_alerts.add(
        reference_id=ref.reference_id,
        alert_type="RETRACTION",
        source="CROSSREF",
        details="Retracted by the publisher.",
        is_retraction=True,
    )
    outcome = r2cb_app.check_currency(ref.reference_id)
    assert outcome["retracted"] is True
    assert outcome["outcome"] == "RETRACTED"
    assert outcome["clinically_usable"] is False
    # History is preserved: the retraction alert remains queryable.
    assert r2cb_app.editorial_alerts.has_retraction(ref.reference_id)


def test_currency_checks_are_historical(r2cb_app):
    ref = _ref(r2cb_app, IJERPH)
    r2cb_app.check_currency(ref.reference_id)
    r2cb_app.check_currency(ref.reference_id)
    checks = r2cb_app.editorial_checks.for_reference(ref.reference_id)
    assert len(checks) == 2
    assert all(c["checked_at"] for c in checks)
