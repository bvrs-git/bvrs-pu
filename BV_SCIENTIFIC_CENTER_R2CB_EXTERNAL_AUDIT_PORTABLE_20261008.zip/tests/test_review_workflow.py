"""R2B GATE 7 - human review workflow (queue + export), no HTTP approval."""

from __future__ import annotations

import csv
import io
import json

import pytest

from bv_scientific_center.errors import CurationApprovalError


def test_review_queue_lists_pending_items(scientific_app):
    queue = scientific_app.review_queue()
    assert queue
    ids = {q["reference_id"] for q in queue}
    assert "REF-PILOT-FMI-FFMI-CANCER" in ids
    item = next(q for q in queue if q["reference_id"] == "REF-PILOT-FMI-FFMI-CANCER")
    for key in ("bibliographic_status", "content_review_status", "curation_status", "editorial_alerts", "links", "appraisals", "clinically_usable"):
        assert key in item


def test_approved_and_clean_item_leaves_queue(scientific_app):
    reference_id = "REF-PILOT-FMI-FFMI-CANCER"
    cur = scientific_app.curation
    cur.screen("reference", reference_id, actor="r")
    cur.curate("reference", reference_id, actor="r", justification="j")
    cur.approve("reference", reference_id, reviewer="r", justification="j")
    ids = {q["reference_id"] for q in scientific_app.review_queue()}
    assert reference_id not in ids


def test_export_json_and_csv(scientific_app):
    payload = scientific_app.export_review_queue("json")
    data = json.loads(payload)
    assert isinstance(data, list) and data

    csv_text = scientific_app.export_review_queue("csv")
    rows = list(csv.DictReader(io.StringIO(csv_text)))
    assert rows and "reference_id" in rows[0]


def test_export_unknown_format_rejected(scientific_app):
    with pytest.raises(ValueError):
        scientific_app.export_review_queue("xml")


def test_approval_still_requires_human_actor(scientific_app):
    reference_id = "REF-PILOT-FMI-FFMI-CANCER"
    cur = scientific_app.curation
    cur.screen("reference", reference_id, actor="r")
    cur.curate("reference", reference_id, actor="r", justification="j")
    with pytest.raises(CurationApprovalError):
        cur.approve("reference", reference_id, reviewer="", justification="j")


def test_reviewer_string_is_not_authentication(scientific_app):
    # Documented contract: the read-only UI has no approval route (see UI tests);
    # here we assert the queue never marks anything approved automatically.
    queue = scientific_app.review_queue()
    assert all(q["clinically_usable"] is False for q in queue)
