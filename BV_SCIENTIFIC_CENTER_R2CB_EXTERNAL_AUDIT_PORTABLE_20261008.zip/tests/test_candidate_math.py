"""R2C-A GATE 5 - mathematical and dimensional validation (prototype only)."""

from __future__ import annotations

import math

import pytest

from bv_scientific_center.core.enums import (
    FormulaCandidateStatus,
    FormulaCandidateType,
    InputSemantics,
    TemporalRequirement,
)
from bv_scientific_center.knowledge.candidate_math import evaluate_candidate_prototype
from bv_scientific_center.knowledge.formula_candidates import CandidateVariable, FormulaCandidate
from bv_scientific_center.knowledge.input_semantics import device_estimate, measurement


def _c(app, candidate_id):
    return app.formula_candidates.get(candidate_id)


def test_bmi_reference_fixture(r2ca_app):
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BMI"),
        {"weight_kg": measurement("weight_kg", 70.0, "kg"),
         "height_m": measurement("height_m", 1.75, "m")},
        population="ADULT",
    )
    assert result.is_valid
    # Independently computed: 70 / (1.75 ** 2)
    assert result.value == pytest.approx(22.857142857142858, rel=1e-12)


def test_unit_conversion_is_explicit(r2ca_app):
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BMI"),
        {"weight_kg": measurement("weight_kg", 154.32358, "lb"),
         "height_m": measurement("height_m", 175.0, "cm")},
        population="ADULT",
    )
    assert result.is_valid
    assert result.value == pytest.approx(22.857, rel=1e-3)
    # Original units are preserved in the resolution trail.
    assert any(r["original_unit"] == "lb" for r in result.resolved)


def test_fmi_and_ffmi_reference_fixtures(r2ca_app):
    fmi = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-FMI"),
        {"fat_mass_kg": device_estimate("fat_mass_kg", 20.0, "kg", device="BIA"),
         "height_m": measurement("height_m", 1.75, "m")},
        population="ADULT",
    )
    assert fmi.value == pytest.approx(20.0 / (1.75 ** 2), rel=1e-12)

    ffmi = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-FFMI"),
        {"fat_free_mass_kg": device_estimate("fat_free_mass_kg", 55.0, "kg", device="BIA"),
         "height_m": measurement("height_m", 1.75, "m")},
        population="ADULT",
    )
    assert ffmi.value == pytest.approx(55.0 / (1.75 ** 2), rel=1e-12)


def test_whtr_and_body_fat_reference_fixtures(r2ca_app):
    whtr = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-WHTR"),
        {"waist_cm": measurement("waist_cm", 90.0, "cm"),
         "height_cm": measurement("height_cm", 175.0, "cm")},
        population="ADULT",
    )
    assert whtr.value == pytest.approx(90.0 / 175.0, rel=1e-12)

    bf = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BODY-FAT-PCT"),
        {"fat_mass_kg": device_estimate("fat_mass_kg", 20.0, "kg", device="BIA"),
         "weight_kg": measurement("weight_kg", 70.0, "kg")},
        population="ADULT",
    )
    assert bf.value == pytest.approx(100.0 * 20.0 / 70.0, rel=1e-12)


def test_longitudinal_change_fixture(r2ca_app):
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BC-LONGITUDINAL"),
        {"baseline_value": measurement("baseline_value", 60.0, "kg"),
         "followup_value": measurement("followup_value", 55.0, "kg")},
        population="ADULT",
    )
    assert result.value == pytest.approx(-5.0)


def test_input_missing_is_refused_not_zeroed(r2ca_app):
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BMI"),
        {"weight_kg": measurement("weight_kg", 70.0, "kg")},
        population="ADULT",
    )
    assert result.status == "INSUFFICIENT_INPUT"
    assert result.value is None


def test_semantics_mismatch_refused(r2ca_app):
    # A device-estimated weight cannot feed a candidate requiring a measurement.
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BMI"),
        {"weight_kg": device_estimate("weight_kg", 70.0, "kg", device="scale"),
         "height_m": measurement("height_m", 1.75, "m")},
        population="ADULT",
    )
    assert result.status == "SEMANTICS_MISMATCH"


def test_unit_incompatible_refused(r2ca_app):
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BMI"),
        {"weight_kg": measurement("weight_kg", 70.0, "kg"),
         "height_m": measurement("height_m", 175.0, "kg")},  # kg is not a length
        population="ADULT",
    )
    assert result.status == "UNIT_INCOMPATIBLE"


def test_not_finite_refused(r2ca_app):
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BMI"),
        {"weight_kg": measurement("weight_kg", math.inf, "kg"),
         "height_m": measurement("height_m", 1.75, "m")},
        population="ADULT",
    )
    assert result.status == "NOT_FINITE"


def test_refusal_condition_defined_domain(r2ca_app):
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BMI"),
        {"weight_kg": measurement("weight_kg", 70.0, "kg"),
         "height_m": measurement("height_m", 0.0, "m")},
        population="ADULT",
    )
    assert result.status == "OUTSIDE_DEFINED_DOMAIN"


def test_division_by_zero_refused():
    candidate = FormulaCandidate(
        candidate_id="C-DIV", name="div", display_name="div", version=1,
        candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX, expression="a / b",
        output_unit="1",
        variables=(CandidateVariable("a", "kg"), CandidateVariable("b", "kg")),
        reference_ids=("X",), review_status=FormulaCandidateStatus.DRAFT,
    )
    result = evaluate_candidate_prototype(
        candidate,
        {"a": measurement("a", 1.0, "kg"), "b": measurement("b", 0.0, "kg")},
    )
    assert result.status == "DIVISION_BY_ZERO"


def test_temporal_incompatibility_refused():
    candidate = FormulaCandidate(
        candidate_id="C-DAY", name="d", display_name="d", version=1,
        candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX, expression="a + b",
        output_unit="kg",
        variables=(CandidateVariable("a", "kg"), CandidateVariable("b", "kg")),
        temporal_requirement=TemporalRequirement.SAME_DAY,
        reference_ids=("X",), review_status=FormulaCandidateStatus.DRAFT,
    )
    result = evaluate_candidate_prototype(
        candidate,
        {
            "a": measurement("a", 1.0, "kg", effective_at="2026-01-01T08:00:00+00:00"),
            "b": measurement("b", 2.0, "kg", effective_at="2025-01-01T08:00:00+00:00"),
        },
    )
    assert result.status == "TEMPORALLY_INCOMPATIBLE"


def test_applicability_not_established_blocks_prototype(r2ca_app):
    result = evaluate_candidate_prototype(
        _c(r2ca_app, "SCI-CAND-BMI"),
        {"weight_kg": measurement("weight_kg", 20.0, "kg"),
         "height_m": measurement("height_m", 1.10, "m")},
        population="PEDIATRIC",
    )
    assert result.status == "APPLICABILITY_NOT_ESTABLISHED"
    assert result.value is None
