"""R2A GATE 4 - linking evidence to formulas, scores and rules."""

from __future__ import annotations

import pytest

from bv_scientific_center.errors import EvidenceGovernanceError
from bv_scientific_center.knowledge.scientific import (
    CurationSubjectType,
    EvidenceRelation,
    LinkTargetType,
)


def test_link_and_query_evidence_for_formula(scientific_app):
    scientific_app.linking.link(
        subject_type=CurationSubjectType.EVIDENCE,
        subject_id="EV-SYN-001",
        target_type=LinkTargetType.FORMULA,
        target_id="WAIST_HEIGHT_RATIO",
        target_version=1,
        relation=EvidenceRelation.VALIDATION,
        actor="reviewer-1",
    )
    prov = scientific_app.linking.formula_provenance("WAIST_HEIGHT_RATIO", 1)
    assert prov["formula_id"] == "WAIST_HEIGHT_RATIO"
    # FOUNDATIONAL link seeded; VALIDATION link just added.
    assert any(l["relation"] == "VALIDATION" for l in prov["validation"])
    assert any(l["relation"] == "FOUNDATIONAL" for l in prov["foundational"])


def test_relations_are_distinguished(scientific_app):
    scientific_app.linking.link(
        subject_type=CurationSubjectType.EVIDENCE,
        subject_id="EV-SYN-002",
        target_type=LinkTargetType.SCORE,
        target_id="METABOLIC_LOAD_TEST_SCORE",
        target_version=1,
        relation=EvidenceRelation.DISCUSSION,
        actor="r",
    )
    links = scientific_app.linking.links_for_target(
        LinkTargetType.SCORE, "METABOLIC_LOAD_TEST_SCORE"
    )
    assert links and links[0]["relation"] == "DISCUSSION"


def test_linking_unknown_subject_is_refused(scientific_app):
    with pytest.raises(EvidenceGovernanceError):
        scientific_app.linking.link(
            subject_type=CurationSubjectType.EVIDENCE,
            subject_id="EV-DOES-NOT-EXIST",
            target_type=LinkTargetType.FORMULA,
            target_id="X",
            relation=EvidenceRelation.FOUNDATIONAL,
            actor="r",
        )


def test_linking_does_not_change_clinical_calculation(seeded_app):
    seeded_app.bootstrap_scientific()
    # A formula's expression must be unaffected by evidence linking.
    before = seeded_app.formulas.get("WAIST_HEIGHT_RATIO", 1).expression
    seeded_app.linking.link(
        subject_type=CurationSubjectType.EVIDENCE,
        subject_id="EV-SYN-001",
        target_type=LinkTargetType.FORMULA,
        target_id="WAIST_HEIGHT_RATIO",
        target_version=1,
        relation=EvidenceRelation.DISCUSSION,
        actor="r",
    )
    after = seeded_app.formulas.get("WAIST_HEIGHT_RATIO", 1).expression
    assert before == after
