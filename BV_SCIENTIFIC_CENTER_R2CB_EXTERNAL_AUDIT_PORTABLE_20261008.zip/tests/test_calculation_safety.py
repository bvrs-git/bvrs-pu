"""R1.1 GATE 2B/2C - calculation safety and deterministic candidate selection."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import (
    CalculationStatus,
    DefinitionStatus,
    ObservationAuthority,
    TemporalRequirement,
)
from bv_scientific_center.formulas.definition import (
    ClinicalFormulaDefinition,
    FormulaInputRequirement,
)
from bv_scientific_center.formulas.engine import compute_metric


def formula(**overrides) -> ClinicalFormulaDefinition:
    defaults = dict(
        definition_id="SAFE",
        name="safe",
        version=1,
        status=DefinitionStatus.VALIDATED_FOR_USE,
        inputs=(
            FormulaInputRequirement("a", "A", "mg/dL"),
            FormulaInputRequirement("b", "B", "mg/dL"),
        ),
        output_unit="1",
        expression="a / b",
        temporal_requirement=TemporalRequirement.SAME_DAY,
    )
    defaults.update(overrides)
    return ClinicalFormulaDefinition(**defaults)


def test_division_by_zero_is_error_not_a_value(make_ref):
    data = {
        "A": [make_ref("A", 10.0, "mg/dL")],
        "B": [make_ref("B", 0.0, "mg/dL")],
    }
    metric = compute_metric(formula(), data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.ERROR
    assert metric.value is None


def test_latest_available_is_deterministic(make_ref):
    single = formula(
        inputs=(FormulaInputRequirement("b", "B", "mg/dL"),),
        expression="b",
        temporal_requirement=TemporalRequirement.LATEST_AVAILABLE,
    )
    data = {
        "B": [
            make_ref("B", 10.0, "mg/dL", when="2026-01-01T08:00:00+00:00"),
            make_ref("B", 20.0, "mg/dL", when="2026-03-01T08:00:00+00:00"),
            make_ref("B", 15.0, "mg/dL", when="2026-02-01T08:00:00+00:00"),
        ]
    }
    first = compute_metric(single, data, patient_id="P1")
    second = compute_metric(single, data, patient_id="P1")
    assert first.value == pytest.approx(20.0)
    assert second.value == pytest.approx(first.value)


def test_confirmed_source_wins_over_unconfirmed(make_ref):
    single = formula(
        inputs=(FormulaInputRequirement("b", "B", "mg/dL"),),
        expression="b",
        temporal_requirement=TemporalRequirement.LATEST_AVAILABLE,
    )
    data = {
        "B": [
            make_ref(
                "B",
                99.0,
                "mg/dL",
                authority=ObservationAuthority.DOCUMENT_EXTRACTED_UNREVIEWED,
            ),
            make_ref("B", 42.0, "mg/dL", authority=ObservationAuthority.LAB_CONFIRMED),
        ]
    }
    metric = compute_metric(single, data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.VALID
    assert metric.value == pytest.approx(42.0)


def test_precedence_missing_beats_unit(make_ref):
    data = {"A": [make_ref("A", 10.0, "mg/dL")]}  # B absent entirely
    metric = compute_metric(formula(), data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.INSUFFICIENT_INPUT


def test_future_dated_observation_excluded_by_as_of(seeded_app):
    from bv_scientific_center.core.timeutil import parse_dt
    from bv_scientific_center.seed.synthetic import SYNTHETIC_PATIENT_ID

    record = seeded_app.latest_run(SYNTHETIC_PATIENT_ID)
    run = seeded_app.rebuild_run(SYNTHETIC_PATIENT_ID, record["run_id"])
    as_of = parse_dt("2025-06-01T00:00:00+00:00")
    projection = seeded_app.build_map(run, as_of=as_of)
    assert projection.nodes == []
