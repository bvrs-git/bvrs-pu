"""R2A GATE 1 - canonical scientific model."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import KnowledgeOrigin
from bv_scientific_center.errors import EvidenceGovernanceError
from bv_scientific_center.knowledge.scientific import (
    ClinicalClaim,
    CurationStatus,
    MetadataSource,
    PublicationType,
    ScientificEvidence,
    ScientificReference,
    StudyDesign,
    VerificationStatus,
)


def a_reference(**overrides) -> ScientificReference:
    defaults = dict(
        reference_id="REF-X",
        title="A verified study",
        authors=("Doe, Jane",),
        publication_year=2021,
        venue="Journal of Examples",
        publication_type=PublicationType.JOURNAL_ARTICLE,
        doi="10.1000/example",
        metadata_source=MetadataSource.CROSSREF,
        verification_status=VerificationStatus.VERIFIED,
        origin=KnowledgeOrigin.IMPORTED,
    )
    defaults.update(overrides)
    return ScientificReference(**defaults)


def test_stable_identifier_priority():
    assert a_reference().stable_identifier() == ("doi", "10.1000/example")
    # Falls back to URL when no DOI/PMID/ISBN.
    assert a_reference(doi=None, url="https://x").stable_identifier() == ("url", "https://x")
    # Nothing to identify -> None (never invented).
    assert a_reference(doi=None, url=None).stable_identifier() is None


def test_content_hash_is_deterministic():
    assert a_reference().content_hash() == a_reference().content_hash()
    assert a_reference().content_hash() != a_reference(title="Different").content_hash()


def test_missing_metadata_is_not_invented():
    pending = a_reference(doi=None, url=None, verification_status=VerificationStatus.VERIFY_PENDING)
    assert pending.stable_identifier() is None
    assert pending.doi is None and pending.pmid is None and pending.isbn is None


def test_reference_validation_and_approval_guards():
    # Synthetic can never approve.
    synthetic = a_reference(origin=KnowledgeOrigin.SYNTHETIC_TEST, curation_status=CurationStatus.APPROVED)
    with pytest.raises(EvidenceGovernanceError):
        synthetic.validate()
    # Unverified + no identifier cannot approve.
    unverifiable = a_reference(
        doi=None, url=None, verification_status=VerificationStatus.VERIFY_PENDING,
        curation_status=CurationStatus.APPROVED,
    )
    with pytest.raises(EvidenceGovernanceError):
        unverifiable.validate()
    # Verified + identifier is approvable.
    a_reference(curation_status=CurationStatus.APPROVED).validate()


def test_evidence_requires_reference_to_approve():
    evidence = ScientificEvidence(
        evidence_id="EV-X",
        title="Study without reference",
        study_design=StudyDesign.COHORT,
        curation_status=CurationStatus.APPROVED,
    )
    with pytest.raises(EvidenceGovernanceError):
        evidence.validate()


def test_claim_requires_evidence_to_approve():
    claim = ClinicalClaim(claim_id="C-X", text="Statement", curation_status=CurationStatus.APPROVED)
    with pytest.raises(EvidenceGovernanceError):
        claim.validate()


def test_models_roundtrip_through_app(scientific_app):
    reference = a_reference(reference_id="REF-NEW")
    scientific_app.ingest_reference(reference)
    stored = scientific_app.references.get("REF-NEW")
    assert stored.doi == reference.doi
    assert stored.verification_status is VerificationStatus.VERIFIED
    assert stored.curation_status is CurationStatus.IMPORTED_UNVERIFIED
