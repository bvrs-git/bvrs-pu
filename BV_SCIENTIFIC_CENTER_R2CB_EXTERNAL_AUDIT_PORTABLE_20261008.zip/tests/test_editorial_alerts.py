"""R2B GATE 6 - editorial alerts: retraction, correction, offline currency."""

from __future__ import annotations

from _biblio_helpers import json_transport, load_fixture
from bv_scientific_center.bibliography.crossref import CrossrefAdapter


def _acquire_retracted(app):
    app.bibliography.crossref = CrossrefAdapter(
        json_transport(load_fixture("crossref_retraction.json"))
    )
    app.bibliography.pubmed = None
    return app.acquire_by_doi("10.1234/retracted.2020")


def test_retraction_detected_from_crossref(biblio_app):
    result = _acquire_retracted(biblio_app)
    reference_id = result["reference_id"]
    alerts = biblio_app.editorial_alerts.for_reference(reference_id)
    assert alerts and alerts[0]["alert_type"] == "RETRACTION"
    assert biblio_app.editorial_alerts.has_retraction(reference_id)


def test_retracted_reference_is_not_clinically_usable_even_if_approved(biblio_app):
    result = _acquire_retracted(biblio_app)
    reference_id = result["reference_id"]
    # Approve it as a human (curation state), then retraction still blocks use.
    cur = biblio_app.curation
    cur.screen("reference", reference_id, actor="r")
    cur.curate("reference", reference_id, actor="r", justification="j")
    cur.approve("reference", reference_id, reviewer="r", justification="j")
    assert biblio_app.curation.is_clinically_usable("reference", reference_id) is True
    assert biblio_app.bibliography.is_clinically_usable(reference_id) is False


def test_erratum_is_not_treated_as_full_retraction(biblio_app):
    from _biblio_helpers import load_fixture as lf
    from _biblio_helpers import routed_transport
    from bv_scientific_center.bibliography.pubmed import PubMedAdapter
    from bv_scientific_center.bibliography.service import reference_id_for

    biblio_app.bibliography.pubmed = PubMedAdapter(
        routed_transport({"esummary": lf("pubmed_erratum.json")})
    )
    biblio_app.bibliography.crossref = None
    record = biblio_app.bibliography.pubmed.fetch_by_pmid("87654321")
    biblio_app.bibliography.import_record(record)

    reference_id = reference_id_for(record)
    alerts = biblio_app.editorial_alerts.for_reference(reference_id)
    assert alerts
    assert all(a["alert_type"] != "RETRACTION" for a in alerts)
    assert not biblio_app.editorial_alerts.has_retraction(reference_id)


def test_offline_check_preserves_state_and_flags_currency(biblio_app):
    # biblio_app has adapters disabled: check_editorial cannot verify currency.
    reference_id = "REF-PILOT-FMI-FFMI-CANCER"
    before = biblio_app.references.get(reference_id)
    alerts = biblio_app.check_editorial(reference_id)
    after = biblio_app.references.get(reference_id)
    # Last known state preserved (metadata not overwritten).
    assert after.doi == before.doi
    assert any("could not be verified" in (a["details"] or "") for a in alerts)
