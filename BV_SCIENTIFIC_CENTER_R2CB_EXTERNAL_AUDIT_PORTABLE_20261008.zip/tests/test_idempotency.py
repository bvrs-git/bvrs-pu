"""R1.1 GATE 3 - ingestion idempotency and duplicate identifiers."""

from __future__ import annotations

from bv_scientific_center.core.context import EvaluationContext
from bv_scientific_center.seed.synthetic import (
    SYNTHETIC_PATIENT_ID,
    SYNTHETIC_DATE,
    synthetic_patient_context,
    synthetic_projections,
)
from bv_scientific_center.seed.synthetic import synthetic_lab_projections


def _ctx() -> EvaluationContext:
    return EvaluationContext.from_patient_context(synthetic_patient_context())


def test_reingest_is_idempotent(seeded_app):
    before = len(seeded_app.observations.list_for_patient(SYNTHETIC_PATIENT_ID))
    seeded_app.run_synthesis(SYNTHETIC_PATIENT_ID, synthetic_projections(), context=_ctx())
    after = len(seeded_app.observations.list_for_patient(SYNTHETIC_PATIENT_ID))
    assert after == before, "re-ingesting identical projections must not duplicate rows"


def test_stable_ids_are_deterministic(make_ref):
    a = make_ref("GLUCOSE_FASTING", 102.0, "mg/dL", entity_id="lab-1")
    b = make_ref("GLUCOSE_FASTING", 102.0, "mg/dL", entity_id="lab-1")
    # Same source natural key -> identical stable id.
    from bv_scientific_center.observations.refs import _stable_ref_id

    key = dict(
        patient_id="P1",
        source_module="LAB",
        source_entity_type="LabObservation",
        source_entity_id="lab-1",
        source_version="1",
        concept="GLUCOSE_FASTING",
        effective_at=a.effective_at,
    )
    assert _stable_ref_id(**key) == _stable_ref_id(**key)
    assert a.observation_ref_id != b.observation_ref_id  # make_ref uses random ids


def test_ingestion_direct_call_is_idempotent(seeded_app):
    from bv_scientific_center.observations.refs import ProjectionIngestor

    refs = ProjectionIngestor().ingest_many(synthetic_lab_projections())
    for _ in range(3):
        seeded_app.observations.save_many(refs)
    stored = [r for r in seeded_app.observations.list_for_patient(SYNTHETIC_PATIENT_ID)]
    ids = [r.observation_ref_id for r in stored]
    assert len(ids) == len(set(ids))


def test_published_definition_republish_is_idempotent(seeded_app):
    from bv_scientific_center.seed.synthetic import synthetic_formulas

    formula = synthetic_formulas()[0]
    seeded_app.formulas.publish(formula)
    seeded_app.formulas.publish(formula)
    assert seeded_app.formulas.versions(formula.definition_id) == [1]
