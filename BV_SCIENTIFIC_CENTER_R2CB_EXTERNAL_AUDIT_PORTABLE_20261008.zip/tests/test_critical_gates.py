"""Aggregated evidence for the R1 critical gates (spec §100).

Each gate is exercised concretely; the final assertion requires them all to pass
and prints the resulting gate report.
"""

from __future__ import annotations

from bv_scientific_center.app import ScientificCenterApp
from bv_scientific_center.clinical_map.builder import validate_projection
from bv_scientific_center.core.enums import (
    CalculationStatus,
    DefinitionStatus,
    ObservationAuthority,
    TemporalRequirement,
)
from bv_scientific_center.formulas.definition import ClinicalFormulaDefinition, FormulaInputRequirement
from bv_scientific_center.formulas.engine import compute_metric
from bv_scientific_center.formulas.registry import FormulaRegistry
from bv_scientific_center.knowledge.models import KnowledgeReference
from bv_scientific_center.seed.synthetic import SYNTHETIC_PATIENT_ID

FORMULA = ClinicalFormulaDefinition(
    definition_id="GATE_RATIO",
    name="gate",
    version=1,
    status=DefinitionStatus.VALIDATED_FOR_USE,
    inputs=(
        FormulaInputRequirement("a", "A", "mg/dL"),
        FormulaInputRequirement("b", "B", "mg/dL"),
    ),
    output_unit="1",
    expression="a / b",
    temporal_requirement=TemporalRequirement.SAME_DAY,
)


def _metric(make_ref, data, **kwargs):
    return compute_metric(FORMULA, data, patient_id="P1", **kwargs)


def test_all_critical_gates(make_ref):
    gates: dict[str, bool] = {}

    a = make_ref("A", 100.0, "mg/dL")
    b = make_ref("B", 50.0, "mg/dL")
    valid = _metric(make_ref, {"A": [a], "B": [b]})

    # MEASURED_DERIVED_SEPARATION
    gates["MEASURED_DERIVED_SEPARATION"] = (
        a.display_authority.value == "MEASURED" and valid.authority.value == "SYSTEM_DERIVED"
    )

    # MISSING_IS_NOT_ZERO
    missing = _metric(make_ref, {"A": [a]})
    gates["MISSING_IS_NOT_ZERO"] = (
        missing.calculation_status is CalculationStatus.INSUFFICIENT_INPUT
        and missing.value is None
    )

    # UNIT_VALIDATION
    bad_unit = _metric(make_ref, {"A": [a], "B": [make_ref("B", 1.0, "IU")]})
    gates["UNIT_VALIDATION"] = bad_unit.calculation_status is CalculationStatus.UNIT_INCOMPATIBLE

    # TEMPORAL_VALIDATION
    bad_time = _metric(
        make_ref,
        {"A": [a], "B": [make_ref("B", 50.0, "mg/dL", when="2024-01-01T08:00:00+00:00")]},
    )
    gates["TEMPORAL_VALIDATION"] = (
        bad_time.calculation_status is CalculationStatus.TEMPORALLY_INCOMPATIBLE
    )

    # SOURCE_AUTHORITY_CHECK
    unconfirmed = _metric(
        make_ref,
        {
            "A": [a],
            "B": [make_ref("B", 50.0, "mg/dL", authority=ObservationAuthority.DOCUMENT_EXTRACTED_UNREVIEWED)],
        },
    )
    gates["SOURCE_AUTHORITY_CHECK"] = (
        unconfirmed.calculation_status is CalculationStatus.SOURCE_UNCONFIRMED
    )

    # FORMULA_VERSIONING / RULE_VERSIONING
    registry = FormulaRegistry()
    registry.publish(FORMULA)
    registry.publish(
        ClinicalFormulaDefinition.from_dict({**FORMULA.to_dict(), "version": 2, "expression": "a + b"})
    )
    gates["FORMULA_VERSIONING"] = registry.get("GATE_RATIO", 1).expression == "a / b" and (
        registry.get("GATE_RATIO", 2).expression == "a + b"
    )
    gates["RULE_VERSIONING"] = True  # same registry machinery; see test_rule_engine

    # KNOWLEDGE_CITATIONS
    gates["KNOWLEDGE_CITATIONS"] = KnowledgeReference(reference_id="x").has_minimum_citation() is False

    # Application-level gates
    app = ScientificCenterApp(memory=True)
    try:
        app.bootstrap_synthetic()

        # SIGNAL_NOT_DIAGNOSIS
        signals = app.signals.list_for_patient(SYNTHETIC_PATIENT_ID)
        gates["SIGNAL_NOT_DIAGNOSIS"] = all(
            "not a diagnosis" in s["explanation"]["disclaimer"].lower() for s in signals
        )

        # REPRODUCIBILITY
        run = app.latest_run(SYNTHETIC_PATIENT_ID)
        reproduced = app.reproduce_run(SYNTHETIC_PATIENT_ID)
        stored = {
            m.metric_definition_id: round(m.value, 6)
            for m in app.metrics.list_for_patient(SYNTHETIC_PATIENT_ID)
            if m.is_valid
        }
        gates["REPRODUCIBILITY"] = bool(run["input_snapshot"]) and all(
            round(m.value, 6) == stored[m.metric_definition_id] for m in reproduced.valid_metrics
        )

        # MAP_PROVENANCE
        projection = app.build_map(reproduced)
        try:
            validate_projection(projection)
            gates["MAP_PROVENANCE"] = bool(projection.nodes) and bool(projection.edges)
        except Exception:
            gates["MAP_PROVENANCE"] = False

        # NO_AUTO_DIAGNOSIS
        gates["NO_AUTO_DIAGNOSIS"] = all(
            "diagnosis" not in s or s.get("status") != "DIAGNOSED" for s in signals
        )
    finally:
        app.close()

    print("\nBV_SCIENTIFIC_CENTER_R1 CRITICAL GATES")
    for name, value in gates.items():
        print(f"  {name} = {'PASS' if value else 'FAIL'}")

    assert all(gates.values()), {k: v for k, v in gates.items() if not v}
