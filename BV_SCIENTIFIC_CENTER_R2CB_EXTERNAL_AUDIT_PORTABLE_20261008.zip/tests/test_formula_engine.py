"""Formula engine: the refusal gates and versioning."""

from __future__ import annotations

import pytest

from bv_scientific_center.core.enums import (
    CalculationStatus,
    DefinitionStatus,
    ObservationAuthority,
    TemporalRequirement,
)
from bv_scientific_center.errors import DuplicateDefinitionError
from bv_scientific_center.formulas.definition import (
    ClinicalFormulaDefinition,
    FormulaInputRequirement,
)
from bv_scientific_center.formulas.engine import compute_metric
from bv_scientific_center.formulas.registry import FormulaRegistry


def a_formula(**overrides) -> ClinicalFormulaDefinition:
    defaults = dict(
        definition_id="TEST_RATIO",
        name="Test ratio",
        version=1,
        description="fixture",
        status=DefinitionStatus.VALIDATED_FOR_USE,
        inputs=(
            FormulaInputRequirement("a", "CONCEPT_A", "mg/dL"),
            FormulaInputRequirement("b", "CONCEPT_B", "mg/dL"),
        ),
        output_unit="1",
        expression="a / b",
        temporal_requirement=TemporalRequirement.SAME_DAY,
    )
    defaults.update(overrides)
    return ClinicalFormulaDefinition(**defaults)


def refs(make_ref, **kwargs):
    return {
        "CONCEPT_A": [make_ref("CONCEPT_A", 100.0, "mg/dL", **kwargs)],
        "CONCEPT_B": [make_ref("CONCEPT_B", 50.0, "mg/dL", **kwargs)],
    }


def test_valid_computation(make_ref):
    metric = compute_metric(a_formula(), refs(make_ref), patient_id="P1")
    assert metric.calculation_status is CalculationStatus.VALID
    assert metric.value == pytest.approx(2.0)
    assert metric.authority.value == "SYSTEM_DERIVED"
    assert metric.input_refs and len(metric.input_refs) == 2


def test_missing_input_is_not_zero(make_ref):
    data = refs(make_ref)
    del data["CONCEPT_B"]
    metric = compute_metric(a_formula(), data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.INSUFFICIENT_INPUT
    assert metric.value is None  # never 0
    assert "b" in metric.missing_inputs


def test_missing_value_is_not_zero(make_ref):
    data = refs(make_ref)
    data["CONCEPT_B"] = [make_ref("CONCEPT_B", None, "mg/dL")]
    metric = compute_metric(a_formula(), data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.INSUFFICIENT_INPUT
    assert metric.value is None


def test_unit_incompatible_refuses(make_ref):
    data = refs(make_ref)
    data["CONCEPT_B"] = [make_ref("CONCEPT_B", 50.0, "IU")]
    metric = compute_metric(a_formula(), data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.UNIT_INCOMPATIBLE
    assert metric.value is None


def test_temporally_incompatible_refuses(make_ref):
    data = refs(make_ref)
    data["CONCEPT_B"] = [
        make_ref("CONCEPT_B", 50.0, "mg/dL", when="2025-09-01T08:00:00+00:00")
    ]
    metric = compute_metric(a_formula(), data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.TEMPORALLY_INCOMPATIBLE
    assert metric.value is None


def test_unconfirmed_source_refuses(make_ref):
    data = refs(make_ref)
    data["CONCEPT_B"] = [
        make_ref(
            "CONCEPT_B",
            50.0,
            "mg/dL",
            authority=ObservationAuthority.DOCUMENT_EXTRACTED_UNREVIEWED,
        )
    ]
    metric = compute_metric(a_formula(), data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.SOURCE_UNCONFIRMED
    assert metric.value is None


def test_unit_conversion_is_applied_and_recorded(make_ref):
    data = refs(make_ref)
    data["CONCEPT_B"] = [make_ref("CONCEPT_B", 500.0, "mg/L")]  # 500 mg/L == 50 mg/dL
    metric = compute_metric(a_formula(), data, patient_id="P1")
    assert metric.calculation_status is CalculationStatus.VALID
    assert metric.value == pytest.approx(2.0)
    assert metric.input_resolutions[1].conversion_applied is True
    assert metric.input_resolutions[1].conversion_ref == "mg/L->mg/dL"


def test_outside_defined_domain(make_ref):
    formula = a_formula(validity_constraints=("b > 100",))
    metric = compute_metric(formula, refs(make_ref), patient_id="P1")
    assert metric.calculation_status is CalculationStatus.OUTSIDE_DEFINED_DOMAIN


def test_pediatric_is_excluded_by_default(make_ref):
    from bv_scientific_center.core.context import EvaluationContext
    from bv_scientific_center.core.enums import PopulationContext

    context = EvaluationContext(population=PopulationContext.PEDIATRIC)
    metric = compute_metric(a_formula(), refs(make_ref), patient_id="P1", context=context)
    assert metric.calculation_status is CalculationStatus.OUTSIDE_DEFINED_DOMAIN


def test_formula_snapshot_is_recorded(make_ref):
    metric = compute_metric(a_formula(), refs(make_ref), patient_id="P1")
    assert metric.formula_snapshot["definition_id"] == "TEST_RATIO"
    assert metric.formula_snapshot["version"] == 1


def test_registry_immutability(make_ref):
    registry = FormulaRegistry()
    registry.publish(a_formula())
    # Identical re-publish is idempotent.
    registry.publish(a_formula())
    # Same version, different content -> error.
    with pytest.raises(DuplicateDefinitionError):
        registry.publish(a_formula(expression="a * b"))


def test_formula_versioning_preserves_history(make_ref):
    registry = FormulaRegistry()
    registry.publish(a_formula(version=1, expression="a + b"))
    v1 = registry.get("TEST_RATIO", 1)
    v1_metric = compute_metric(v1, refs(make_ref), patient_id="P1")
    assert v1_metric.value == pytest.approx(150.0)

    registry.publish(a_formula(version=2, expression="a / b"))
    v2_metric = compute_metric(registry.get("TEST_RATIO", 2), refs(make_ref), patient_id="P1")
    assert v2_metric.value == pytest.approx(2.0)
    assert v2_metric.metric_definition_version == 2

    # Historical v1 result remains reproducible and pinned to v1.
    assert registry.get("TEST_RATIO", 1).version == 1
    again = compute_metric(registry.get("TEST_RATIO", 1), refs(make_ref), patient_id="P1")
    assert again.value == pytest.approx(150.0)
    assert again.metric_definition_version == 1
