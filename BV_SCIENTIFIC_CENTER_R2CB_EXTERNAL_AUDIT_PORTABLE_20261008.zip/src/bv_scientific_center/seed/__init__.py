"""Deterministic synthetic fixtures (no real patient data)."""
