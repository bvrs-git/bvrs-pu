"""Synthetic knowledge fixtures and a synthetic knowledge package.

IMPORTANT: the citations below are clearly-labelled SYNTHETIC FIXTURES, not real
references. They exist to validate the repository/search/package machinery and
are deliberately NOT APPROVED. Production content is imported through reviewed
knowledge packages carrying real citation metadata (spec §22, §23, §65, §97).
"""

from __future__ import annotations

from datetime import datetime

from ..knowledge.models import KnowledgeReference, ScientificKnowledgeItem
from ..knowledge.packages import KnowledgePackage
from ..knowledge.repository import KnowledgeRepository
from ..core.enums import (
    KnowledgeOrigin,
    KnowledgeSourceType,
    KnowledgeStatus,
    PackageReviewStatus,
    TargetType,
)
from ..core.timeutil import now_utc
from .synthetic import synthetic_formulas, synthetic_rules, synthetic_scores


def _item(
    knowledge_id: str,
    title: str,
    topic: str,
    summary: str,
    key_points: list[str],
    tags: list[str],
) -> ScientificKnowledgeItem:
    return ScientificKnowledgeItem(
        knowledge_id=knowledge_id,
        title=title,
        topic=topic,
        summary=summary,
        key_points=tuple(key_points),
        source_type=KnowledgeSourceType.CONSENSUS,
        publication_year=2026,
        authors=("BV Synthetic Fixture",),
        journal="SYNTHETIC FIXTURE - not a real journal",
        citation=(
            "[SYNTHETIC FIXTURE] This is a placeholder citation used to validate the "
            "knowledge repository. It is not a real reference and must not be used "
            "clinically."
        ),
        target_type=TargetType.OPTIMAL_RANGE,
        tags=tuple(tags + ["SYNTHETIC_FIXTURE"]),
        status=KnowledgeStatus.IN_REVIEW,
        origin=KnowledgeOrigin.SYNTHETIC_TEST,
    )


def synthetic_knowledge_items() -> list[ScientificKnowledgeItem]:
    return [
        _item(
            "KNOW-ADRENAL-CORTISOL-DHEA",
            "Cortisol and DHEA: interpretive context",
            "Adrenal",
            "Fixture overview of how adrenal markers may be contextualised together.",
            [
                "Cortisol has a strong diurnal rhythm; collection time matters.",
                "A cortisol/DHEA relationship is contextual, not diagnostic.",
                "Assay method and collection time should be recorded.",
            ],
            ["cortisol", "dhea", "adrenal"],
        ),
        _item(
            "KNOW-MICRO-SELENIUM",
            "Selenium and thyroid physiology",
            "Micronutrient",
            "Fixture summary linking selenium status with thyroid-related markers.",
            [
                "Selenium is a trace element relevant to thyroid hormone metabolism.",
                "Interpretation depends on assay and population reference.",
            ],
            ["selenio", "selenium", "thyroid", "micronutrient"],
        ),
        _item(
            "KNOW-METABOLIC-INSULIN-RESISTANCE",
            "Insulin resistance: assessment context",
            "Metabolic",
            "Fixture summary of context around glycemic and lipid markers.",
            [
                "Fasting status must be recorded for surrogate indices.",
                "Single indices are contextual, not diagnostic.",
            ],
            ["resistencia insulinica", "insulin", "glycemic", "metabolic"],
        ),
        _item(
            "KNOW-BODYCOMP-MUSCLE-MASS",
            "Skeletal muscle mass assessment",
            "Body composition",
            "Fixture summary of body-composition derived metrics such as FFMI.",
            [
                "FFMI normalises fat-free mass by height squared.",
                "Device and method must be recorded for comparability.",
            ],
            ["massa muscular", "muscle", "body composition", "ffmi"],
        ),
        _item(
            "KNOW-MICRO-VITAMIN-D",
            "Vitamin D measurement and interpretation",
            "Micronutrient",
            "Fixture summary on Vitamin D 25-OH units and target ambiguity.",
            [
                "25-OH vitamin D is reported in ng/mL or nmol/L.",
                "Reference ranges and targets differ and must cite their source.",
            ],
            ["vitamina d", "vitamin d", "micronutrient"],
        ),
        _item(
            "KNOW-GONADAL-TE-RATIO",
            "Testosterone/estradiol ratio interpretation context",
            "Gonadal",
            "Fixture summary on cross-unit ratio computation and temporal alignment.",
            [
                "A ratio depends on the units declared for each input.",
                "Inputs should be temporally aligned; distant samples are not comparable.",
            ],
            ["testosterone", "estradiol", "ratio", "gonadal"],
        ),
    ]


def build_synthetic_package(version: str = "1") -> KnowledgePackage:
    items = synthetic_knowledge_items()
    return KnowledgePackage(
        package_id="BV_SYNTHETIC_TEST_PACKAGE",
        name="BV Synthetic Test Package",
        version=version,
        domain="MULTI",
        items=tuple(items),
        formulas=tuple(f.to_dict() for f in synthetic_formulas()),
        scores=tuple(s.to_dict() for s in synthetic_scores()),
        rules=tuple(r.to_dict() for r in synthetic_rules()),
        references=(
            KnowledgeReference(
                reference_id="REF-SYNTHETIC-FIXTURE",
                citation="[SYNTHETIC FIXTURE] Placeholder reference.",
                title="Synthetic Fixture Reference",
                source="SYNTHETIC FIXTURE",
                year=2026,
                url="https://example.invalid/synthetic-fixture",
            ),
        ),
        source_manifest=(
            {
                "manifest_id": "MANIFEST-SYNTHETIC",
                "origin": "GPT_WORK_PLACEHOLDER",
                "note": "Synthetic manifest - no external documents consumed.",
            },
        ),
        review_status=PackageReviewStatus.IN_REVIEW,
    )


def seed_knowledge(repository: KnowledgeRepository) -> list[ScientificKnowledgeItem]:
    items = synthetic_knowledge_items()
    for item in items:
        repository.save_item(item, require_citation=False)
    repository.save_reference(
        KnowledgeReference(
            reference_id="REF-SYNTHETIC-FIXTURE",
            citation="[SYNTHETIC FIXTURE] Placeholder reference.",
            title="Synthetic Fixture Reference",
            source="SYNTHETIC FIXTURE",
            year=2026,
            url="https://example.invalid/synthetic-fixture",
        )
    )
    return items


def seed_datetime() -> datetime:
    return now_utc()
