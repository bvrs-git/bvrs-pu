"""Synthetic fixtures: one synthetic patient, a few formulas, a score and rules.

These exist ONLY to validate the architecture. They are explicitly marked as
synthetic/test content and must never be shipped as production clinical
knowledge (spec §89, §90). No real patient data is used.
"""

from __future__ import annotations

from ..contracts.inputs import (
    BioimpedanceMeasurement,
    BioimpedanceSummaryProjection,
    IntegrativeIntakeSummary,
    IntegrativeResponse,
    LabObservationProjection,
    NutritionAssessmentProjection,
    PatientContextProjection,
)
from ..core import concepts as c
from ..core.enums import (
    ClinicalDomain,
    DefinitionStatus,
    FastingStatus,
    ObservationAuthority,
    PopulationContext,
    ScoreBandDirection,
    Severity,
    SexContext,
    SignalType,
    TemporalRequirement,
)
from ..formulas.definition import ClinicalFormulaDefinition, FormulaInputRequirement
from ..formulas.registry import FormulaRegistry
from ..rules.definition import (
    DERIVED_METRIC,
    OBSERVATION,
    RuleInput,
    RuleSeverityEscalation,
    ScientificClinicalRule,
)
from ..rules.registry import RuleRegistry
from ..scores.definition import ClinicalScoreDefinition, ScoreBand, ScoreInput
from ..scores.registry import ScoreRegistry

SYNTHETIC_PATIENT_ID = "SYNTH-0001"
SYNTHETIC_DATE = "2026-03-01T08:00:00+00:00"
SYNTHETIC_DATE_2 = "2026-03-01T08:05:00+00:00"


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------
def _lab(concept: str, value: float, unit: str, *, entity: str, authority=ObservationAuthority.LAB_CONFIRMED,
         laboratory: str = "SYNTHETIC_LAB", fasting: FastingStatus = FastingStatus.UNKNOWN) -> LabObservationProjection:
    return LabObservationProjection(
        patient_id=SYNTHETIC_PATIENT_ID,
        source_entity_id=entity,
        concept=concept,
        value=value,
        unit=unit,
        effective_at=SYNTHETIC_DATE,
        authority=authority,
        method="SYNTHETIC_METHOD",
        matrix="SERUM",
        laboratory=laboratory,
        collection_at=SYNTHETIC_DATE,
        fasting_status=fasting,
    )


def synthetic_lab_projections() -> list[LabObservationProjection]:
    return [
        _lab(c.GLUCOSE_FASTING, 102.0, "mg/dL", entity="lab-1", fasting=FastingStatus.FASTING),
        _lab(c.INSULIN_FASTING, 12.0, "uU/mL", entity="lab-2", fasting=FastingStatus.FASTING),
        _lab(c.HDL_CHOLESTEROL, 38.0, "mg/dL", entity="lab-3"),
        _lab(c.TRIGLYCERIDES, 190.0, "mg/dL", entity="lab-4"),
        _lab(c.TESTOSTERONE_TOTAL, 480.0, "ng/dL", entity="lab-5"),
        _lab(c.ESTRADIOL, 28.0, "pg/mL", entity="lab-6"),
        _lab(c.DHEAS, 180.0, "ug/dL", entity="lab-7"),
        _lab(c.CORTISOL, 14.0, "ug/dL", entity="lab-8"),
        _lab(c.VITAMIN_D_25OH, 22.0, "ng/mL", entity="lab-9"),
        _lab(c.NEUTROPHILS_ABSOLUTE, 4.2, "10^3/uL", entity="lab-10"),
        _lab(c.LYMPHOCYTES_ABSOLUTE, 1.8, "10^3/uL", entity="lab-11"),
    ]


def synthetic_bioimpedance() -> BioimpedanceSummaryProjection:
    return BioimpedanceSummaryProjection(
        patient_id=SYNTHETIC_PATIENT_ID,
        source_entity_id="bia-1",
        effective_at=SYNTHETIC_DATE_2,
        device="SYNTHETIC_BIA",
        measurements=[
            BioimpedanceMeasurement(c.WEIGHT, 92.0, "kg"),
            BioimpedanceMeasurement(c.HEIGHT, 178.0, "cm"),
            BioimpedanceMeasurement(c.FAT_MASS, 28.0, "kg"),
            BioimpedanceMeasurement(c.FAT_FREE_MASS, 64.0, "kg"),
            BioimpedanceMeasurement(c.BODY_FAT_PERCENT, 30.4, "%"),
            BioimpedanceMeasurement(c.WAIST_CIRCUMFERENCE, 102.0, "cm"),
        ],
    )


def synthetic_integrative() -> IntegrativeIntakeSummary:
    return IntegrativeIntakeSummary(
        patient_id=SYNTHETIC_PATIENT_ID,
        source_entity_id="int-1",
        effective_at=SYNTHETIC_DATE,
        responses=[
            IntegrativeResponse(c.SLEEP_QUALITY, "sleep", 6.0, "1"),
            IntegrativeResponse(c.ENERGY_LEVEL, "energy", 5.0, "1"),
            IntegrativeResponse(c.GI_SYMPTOMS, "gi", 4.0, "1"),
            IntegrativeResponse(c.STRESS_LEVEL, "stress", 7.0, "1"),
        ],
    )


def synthetic_nutrition() -> NutritionAssessmentProjection:
    return NutritionAssessmentProjection(
        patient_id=SYNTHETIC_PATIENT_ID,
        source_entity_id="nut-1",
        effective_at=SYNTHETIC_DATE,
        energy_target_kcal=2200.0,
        protein_target_g=150.0,
        notes="Synthetic nutrition assessment",
    )


def synthetic_patient_context() -> PatientContextProjection:
    return PatientContextProjection(
        patient_id=SYNTHETIC_PATIENT_ID,
        sex=SexContext.MALE,
        age_years=42.0,
        population=PopulationContext.ADULT,
    )


def synthetic_projections() -> list:
    return [
        *synthetic_lab_projections(),
        synthetic_bioimpedance(),
        synthetic_integrative(),
        synthetic_nutrition(),
    ]


# ---------------------------------------------------------------------------
# Formulas (architecture validation only)
# ---------------------------------------------------------------------------
def synthetic_formulas() -> list[ClinicalFormulaDefinition]:
    def inp(name: str, concept: str, unit: str, *, confirmed: bool = True) -> FormulaInputRequirement:
        return FormulaInputRequirement(
            name=name, concept=concept, required_unit=unit, requires_confirmed_source=confirmed
        )

    return [
        ClinicalFormulaDefinition(
            definition_id=c.TESTOSTERONE_ESTRADIOL_RATIO,
            name="Testosterone / Estradiol ratio (TEST)",
            version=1,
            description="Synthetic ratio fixture. Not a validated clinical formula.",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            inputs=(
                inp("testosterone", c.TESTOSTERONE_TOTAL, "ng/dL"),
                inp("estradiol", c.ESTRADIOL, "pg/mL"),
            ),
            output_unit="1",
            expression="testosterone / estradiol",
            temporal_requirement=TemporalRequirement.SAME_DAY,
            validity_constraints=("estradiol > 0",),
            domain=ClinicalDomain.GONADAL.value,
            warnings=("SYNTHETIC_TEST_FORMULA - architecture validation only",),
            population_constraints={"allow_pregnancy": [False]},
        ),
        ClinicalFormulaDefinition(
            definition_id=c.TRIGLYCERIDE_HDL_RATIO,
            name="Triglyceride / HDL ratio (TEST)",
            version=1,
            description="Synthetic lipid ratio fixture.",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            inputs=(
                inp("triglycerides", c.TRIGLYCERIDES, "mg/dL"),
                inp("hdl", c.HDL_CHOLESTEROL, "mg/dL"),
            ),
            output_unit="1",
            expression="triglycerides / hdl",
            temporal_requirement=TemporalRequirement.SAME_DAY,
            validity_constraints=("hdl > 0",),
            domain=ClinicalDomain.LIPID.value,
            warnings=("SYNTHETIC_TEST_FORMULA - architecture validation only",),
        ),
        ClinicalFormulaDefinition(
            definition_id=c.NEUTROPHIL_LYMPHOCYTE_RATIO,
            name="Neutrophil / Lymphocyte ratio (TEST)",
            version=1,
            description="Synthetic inflammatory ratio fixture (cross-unit safe).",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            inputs=(
                inp("neutrophils", c.NEUTROPHILS_ABSOLUTE, "10^3/uL"),
                inp("lymphocytes", c.LYMPHOCYTES_ABSOLUTE, "10^3/uL"),
            ),
            output_unit="1",
            expression="neutrophils / lymphocytes",
            temporal_requirement=TemporalRequirement.SAME_DAY,
            validity_constraints=("lymphocytes > 0",),
            domain=ClinicalDomain.INFLAMMATORY.value,
            warnings=("SYNTHETIC_TEST_FORMULA - architecture validation only",),
        ),
        ClinicalFormulaDefinition(
            definition_id=c.BMI,
            name="Body mass index (TEST)",
            version=1,
            description="Synthetic body-composition fixture.",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            inputs=(
                inp("weight", c.WEIGHT, "kg"),
                inp("height_m", c.HEIGHT, "m"),
            ),
            output_unit="kg/m^2",
            expression="weight / (height_m * height_m)",
            temporal_requirement=TemporalRequirement.WITHIN_N_DAYS,
            temporal_window_days=1,
            validity_constraints=("height_m > 0",),
            domain=ClinicalDomain.BODY_COMPOSITION.value,
            warnings=("SYNTHETIC_TEST_FORMULA - architecture validation only",),
        ),
        ClinicalFormulaDefinition(
            definition_id=c.FFMI,
            name="Fat-free mass index (TEST)",
            version=1,
            description="Synthetic body-composition fixture using BIA fat-free mass.",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            inputs=(
                inp("fat_free_mass", c.FAT_FREE_MASS, "kg"),
                inp("height_m", c.HEIGHT, "m"),
            ),
            output_unit="kg/m^2",
            expression="fat_free_mass / (height_m * height_m)",
            temporal_requirement=TemporalRequirement.SAME_COLLECTION,
            validity_constraints=("height_m > 0",),
            domain=ClinicalDomain.BODY_COMPOSITION.value,
            warnings=("SYNTHETIC_TEST_FORMULA - architecture validation only",),
        ),
        ClinicalFormulaDefinition(
            definition_id=c.WAIST_HEIGHT_RATIO,
            name="Waist / height ratio (TEST)",
            version=1,
            description="Synthetic anthropometric ratio fixture.",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            inputs=(
                inp("waist", c.WAIST_CIRCUMFERENCE, "cm"),
                inp("height", c.HEIGHT, "cm"),
            ),
            output_unit="1",
            expression="waist / height",
            temporal_requirement=TemporalRequirement.SAME_COLLECTION,
            validity_constraints=("height > 0",),
            domain=ClinicalDomain.BODY_COMPOSITION.value,
            warnings=("SYNTHETIC_TEST_FORMULA - architecture validation only",),
        ),
        ClinicalFormulaDefinition(
            definition_id=c.HOMA_IR,
            name="HOMA-IR (TEST)",
            version=1,
            description="Synthetic insulin-resistance fixture (fasting inputs).",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            inputs=(
                inp("glucose", c.GLUCOSE_FASTING, "mg/dL"),
                inp("insulin", c.INSULIN_FASTING, "uU/mL"),
            ),
            output_unit="1",
            expression="glucose * insulin / 405",
            temporal_requirement=TemporalRequirement.SAME_DAY,
            domain=ClinicalDomain.GLYCEMIC.value,
            warnings=(
                "SYNTHETIC_TEST_FORMULA - architecture validation only",
                "HOMA requires fasting status confirmed by the source",
            ),
        ),
    ]


# ---------------------------------------------------------------------------
# Score (architecture validation only)
# ---------------------------------------------------------------------------
def synthetic_scores() -> list[ClinicalScoreDefinition]:
    return [
        ClinicalScoreDefinition(
            definition_id="METABOLIC_LOAD_TEST_SCORE",
            name="Metabolic load test score (TEST)",
            version=1,
            description="Deterministic fixture score over the TG/HDL ratio.",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            inputs=(
                ScoreInput("triglycerides", c.TRIGLYCERIDES, "mg/dL"),
                ScoreInput("hdl", c.HDL_CHOLESTEROL, "mg/dL"),
            ),
            output_unit="1",
            expression="triglycerides / hdl",
            bands=(
                ScoreBand("lower", None, 2.0, "Fixture band: lower"),
                ScoreBand("moderate", 2.0, 4.0, "Fixture band: moderate"),
                ScoreBand("higher", 4.0, None, "Fixture band: higher"),
            ),
            band_direction=ScoreBandDirection.NON_DIRECTIONAL,
            temporal_requirement=TemporalRequirement.SAME_DAY,
            domain=ClinicalDomain.METABOLIC.value,
            warnings=("SYNTHETIC_TEST_SCORE - architecture validation only",),
            metadata={"test": True},
        )
    ]


# ---------------------------------------------------------------------------
# Rules (TEST_RULE fixtures)
# ---------------------------------------------------------------------------
def synthetic_rules() -> list[ScientificClinicalRule]:
    return [
        ScientificClinicalRule(
            definition_id="TEST_RULE_LOW_VITAMIN_D",
            name="TEST_RULE: Vitamin D below fixture threshold",
            version=1,
            description="Synthetic rule used to validate the rule engine.",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            evidence_refs=("SYNTHETIC_FIXTURE",),
            inputs=(
                RuleInput("vitamin_d", c.VITAMIN_D_25OH, OBSERVATION, "ng/mL"),
            ),
            conditions=("vitamin_d < 30",),
            combine="ALL",
            signal_type=SignalType.OBSERVATION_FLAG,
            severity=Severity.MODERATE,
            severity_escalations=(
                RuleSeverityEscalation("vitamin_d < 20", Severity.HIGH),
            ),
            explanation_template=(
                "Vitamin D {vitamin_d} {vitamin_d_unit} is below the fixture threshold "
                "of 30 ng/mL. Synthetic test rule - not clinical guidance."
            ),
            category="Micronutrient",
            domain=ClinicalDomain.MICRONUTRIENT.value,
            tags=("TEST_RULE", "SYNTHETIC"),
            test_rule=True,
        ),
        ScientificClinicalRule(
            definition_id="TEST_RULE_HIGH_TE_RATIO",
            name="TEST_RULE: Elevated T/E ratio (derived metric input)",
            version=1,
            description="Synthetic rule consuming a derived metric.",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            evidence_refs=("SYNTHETIC_FIXTURE",),
            inputs=(
                RuleInput(
                    "te_ratio",
                    c.TESTOSTERONE_ESTRADIOL_RATIO,
                    DERIVED_METRIC,
                    "1",
                ),
            ),
            conditions=("te_ratio > 15",),
            combine="ALL",
            signal_type=SignalType.COMBINATION_FLAG,
            severity=Severity.INFO,
            explanation_template=(
                "Derived T/E ratio {te_ratio} exceeds the fixture threshold. "
                "Synthetic test rule - not clinical guidance."
            ),
            category="Gonadal",
            domain=ClinicalDomain.GONADAL.value,
            tags=("TEST_RULE", "SYNTHETIC"),
            test_rule=True,
        ),
        ScientificClinicalRule(
            definition_id="TEST_RULE_GLYCEMIC_COMBINATION",
            name="TEST_RULE: Glycemic combination fixture",
            version=1,
            description="Synthetic multi-input combination rule (SAME_DAY).",
            status=DefinitionStatus.VALIDATED_FOR_USE,
            evidence_refs=("SYNTHETIC_FIXTURE",),
            inputs=(
                RuleInput("glucose", c.GLUCOSE_FASTING, OBSERVATION, "mg/dL"),
                RuleInput("insulin", c.INSULIN_FASTING, OBSERVATION, "uU/mL"),
            ),
            conditions=("glucose >= 100", "insulin >= 10"),
            combine="ALL",
            signal_type=SignalType.COMBINATION_FLAG,
            severity=Severity.LOW,
            temporal_requirement=TemporalRequirement.SAME_DAY,
            explanation_template=(
                "Fixture combination: glucose {glucose} mg/dL and insulin {insulin} uU/mL. "
                "Synthetic test rule - not clinical guidance."
            ),
            category="Glycemic",
            domain=ClinicalDomain.GLYCEMIC.value,
            interpretation_warning="Fasting status must be confirmed by the source.",
            tags=("TEST_RULE", "SYNTHETIC"),
            test_rule=True,
        ),
    ]


# ---------------------------------------------------------------------------
# Registration helpers
# ---------------------------------------------------------------------------
def register_synthetic_formulas(registry: FormulaRegistry) -> None:
    for formula in synthetic_formulas():
        registry.publish(formula)


def register_synthetic_scores(registry: ScoreRegistry) -> None:
    for score in synthetic_scores():
        registry.publish(score)


def register_synthetic_rules(registry: RuleRegistry) -> None:
    for rule in synthetic_rules():
        registry.publish(rule)
