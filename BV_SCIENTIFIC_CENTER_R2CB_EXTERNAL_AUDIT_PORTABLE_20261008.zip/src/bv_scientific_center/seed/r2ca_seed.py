"""R2C-A seed: formula candidates, honest appraisals and evidence links.

No scientific result is invented. The frozen corpus carries only bibliographic
metadata (no abstract/full text), so scientific fields are recorded as
INSUFFICIENT_INFORMATION and marked as pending. Candidate definitions are
non-operational.
"""

from __future__ import annotations

from typing import Any

from ..core.enums import (
    AppraisalFieldProvenance,
    FormulaCandidateStatus,
    FormulaCandidateType,
    InputSemantics,
    TemporalRequirement,
)
from ..knowledge.applicability import ApplicabilityProfile
from ..knowledge.formula_candidates import CandidateVariable, FormulaCandidate
from ..knowledge.input_semantics import InputValue, device_estimate, measurement
from ..knowledge.scientific import CurationSubjectType, EvidenceRelation, LinkTargetType

# Corpus DOIs selected for appraisal (body composition / FMI-FFMI / BIA / longitudinal).
SELECTED_DOIS = (
    "10.3928/21650799-20140514-04",       # limitations of BMI to assess body fat
    "10.3390/ijerph16111920",             # percentile curves BMI/waist
    "10.1253/circj.cj-10-0583",           # waist-height ratio vs waist circumference
    "10.1016/j.clnu.2018.10.010",         # FMI/FFMI reference values by BIA
    "10.20960/nh.03161",                  # FMI/FFMI reference values in adolescents
    "10.1097/01823246-199001010-00008",   # BIA validity in obese/normal
    "10.1016/s0899-9007(97)85179-9",      # BIA in body composition measurement
    "10.1016/s0261-5614(03)80008-0",      # longitudinal body composition follow-up
)

_APPRAISAL_PENDING = (
    "scientific_question",
    "study_design",
    "population",
    "sample_size",
    "reference_method",
    "outcomes",
    "quantitative_results",
    "limitations",
    "clinical_applicability",
)


def _resolve(app, doi: str) -> str | None:
    reference = app.references.find_by_identifier("doi", doi)
    return reference.reference_id if reference else None


def _candidates(app) -> list[FormulaCandidate]:
    def refs(*dois: str) -> tuple[str, ...]:
        return tuple(rid for rid in (_resolve(app, d) for d in dois) if rid)

    measured = (InputSemantics.MEASURED, InputSemantics.CLINICIAN_ASSESSED)
    measured_or_device = (
        InputSemantics.MEASURED,
        InputSemantics.CLINICIAN_ASSESSED,
        InputSemantics.DEVICE_ESTIMATED,
    )

    return [
        FormulaCandidate(
            candidate_id="SCI-CAND-BMI",
            name="Body mass index",
            display_name="IMC",
            version=1,
            candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX,
            expression="weight_kg / (height_m * height_m)",
            output_unit="kg/m^2",
            output_domain="height_m > 0",
            variables=(
                CandidateVariable("weight_kg", "kg", "Body mass", allowed_semantics=measured),
                CandidateVariable("height_m", "m", "Standing height", allowed_semantics=measured),
            ),
            applicability=ApplicabilityProfile(
                applicable_populations=("ADULT",),
                not_validated_populations=("PEDIATRIC", "PREGNANT", "ATHLETE", "SEVERE_OBESITY"),
                notes="Index; cutoffs are not imported as diagnostic criteria.",
            ),
            refusal_conditions=("height_m <= 0",),
            reference_ids=refs("10.3928/21650799-20140514-04", "10.3390/ijerph16111920"),
            limitations=(
                "Does not distinguish fat from lean mass.",
                "No validated cutoff imported.",
            ),
            review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW
            if refs("10.3928/21650799-20140514-04")
            else FormulaCandidateStatus.DRAFT,
        ),
        FormulaCandidate(
            candidate_id="SCI-CAND-FMI",
            name="Fat mass index",
            display_name="FMI",
            version=1,
            candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX,
            expression="fat_mass_kg / (height_m * height_m)",
            output_unit="kg/m^2",
            output_domain="height_m > 0",
            variables=(
                CandidateVariable(
                    "fat_mass_kg", "kg", "Fat mass (may be device-estimated)",
                    allowed_semantics=measured_or_device,
                ),
                CandidateVariable("height_m", "m", "Standing height", allowed_semantics=measured),
            ),
            applicability=ApplicabilityProfile(
                applicable_populations=("ADULT",),
                not_validated_populations=("PEDIATRIC", "PREGNANT", "EDEMA_ASCITES"),
                notes="Reference values population-specific; not imported.",
            ),
            refusal_conditions=("height_m <= 0",),
            reference_ids=refs("10.1016/j.clnu.2018.10.010", "10.20960/nh.03161"),
            limitations=(
                "Depends on the fat-mass estimation method.",
                "Population-specific reference values not imported.",
            ),
            review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW
            if refs("10.1016/j.clnu.2018.10.010")
            else FormulaCandidateStatus.DRAFT,
        ),
        FormulaCandidate(
            candidate_id="SCI-CAND-FFMI",
            name="Fat-free mass index",
            display_name="FFMI",
            version=1,
            candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX,
            expression="fat_free_mass_kg / (height_m * height_m)",
            output_unit="kg/m^2",
            output_domain="height_m > 0",
            variables=(
                CandidateVariable(
                    "fat_free_mass_kg", "kg", "Fat-free mass (often device-estimated)",
                    allowed_semantics=measured_or_device,
                ),
                CandidateVariable("height_m", "m", "Standing height", allowed_semantics=measured),
            ),
            applicability=ApplicabilityProfile(
                applicable_populations=("ADULT",),
                not_validated_populations=("PEDIATRIC", "PREGNANT"),
                notes="Sensitive to hydration and estimation method.",
            ),
            refusal_conditions=("height_m <= 0",),
            reference_ids=refs("10.1016/j.clnu.2018.10.010", "10.20960/nh.03161"),
            limitations=(
                "Depends on the fat-free-mass estimation method.",
                "Not validated as a standalone clinical criterion.",
            ),
            review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW
            if refs("10.1016/j.clnu.2018.10.010")
            else FormulaCandidateStatus.DRAFT,
        ),
        FormulaCandidate(
            candidate_id="SCI-CAND-WHTR",
            name="Waist-to-height ratio",
            display_name="RCE (cintura/estatura)",
            version=1,
            candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX,
            expression="waist_cm / height_cm",
            output_unit="1",
            output_domain="height_cm > 0",
            variables=(
                CandidateVariable("waist_cm", "cm", "Waist circumference", allowed_semantics=measured),
                CandidateVariable("height_cm", "cm", "Standing height", allowed_semantics=measured),
            ),
            applicability=ApplicabilityProfile(
                applicable_populations=("ADULT",),
                not_validated_populations=("PEDIATRIC", "PREGNANT"),
                notes="Cutoffs not imported.",
            ),
            refusal_conditions=("height_cm <= 0",),
            reference_ids=refs("10.1253/circj.cj-10-0583", "10.3390/ijerph16111920"),
            limitations=("Measurement-site variability.", "No validated cutoff imported."),
            review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW
            if refs("10.1253/circj.cj-10-0583")
            else FormulaCandidateStatus.DRAFT,
        ),
        FormulaCandidate(
            candidate_id="SCI-CAND-BODY-FAT-PCT",
            name="Body fat percentage (from fat mass and body mass)",
            display_name="Percentual de gordura",
            version=1,
            candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX,
            expression="100 * fat_mass_kg / weight_kg",
            output_unit="%",
            output_domain="weight_kg > 0",
            variables=(
                CandidateVariable(
                    "fat_mass_kg", "kg", "Fat mass (may be device-estimated)",
                    allowed_semantics=measured_or_device,
                ),
                CandidateVariable("weight_kg", "kg", "Body mass", allowed_semantics=measured),
            ),
            applicability=ApplicabilityProfile(
                applicable_populations=("ADULT",),
                not_validated_populations=("PREGNANT", "EDEMA_ASCITES", "HYDRATION_CHANGE"),
                notes="Inherits the estimation method's uncertainty.",
            ),
            refusal_conditions=("weight_kg <= 0",),
            reference_ids=refs("10.1097/01823246-199001010-00008", "10.1016/s0899-9007(97)85179-9"),
            limitations=("Device-estimated inputs propagate uncertainty.",),
            review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW
            if refs("10.1097/01823246-199001010-00008")
            else FormulaCandidateStatus.DRAFT,
        ),
        FormulaCandidate(
            candidate_id="SCI-CAND-BC-LONGITUDINAL",
            name="Longitudinal change in a body-composition measure",
            display_name="Variação longitudinal",
            version=1,
            candidate_type=FormulaCandidateType.ALGEBRAIC_INDEX,
            expression="followup_value - baseline_value",
            output_unit="kg",
            output_domain="measures share the same unit",
            variables=(
                CandidateVariable("baseline_value", "kg", "Baseline measurement"),
                CandidateVariable("followup_value", "kg", "Follow-up measurement"),
            ),
            temporal_requirement=TemporalRequirement.OTHER_EXPLICIT_RULE,
            applicability=ApplicabilityProfile(
                applicable_populations=("ADULT",),
                not_validated_populations=("PREGNANT", "EDEMA_ASCITES", "ACUTE_CONDITION"),
                notes="Interpretation requires an explicit interval; not a treatment-effect claim.",
            ),
            reference_ids=refs("10.1016/s0261-5614(03)80008-0"),
            limitations=("Change is arithmetic; no efficacy inference.",),
            review_status=FormulaCandidateStatus.UNDER_SCIENTIFIC_REVIEW
            if refs("10.1016/s0261-5614(03)80008-0")
            else FormulaCandidateStatus.DRAFT,
        ),
        FormulaCandidate(
            candidate_id="SCI-CAND-WHTR-CUTOFF-PLACEHOLDER",
            name="Waist-to-height ratio interpretive criterion (placeholder)",
            display_name="RCE — critério interpretativo (placeholder)",
            version=1,
            candidate_type=FormulaCandidateType.INTERPRETIVE_CRITERION,
            expression="whtr",
            output_unit="1",
            output_domain="no cutoff defined",
            variables=(CandidateVariable("whtr", "1", "Waist-to-height ratio"),),
            applicability=ApplicabilityProfile(
                applicable_populations=(),
                not_validated_populations=("ADULT", "PEDIATRIC"),
                notes="No validated cutoff imported; placeholder for future review.",
            ),
            reference_ids=refs("10.1253/circj.cj-10-0583"),
            limitations=("Cutoffs are NOT imported as diagnostic criteria.",),
            review_status=FormulaCandidateStatus.DRAFT,
            metadata={"cutoff_defined": False},
        ),
    ]


def seed_r2ca(app) -> dict[str, Any]:
    from ..knowledge.formula_candidates import FormulaCandidate  # noqa: F401

    published = 0
    for candidate in _candidates(app):
        app.formula_candidate_repo.save(candidate)
        app.formula_candidates.publish(candidate)
        published += 1

    # Evidence links (reference -> formula candidate), with justification/version.
    links = 0
    for candidate in app.formula_candidates.all_latest():
        for reference_id in candidate.reference_ids:
            app.linking.link(
                subject_type=CurationSubjectType.REFERENCE,
                subject_id=reference_id,
                target_type=LinkTargetType.FORMULA_CANDIDATE,
                target_id=candidate.candidate_id,
                target_version=candidate.version,
                relation=EvidenceRelation.METHODOLOGICAL_FOUNDATION
                if candidate.candidate_type is FormulaCandidateType.ALGEBRAIC_INDEX
                else EvidenceRelation.DERIVATION_ORIGINAL,
                actor="seed_r2ca",
                justification="Selected from the initial body-composition corpus; not yet appraised.",
            )
            links += 1

    # Honest appraisals: metadata verified, scientific fields insufficient.
    appraisals = 0
    for doi in SELECTED_DOIS:
        reference_id = _resolve(app, doi)
        if reference_id is None:
            continue
        app.bibliography.record_appraisal(
            {
                "reference_id": reference_id,
                "reviewer": None,
                "content_review_status": "INSUFFICIENT_INFORMATION",
                "pending_fields": list(_APPRAISAL_PENDING),
                "field_provenance": {
                    "doi": AppraisalFieldProvenance.SOURCE_VERIFIED.value,
                    "title": AppraisalFieldProvenance.SOURCE_VERIFIED.value,
                    "publication_year": AppraisalFieldProvenance.SOURCE_VERIFIED.value,
                    "journal": AppraisalFieldProvenance.SOURCE_VERIFIED.value,
                    **{f: AppraisalFieldProvenance.INSUFFICIENT_INFORMATION.value for f in _APPRAISAL_PENDING},
                },
                "field_provenance_note": (
                    "Only bibliographic metadata is available (no abstract/full text consulted); "
                    "scientific fields are not invented."
                ),
            }
        )
        appraisals += 1

    return {
        "formula_candidates": published,
        "evidence_links": links,
        "appraisals": appraisals,
        "selected_dois": len(SELECTED_DOIS),
    }
