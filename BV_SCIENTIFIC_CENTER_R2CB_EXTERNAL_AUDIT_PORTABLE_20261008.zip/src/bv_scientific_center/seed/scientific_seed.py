"""R2A seed: a complete synthetic curation set plus a small real-reference pilot.

Synthetic content is marked ``origin=SYNTHETIC_TEST`` and can never be APPROVED.
The real-reference pilot uses metadata retrieved from the Crossref REST API
(``metadata_source=CROSSREF``, ``verification_status=VERIFIED``) and is imported
as ``IMPORTED_UNVERIFIED`` — never auto-approved. No DOI, title, author or result
is invented; only fields returned by Crossref are recorded.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from ..core.enums import KnowledgeOrigin
from ..knowledge.scientific import (
    BibliographicVerification,
    CertaintyFramework,
    CertaintyLevel,
    ClinicalClaim,
    CurationSubjectType,
    EvidenceRelation,
    LinkTargetType,
    MetadataSource,
    PublicationType,
    ScientificEvidence,
    ScientificReference,
    StudyDesign,
    VerificationStatus,
)
from .synthetic import SYNTHETIC_PATIENT_ID  # noqa: F401  (documentation reference)

PILOT_VERIFIED_AT = "2026-10-08"


# ---------------------------------------------------------------------------
# Synthetic curation set (contract/workflow fixtures)
# ---------------------------------------------------------------------------
def synthetic_references() -> list[ScientificReference]:
    def make(rid, title, design_note, year=2026):
        return ScientificReference(
            reference_id=rid,
            title=title,
            authors=("Synthetic Fixture Author",),
            organization="BV Synthetic Fixture",
            publication_year=year,
            venue="SYNTHETIC FIXTURE - not a real source",
            publication_type=PublicationType.OTHER,
            url=f"https://example.invalid/{rid}",
            metadata_source=MetadataSource.SYNTHETIC,
            verification_status=VerificationStatus.VERIFY_PENDING,
            origin=KnowledgeOrigin.SYNTHETIC_TEST,
            notes=design_note,
        )

    return [
        make("REF-SYN-001", "Synthetic fixture: anthropometric ratio context",
             "Fixtures for the reference contract."),
        make("REF-SYN-002", "Synthetic fixture: body-composition method comparability",
             "Fixtures for the evidence contract."),
        make("REF-SYN-003", "Synthetic fixture: nutrition assessment workflow",
             "Fixtures for the claim contract."),
    ]


def synthetic_evidence() -> list[ScientificEvidence]:
    return [
        ScientificEvidence(
            evidence_id="EV-SYN-001",
            title="Synthetic fixture evidence (cross-sectional)",
            reference_ids=("REF-SYN-001",),
            study_design=StudyDesign.CROSS_SECTIONAL,
            population="Synthetic population",
            outcomes=("synthetic outcome",),
            limitations=("synthetic limitation",),
            domain="BODY_COMPOSITION",
            origin=KnowledgeOrigin.SYNTHETIC_TEST,
        ),
        ScientificEvidence(
            evidence_id="EV-SYN-002",
            title="Synthetic fixture evidence (cohort)",
            reference_ids=("REF-SYN-002",),
            study_design=StudyDesign.COHORT,
            population="Synthetic cohort",
            outcomes=("synthetic outcome",),
            domain="NUTRITION",
            origin=KnowledgeOrigin.SYNTHETIC_TEST,
        ),
        ScientificEvidence(
            evidence_id="EV-SYN-003",
            title="Synthetic fixture evidence (instrument validation)",
            reference_ids=("REF-SYN-002",),
            study_design=StudyDesign.INSTRUMENT_VALIDATION,
            population="Synthetic validation sample",
            outcomes=("synthetic agreement metric",),
            domain="BODY_COMPOSITION",
            origin=KnowledgeOrigin.SYNTHETIC_TEST,
        ),
    ]


def synthetic_claims() -> list[ClinicalClaim]:
    return [
        ClinicalClaim(
            claim_id="CLAIM-SYN-001",
            text="Synthetic fixture claim bounded to the fixture population.",
            favorable_evidence_ids=("EV-SYN-001",),
            contrary_evidence_ids=("EV-SYN-002",),
            inconclusive_evidence_ids=("EV-SYN-003",),
            population_context="Synthetic only",
            limitations=("synthetic limitation",),
            certainty_level=CertaintyLevel.NOT_ASSESSED,
            certainty_framework=CertaintyFramework.NONE,
            origin=KnowledgeOrigin.SYNTHETIC_TEST,
        ),
    ]


# ---------------------------------------------------------------------------
# Real-reference pilot (verified via Crossref; never auto-approved)
# ---------------------------------------------------------------------------
def pilot_references() -> list[ScientificReference]:
    accessed = datetime(2026, 10, 8, tzinfo=timezone.utc)
    return [
        ScientificReference(
            reference_id="REF-PILOT-FMI-FFMI-CANCER",
            title=(
                "Association Between Fat Mass Index, Fat Free Mass Index and "
                "Metabolic Syndrome, Cachexia, and All-Cause Mortality Among "
                "Patients with Cancer"
            ),
            authors=("Tian, Hai-Ying", "Liu, Chen-An", "Shi, Han-Ping"),
            publication_year=2025,
            venue="Nutrition and Cancer",
            publication_type=PublicationType.JOURNAL_ARTICLE,
            doi="10.1080/01635581.2025.2581336",
            url="https://doi.org/10.1080/01635581.2025.2581336",
            accessed_at=accessed,
            metadata_source=MetadataSource.CROSSREF,
            verification_status=VerificationStatus.VERIFIED,
            bibliographic_status=BibliographicVerification.VERIFIED,
            origin=KnowledgeOrigin.IMPORTED,
            notes="Metadata retrieved from the Crossref REST API (title, authors, venue, year, DOI, volume/pages).",
        ),
        ScientificReference(
            reference_id="REF-PILOT-BMI-FMI-FFMI-KOREAN",
            title=(
                "Relationship between Body Mass Index and, Fat-Free Mass Index and "
                "Fat-Mass Index in Korean Population."
            ),
            authors=("Sung, Soonchang", "Kim, Hyunsoo"),
            publication_year=2013,
            venue="Exercise Science",
            publication_type=PublicationType.JOURNAL_ARTICLE,
            doi="10.15857/ksep.2013.22.4.301",
            url="https://doi.org/10.15857/ksep.2013.22.4.301",
            accessed_at=accessed,
            metadata_source=MetadataSource.CROSSREF,
            verification_status=VerificationStatus.VERIFIED,
            bibliographic_status=BibliographicVerification.VERIFIED,
            origin=KnowledgeOrigin.IMPORTED,
            notes="Metadata retrieved from the Crossref REST API.",
        ),
        ScientificReference(
            reference_id="REF-PILOT-FMI-FFMI-GIRLS-NORMS",
            title="Reference norms of fat mass index and fat-free mass index for girls",
            authors=("김난수", "김현수"),
            publication_year=2009,
            venue="Exercise Science",
            publication_type=PublicationType.JOURNAL_ARTICLE,
            doi="10.15857/ksep.2009.18.2.256",
            url="https://doi.org/10.15857/ksep.2009.18.2.256",
            accessed_at=accessed,
            metadata_source=MetadataSource.CROSSREF,
            verification_status=VerificationStatus.VERIFIED,
            bibliographic_status=BibliographicVerification.VERIFIED,
            origin=KnowledgeOrigin.IMPORTED,
            notes="Metadata retrieved from the Crossref REST API (author names as returned, Korean script).",
        ),
        ScientificReference(
            reference_id="REF-PILOT-WHTR-MULTIMORBIDITY",
            title=(
                "Waist-to-Height Ratio, Waist Circumference, Body Mass Index and Risk "
                "of Cardiometabolic Multimorbidity: A National Longitudinal Cohort Study"
            ),
            authors=("Lu, Yanqiang", "Liu, Siyuan", "Qiao, Yanan", "Li, Guochen", "Wu, Ying", "Ke, Chaofu"),
            publication_year=2020,
            venue="Research Square (preprint)",
            publication_type=PublicationType.PREPRINT,
            doi="10.21203/rs.3.rs-137388/v1",
            url="https://doi.org/10.21203/rs.3.rs-137388/v1",
            accessed_at=accessed,
            metadata_source=MetadataSource.CROSSREF,
            verification_status=VerificationStatus.VERIFIED,
            bibliographic_status=BibliographicVerification.VERIFIED,
            origin=KnowledgeOrigin.IMPORTED,
            notes="Crossref record type 'posted-content' (preprint); not peer-reviewed. Metadata retrieved via Crossref REST API.",
        ),
    ]


# ---------------------------------------------------------------------------
# Seeding
# ---------------------------------------------------------------------------
def seed_scientific(app, *, include_pilot: bool = True) -> dict[str, Any]:
    for reference in synthetic_references():
        app.references.save(reference)
    for evidence in synthetic_evidence():
        app.evidence_records.save(evidence)
    for claim in synthetic_claims():
        app.claims.save(claim)

    # Link the synthetic evidence to a synthetic formula for contract coverage.
    app.linking.link(
        subject_type=CurationSubjectType.EVIDENCE,
        subject_id="EV-SYN-001",
        target_type=LinkTargetType.FORMULA,
        target_id="WAIST_HEIGHT_RATIO",
        target_version=1,
        relation=EvidenceRelation.FOUNDATIONAL,
        actor="seed_synthetic",
        applicability="Synthetic fixture only",
    )

    pilot_imported = 0
    if include_pilot:
        for reference in pilot_references():
            existing = app.references.find_by_identifier("doi", reference.doi)
            if existing is None:
                app.references.save(reference)
                pilot_imported += 1

    return {
        "synthetic_references": len(synthetic_references()),
        "synthetic_evidence": len(synthetic_evidence()),
        "synthetic_claims": len(synthetic_claims()),
        "pilot_imported": pilot_imported,
        "pilot_verified_at": PILOT_VERIFIED_AT,
    }
