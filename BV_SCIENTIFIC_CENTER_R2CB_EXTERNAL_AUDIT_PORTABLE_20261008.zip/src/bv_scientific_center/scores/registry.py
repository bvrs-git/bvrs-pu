"""Score registry with publication-time validation."""

from __future__ import annotations

from ..core.enums import TemporalRequirement
from ..core.expression import compile_expression
from ..core.registry import DefinitionRegistry
from ..core.units import is_known
from ..errors import ExpressionError, UnknownUnitError
from .definition import ClinicalScoreDefinition


def validate_score(score: ClinicalScoreDefinition) -> None:
    if not score.definition_id:
        raise ExpressionError("Score requires a definition_id")
    if not score.expression:
        raise ExpressionError(f"Score {score.definition_id} has no expression")
    compiled = compile_expression(score.expression)
    declared = set(score.input_names())
    undeclared = compiled.names - declared
    if undeclared:
        raise ExpressionError(
            f"Score {score.definition_id} expression references undeclared inputs: "
            f"{sorted(undeclared)}"
        )
    if not is_known(score.output_unit):
        raise UnknownUnitError(
            f"Score {score.definition_id} output unit {score.output_unit!r} is unknown"
        )
    for requirement in score.inputs:
        if not is_known(requirement.required_unit):
            raise UnknownUnitError(
                f"Score {score.definition_id} input {requirement.name!r} uses unknown "
                f"unit {requirement.required_unit!r}"
            )
    if score.temporal_requirement is TemporalRequirement.WITHIN_N_DAYS and (
        not score.temporal_window_days or score.temporal_window_days <= 0
    ):
        raise ExpressionError(
            f"Score {score.definition_id} requires a positive temporal_window_days"
        )
    for constraint in score.validity_constraints:
        compile_expression(constraint)


class ScoreRegistry(DefinitionRegistry[ClinicalScoreDefinition]):
    def __init__(self) -> None:
        super().__init__("score", validate_score)
