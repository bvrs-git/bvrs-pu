"""Clinical score definitions, bands and results.

A score is *not* a plain formula: it has interpretation bands. A score result is
never a diagnosis; bands are interpreted as descriptive strata only.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..core.definition import VersionedDefinition
from ..core.enums import DefinitionStatus, ScoreBandDirection, TemporalRequirement


@dataclass(frozen=True)
class ScoreInput:
    name: str
    concept: str
    required_unit: str = "1"
    required: bool = True
    # Reported/questionnaire inputs are not "confirmed instrument" sources.
    requires_confirmed_source: bool = False
    label: str | None = None
    question_code: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "ScoreInput":
        return cls(
            name=data["name"],
            concept=data.get("concept", data["name"]),
            required_unit=data.get("required_unit", "1"),
            required=bool(data.get("required", True)),
            requires_confirmed_source=bool(data.get("requires_confirmed_source", False)),
            label=data.get("label"),
            question_code=data.get("question_code"),
        )


@dataclass(frozen=True)
class ScoreBand:
    label: str
    lower: float | None = None          # inclusive
    upper: float | None = None          # exclusive
    interpretation: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> "ScoreBand":
        return cls(
            label=data["label"],
            lower=data.get("lower"),
            upper=data.get("upper"),
            interpretation=data.get("interpretation", ""),
        )

    def contains(self, value: float) -> bool:
        if self.lower is not None and value < self.lower:
            return False
        if self.upper is not None and value >= self.upper:
            return False
        return True


@dataclass(frozen=True)
class ClinicalScoreDefinition(VersionedDefinition):
    inputs: tuple[ScoreInput, ...] = ()
    output_unit: str = "1"
    expression: str = ""
    bands: tuple[ScoreBand, ...] = ()
    band_direction: ScoreBandDirection = ScoreBandDirection.NON_DIRECTIONAL
    temporal_requirement: TemporalRequirement = TemporalRequirement.LATEST_AVAILABLE
    temporal_window_days: int | None = None
    validity_constraints: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    domain: str | None = None
    population_constraints: dict[str, list[str]] = field(default_factory=dict)
    output_label: str | None = None

    def band_for(self, value: float) -> ScoreBand | None:
        for band in self.bands:
            if band.contains(value):
                return band
        return None

    def input_names(self) -> tuple[str, ...]:
        return tuple(i.name for i in self.inputs)

    @classmethod
    def from_dict(cls, data: dict) -> "ClinicalScoreDefinition":
        from ..core.definition import coerce_enum

        return cls(
            definition_id=data["definition_id"],
            name=data.get("name", data["definition_id"]),
            version=int(data.get("version", 1)),
            description=data.get("description", ""),
            status=coerce_enum(DefinitionStatus, data.get("status", "DRAFT")),
            evidence_refs=tuple(data.get("evidence_refs", ())),
            metadata=dict(data.get("metadata", {})),
            inputs=tuple(ScoreInput.from_dict(i) for i in data.get("inputs", ())),
            output_unit=data.get("output_unit", "1"),
            expression=data.get("expression", ""),
            bands=tuple(ScoreBand.from_dict(b) for b in data.get("bands", ())),
            band_direction=coerce_enum(
                ScoreBandDirection, data.get("band_direction", "NON_DIRECTIONAL")
            ),
            temporal_requirement=coerce_enum(
                TemporalRequirement, data.get("temporal_requirement", "LATEST_AVAILABLE")
            ),
            temporal_window_days=data.get("temporal_window_days"),
            validity_constraints=tuple(data.get("validity_constraints", ())),
            warnings=tuple(data.get("warnings", ())),
            domain=data.get("domain"),
            population_constraints=dict(data.get("population_constraints", {})),
            output_label=data.get("output_label"),
        )
