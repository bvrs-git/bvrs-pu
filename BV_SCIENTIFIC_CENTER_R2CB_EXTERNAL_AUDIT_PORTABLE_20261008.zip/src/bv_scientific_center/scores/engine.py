"""Score engine.

Reuses the derived-metric machinery (same unit/temporal/authority safety) and
adds interpretation bands. A band is a descriptive stratum - never a diagnosis.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core.enums import Authority, CalculationStatus
from ..core.context import EvaluationContext
from ..formulas.definition import ClinicalFormulaDefinition, FormulaInputRequirement
from ..formulas.engine import DerivedClinicalMetric, compute_metric
from ..observations.refs import ScientificObservationRef
from .definition import ClinicalScoreDefinition


@dataclass
class ClinicalScoreResult:
    score_result_id: str
    patient_id: str
    score_id: str
    score_version: int
    value: float | None
    unit: str
    band: str | None
    band_interpretation: str | None
    computed_at: datetime
    effective_at: datetime | None
    calculation_status: CalculationStatus
    authority: Authority = Authority.SYSTEM_DERIVED
    inputs: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    refusal_reason: str | None = None
    domain: str | None = None
    derived_from_metric_id: str | None = None

    @property
    def is_valid(self) -> bool:
        return self.calculation_status.is_valid

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


def score_as_formula(score: ClinicalScoreDefinition) -> ClinicalFormulaDefinition:
    """Adapt a score to the formula engine (single code path for safety)."""
    return ClinicalFormulaDefinition(
        definition_id=score.definition_id,
        name=score.name,
        version=score.version,
        description=score.description,
        status=score.status,
        evidence_refs=score.evidence_refs,
        metadata={"kind": "score", **dict(score.metadata)},
        inputs=tuple(
            FormulaInputRequirement(
                name=i.name,
                concept=i.concept,
                required_unit=i.required_unit,
                required=i.required,
                requires_confirmed_source=i.requires_confirmed_source,
                label=i.label,
            )
            for i in score.inputs
        ),
        output_unit=score.output_unit,
        expression=score.expression,
        temporal_requirement=score.temporal_requirement,
        temporal_window_days=score.temporal_window_days,
        validity_constraints=score.validity_constraints,
        warnings=score.warnings,
        domain=score.domain,
        population_constraints=score.population_constraints,
        output_label=score.output_label,
    )


def _wrap(
    score: ClinicalScoreDefinition, metric: DerivedClinicalMetric
) -> ClinicalScoreResult:
    band_label: str | None = None
    band_interpretation: str | None = None
    if metric.is_valid and metric.value is not None:
        band = score.band_for(metric.value)
        if band is not None:
            band_label = band.label
            band_interpretation = band.interpretation
    return ClinicalScoreResult(
        score_result_id=metric.metric_id.replace("metric_", "score_", 1),
        patient_id=metric.patient_id,
        score_id=score.definition_id,
        score_version=score.version,
        value=metric.value,
        unit=score.output_unit,
        band=band_label,
        band_interpretation=band_interpretation,
        computed_at=metric.computed_at,
        effective_at=metric.effective_at,
        calculation_status=metric.calculation_status,
        authority=Authority.SYSTEM_DERIVED,
        inputs=[
            {
                "name": r.name,
                "concept": r.concept,
                "observation_ref_id": r.observation_ref_id,
                "value": r.original_value,
                "unit": r.original_unit,
                "normalized_value": r.normalized_value,
                "normalized_unit": r.normalized_unit,
                "effective_at": r.effective_at,
            }
            for r in metric.input_resolutions
        ],
        warnings=list(metric.warnings),
        refusal_reason=metric.refusal_reason,
        domain=score.domain,
        derived_from_metric_id=metric.metric_id,
    )


def compute_score(
    score: ClinicalScoreDefinition,
    refs_by_concept: dict[str, list[ScientificObservationRef]],
    *,
    patient_id: str,
    context: EvaluationContext | None = None,
    computed_at: datetime | None = None,
) -> ClinicalScoreResult:
    metric = compute_metric(
        score_as_formula(score),
        refs_by_concept,
        patient_id=patient_id,
        context=context,
        computed_at=computed_at,
    )
    return _wrap(score, metric)
