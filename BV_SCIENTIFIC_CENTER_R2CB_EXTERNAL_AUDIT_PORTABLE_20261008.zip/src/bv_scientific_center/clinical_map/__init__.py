"""Clinical map model and projections (clinician-facing graph)."""
