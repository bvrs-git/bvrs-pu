"""Clinical map builder.

Builds the clinician-facing graph (NOT a patient portal) from a synthesis run.
Every node and edge is traceable to a source reference, a formula, a rule or an
explicit clinician annotation - there are no orphan edges (spec §33, §75, §96).

Layout is presentation only; the map can be rebuilt from source + derived state.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Iterable

from ..contracts.outputs import (
    ClinicalMapMetadata,
    ClinicalMapProjectionV1,
    MapEdgeProjection,
    MapNodeProjection,
    Provenance,
)
from ..core import ids
from ..core.enums import ClinicalDomain, EdgeType, MapLayer, NodeType
from ..core.timeutil import now_utc, parse_dt, to_iso
from ..errors import ProvenanceError
from ..observations.refs import ScientificObservationRef
from ..synthesis.run import SynthesisRunResult

CONTRACT_VERSION = "ClinicalMapProjectionV1"

# A small, transparent concept -> domain mapping used only for grouping in the
# UI. It carries no clinical conclusion.
CONCEPT_DOMAIN: dict[str, ClinicalDomain] = {
    "GLUCOSE_FASTING": ClinicalDomain.GLYCEMIC,
    "INSULIN_FASTING": ClinicalDomain.GLYCEMIC,
    "HBA1C": ClinicalDomain.GLYCEMIC,
    "HOMA_IR": ClinicalDomain.GLYCEMIC,
    "TOTAL_CHOLESTEROL": ClinicalDomain.LIPID,
    "HDL_CHOLESTEROL": ClinicalDomain.LIPID,
    "LDL_CHOLESTEROL": ClinicalDomain.LIPID,
    "TRIGLYCERIDES": ClinicalDomain.LIPID,
    "NON_HDL_CHOLESTEROL": ClinicalDomain.LIPID,
    "REMNANT_CHOLESTEROL": ClinicalDomain.LIPID,
    "C_REACTIVE_PROTEIN": ClinicalDomain.INFLAMMATORY,
    "NEUTROPHILS_ABSOLUTE": ClinicalDomain.INFLAMMATORY,
    "LYMPHOCYTES_ABSOLUTE": ClinicalDomain.INFLAMMATORY,
    "PLATELETS": ClinicalDomain.INFLAMMATORY,
    "TSH": ClinicalDomain.THYROID,
    "FREE_T4": ClinicalDomain.THYROID,
    "DHEAS": ClinicalDomain.ADRENAL,
    "CORTISOL": ClinicalDomain.ADRENAL,
    "TESTOSTERONE_TOTAL": ClinicalDomain.GONADAL,
    "ESTRADIOL": ClinicalDomain.GONADAL,
    "SHBG": ClinicalDomain.GONADAL,
    "VITAMIN_D_25OH": ClinicalDomain.MICRONUTRIENT,
    "SELENIUM": ClinicalDomain.MICRONUTRIENT,
    "VITAMIN_B12": ClinicalDomain.MICRONUTRIENT,
    "FERRITIN": ClinicalDomain.MICRONUTRIENT,
    "WEIGHT": ClinicalDomain.BODY_COMPOSITION,
    "HEIGHT": ClinicalDomain.BODY_COMPOSITION,
    "BODY_FAT_PERCENT": ClinicalDomain.BODY_COMPOSITION,
    "FAT_MASS": ClinicalDomain.BODY_COMPOSITION,
    "FAT_FREE_MASS": ClinicalDomain.BODY_COMPOSITION,
    "SKELETAL_MUSCLE_MASS": ClinicalDomain.BODY_COMPOSITION,
    "WAIST_CIRCUMFERENCE": ClinicalDomain.BODY_COMPOSITION,
    "SLEEP_QUALITY": ClinicalDomain.SLEEP,
    "ENERGY_LEVEL": ClinicalDomain.RECOVERY,
    "GI_SYMPTOMS": ClinicalDomain.GI,
    "STRESS_LEVEL": ClinicalDomain.STRESS,
    "ENERGY_TARGET": ClinicalDomain.NUTRITION,
}


def _concept_domain(concept: str) -> str | None:
    domain = CONCEPT_DOMAIN.get(concept)
    return domain.value if domain else None


def _format_value(value: float | None, unit: str | None) -> str:
    if value is None:
        return ""
    pretty = f"{value:g}"
    return f"{pretty} {unit}".strip() if unit else pretty


def _within_as_of(value: datetime | None, as_of: datetime | None) -> bool:
    if as_of is None or value is None:
        return True
    return parse_dt(value) <= parse_dt(as_of)


class ClinicalMapBuilder:
    def __init__(self, annotations: Iterable[dict[str, Any]] | None = None) -> None:
        self.annotations = list(annotations or [])

    def build(
        self,
        run: SynthesisRunResult,
        *,
        layers: Iterable[MapLayer] | None = None,
        as_of: datetime | None = None,
        temporal_mode: str = "TODAY",
    ) -> ClinicalMapProjectionV1:
        layer_filter = set(layers) if layers else None
        nodes: dict[str, MapNodeProjection] = {}
        edges: list[MapEdgeProjection] = []

        ref_node_ids: dict[str, str] = {}

        # --- observation nodes -------------------------------------------
        for ref in run.observation_refs:
            if not self._node_in_window(ref, as_of):
                continue
            node = self._observation_node(ref)
            if layer_filter and node.layer not in layer_filter:
                continue
            nodes[node.node_id] = node
            ref_node_ids[ref.observation_ref_id] = node.node_id

        # --- derived metric nodes ----------------------------------------
        for metric in run.metrics:
            if not metric.is_valid:
                continue
            if not _within_as_of(metric.effective_at, as_of):
                continue
            node = MapNodeProjection(
                node_id=f"metric:{metric.metric_id}",
                node_type=NodeType.DERIVED_METRIC,
                layer=MapLayer.DERIVED,
                label=f"{metric.metric_definition_id} = {_format_value(metric.value, metric.unit)}",
                authority=metric.authority.value,
                domain=metric.domain,
                value=metric.value,
                unit=metric.unit,
                effective_at=to_iso(metric.effective_at),
                provenance=Provenance(
                    formula_id=metric.metric_definition_id,
                    formula_version=metric.metric_definition_version,
                    note="SYSTEM_DERIVED",
                ),
                metadata={
                    "status": metric.calculation_status.value,
                    "warnings": list(metric.warnings),
                    "input_refs": [r["observation_ref_id"] for r in metric.input_refs],
                },
            )
            if layer_filter and node.layer not in layer_filter:
                continue
            nodes[node.node_id] = node
            for input_ref in metric.input_refs:
                ref_id = input_ref.get("observation_ref_id")
                source_node = ref_node_ids.get(ref_id)
                if source_node is None:
                    continue
                edges.append(
                    MapEdgeProjection(
                        edge_id=f"edge:{source_node}->{node.node_id}:DERIVED_FROM",
                        source_node_id=source_node,
                        target_node_id=node.node_id,
                        relation=EdgeType.DERIVED_FROM,
                        layer=MapLayer.DERIVED,
                        provenance=Provenance(
                            formula_id=metric.metric_definition_id,
                            formula_version=metric.metric_definition_version,
                            note=f"computed from {input_ref.get('concept')}",
                        ),
                    )
                )

        # --- score nodes --------------------------------------------------
        for score in run.scores:
            if not score.is_valid:
                continue
            if not _within_as_of(score.effective_at, as_of):
                continue
            node = MapNodeProjection(
                node_id=f"score:{score.score_result_id}",
                node_type=NodeType.DERIVED_METRIC,
                layer=MapLayer.DERIVED,
                label=f"{score.score_id} = {_format_value(score.value, score.unit)}"
                + (f" [{score.band}]" if score.band else ""),
                authority=score.authority.value,
                domain=score.domain,
                value=score.value,
                unit=score.unit,
                effective_at=to_iso(score.effective_at),
                provenance=Provenance(
                    score_id=score.score_id,
                    score_version=score.score_version,
                    note="derived score (not a diagnosis)",
                ),
                metadata={"band": score.band, "band_interpretation": score.band_interpretation},
            )
            if layer_filter and node.layer not in layer_filter:
                continue
            nodes[node.node_id] = node

        # --- signal nodes -------------------------------------------------
        for signal in run.signals:
            if not _within_as_of(signal.generated_at, as_of):
                continue
            node = MapNodeProjection(
                node_id=f"signal:{signal.signal_id}",
                node_type=NodeType.CLINICAL_SIGNAL,
                layer=MapLayer.SIGNALS,
                label=signal.title,
                authority=signal.authority.value,
                domain=signal.domain,
                provenance=Provenance(
                    rule_id=signal.rule_id,
                    rule_version=signal.rule_version,
                    evidence_refs=list(signal.explanation.get("evidence_refs", [])),
                    note="signal candidate - not a diagnosis",
                ),
                metadata={
                    "severity": signal.severity.value,
                    "signal_type": signal.signal_type.value,
                    "status": signal.status.value,
                    "explanation": signal.explanation,
                },
            )
            if layer_filter and node.layer not in layer_filter:
                continue
            nodes[node.node_id] = node
            for supporting in signal.supporting_refs:
                target = self._supporting_node_id(supporting, ref_node_ids)
                if target is None or target not in nodes:
                    continue
                edges.append(
                    MapEdgeProjection(
                        edge_id=f"edge:{target}->{node.node_id}:SUPPORTS_SIGNAL",
                        source_node_id=target,
                        target_node_id=node.node_id,
                        relation=EdgeType.SUPPORTS_SIGNAL,
                        layer=MapLayer.SIGNALS,
                        provenance=Provenance(
                            rule_id=signal.rule_id,
                            rule_version=signal.rule_version,
                            evidence_refs=list(signal.explanation.get("evidence_refs", [])),
                            note="input referenced by rule conditions",
                        ),
                    )
                )

        # --- clinician annotations (node metadata only) ------------------
        nodes = self._attach_annotations(nodes)

        # --- prune edges whose endpoints were filtered out ----------------
        edges = [
            e
            for e in edges
            if e.source_node_id in nodes and e.target_node_id in nodes
        ]

        metadata = ClinicalMapMetadata(
            patient_id=run.patient_id,
            generation_time=to_iso(now_utc()),
            rule_versions=dict(run.rule_versions),
            formula_versions=dict(run.formula_versions),
            score_versions=dict(run.score_versions),
            knowledge_package_version=run.knowledge_package_version,
            run_id=run.run_id,
            window_start=to_iso(min((r.effective_at for r in run.observation_refs), default=None)),
            window_end=to_iso(max((r.effective_at for r in run.observation_refs), default=None)),
            temporal_mode=temporal_mode,
            layers_enabled=sorted(l.value for l in layer_filter) if layer_filter else [
                l.value for l in MapLayer
            ],
        )

        projection = ClinicalMapProjectionV1(
            contract_version=CONTRACT_VERSION,
            metadata=metadata,
            nodes=list(nodes.values()),
            edges=edges,
        )
        validate_projection(projection)
        return projection

    # -- helpers -----------------------------------------------------------
    def _observation_node(self, ref: ScientificObservationRef) -> MapNodeProjection:
        node_type, layer = self._kind_for(ref)
        label_concept = ref.label()
        return MapNodeProjection(
            node_id=f"obs:{ref.observation_ref_id}",
            node_type=node_type,
            layer=layer,
            label=f"{label_concept} {_format_value(ref.value, ref.unit)}".strip(),
            authority=ref.display_authority.value,
            domain=_concept_domain(ref.concept),
            value=ref.value,
            unit=ref.unit,
            effective_at=to_iso(ref.effective_at),
            provenance=Provenance(
                source_ref=ref.observation_ref_id,
                source_module=ref.source_module,
                source_entity_id=ref.source_entity_id,
                note=f"{ref.source_module}.{ref.source_entity_type} v{ref.source_version}",
            ),
            metadata={
                "concept": ref.concept,
                "authority": ref.authority.value,
                "fasting_status": ref.fasting_status.value,
                "provenance": ref.provenance,
            },
        )

    @staticmethod
    def _kind_for(ref: ScientificObservationRef) -> tuple[NodeType, MapLayer]:
        if ref.layer is MapLayer.PATIENT_REPORTED:
            return NodeType.QUESTIONNAIRE_DOMAIN, MapLayer.PATIENT_REPORTED
        if ref.layer is MapLayer.CLINICIAN_CONFIRMED:
            if ref.concept == "MEDICATION":
                return NodeType.MEDICATION, MapLayer.CLINICIAN_CONFIRMED
            return NodeType.DIAGNOSIS, MapLayer.CLINICIAN_CONFIRMED
        if ref.source_module == "BIOIMPEDANCE":
            return NodeType.BODY_COMPOSITION, MapLayer.OBJECTIVE
        if ref.source_module == "NUTROLOGIA":
            return NodeType.NUTRITION, MapLayer.DERIVED
        return NodeType.LAB_MARKER, MapLayer.OBJECTIVE

    @staticmethod
    def _node_in_window(ref: ScientificObservationRef, as_of: datetime | None) -> bool:
        if as_of is None or ref.effective_at is None:
            return True
        return parse_dt(ref.effective_at) <= parse_dt(as_of)

    @staticmethod
    def _supporting_node_id(
        supporting: dict[str, Any], ref_node_ids: dict[str, str]
    ) -> str | None:
        kind = supporting.get("ref_kind")
        ref_id = supporting.get("ref_id")
        if kind == "DERIVED_METRIC":
            return f"metric:{ref_id}"
        if kind == "OBSERVATION":
            return ref_node_ids.get(ref_id)
        if supporting.get("evidence_ref"):
            return None
        return None

    def _attach_annotations(
        self, nodes: dict[str, MapNodeProjection]
    ) -> dict[str, MapNodeProjection]:
        for annotation in self.annotations:
            target_id = annotation.get("target_id")
            if target_id and target_id in nodes:
                nodes[target_id].metadata.setdefault("annotations", []).append(
                    {
                        "annotation_id": annotation.get("annotation_id"),
                        "text": annotation.get("text"),
                        "author": annotation.get("author"),
                        "created_at": to_iso(annotation.get("created_at"))
                        if annotation.get("created_at")
                        else None,
                    }
                )
        return nodes


def validate_projection(projection: ClinicalMapProjectionV1) -> None:
    """Reject any orphan node or unexplained edge (TEST - MAP PROVENANCE)."""
    for node in projection.nodes:
        if not node.provenance.is_traceable():
            raise ProvenanceError(
                f"Map node {node.node_id!r} ({node.label!r}) has no traceable provenance"
            )
    node_ids = {n.node_id for n in projection.nodes}
    for edge in projection.edges:
        if edge.source_node_id not in node_ids or edge.target_node_id not in node_ids:
            raise ProvenanceError(
                f"Map edge {edge.edge_id!r} references a missing endpoint"
            )
        if not edge.provenance.is_traceable():
            raise ProvenanceError(f"Map edge {edge.edge_id!r} has no traceable provenance")
