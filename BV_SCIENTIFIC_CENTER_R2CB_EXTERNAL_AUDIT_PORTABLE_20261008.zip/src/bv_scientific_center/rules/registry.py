"""Rule registry with publication-time validation."""

from __future__ import annotations

from ..core.enums import TemporalRequirement
from ..core.expression import compile_expression
from ..core.registry import DefinitionRegistry
from ..core.units import is_known
from ..errors import ExpressionError, UnknownUnitError
from .definition import DERIVED_METRIC, OBSERVATION, ScientificClinicalRule


def validate_rule(rule: ScientificClinicalRule) -> None:
    if not rule.definition_id:
        raise ExpressionError("Rule requires a definition_id")
    if rule.combine not in {"ALL", "ANY"}:
        raise ExpressionError(f"Rule {rule.definition_id} combine must be ALL or ANY")
    if not rule.conditions:
        raise ExpressionError(f"Rule {rule.definition_id} has no conditions")

    declared = set(rule.input_names())
    for condition in rule.conditions:
        compiled = compile_expression(condition)
        undeclared = compiled.names - declared
        if undeclared:
            raise ExpressionError(
                f"Rule {rule.definition_id} condition references undeclared inputs: "
                f"{sorted(undeclared)}"
            )
    for escalation in rule.severity_escalations:
        compile_expression(escalation.expression)

    for requirement in rule.inputs:
        if requirement.source not in {OBSERVATION, DERIVED_METRIC}:
            raise ExpressionError(
                f"Rule {rule.definition_id} input {requirement.name!r} has invalid source"
            )
        if not is_known(requirement.required_unit):
            raise UnknownUnitError(
                f"Rule {rule.definition_id} input {requirement.name!r} uses unknown unit "
                f"{requirement.required_unit!r}"
            )

    if rule.temporal_requirement is TemporalRequirement.WITHIN_N_DAYS and (
        not rule.temporal_window_days or rule.temporal_window_days <= 0
    ):
        raise ExpressionError(
            f"Rule {rule.definition_id} requires a positive temporal_window_days"
        )


class RuleRegistry(DefinitionRegistry[ScientificClinicalRule]):
    def __init__(self) -> None:
        super().__init__("rule", validate_rule)
