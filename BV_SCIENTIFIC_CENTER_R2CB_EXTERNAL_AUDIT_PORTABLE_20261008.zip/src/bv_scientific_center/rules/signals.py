"""Clinical signal candidates.

A signal is a *candidate* for clinician attention. It is not a diagnostic
hypothesis and never a diagnosis. The physician reviews it; acceptance does not
create a diagnosis and writes nothing to the Prontuario.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core.enums import Authority, Severity, SignalStatus, SignalType


@dataclass
class ClinicalSignalCandidate:
    signal_id: str
    patient_id: str
    rule_id: str
    rule_version: int
    title: str
    category: str
    severity: Severity
    signal_type: SignalType
    supporting_refs: list[dict[str, Any]]
    generated_at: datetime
    explanation: dict[str, Any]
    authority: Authority = Authority.SYSTEM_DERIVED
    status: SignalStatus = SignalStatus.NEW
    run_id: str | None = None
    domain: str | None = None
    interpretation_warning: str | None = None

    def why(self) -> dict[str, Any]:
        """Answer "WHY AM I SEEING THIS?" - fully explainable, no black box."""
        return dict(self.explanation)

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


@dataclass
class SignalReview:
    signal_id: str
    status: SignalStatus
    note: str | None = None
    reviewer: str | None = None
    reviewed_at: datetime | None = None
    history: list[dict[str, Any]] = field(default_factory=list)
