"""Scientific clinical rule definitions (signal generation).

A rule is declarative. It never contains executable code: conditions are
constrained boolean expressions evaluated by
:mod:`bv_scientific_center.core.expression`. A rule produces a
:class:`~bv_scientific_center.rules.signals.ClinicalSignalCandidate`, which is
explicitly *not* a diagnosis.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..core.definition import VersionedDefinition
from ..core.enums import DefinitionStatus, Severity, SignalType, TemporalRequirement

OBSERVATION = "OBSERVATION"
DERIVED_METRIC = "DERIVED_METRIC"


@dataclass(frozen=True)
class RuleInput:
    name: str
    ref: str                        # concept (observation) or metric definition id
    source: str = OBSERVATION
    required_unit: str = "1"
    required: bool = True
    requires_confirmed_source: bool = False
    label: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "RuleInput":
        return cls(
            name=data["name"],
            ref=data.get("ref", data["name"]),
            source=data.get("source", OBSERVATION),
            required_unit=data.get("required_unit", "1"),
            required=bool(data.get("required", True)),
            requires_confirmed_source=bool(data.get("requires_confirmed_source", False)),
            label=data.get("label"),
        )


@dataclass(frozen=True)
class RuleSeverityEscalation:
    expression: str
    severity: Severity

    @classmethod
    def from_dict(cls, data: dict) -> "RuleSeverityEscalation":
        from ..core.definition import coerce_enum

        return cls(
            expression=data["expression"],
            severity=coerce_enum(Severity, data.get("severity", "INFO")),
        )


@dataclass(frozen=True)
class ScientificClinicalRule(VersionedDefinition):
    inputs: tuple[RuleInput, ...] = ()
    conditions: tuple[str, ...] = ()
    combine: str = "ALL"            # ALL | ANY
    signal_type: SignalType = SignalType.OBSERVATION_FLAG
    severity: Severity = Severity.INFO
    severity_escalations: tuple[RuleSeverityEscalation, ...] = ()
    explanation_template: str = ""
    category: str = ""
    domain: str | None = None
    temporal_requirement: TemporalRequirement = TemporalRequirement.LATEST_AVAILABLE
    temporal_window_days: int | None = None
    population_constraints: dict[str, list[str]] = field(default_factory=dict)
    interpretation_warning: str | None = None
    tags: tuple[str, ...] = ()
    test_rule: bool = False         # marks synthetic/architecture-validation rules

    def input_names(self) -> tuple[str, ...]:
        return tuple(i.name for i in self.inputs)

    @classmethod
    def from_dict(cls, data: dict) -> "ScientificClinicalRule":
        from ..core.definition import coerce_enum

        return cls(
            definition_id=data["definition_id"],
            name=data.get("name", data["definition_id"]),
            version=int(data.get("version", 1)),
            description=data.get("description", ""),
            status=coerce_enum(DefinitionStatus, data.get("status", "DRAFT")),
            evidence_refs=tuple(data.get("evidence_refs", ())),
            metadata=dict(data.get("metadata", {})),
            inputs=tuple(RuleInput.from_dict(i) for i in data.get("inputs", ())),
            conditions=tuple(data.get("conditions", ())),
            combine=data.get("combine", "ALL"),
            signal_type=coerce_enum(SignalType, data.get("signal_type", "OBSERVATION_FLAG")),
            severity=coerce_enum(Severity, data.get("severity", "INFO")),
            severity_escalations=tuple(
                RuleSeverityEscalation.from_dict(e)
                for e in data.get("severity_escalations", ())
            ),
            explanation_template=data.get("explanation_template", ""),
            category=data.get("category", ""),
            domain=data.get("domain"),
            temporal_requirement=coerce_enum(
                TemporalRequirement, data.get("temporal_requirement", "LATEST_AVAILABLE")
            ),
            temporal_window_days=data.get("temporal_window_days"),
            population_constraints=dict(data.get("population_constraints", {})),
            interpretation_warning=data.get("interpretation_warning"),
            tags=tuple(data.get("tags", ())),
            test_rule=bool(data.get("test_rule", False)),
        )
