"""Scientific clinical rule engine (signal generation)."""
