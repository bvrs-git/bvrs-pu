"""Rule engine: turns declarative rules into explainable signal candidates.

The engine performs the same safety gates as the formula engine (presence,
source authority, unit compatibility, temporal alignment) and then evaluates the
rule's constrained boolean conditions. Failures to resolve inputs do not raise:
the rule is simply not evaluated and the reason is recorded.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core import ids
from ..core.context import EvaluationContext
from ..core.enums import (
    Authority,
    Severity,
    SignalStatus,
    TemporalRequirement,
    is_confirmed_authority,
)
from ..core.expression import ExpressionError, compile_expression
from ..core.timeutil import now_utc, parse_dt
from ..core.units import convert, is_known, same_dimension
from ..errors import UnitConversionError, UnknownUnitError
from ..formulas.alignment import align_inputs
from ..formulas.engine import DerivedClinicalMetric
from ..observations.refs import ScientificObservationRef
from .definition import DERIVED_METRIC, OBSERVATION, ScientificClinicalRule
from .signals import ClinicalSignalCandidate


@dataclass(frozen=True)
class RuleCandidate:
    ref_id: str
    ref_kind: str
    label: str
    value: float
    unit: str
    effective_at: datetime
    source_module: str
    source_entity_id: str
    authority: str
    is_confirmed: bool
    concept: str
    laboratory: str | None
    method: str | None
    snapshot: dict[str, Any]


@dataclass
class RuleEvaluation:
    rule_id: str
    rule_version: int
    evaluated: bool
    matched: bool
    reason: str
    signal: ClinicalSignalCandidate | None = None
    inputs: list[dict[str, Any]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Candidate construction
# ---------------------------------------------------------------------------
def _observation_candidate(ref: ScientificObservationRef) -> RuleCandidate:
    return RuleCandidate(
        ref_id=ref.observation_ref_id,
        ref_kind=OBSERVATION,
        label=ref.label(),
        value=float(ref.value),
        unit=ref.unit,
        effective_at=parse_dt(ref.effective_at),
        source_module=ref.source_module,
        source_entity_id=ref.source_entity_id,
        authority=ref.authority.value,
        is_confirmed=is_confirmed_authority(ref.authority),
        concept=ref.concept,
        laboratory=ref.provenance.get("laboratory"),
        method=ref.provenance.get("method"),
        snapshot=ref.snapshot(),
    )


def _metric_candidate(metric: DerivedClinicalMetric) -> RuleCandidate:
    return RuleCandidate(
        ref_id=metric.metric_id,
        ref_kind=DERIVED_METRIC,
        label=metric.metric_definition_id,
        value=float(metric.value),
        unit=metric.unit,
        effective_at=parse_dt(metric.effective_at),
        source_module="SCIENTIFIC_CENTER",
        source_entity_id=metric.metric_id,
        authority=metric.authority.value,
        is_confirmed=False,  # a derived metric is never a confirmed source
        concept=metric.metric_definition_id,
        laboratory=None,
        method=None,
        snapshot={
            "metric_id": metric.metric_id,
            "definition": metric.metric_definition_id,
            "version": metric.metric_definition_version,
            "value": metric.value,
            "unit": metric.unit,
        },
    )


def _unit_compatible(candidate: RuleCandidate, required_unit: str) -> bool:
    if not is_known(candidate.unit):
        return False
    try:
        return same_dimension(candidate.unit, required_unit)
    except UnknownUnitError:
        return False


def _render(template: str, inputs: list[dict[str, Any]]) -> str:
    if not template:
        return ""
    rendered = template
    for item in inputs:
        name = item["name"]
        value = item["value"]
        unit = item["unit"]
        pretty = f"{value:g}" if isinstance(value, (int, float)) else str(value)
        rendered = rendered.replace("{" + f"{name}" + "}", pretty)
        rendered = rendered.replace("{" + f"{name}_unit" + "}", str(unit or ""))
        rendered = rendered.replace("{" + f"{name}_label" + "}", str(item.get("label") or name))
    return rendered


def evaluate_rule(
    rule: ScientificClinicalRule,
    *,
    patient_id: str,
    observations_by_concept: dict[str, list[ScientificObservationRef]] | None = None,
    metrics_by_definition: dict[str, list[DerivedClinicalMetric]] | None = None,
    context: EvaluationContext | None = None,
    generated_at: datetime | None = None,
    run_id: str | None = None,
) -> RuleEvaluation:
    observations_by_concept = observations_by_concept or {}
    metrics_by_definition = metrics_by_definition or {}
    generated_at = generated_at or now_utc()

    candidates_by_name: dict[str, list[RuleCandidate]] = {}
    missing: list[str] = []
    for requirement in rule.inputs:
        if requirement.source == DERIVED_METRIC:
            metrics = [
                m
                for m in metrics_by_definition.get(requirement.ref, [])
                if m.is_valid and m.value is not None
            ]
            candidates = [_metric_candidate(m) for m in metrics]
        else:
            refs = [
                r
                for r in observations_by_concept.get(requirement.ref, [])
                if r.value is not None
            ]
            candidates = [_observation_candidate(r) for r in refs]

        if requirement.requires_confirmed_source:
            candidates = [c for c in candidates if c.is_confirmed]
        candidates = [c for c in candidates if _unit_compatible(c, requirement.required_unit)]

        if not candidates:
            if requirement.required:
                missing.append(requirement.name)
            continue
        candidates_by_name[requirement.name] = candidates

    if missing:
        return RuleEvaluation(
            rule_id=rule.definition_id,
            rule_version=rule.version,
            evaluated=False,
            matched=False,
            reason=f"missing required input(s): {', '.join(missing)}",
        )

    # Temporal alignment across inputs. RuleCandidate duck-types the fields the
    # generic aligner needs (effective_at, source_entity_id, source_module).
    variables: dict[str, float] = {}
    input_values: list[dict[str, Any]] = []
    warnings: list[str] = []

    alignment = align_inputs(
        candidates_by_name, rule.temporal_requirement, rule.temporal_window_days
    )
    if not alignment.ok:
        return RuleEvaluation(
            rule_id=rule.definition_id,
            rule_version=rule.version,
            evaluated=False,
            matched=False,
            reason=alignment.reason,
        )
    chosen = alignment.mapping

    for name, candidate in chosen.items():
        requirement = next(i for i in rule.inputs if i.name == name)
        try:
            normalized = convert(candidate.value, candidate.unit, requirement.required_unit)
        except (UnitConversionError, UnknownUnitError):
            return RuleEvaluation(
                rule_id=rule.definition_id,
                rule_version=rule.version,
                evaluated=False,
                matched=False,
                reason=f"cannot convert input {name!r} to {requirement.required_unit!r}",
            )
        variables[name] = normalized
        conversion_applied = candidate.unit != requirement.required_unit
        if conversion_applied:
            warnings.append(f"UNIT_CONVERSION_APPLIED ({name}:{candidate.unit}->{requirement.required_unit})")
        input_values.append(
            {
                "name": name,
                "label": requirement.label or name,
                "concept": candidate.concept,
                "value": normalized,
                "unit": requirement.required_unit,
                "original_value": candidate.value,
                "original_unit": candidate.unit,
                "effective_at": candidate.effective_at.isoformat(),
                "ref_id": candidate.ref_id,
                "ref_kind": candidate.ref_kind,
                "source_module": candidate.source_module,
                "authority": candidate.authority,
                "laboratory": candidate.laboratory,
            }
        )

    # Evaluate conditions.
    try:
        results = [bool(compile_expression(c).evaluate(variables)) for c in rule.conditions]
    except ExpressionError as exc:
        return RuleEvaluation(
            rule_id=rule.definition_id,
            rule_version=rule.version,
            evaluated=False,
            matched=False,
            reason=f"condition error: {exc}",
        )

    matched = all(results) if rule.combine == "ALL" else any(results)
    if not matched:
        return RuleEvaluation(
            rule_id=rule.definition_id,
            rule_version=rule.version,
            evaluated=True,
            matched=False,
            reason="conditions not met",
            inputs=input_values,
        )

    severity = rule.severity
    for escalation in rule.severity_escalations:
        try:
            if bool(compile_expression(escalation.expression).evaluate(variables)):
                severity = escalation.severity
        except ExpressionError:
            continue

    explanation = {
        "rule": rule.definition_id,
        "rule_version": rule.version,
        "signal_type": rule.signal_type.value,
        "category": rule.category,
        "combine": rule.combine,
        "conditions": list(rule.conditions),
        "inputs": input_values,
        "evidence_refs": list(rule.evidence_refs),
        "severity": severity.value,
        "warnings": warnings + ([rule.interpretation_warning] if rule.interpretation_warning else []),
        "rendered": _render(rule.explanation_template, input_values),
        "is_test_rule": rule.test_rule,
        "authority": Authority.SYSTEM_DERIVED.value,
        "disclaimer": "Signal candidate for clinician review. Not a diagnosis.",
    }

    signal = ClinicalSignalCandidate(
        signal_id=ids.signal_id(),
        patient_id=patient_id,
        rule_id=rule.definition_id,
        rule_version=rule.version,
        title=rule.name or rule.definition_id,
        category=rule.category or (rule.domain or "GENERAL"),
        severity=severity,
        signal_type=rule.signal_type,
        supporting_refs=(
            [i for i in input_values]
            + [{"evidence_ref": e} for e in rule.evidence_refs]
        ),
        generated_at=generated_at,
        explanation=explanation,
        authority=Authority.SYSTEM_DERIVED,
        status=SignalStatus.NEW,
        run_id=run_id,
        domain=rule.domain,
        interpretation_warning=rule.interpretation_warning,
    )
    return RuleEvaluation(
        rule_id=rule.definition_id,
        rule_version=rule.version,
        evaluated=True,
        matched=True,
        reason="matched",
        signal=signal,
        inputs=input_values,
    )
