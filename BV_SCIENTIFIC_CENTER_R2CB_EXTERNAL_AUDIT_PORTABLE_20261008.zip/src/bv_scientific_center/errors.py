"""Typed exceptions for the Scientific Center.

Errors are split into two families:

* *Programming / contract violations* - raised (bugs, malformed packages,
  forbidden constructs). These must fail loudly.
* *Clinical computation outcomes* - NOT raised. They are returned as a
  :class:`CalculationStatus` on the result so that no silent computation
  happens and the UI can display the refusal reason explicitly.
"""

from __future__ import annotations


class ScientificCenterError(Exception):
    """Base class for all Scientific Center errors."""


# --------------------------------------------------------------------------
# Contract / programming errors
# --------------------------------------------------------------------------
class ContractViolation(ScientificCenterError):
    """An input projection or outward DTO violated its contract."""


class UnknownUnitError(ScientificCenterError):
    """A unit symbol is not present in the unit registry."""


class UnitConversionError(ScientificCenterError):
    """An explicit conversion between two units is not defined."""


class ImmutablePublishError(ScientificCenterError):
    """Attempted mutation of a published (immutable) version."""


class ExpressionError(ScientificCenterError):
    """A formula/score/rule expression is invalid or uses forbidden syntax."""


class PackageSecurityError(ScientificCenterError):
    """An imported knowledge package contains forbidden/unsafe content."""


class PackageValidationError(ScientificCenterError):
    """A knowledge package failed structural validation."""


class DuplicateDefinitionError(ScientificCenterError):
    """A definition id+version already exists with different content."""


class CitationRequiredError(ScientificCenterError):
    """A knowledge item cannot reach APPROVED without a real citation."""


class KnowledgeGovernanceError(ScientificCenterError):
    """A knowledge governance rule was violated (e.g. approving synthetic content)."""


class ProvenanceError(ScientificCenterError):
    """A required provenance link (node/edge/claim) is missing."""


class IngestionConflictError(ContractViolation):
    """An observation with the same stable identity already exists with
    divergent content. Silent overwrite is forbidden; the caller must either
    correct the source (bumping ``source_version``) or request an explicit
    revision.
    """


class NaiveTimestampError(ContractViolation):
    """A clinical timestamp was supplied without timezone information.

    Clinical chronology must never be altered by silently assuming a zone.
    """


# --------------------------------------------------------------------------
# R2A - scientific curation and evidence governance
# --------------------------------------------------------------------------
class BackupVerificationError(ScientificCenterError):
    """A database backup failed integrity verification and was rejected."""


class CurationError(ScientificCenterError):
    """Base class for curation workflow violations."""


class CurationTransitionError(CurationError):
    """A curation status transition is not allowed."""


class CurationApprovalError(CurationError):
    """Approval attempted without a human reviewer, justification or version."""


class DuplicateReferenceError(ScientificCenterError):
    """A scientific reference with the same stable identifier already exists."""


class MetadataConflictError(ScientificCenterError):
    """Existing identifier metadata differs from the incoming metadata."""


class EvidenceGovernanceError(ScientificCenterError):
    """An evidence/reference governance rule was violated (e.g. synthetic
    content approved, or retracted evidence presented as current)."""
