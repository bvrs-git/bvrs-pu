"""Clinical synthesis run.

A run is the reproducible unit of computation: it records the input snapshot,
the formula/score/rule versions used, the knowledge package version and the
timestamps. Historical results are never rewritten - a knowledge update creates a
new run.

R1.1 hardening:

* **Patient isolation (fail-closed):** every ingested reference must belong to the
  run's ``patient_id``; a mismatch aborts the run before any data is written.
* **Fail-closed execution:** computation happens *before* persistence. If any
  step fails, no partial derived data is written and a ``FAILED`` run record is
  stored for audit, then the exception is re-raised.
* **Deterministic reconstruction:** :meth:`SynthesisRunner.reconstruct_run` rebuilds
  a run from persisted state so the clinical map of a stored run is reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Iterable

from ..core import ids
from ..core.context import EvaluationContext
from ..core.enums import (
    Authority,
    Severity,
    SignalStatus,
    SignalType,
    SynthesisRunStatus,
)
from ..core.serialization import dump
from ..core.timeutil import now_utc, parse_dt, to_iso
from ..errors import ContractViolation
from ..events.bus import EventBus
from ..formulas.engine import DerivedClinicalMetric, compute_metric
from ..formulas.registry import FormulaRegistry
from ..observations.refs import ProjectionIngestor, ScientificObservationRef
from ..rules.engine import RuleEvaluation, evaluate_rule
from ..rules.registry import RuleRegistry
from ..rules.signals import ClinicalSignalCandidate
from ..scores.engine import ClinicalScoreResult, compute_score
from ..scores.registry import ScoreRegistry
from ..storage.repositories import (
    DerivedMetricRepository,
    ObservationRepository,
    ScoreResultRepository,
    SignalRepository,
    SynthesisRunRepository,
)


@dataclass
class SynthesisRunResult:
    run_id: str
    patient_id: str
    status: SynthesisRunStatus
    started_at: datetime
    completed_at: datetime | None = None
    knowledge_package_version: str | None = None
    observation_refs: list[ScientificObservationRef] = field(default_factory=list)
    metrics: list[DerivedClinicalMetric] = field(default_factory=list)
    scores: list[ClinicalScoreResult] = field(default_factory=list)
    signals: list[ClinicalSignalCandidate] = field(default_factory=list)
    rule_evaluations: list[RuleEvaluation] = field(default_factory=list)
    formula_versions: dict[str, int] = field(default_factory=dict)
    score_versions: dict[str, int] = field(default_factory=dict)
    rule_versions: dict[str, int] = field(default_factory=dict)

    @property
    def valid_metrics(self) -> list[DerivedClinicalMetric]:
        return [m for m in self.metrics if m.is_valid]

    @property
    def valid_scores(self) -> list[ClinicalScoreResult]:
        return [s for s in self.scores if s.is_valid]

    def logical_fingerprint(self) -> str:
        """Content identity of the derived result, independent of execution id.

        Two runs over the same inputs and versions share this fingerprint even
        though their ``run_id`` differs.
        """
        from ..core.definition import content_hash

        return content_hash(
            {
                "patient_id": self.patient_id,
                "formula_versions": dict(self.formula_versions),
                "score_versions": dict(self.score_versions),
                "rule_versions": dict(self.rule_versions),
                "metrics": sorted(
                    (
                        m.metric_definition_id,
                        m.metric_definition_version,
                        None if m.value is None else round(m.value, 9),
                        m.unit,
                        m.calculation_status.value,
                    )
                    for m in self.metrics
                ),
                "scores": sorted(
                    (s.score_id, s.score_version, None if s.value is None else round(s.value, 9), s.band)
                    for s in self.scores
                ),
                "signals": sorted(
                    (s.rule_id, s.rule_version, s.severity.value, s.title) for s in self.signals
                ),
            }
        )

    def to_dict(self) -> dict[str, Any]:
        return dump(self)


class SynthesisRunner:
    def __init__(
        self,
        *,
        formulas: FormulaRegistry,
        scores: ScoreRegistry,
        rules: RuleRegistry,
        observations: ObservationRepository | None = None,
        metrics: DerivedMetricRepository | None = None,
        score_results: ScoreResultRepository | None = None,
        signals: SignalRepository | None = None,
        runs: SynthesisRunRepository | None = None,
        event_bus: EventBus | None = None,
        database: Any | None = None,
        knowledge_package_version: str | None = None,
    ) -> None:
        self.formulas = formulas
        self.scores = scores
        self.rules = rules
        self.observations = observations
        self.metrics = metrics
        self.score_results = score_results
        self.signals = signals
        self.runs = runs
        self.event_bus = event_bus or EventBus()
        self.database = database
        self.knowledge_package_version = knowledge_package_version

    # -- public API --------------------------------------------------------
    def run(
        self,
        patient_id: str,
        projections: Iterable[Any] = (),
        *,
        observation_refs: Iterable[ScientificObservationRef] | None = None,
        context: EvaluationContext | None = None,
        persist: bool = True,
    ) -> SynthesisRunResult:
        run_id = ids.run_id()
        started_at = now_utc()
        context = context or EvaluationContext()

        try:
            refs = self._ingest(patient_id, projections, observation_refs)
            result = self._compute(patient_id, run_id, started_at, refs, context)
            if persist:
                self._persist(result)
        except Exception as exc:  # noqa: BLE001 - fail-closed, record and re-raise
            self._record_failure(run_id, patient_id, started_at, exc, persist)
            raise

        self._emit(result)
        return result

    # -- pipeline stages ---------------------------------------------------
    def _ingest(
        self,
        patient_id: str,
        projections: Iterable[Any],
        observation_refs: Iterable[ScientificObservationRef] | None,
    ) -> list[ScientificObservationRef]:
        refs: list[ScientificObservationRef] = list(observation_refs or [])
        if projections:
            refs.extend(ProjectionIngestor().ingest_many(projections))
        foreign = sorted({r.patient_id for r in refs if r.patient_id != patient_id})
        if foreign:
            raise ContractViolation(
                f"patient isolation violation: run patient_id={patient_id!r} but received "
                f"references for {foreign}"
            )
        return refs

    def _compute(
        self,
        patient_id: str,
        run_id: str,
        started_at: datetime,
        refs: list[ScientificObservationRef],
        context: EvaluationContext,
    ) -> SynthesisRunResult:
        result = SynthesisRunResult(
            run_id=run_id,
            patient_id=patient_id,
            status=SynthesisRunStatus.STARTED,
            started_at=started_at,
            knowledge_package_version=self.knowledge_package_version,
            observation_refs=refs,
        )
        refs_by_concept = _group_by_concept(refs)

        for formula in self.formulas.all_latest():
            if not formula.is_usable:
                continue
            metric = compute_metric(
                formula, refs_by_concept, patient_id=patient_id, context=context
            )
            result.metrics.append(metric)
            result.formula_versions[formula.definition_id] = formula.version

        for score in self.scores.all_latest():
            if not score.is_usable:
                continue
            result.scores.append(
                compute_score(score, refs_by_concept, patient_id=patient_id, context=context)
            )
            result.score_versions[score.definition_id] = score.version

        metrics_by_definition = _group_metrics(result.metrics)
        for rule in self.rules.all_latest():
            if not rule.is_usable:
                continue
            evaluation = evaluate_rule(
                rule,
                patient_id=patient_id,
                observations_by_concept=refs_by_concept,
                metrics_by_definition=metrics_by_definition,
                context=context,
                generated_at=started_at,
                run_id=run_id,
            )
            result.rule_evaluations.append(evaluation)
            result.rule_versions[rule.definition_id] = rule.version
            if evaluation.signal is not None:
                result.signals.append(evaluation.signal)

        result.completed_at = now_utc()
        result.status = SynthesisRunStatus.COMPLETED
        return result

    def _persist(self, result: SynthesisRunResult) -> None:
        """Persist the whole run as one transactional unit (derived.db).

        Observations, metrics, score results, signals and the run record are
        written inside a single ``BEGIN IMMEDIATE ... COMMIT``. If any write
        fails the transaction rolls back, leaving the previous state intact; the
        failure is then recorded separately (see ``_record_failure``).
        """
        if self.database is not None:
            with self.database.transaction("clinical"):
                self._write_rows(result, commit=False)
            return
        self._write_rows(result, commit=True)

    def _write_rows(self, result: SynthesisRunResult, *, commit: bool) -> None:
        if self.observations is not None:
            self.observations.save_many(result.observation_refs, commit=commit)
        if self.metrics is not None:
            for metric in result.metrics:
                self.metrics.save(metric, result.run_id, commit=commit)
        if self.score_results is not None:
            for score in result.scores:
                self.score_results.save(score, result.run_id, commit=commit)
        if self.signals is not None:
            for signal in result.signals:
                self.signals.save(signal, result.run_id, commit=commit)
        if self.runs is not None:
            self.runs.save(self._run_record(result), commit=commit)

    def _emit(self, result: SynthesisRunResult) -> None:
        for metric in result.valid_metrics:
            self.event_bus.emit(
                "DerivedMetricComputed",
                payload={
                    "metric_id": metric.metric_id,
                    "definition": metric.metric_definition_id,
                    "version": metric.metric_definition_version,
                    "value": metric.value,
                    "unit": metric.unit,
                },
                patient_id=result.patient_id,
                run_id=result.run_id,
            )
        for signal in result.signals:
            self.event_bus.emit(
                "ClinicalSignalGenerated",
                payload={
                    "signal_id": signal.signal_id,
                    "rule": signal.rule_id,
                    "rule_version": signal.rule_version,
                    "severity": signal.severity.value,
                },
                patient_id=result.patient_id,
                run_id=result.run_id,
            )
        self.event_bus.emit(
            "SynthesisRunCompleted",
            payload={
                "run_id": result.run_id,
                "metrics": len(result.metrics),
                "scores": len(result.scores),
                "signals": len(result.signals),
            },
            patient_id=result.patient_id,
            run_id=result.run_id,
        )

    def _record_failure(
        self,
        run_id: str,
        patient_id: str,
        started_at: datetime,
        exc: Exception,
        persist: bool,
    ) -> None:
        if not persist or self.runs is None:
            return
        try:
            self.runs.save(
                {
                    "run_id": run_id,
                    "patient_id": patient_id,
                    "knowledge_package_version": self.knowledge_package_version,
                    "input_snapshot": [],
                    "formula_versions": {},
                    "score_versions": {},
                    "rule_versions": {},
                    "started_at": to_iso(started_at),
                    "completed_at": to_iso(now_utc()),
                    "status": SynthesisRunStatus.FAILED.value,
                    "meta": {"error_type": type(exc).__name__, "error": str(exc)},
                },
                commit=True,
            )
        except Exception:  # pragma: no cover - best-effort audit
            pass

    # -- helpers -----------------------------------------------------------
    def _run_record(self, result: SynthesisRunResult) -> dict[str, Any]:
        return {
            "run_id": result.run_id,
            "patient_id": result.patient_id,
            "knowledge_package_version": result.knowledge_package_version,
            "input_snapshot": [ref.snapshot() for ref in result.observation_refs],
            "formula_versions": result.formula_versions,
            "score_versions": result.score_versions,
            "rule_versions": result.rule_versions,
            "started_at": to_iso(result.started_at),
            "completed_at": to_iso(result.completed_at),
            "status": result.status.value,
            "meta": {
                "observation_ref_ids": [ref.observation_ref_id for ref in result.observation_refs],
                "metric_ids": [m.metric_id for m in result.metrics],
                "signal_ids": [s.signal_id for s in result.signals],
            },
        }

    # -- deterministic reconstruction -------------------------------------
    @classmethod
    def reconstruct_run(
        cls,
        run_record: dict[str, Any],
        *,
        refs: Iterable[ScientificObservationRef],
        metrics: Iterable[DerivedClinicalMetric],
        score_rows: Iterable[dict[str, Any]],
        signal_rows: Iterable[dict[str, Any]],
    ) -> SynthesisRunResult:
        """Rebuild a run from persisted state (stable ids -> deterministic map)."""
        return SynthesisRunResult(
            run_id=run_record["run_id"],
            patient_id=run_record["patient_id"],
            status=SynthesisRunStatus(run_record.get("status", "COMPLETED")),
            started_at=parse_dt(run_record.get("started_at")) or now_utc(),
            completed_at=parse_dt(run_record.get("completed_at")),
            knowledge_package_version=run_record.get("knowledge_package_version"),
            observation_refs=list(refs),
            metrics=list(metrics),
            scores=[_score_from_row(row) for row in score_rows],
            signals=[_signal_from_row(row) for row in signal_rows],
            formula_versions=dict(run_record.get("formula_versions", {})),
            score_versions=dict(run_record.get("score_versions", {})),
            rule_versions=dict(run_record.get("rule_versions", {})),
        )


def _group_by_concept(
    refs: Iterable[ScientificObservationRef],
) -> dict[str, list[ScientificObservationRef]]:
    grouped: dict[str, list[ScientificObservationRef]] = {}
    for ref in refs:
        grouped.setdefault(ref.concept, []).append(ref)
    return grouped


def _group_metrics(
    metrics: Iterable[DerivedClinicalMetric],
) -> dict[str, list[DerivedClinicalMetric]]:
    grouped: dict[str, list[DerivedClinicalMetric]] = {}
    for metric in metrics:
        grouped.setdefault(metric.metric_definition_id, []).append(metric)
    return grouped


def _score_from_row(row: dict[str, Any]) -> ClinicalScoreResult:
    from ..core.enums import CalculationStatus
    from ..core.serialization import loads

    return ClinicalScoreResult(
        score_result_id=row["score_result_id"],
        patient_id=row["patient_id"],
        score_id=row["score_id"],
        score_version=row["score_version"],
        value=row["value"],
        unit=row["unit"],
        band=row["band"],
        band_interpretation=row["band_interpretation"],
        computed_at=parse_dt(row["computed_at"]) or now_utc(),
        effective_at=parse_dt(row["effective_at"]) if row["effective_at"] else None,
        calculation_status=CalculationStatus(row["calculation_status"]),
        authority=Authority(row["authority"]),
        inputs=loads(row["inputs"]) if row.get("inputs") else [],
        warnings=loads(row["warnings"]) if row.get("warnings") else [],
        refusal_reason=row.get("refusal_reason"),
        domain=row.get("domain"),
    )


def _signal_from_row(row: dict[str, Any]) -> ClinicalSignalCandidate:
    return ClinicalSignalCandidate(
        signal_id=row["signal_id"],
        patient_id=row["patient_id"],
        rule_id=row["rule_id"],
        rule_version=row["rule_version"],
        title=row["title"],
        category=row["category"],
        severity=Severity(row["severity"]),
        signal_type=SignalType(row["signal_type"]),
        supporting_refs=row.get("supporting_refs", []),
        generated_at=parse_dt(row["generated_at"]) or now_utc(),
        explanation=row.get("explanation", {}),
        authority=Authority(row["authority"]),
        status=SignalStatus(row["status"]),
        run_id=row.get("run_id"),
        domain=row.get("domain"),
        interpretation_warning=row.get("interpretation_warning"),
    )
