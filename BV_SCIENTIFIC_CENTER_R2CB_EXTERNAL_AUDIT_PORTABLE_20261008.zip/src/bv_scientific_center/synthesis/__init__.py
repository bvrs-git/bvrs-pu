"""Clinical synthesis runs (reproducible orchestration)."""
