"""Conservative, citation-grounded extraction from acquired scientific content.

Automated extraction is NOT human critical review. Every extracted field records
the exact verbatim span it came from and the SHA-256 of the source consulted, so
the mapping can be re-checked deterministically. Fields that cannot be grounded
in the consulted text are marked ``INSUFFICIENT_INFORMATION`` and never invented.

Only deterministic, documented rules are applied. Numeric results are never
fabricated; a span is stored only when it literally occurs in the source.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core import ids
from ..core.enums import AppraisalFieldProvenance
from ..core.timeutil import now_utc

EXTRACTION_VERSION = "r2cb-2"

# Appraisal fields considered by the extractor.
TARGET_FIELDS = (
    "scientific_question",
    "study_design",
    "population",
    "sample_size",
    "reference_method",
    "outcomes",
    "quantitative_results",
    "confidence_intervals",
    "limitations",
    "clinical_applicability",
    "author_conclusions",
)

_SECTION = re.compile(r"<h4>(.*?)</h4>", re.IGNORECASE)
_TAGS = re.compile(r"<[^>]+>")

# Inline section markers (some abstracts embed sections as "Introduction: ..." text).
_INLINE_MARKER = re.compile(
    r"(?:(?<=^)|(?<=\s))"
    r"(Introduction|Background(?: & aims)?|Objectives?|Aims?|Purpose|Materials and methods|"
    r"Methods?|Results|Findings|Conclusions?|Discussion)\s*:\s*",
    re.IGNORECASE,
)

_DESIGN_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("SYSTEMATIC_REVIEW", re.compile(r"systematic review", re.IGNORECASE)),
    ("META_ANALYSIS", re.compile(r"meta-?analys[ie]s", re.IGNORECASE)),
    ("RANDOMIZED_CONTROLLED_TRIAL", re.compile(r"randomi[sz]ed controlled", re.IGNORECASE)),
    ("CROSS_SECTIONAL", re.compile(r"cross-sectional|cross sectional", re.IGNORECASE)),
    ("CASE_CONTROL", re.compile(r"case-control|case control", re.IGNORECASE)),
    ("COHORT", re.compile(r"\bcohort\b", re.IGNORECASE)),
    ("INSTRUMENT_VALIDATION", re.compile(r"validity and reliability|validation study", re.IGNORECASE)),
    ("LONGITUDINAL", re.compile(r"\blongitudinal\b", re.IGNORECASE)),
)

_METHOD_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("bioelectrical impedance analysis", re.compile(r"bioelectrical impedance analysis|\bBIA\b")),
    ("skinfold thickness", re.compile(r"skinfold", re.IGNORECASE)),
    ("dual-energy X-ray absorptiometry", re.compile(r"dual[- ]energy x[- ]ray absorptiometry|\bDXA\b")),
    ("air displacement plethysmography", re.compile(r"air[- ]displacement", re.IGNORECASE)),
    ("standardized measuring protocol", re.compile(r"standardized measuring protocol", re.IGNORECASE)),
    ("anthropometric techniques", re.compile(r"anthropometric techniques", re.IGNORECASE)),
)

_SAMPLE_SIZE = re.compile(
    r"\b(\d[\d,\.]*)\s+([A-Za-z][A-Za-z\- ]{3,60}?"
    r"(?:students|adults|adolescents|children|participants|men|women|people|subjects|patients|individuals))",
    re.IGNORECASE,
)

_QUESTION_KEYS = ("purpose", "aim", "objective", "background", "introduction")
_CONCLUSION_KEYS = ("conclusion",)
_RESULTS_KEYS = ("results", "findings")


@dataclass
class ExtractedField:
    name: str
    value: str | None
    locator: str | None
    verbatim: str | None
    provenance: AppraisalFieldProvenance
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "locator": self.locator,
            "verbatim": self.verbatim,
            "provenance": self.provenance.value,
            "note": self.note,
        }


@dataclass
class ContentExtraction:
    reference_id: str
    content_id: str | None
    source_kind: str
    source_sha256: str
    extraction_version: str = EXTRACTION_VERSION
    fields: dict[str, ExtractedField] = field(default_factory=dict)
    created_at: datetime = field(default_factory=now_utc)

    @property
    def extraction_id(self) -> str:
        # Stable identity: same source + version → same row (idempotent replay).
        return ids.stable_id("XTR", self.reference_id, self.extraction_version, self.source_sha256)

    def pending_fields(self) -> list[str]:
        return [
            name
            for name, f in self.fields.items()
            if f.provenance is AppraisalFieldProvenance.INSUFFICIENT_INFORMATION
        ]

    def to_dict(self) -> dict[str, Any]:
        return {
            "extraction_id": self.extraction_id,
            "reference_id": self.reference_id,
            "content_id": self.content_id,
            "source_kind": self.source_kind,
            "source_sha256": self.source_sha256,
            "extraction_version": self.extraction_version,
            "fields": {name: f.to_dict() for name, f in self.fields.items()},
            "pending_fields": self.pending_fields(),
            "created_at": self.created_at.isoformat(),
        }


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", _TAGS.sub(" ", text)).strip()


def _sections(text: str) -> list[tuple[str, str]]:
    """Split an HTML-ish abstract into (heading, cleaned body) sections.

    Handles both ``<h4>``-delimited abstracts and abstracts that embed sections
    inline (e.g. ``Introduction: ... Methods: ...``).
    """
    matches = list(_SECTION.finditer(text))
    if not matches:
        raw: list[tuple[str, str]] = [("abstract", _clean(text))]
    else:
        raw = []
        for index, match in enumerate(matches):
            start = match.end()
            end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
            raw.append((_clean(match.group(1)), _clean(text[start:end])))

    sections: list[tuple[str, str]] = []
    for heading, body in raw:
        if _INLINE_MARKER.search(body):
            parts = _INLINE_MARKER.split(body)
            preamble = parts[0].strip()
            if preamble:
                sections.append((heading, preamble))
            for index in range(1, len(parts) - 1, 2):
                sections.append((parts[index].strip(), parts[index + 1].strip()))
        else:
            sections.append((heading, body))
    return sections


def _find_section(sections: list[tuple[str, str]], keys: tuple[str, ...]) -> tuple[str, str] | None:
    for heading, body in sections:
        lowered = heading.lower().rstrip(":.")
        if any(key in lowered for key in keys):
            return heading, body
    return None


def _verbatim_ok(span: str, source: str) -> bool:
    """True when ``span`` literally occurs in ``source`` (whitespace-normalized)."""
    return bool(span) and span in source


def _provenance_for(value: str | None, span: str | None, source: str) -> AppraisalFieldProvenance:
    if value is None:
        return AppraisalFieldProvenance.INSUFFICIENT_INFORMATION
    # Fully automated extraction is never recorded as human-reviewed. It is
    # EXTRACTED_UNVERIFIED even when the span is found verbatim.
    if span is not None and not _verbatim_ok(span, source):  # pragma: no cover - guard
        raise ValueError("Extracted span is not present in the consulted source")
    return AppraisalFieldProvenance.EXTRACTED_UNVERIFIED


def extract_from_abstract(
    reference_id: str,
    abstract: str,
    *,
    content_id: str | None,
    source_sha256: str,
    extraction_version: str = EXTRACTION_VERSION,
) -> ContentExtraction:
    """Extract appraisal fields that are literally supported by the abstract.

    Only fields grounded in a verbatim span are populated; the remainder are
    marked INSUFFICIENT_INFORMATION with an explicit reason.
    """
    source = _clean(abstract)
    sections = _sections(abstract)
    result = ContentExtraction(
        reference_id=reference_id,
        content_id=content_id,
        source_kind="ABSTRACT",
        source_sha256=source_sha256,
        extraction_version=extraction_version,
    )

    def put(name: str, value: str | None, locator: str | None, verbatim: str | None, note: str = ""):
        result.fields[name] = ExtractedField(
            name=name,
            value=value,
            locator=locator,
            verbatim=verbatim,
            provenance=_provenance_for(value, verbatim, source),
            note=note,
        )

    # scientific_question — the stated aim/purpose/background section.
    question = _find_section(sections, _QUESTION_KEYS)
    if question is not None:
        heading, body = question
        value = re.sub(r"^\s*(introduction|background & aims|background)\s*:\s*", "", body, flags=re.IGNORECASE)
        put("scientific_question", value, f"abstract:{heading}", value)

    # study_design — first explicitly named design.
    for canonical, pattern in _DESIGN_PATTERNS:
        match = pattern.search(source)
        if match:
            put("study_design", canonical, "abstract", match.group(0))
            break

    # sample_size + population — only when a bounded count+noun clause is present.
    sample = _SAMPLE_SIZE.search(source)
    if sample:
        put("sample_size", sample.group(1), "abstract", sample.group(0))
        put("population", sample.group(2).strip(), "abstract", sample.group(0))

    # reference_method — first explicitly named measurement method.
    for canonical, pattern in _METHOD_PATTERNS:
        match = pattern.search(source)
        if match:
            put("reference_method", canonical, "abstract", match.group(0))
            break

    # author_conclusions — the stated conclusion section.
    conclusion = _find_section(sections, _CONCLUSION_KEYS)
    if conclusion is not None:
        heading, body = conclusion
        put("author_conclusions", body, f"abstract:{heading}", body)

    # Fields not reliably groundable from an abstract alone remain insufficient.
    for name in TARGET_FIELDS:
        if name in result.fields:
            continue
        if name == "outcomes":
            note = "Structured outcomes require the full text; abstract not sufficient."
        elif name == "quantitative_results":
            note = "Structured numeric results not extracted automatically from the abstract."
        elif name == "confidence_intervals":
            note = "Confidence intervals not reported in the consulted abstract."
        elif name == "limitations":
            note = "Limitations not stated in the consulted abstract."
        elif name == "clinical_applicability":
            note = "Applicability requires full-text appraisal and human review."
        else:
            note = "Field not grounded in the consulted abstract."
        put(name, None, None, None, note)

    return result


def extraction_from_dict(data: dict[str, Any]) -> ContentExtraction:
    fields = {
        name: ExtractedField(
            name=name,
            value=payload.get("value"),
            locator=payload.get("locator"),
            verbatim=payload.get("verbatim"),
            provenance=AppraisalFieldProvenance(payload.get("provenance")),
            note=payload.get("note", ""),
        )
        for name, payload in (data.get("fields") or {}).items()
    }
    from ..core.timeutil import parse_dt

    created = parse_dt(data["created_at"]) if data.get("created_at") else None
    return ContentExtraction(
        reference_id=data["reference_id"],
        content_id=data.get("content_id"),
        source_kind=data.get("source_kind", "ABSTRACT"),
        source_sha256=data.get("source_sha256", ""),
        extraction_version=data.get("extraction_version", EXTRACTION_VERSION),
        fields=fields,
        created_at=created or now_utc(),
    )
