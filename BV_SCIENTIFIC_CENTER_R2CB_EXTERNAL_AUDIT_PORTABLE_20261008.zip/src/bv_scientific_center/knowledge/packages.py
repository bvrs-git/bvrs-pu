"""Knowledge packages: importable, versioned, validated scientific content.

A package bundles knowledge items with formula/score/rule definitions so that
scientific content can evolve independently of application code.

Security posture (spec §59/§60): an imported package is *untrusted* until
validated. No scripts, no executable HTML, no arbitrary paths. Formulas/rules
remain declarative JSON and are evaluated only by the constrained interpreter.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core.definition import content_hash
from ..core.enums import KnowledgeOrigin, PackageReviewStatus
from ..errors import PackageSecurityError, PackageValidationError
from .models import KnowledgeReference, ScientificKnowledgeItem

# Substrings that must never appear anywhere in an imported package payload.
_FORBIDDEN_SUBSTRINGS = (
    "<script",
    "</script",
    "javascript:",
    "onerror=",
    "onload=",
    "<iframe",
    "eval(",
    "exec(",
    "__import__",
    "subprocess",
    "os.system",
    "require(",
    "import os",
)

_PATH_KEYS = {"path", "file_path", "filepath", "filename", "local_path", "uri"}


def _scan(value: Any, path: str = "$") -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if str(key).lower() in _PATH_KEYS:
                raise PackageSecurityError(
                    f"Packages may not reference filesystem paths ({path}.{key})"
                )
            _scan(item, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _scan(item, f"{path}[{index}]")
    elif isinstance(value, str):
        lowered = value.lower()
        for needle in _FORBIDDEN_SUBSTRINGS:
            if needle in lowered:
                raise PackageSecurityError(
                    f"Forbidden content {needle!r} found at {path}"
                )


@dataclass
class KnowledgePackage:
    package_id: str
    name: str
    version: str
    domain: str = ""
    items: tuple[ScientificKnowledgeItem, ...] = ()
    formulas: tuple[dict[str, Any], ...] = ()
    scores: tuple[dict[str, Any], ...] = ()
    rules: tuple[dict[str, Any], ...] = ()
    references: tuple[KnowledgeReference, ...] = ()
    source_manifest: tuple[dict[str, Any], ...] = ()
    review_status: PackageReviewStatus = PackageReviewStatus.DRAFT
    created_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    # -- R2A evolution ----------------------------------------------------
    author: str | None = None
    reviewer: str | None = None
    provenance: dict[str, Any] = field(default_factory=dict)
    dependencies: tuple[dict[str, Any], ...] = ()
    revision_history: tuple[dict[str, Any], ...] = ()
    origin: KnowledgeOrigin = KnowledgeOrigin.IMPORTED
    scientific_reference_ids: tuple[str, ...] = ()
    evidence_ids: tuple[str, ...] = ()
    claim_ids: tuple[str, ...] = ()

    # -- identity ----------------------------------------------------------
    @property
    def key(self) -> tuple[str, str]:
        return (self.package_id, self.version)

    def hash(self) -> str:
        return content_hash(dump_package(self))

    # -- serialization -----------------------------------------------------
    def to_payload(self) -> dict[str, Any]:
        return dump_package(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "KnowledgePackage":
        from ..core.definition import coerce_enum

        items = tuple(
            ScientificKnowledgeItem.from_dict(i) for i in data.get("items", ())
        )
        references = tuple(
            KnowledgeReference.from_dict(r) for r in data.get("references", ())
        )
        return cls(
            package_id=data["package_id"],
            name=data.get("name", data["package_id"]),
            version=str(data["version"]),
            domain=data.get("domain", ""),
            items=items,
            formulas=tuple(data.get("formulas", ())),
            scores=tuple(data.get("scores", ())),
            rules=tuple(data.get("rules", ())),
            references=references,
            source_manifest=tuple(data.get("source_manifest", ())),
            review_status=coerce_enum(
                PackageReviewStatus, data.get("review_status", "DRAFT")
            ),
            metadata=dict(data.get("metadata", {})),
            author=data.get("author"),
            reviewer=data.get("reviewer"),
            provenance=dict(data.get("provenance", {})),
            dependencies=tuple(data.get("dependencies", ())),
            revision_history=tuple(data.get("revision_history", ())),
            origin=coerce_enum(KnowledgeOrigin, data.get("origin", "IMPORTED")),
            scientific_reference_ids=tuple(data.get("scientific_reference_ids", ())),
            evidence_ids=tuple(data.get("evidence_ids", ())),
            claim_ids=tuple(data.get("claim_ids", ())),
        )

    # -- validation --------------------------------------------------------
    def validate(self) -> None:
        if not self.package_id or not self.version:
            raise PackageValidationError("Package requires package_id and version")
        _scan(self.to_payload())
        if (
            self.review_status is PackageReviewStatus.APPROVED
            and self.origin is KnowledgeOrigin.SYNTHETIC_TEST
        ):
            raise PackageValidationError(
                f"Package {self.package_id!r} is SYNTHETIC_TEST content and cannot be APPROVED"
            )
        if self.review_status is PackageReviewStatus.APPROVED and (
            not self.reviewer or not self.author
        ):
            raise PackageValidationError(
                "An APPROVED package requires an author and a reviewer"
            )
        for item in self.items:
            if not item.knowledge_id or not item.title:
                raise PackageValidationError("Every knowledge item requires id and title")
        for collection, name in (
            (self.formulas, "formula"),
            (self.scores, "score"),
            (self.rules, "rule"),
        ):
            for definition in collection:
                if not definition.get("definition_id"):
                    raise PackageValidationError(f"Every {name} requires a definition_id")
                if "version" not in definition:
                    raise PackageValidationError(
                        f"Every {name} requires an explicit version"
                    )
        for dependency in self.dependencies:
            if not dependency.get("package_id") or not dependency.get("version"):
                raise PackageValidationError(
                    "Every dependency requires package_id and version"
                )

    def describe_integrity(self) -> dict[str, Any]:
        """Integrity summary: content hash + declared dependency/constituent ids."""
        return {
            "package_id": self.package_id,
            "version": self.version,
            "content_hash": self.hash(),
            "origin": self.origin.value,
            "items": [i.knowledge_id for i in self.items],
            "scientific_reference_ids": list(self.scientific_reference_ids),
            "evidence_ids": list(self.evidence_ids),
            "claim_ids": list(self.claim_ids),
            "dependencies": list(self.dependencies),
        }


def dump_package(package: KnowledgePackage) -> dict[str, Any]:
    from ..core.serialization import dump

    return dump(package)
