"""Methodological assessment taxonomy and non-automatic suggestions (GATE 3).

The taxonomy is deliberately *advisory*, not a rigid universal hierarchy. A
question type suggests which designs may be informative; it never implies that a
design is automatically higher quality, and it never assigns GRADE certainty
without human assessment.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from .scientific import CertaintyFramework, CertaintyLevel, StudyDesign

SUGGESTION_NOTICE = (
    "Structured suggestion only. It does not approve, rate, or grade the "
    "evidence. Certainty must be applied by a human reviewer."
)

# Clinical question type -> study designs that may be informative (advisory).
QUESTION_TYPE_TAXONOMY: dict[str, tuple[StudyDesign, ...]] = {
    "THERAPY": (
        StudyDesign.SYSTEMATIC_REVIEW,
        StudyDesign.META_ANALYSIS,
        StudyDesign.RCT,
        StudyDesign.COHORT,
    ),
    "DIAGNOSIS": (
        StudyDesign.SYSTEMATIC_REVIEW,
        StudyDesign.DIAGNOSTIC_ACCURACY,
        StudyDesign.CROSS_SECTIONAL,
    ),
    "PROGNOSIS": (
        StudyDesign.SYSTEMATIC_REVIEW,
        StudyDesign.COHORT,
        StudyDesign.CASE_CONTROL,
    ),
    "ETIOLOGY_HARM": (
        StudyDesign.SYSTEMATIC_REVIEW,
        StudyDesign.COHORT,
        StudyDesign.CASE_CONTROL,
    ),
    "INSTRUMENT_VALIDATION": (
        StudyDesign.INSTRUMENT_VALIDATION,
        StudyDesign.CROSS_SECTIONAL,
    ),
    "REFERENCE_RANGE": (
        StudyDesign.CROSS_SECTIONAL,
        StudyDesign.COHORT,
        StudyDesign.CLINICAL_GUIDELINE,
        StudyDesign.CONSENSUS,
    ),
    "MEASUREMENT_PROPERTY": (
        StudyDesign.INSTRUMENT_VALIDATION,
        StudyDesign.DIAGNOSTIC_ACCURACY,
    ),
}

# Domains considered by GRADE-style human assessment (never auto-graded).
ASSESSMENT_DOMAINS: tuple[str, ...] = (
    "risk_of_bias",
    "selection_bias",
    "sample_characteristics",
    "measurement_validity",
    "confounding",
    "precision",
    "reproducibility",
    "internal_validity",
    "external_validity",
    "reference_method_adequacy",
    "generalisability",
)

_VALIDATION_DOMAINS: tuple[str, ...] = (
    "risk_of_bias",
    "reference_method_adequacy",
    "measurement_validity",
    "reproducibility",
    "external_validity",
)
_SYNTHESIS_DOMAINS: tuple[str, ...] = (
    "risk_of_bias",
    "precision",
    "consistency",
    "directness",
    "publication_bias",
)


def design_assessment_template(design: StudyDesign) -> dict[str, Any]:
    """Return the assessment domains relevant to a study design (advisory)."""
    if design in {StudyDesign.INSTRUMENT_VALIDATION, StudyDesign.DIAGNOSTIC_ACCURACY}:
        return {"design": design.value, "domains": list(_VALIDATION_DOMAINS)}
    if design in {StudyDesign.SYSTEMATIC_REVIEW, StudyDesign.META_ANALYSIS}:
        return {"design": design.value, "domains": list(_SYNTHESIS_DOMAINS)}
    if design in {StudyDesign.RCT}:
        return {"design": design.value, "domains": ["risk_of_bias", "precision", "internal_validity", "external_validity"]}
    return {"design": design.value, "domains": list(ASSESSMENT_DOMAINS)}


@dataclass
class ValidationMetrics:
    """Validation/agreement metrics for measurement and equation validation.

    Numbers may only be recorded when reported by the consulted source; when the
    full text is unavailable the fields stay ``None`` (never invented).
    """

    correlation: str | None = None
    agreement: str | None = None
    mean_bias: str | None = None
    limits_of_agreement: str | None = None
    estimation_error: str | None = None
    calibration: str | None = None
    external_validation: str | None = None
    subgroup_performance: str | None = None
    notes: str | None = None
    reported_by_source: bool = False

    def populated_fields(self) -> list[str]:
        return [
            name
            for name in (
                "correlation",
                "agreement",
                "mean_bias",
                "limits_of_agreement",
                "estimation_error",
                "calibration",
                "external_validation",
                "subgroup_performance",
            )
            if getattr(self, name) not in (None, "")
        ]

    def validate(self) -> None:
        if self.populated_fields() and not self.reported_by_source:
            raise ValueError(
                "Validation metrics cannot be recorded unless reported by the consulted source"
            )

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ValidationMetrics":
        return cls(**{k: data.get(k) for k in (
            "correlation", "agreement", "mean_bias", "limits_of_agreement",
            "estimation_error", "calibration", "external_validation",
            "subgroup_performance", "notes", "reported_by_source",
        )})


DESIGN_LABELS: dict[StudyDesign, str] = {
    StudyDesign.SYSTEMATIC_REVIEW: "Revisão sistemática",
    StudyDesign.META_ANALYSIS: "Metanálise",
    StudyDesign.RCT: "Ensaio clínico randomizado",
    StudyDesign.COHORT: "Coorte",
    StudyDesign.CASE_CONTROL: "Caso-controle",
    StudyDesign.CROSS_SECTIONAL: "Estudo transversal",
    StudyDesign.DIAGNOSTIC_ACCURACY: "Estudo diagnóstico",
    StudyDesign.INSTRUMENT_VALIDATION: "Validação de instrumento",
    StudyDesign.CLINICAL_GUIDELINE: "Diretriz clínica",
    StudyDesign.CONSENSUS: "Consenso",
    StudyDesign.CASE_SERIES: "Série de casos",
    StudyDesign.CASE_REPORT: "Relato de caso",
    StudyDesign.PRECLINICAL: "Estudo pré-clínico",
    StudyDesign.OTHER: "Outro",
}


@dataclass
class MethodologicalAssessment:
    """Human-applied methodological assessment of a single evidence record."""

    framework: CertaintyFramework = CertaintyFramework.NONE
    certainty: CertaintyLevel = CertaintyLevel.NOT_ASSESSED
    domains: dict[str, str] = field(default_factory=dict)  # e.g. {"risk_of_bias": "high"}
    summary: str | None = None
    assessed_by: str | None = None
    assessed_at: datetime | None = None
    human_applied: bool = True

    def validate(self) -> None:
        # A certainty other than NOT_ASSESSED must name a human assessor.
        if self.certainty is not CertaintyLevel.NOT_ASSESSED:
            if not self.human_applied or not self.assessed_by:
                raise ValueError(
                    "Certainty cannot be set without a human assessor (GRADE is never automatic)"
                )

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


# Design-appropriate risk-of-bias instruments (advisory suggestions only).
# A suggestion is NEVER an assessment: the tool is not applied automatically and
# any rating stays UNASSESSED/PROVISIONAL until a named human reviewer applies it.
ROB_INSTRUMENT_BY_DESIGN: dict[StudyDesign, str] = {
    StudyDesign.RCT: "RoB 2",
    StudyDesign.COHORT: "ROBINS-I (Newcastle-Ottawa for observational associations)",
    StudyDesign.CASE_CONTROL: "ROBINS-I (Newcastle-Ottawa for observational associations)",
    StudyDesign.CROSS_SECTIONAL: "JBI checklist for analytical cross-sectional studies",
    StudyDesign.DIAGNOSTIC_ACCURACY: "QUADAS-2",
    StudyDesign.INSTRUMENT_VALIDATION: "COSMIN (measurement properties)",
    StudyDesign.SYSTEMATIC_REVIEW: "AMSTAR-2 / ROBIS",
    StudyDesign.META_ANALYSIS: "AMSTAR-2 / ROBIS",
    StudyDesign.CASE_SERIES: "JBI checklist for case series",
    StudyDesign.CASE_REPORT: "JBI checklist for case reports",
    StudyDesign.PRECLINICAL: "SYRCLE risk-of-bias tool",
}


def suggested_rob_instrument(design: StudyDesign) -> dict[str, Any]:
    """Suggest a design-appropriate risk-of-bias instrument (never auto-applied).

    Reporting checklists (STROBE/TRIPOD/GRRAS) are **not** risk-of-bias tools and
    are never returned here.
    """
    tool = ROB_INSTRUMENT_BY_DESIGN.get(design)
    return {
        "design": design.value,
        "suggested_tool": tool,
        "auto_applied": False,
        "status": "UNASSESSED",
        "reason": (
            "Suggestion only; the instrument must be applied by a human reviewer."
            if tool
            else "No single validated risk-of-bias tool maps to this design; human selection required."
        ),
    }


def taxonomy() -> dict[str, Any]:
    """Return the configurable taxonomy (question types, designs, domains)."""
    return {
        "question_types": {k: [d.value for d in v] for k, v in QUESTION_TYPE_TAXONOMY.items()},
        "study_designs": [d.value for d in StudyDesign],
        "assessment_domains": list(ASSESSMENT_DOMAINS),
        "design_labels": {k.value: v for k, v in DESIGN_LABELS.items()},
    }


def suggest_assessment(evidence, *, references_present: bool) -> dict[str, Any]:
    """Produce a **structured suggestion** for human review. Never grades.

    The result includes ``auto_certainty=False`` and a notice; it must not be
    persisted as an assessment without human editing and an assessor identity.
    """
    design = evidence.study_design
    notes: list[str] = []
    if not references_present:
        notes.append("No supporting reference attached; verification pending.")
    if design in {StudyDesign.SYSTEMATIC_REVIEW, StudyDesign.META_ANALYSIS}:
        notes.append("Synthesis design: consider assessing heterogeneity and publication bias.")
    elif design is StudyDesign.RCT:
        notes.append("Randomized design: assess allocation concealment and blinding.")
    elif design in {StudyDesign.COHORT, StudyDesign.CASE_CONTROL, StudyDesign.CROSS_SECTIONAL}:
        notes.append("Observational design: assess confounding and selection bias.")
    elif design in {StudyDesign.DIAGNOSTIC_ACCURACY, StudyDesign.INSTRUMENT_VALIDATION}:
        notes.append("Assess reference standard and measurement properties.")
    else:
        notes.append("Assess design-specific risks before any inference.")

    return {
        "evidence_id": evidence.evidence_id,
        "study_design": design.value,
        "suggested_framework": CertaintyFramework.GRADE.value,
        "suggested_domains": list(ASSESSMENT_DOMAINS),
        "suggested_certainty": None,
        "auto_certainty": False,
        "notes": notes,
        "notice": SUGGESTION_NOTICE,
    }
