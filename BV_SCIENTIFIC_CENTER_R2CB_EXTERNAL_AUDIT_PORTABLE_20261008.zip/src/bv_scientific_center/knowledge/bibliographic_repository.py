"""Persistence for acquisition provenance, editorial alerts and appraisals."""

from __future__ import annotations

import json
from typing import Any

from ..core import ids
from ..core.serialization import dumps
from ..core.timeutil import now_utc, parse_dt, to_iso
from ..storage.database import Database


def _loads(value: Any, default: Any) -> Any:
    if not value:
        return default
    if isinstance(value, (list, dict)):
        return value
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return default


class AcquisitionRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def append(
        self,
        *,
        reference_id: str | None,
        provider: str,
        endpoint: str,
        params: dict[str, Any],
        queried_at,
        record_identity: str,
        identifiers: dict[str, Any],
        payload_sha256: str,
        processing_version: str,
        verification_status: str,
        divergences: dict[str, Any] | None = None,
        commit: bool = True,
    ) -> str:
        acquisition_id = ids.new_id("acq")
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT INTO acquisition_records (
                    acquisition_id, reference_id, provider, endpoint, params_json, queried_at,
                    record_identity, identifiers_json, payload_sha256, processing_version,
                    verification_status, divergences_json, created_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    acquisition_id,
                    reference_id,
                    provider,
                    endpoint,
                    dumps(params),
                    to_iso(queried_at),
                    record_identity,
                    dumps(identifiers),
                    payload_sha256,
                    processing_version,
                    verification_status,
                    dumps(divergences or {}),
                    to_iso(now_utc()),
                ),
            )
            if commit:
                self.conn.commit()
        return acquisition_id

    def for_reference(self, reference_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM acquisition_records WHERE reference_id = ? ORDER BY created_at",
            (reference_id,),
        ).fetchall()
        result = []
        for row in rows:
            data = dict(row)
            data["params_json"] = _loads(data.get("params_json"), {})
            data["identifiers_json"] = _loads(data.get("identifiers_json"), {})
            data["divergences_json"] = _loads(data.get("divergences_json"), {})
            result.append(data)
        return result

    def count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) AS c FROM acquisition_records").fetchone()["c"]


class EditorialAlertRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def add(
        self,
        *,
        reference_id: str,
        alert_type: str,
        source: str,
        details: str,
        is_retraction: bool,
        detected_at=None,
        commit: bool = True,
    ) -> str:
        alert_id = ids.new_id("alert")
        with self.database.write_lock:
            # Idempotent: same reference+type+source+details is not duplicated.
            existing = self.conn.execute(
                "SELECT alert_id FROM editorial_alerts WHERE reference_id = ? AND alert_type = ? "
                "AND source = ? AND details = ?",
                (reference_id, alert_type, source, details),
            ).fetchone()
            if existing:
                return existing["alert_id"]
            self.conn.execute(
                """
                INSERT INTO editorial_alerts (
                    alert_id, reference_id, alert_type, source, detected_at, details,
                    is_retraction, created_at
                ) VALUES (?,?,?,?,?,?,?,?)
                """,
                (
                    alert_id,
                    reference_id,
                    alert_type,
                    source,
                    to_iso(detected_at or now_utc()),
                    details,
                    1 if is_retraction else 0,
                    to_iso(now_utc()),
                ),
            )
            if commit:
                self.conn.commit()
        return alert_id

    def for_reference(self, reference_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM editorial_alerts WHERE reference_id = ? ORDER BY created_at",
            (reference_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def has_retraction(self, reference_id: str) -> bool:
        row = self.conn.execute(
            "SELECT COUNT(*) AS c FROM editorial_alerts WHERE reference_id = ? AND is_retraction = 1",
            (reference_id,),
        ).fetchone()
        return bool(row["c"])

    def references_with_alerts(self) -> set[str]:
        rows = self.conn.execute("SELECT DISTINCT reference_id FROM editorial_alerts").fetchall()
        return {row["reference_id"] for row in rows}

    def count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) AS c FROM editorial_alerts").fetchone()["c"]


class AppraisalRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def save(self, appraisal: dict[str, Any], *, commit: bool = True) -> str:
        appraisal_id = appraisal.get("appraisal_id") or ids.new_id("appr")
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO review_appraisals (
                    appraisal_id, reference_id, reviewer, created_at, content_review_status,
                    scientific_question, study_design, population, sample_size,
                    inclusion_criteria, exclusion_criteria, reference_method, intervention,
                    comparator, outcomes, quantitative_results, confidence_intervals,
                    limitations, risk_of_bias, clinical_applicability, author_conclusions,
                    reviewer_interpretation, provenance_locations, pending_fields,
                    field_provenance, validation_metrics, field_provenance_note
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    appraisal_id,
                    appraisal["reference_id"],
                    appraisal.get("reviewer"),
                    to_iso(appraisal.get("created_at") or now_utc()),
                    appraisal.get("content_review_status"),
                    appraisal.get("scientific_question"),
                    appraisal.get("study_design"),
                    appraisal.get("population"),
                    appraisal.get("sample_size"),
                    appraisal.get("inclusion_criteria"),
                    appraisal.get("exclusion_criteria"),
                    appraisal.get("reference_method"),
                    appraisal.get("intervention"),
                    appraisal.get("comparator"),
                    dumps(appraisal.get("outcomes")),
                    dumps(appraisal.get("quantitative_results")),
                    dumps(appraisal.get("confidence_intervals")),
                    dumps(appraisal.get("limitations")),
                    appraisal.get("risk_of_bias"),
                    appraisal.get("clinical_applicability"),
                    appraisal.get("author_conclusions"),
                    appraisal.get("reviewer_interpretation"),
                    dumps(appraisal.get("provenance_locations")),
                    dumps(appraisal.get("pending_fields")),
                    dumps(appraisal.get("field_provenance")),
                    dumps(appraisal.get("validation_metrics")),
                    appraisal.get("field_provenance_note"),
                ),
            )
            if commit:
                self.conn.commit()
        return appraisal_id

    def for_reference(self, reference_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM review_appraisals WHERE reference_id = ? ORDER BY created_at",
            (reference_id,),
        ).fetchall()
        result = []
        for row in rows:
            data = dict(row)
            for key in (
                "outcomes",
                "quantitative_results",
                "confidence_intervals",
                "limitations",
                "provenance_locations",
                "pending_fields",
                "field_provenance",
                "validation_metrics",
            ):
                default = {}
                if key in {"outcomes", "limitations", "provenance_locations", "pending_fields"}:
                    default = []
                loaded = _loads(data.get(key), default)
                data[key] = default if loaded is None else loaded
            result.append(data)
        return result
