"""Persistence and search for the R2A scientific model.

All tables live in ``knowledge.db`` and contain **no patient data**. Writes are
serialized through the database write lock; ingestion is idempotent and detects
conflicting metadata for the same stable identifier.
"""

from __future__ import annotations

import json
import re
import sqlite3
from typing import Any

from ..core.enums import BibliographicVerification, ContentReviewStatus, KnowledgeOrigin
from ..core.serialization import dumps
from ..core.timeutil import now_utc, parse_dt, to_iso
from ..errors import DuplicateReferenceError, MetadataConflictError
from ..storage.database import Database
from .scientific import (
    CertaintyFramework,
    CertaintyLevel,
    ClinicalClaim,
    CurationEvent,
    CurationStatus,
    CurationSubjectType,
    EvidenceLink,
    EvidenceRelation,
    LinkTargetType,
    MetadataSource,
    PublicationType,
    ScientificEvidence,
    ScientificReference,
    StudyDesign,
    VerificationStatus,
)

_TERM_RE = re.compile(r"\w+", re.UNICODE)

_FTS_BASE = {
    "reference_fts": "scientific_references",
    "evidence_fts": "scientific_evidence",
}


def _loads(value: Any, default: Any) -> Any:
    if not value:
        return default
    if isinstance(value, (list, dict)):
        return value
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return default


def _enum(klass, value, default):
    if value is None or value == "":
        return default
    if isinstance(value, klass):
        return value
    return klass(str(value))


def _stored_hash(obj: Any) -> str:
    """Return the stored content hash for a model with a ``content_hash_value`` field.

    Falls back to computing it when the field is empty. The ``content_hash()``
    method is never shadowed (R2B RR-7 fix).
    """
    value = getattr(obj, "content_hash_value", None)
    if value:
        return value
    method = getattr(obj, "content_hash", None)
    return method() if callable(method) else ""


# ---------------------------------------------------------------------------
# References
# ---------------------------------------------------------------------------
class ScientificReferenceRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def find_by_identifier(self, kind: str, value: str) -> ScientificReference | None:
        column = {"doi": "doi", "pmid": "pmid", "isbn": "isbn", "url": "url"}[kind]
        normalized = value.strip().lower() if kind != "url" else value.strip()
        rows = self.conn.execute(
            f"SELECT * FROM scientific_references WHERE {column} IS NOT NULL"
        ).fetchall()
        for row in rows:
            candidate = row[column]
            if candidate and candidate.strip().lower() == normalized:
                return self._row(row)
        return None

    def save(self, reference: ScientificReference, *, commit: bool = True) -> ScientificReference:
        reference.validate()
        with self.database.write_lock:
            existing = self.conn.execute(
                "SELECT * FROM scientific_references WHERE reference_id = ?",
                (reference.reference_id,),
            ).fetchone()
            created = parse_dt(existing["created_at"]) if existing and existing["created_at"] else None
            reference.content_hash_value = reference.content_hash()
            reference.created_at = reference.created_at or created or now_utc()
            reference.updated_at = now_utc() if existing else reference.created_at
            self.conn.execute(
                """
                INSERT OR REPLACE INTO scientific_references (
                    reference_id, title, authors, organization, publication_year, venue,
                    publication_type, doi, pmid, isbn, issn, url, accessed_at, metadata_source,
                    verification_status, bibliographic_status, content_review_status,
                    last_checked_at, curation_status, version, content_hash, origin,
                    superseded_by, retraction_reason, notes, created_at, updated_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    reference.reference_id,
                    reference.title,
                    dumps(list(reference.authors)),
                    reference.organization,
                    reference.publication_year,
                    reference.venue,
                    reference.publication_type.value,
                    reference.doi,
                    reference.pmid,
                    reference.isbn,
                    dumps(list(reference.issn)),
                    reference.url,
                    to_iso(reference.accessed_at),
                    reference.metadata_source.value,
                    reference.verification_status.value,
                    reference.bibliographic_status.value,
                    reference.content_review_status.value,
                    to_iso(reference.last_checked_at),
                    reference.curation_status.value,
                    reference.version,
                    reference.content_hash_value,
                    reference.origin.value,
                    reference.superseded_by,
                    reference.retraction_reason,
                    reference.notes,
                    to_iso(reference.created_at),
                    to_iso(reference.updated_at),
                ),
            )
            self._index(reference)
            if commit:
                self.conn.commit()
        return reference

    def ingest(self, reference: ScientificReference, *, commit: bool = True) -> ScientificReference:
        """Idempotent import by stable identifier with conflict detection."""
        identifier = reference.stable_identifier()
        if identifier is None:
            return self.save(reference, commit=commit)
        kind, value = identifier
        existing = self.find_by_identifier(kind, value)
        if existing is None:
            return self.save(reference, commit=commit)
        if _stored_hash(existing) == _stored_hash(reference):
            return existing  # exact duplicate -> idempotent
        raise MetadataConflictError(
            f"{kind.upper()} {value!r} already exists as {existing.reference_id!r} with "
            "different metadata; resolve the conflict explicitly (never silent overwrite)"
        )

    def get(self, reference_id: str) -> ScientificReference | None:
        row = self.conn.execute(
            "SELECT * FROM scientific_references WHERE reference_id = ?", (reference_id,)
        ).fetchone()
        return self._row(row) if row else None

    def list(
        self,
        *,
        status: str | None = None,
        publication_type: str | None = None,
        year: int | None = None,
        origin: str | None = None,
    ) -> list[ScientificReference]:
        sql = "SELECT * FROM scientific_references"
        clauses: list[str] = []
        params: list[Any] = []
        for column, value in (
            ("curation_status", status),
            ("publication_type", publication_type),
            ("publication_year", year),
            ("origin", origin),
        ):
            if value is not None:
                clauses.append(f"{column} = ?")
                params.append(value)
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY title"
        return [self._row(r) for r in self.conn.execute(sql, params).fetchall()]

    def count_by_status(self) -> dict[str, int]:
        rows = self.conn.execute(
            "SELECT curation_status, COUNT(*) AS n FROM scientific_references GROUP BY curation_status"
        ).fetchall()
        return {row["curation_status"]: row["n"] for row in rows}

    def _index(self, reference: ScientificReference) -> None:
        self.conn.execute("DELETE FROM reference_fts WHERE reference_id = ?", (reference.reference_id,))
        self.conn.execute(
            "INSERT INTO reference_fts (reference_id, title, authors, venue, doi, pmid, organization) "
            "VALUES (?,?,?,?,?,?,?)",
            (
                reference.reference_id,
                reference.title,
                " ".join(reference.authors),
                reference.venue or "",
                reference.doi or "",
                reference.pmid or "",
                reference.organization or "",
            ),
        )

    @staticmethod
    def _row(row: Any) -> ScientificReference:
        reference = ScientificReference(
            reference_id=row["reference_id"],
            title=row["title"],
            authors=tuple(_loads(row["authors"], [])),
            organization=row["organization"],
            publication_year=row["publication_year"],
            venue=row["venue"],
            publication_type=_enum(PublicationType, row["publication_type"], PublicationType.OTHER),
            doi=row["doi"],
            pmid=row["pmid"],
            isbn=row["isbn"],
            issn=tuple(_loads(row["issn"], [])),
            url=row["url"],
            accessed_at=parse_dt(row["accessed_at"]) if row["accessed_at"] else None,
            metadata_source=_enum(MetadataSource, row["metadata_source"], MetadataSource.MANUAL),
            verification_status=_enum(
                VerificationStatus, row["verification_status"], VerificationStatus.UNVERIFIED
            ),
            bibliographic_status=_enum(
                BibliographicVerification,
                row["bibliographic_status"] if "bibliographic_status" in row.keys() else None,
                BibliographicVerification.PENDING,
            ),
            content_review_status=_enum(
                ContentReviewStatus,
                row["content_review_status"] if "content_review_status" in row.keys() else None,
                ContentReviewStatus.NOT_REVIEWED,
            ),
            last_checked_at=parse_dt(row["last_checked_at"])
            if ("last_checked_at" in row.keys() and row["last_checked_at"])
            else None,
            curation_status=_enum(
                CurationStatus, row["curation_status"], CurationStatus.IMPORTED_UNVERIFIED
            ),
            version=row["version"] or 1,
            origin=_enum(KnowledgeOrigin, row["origin"], KnowledgeOrigin.IMPORTED),
            superseded_by=row["superseded_by"],
            retraction_reason=row["retraction_reason"],
            notes=row["notes"],
            created_at=parse_dt(row["created_at"]) if row["created_at"] else None,
            updated_at=parse_dt(row["updated_at"]) if row["updated_at"] else None,
            content_hash_value=row["content_hash"],
        )
        return reference


# ---------------------------------------------------------------------------
# Evidence
# ---------------------------------------------------------------------------
class ScientificEvidenceRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def save(self, evidence: ScientificEvidence, *, commit: bool = True) -> ScientificEvidence:
        evidence.validate()
        evidence.content_hash_value = evidence.content_hash()
        with self.database.write_lock:
            existing = self.conn.execute(
                "SELECT created_at FROM scientific_evidence WHERE evidence_id = ?",
                (evidence.evidence_id,),
            ).fetchone()
            created = parse_dt(existing["created_at"]) if existing and existing["created_at"] else None
            evidence.created_at = evidence.created_at or created or now_utc()
            evidence.updated_at = now_utc() if existing else evidence.created_at
            self.conn.execute(
                """
                INSERT OR REPLACE INTO scientific_evidence (
                    evidence_id, title, reference_ids, study_design, population, intervention,
                    comparator, outcomes, quantitative_results, limitations, clinical_applicability,
                    uncertainties, biases, editorial_status, corrections, retraction_notes,
                    methodology, domain, curation_status, version, content_hash, origin,
                    superseded_by, created_at, updated_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    evidence.evidence_id,
                    evidence.title,
                    dumps(list(evidence.reference_ids)),
                    evidence.study_design.value,
                    evidence.population,
                    evidence.intervention,
                    evidence.comparator,
                    dumps(list(evidence.outcomes)),
                    dumps(evidence.quantitative_results),
                    dumps(list(evidence.limitations)),
                    evidence.clinical_applicability,
                    dumps(list(evidence.uncertainties)),
                    dumps(list(evidence.biases)),
                    evidence.editorial_status,
                    dumps(list(evidence.corrections)),
                    evidence.retraction_notes,
                    dumps(evidence.methodology),
                    evidence.domain,
                    evidence.curation_status.value,
                    evidence.version,
                    evidence.content_hash_value,
                    evidence.origin.value,
                    evidence.superseded_by,
                    to_iso(evidence.created_at),
                    to_iso(evidence.updated_at),
                ),
            )
            self._index(evidence)
            if commit:
                self.conn.commit()
        return evidence

    def get(self, evidence_id: str) -> ScientificEvidence | None:
        row = self.conn.execute(
            "SELECT * FROM scientific_evidence WHERE evidence_id = ?", (evidence_id,)
        ).fetchone()
        return self._row(row) if row else None

    def list(self, *, status: str | None = None, design: str | None = None) -> list[ScientificEvidence]:
        sql = "SELECT * FROM scientific_evidence"
        clauses, params = [], []
        if status is not None:
            clauses.append("curation_status = ?")
            params.append(status)
        if design is not None:
            clauses.append("study_design = ?")
            params.append(design)
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY title"
        return [self._row(r) for r in self.conn.execute(sql, params).fetchall()]

    def _index(self, evidence: ScientificEvidence) -> None:
        self.conn.execute("DELETE FROM evidence_fts WHERE evidence_id = ?", (evidence.evidence_id,))
        self.conn.execute(
            "INSERT INTO evidence_fts (evidence_id, title, population, outcomes, domain) VALUES (?,?,?,?,?)",
            (
                evidence.evidence_id,
                evidence.title,
                evidence.population or "",
                " ".join(evidence.outcomes),
                evidence.domain or "",
            ),
        )

    @staticmethod
    def _row(row: Any) -> ScientificEvidence:
        return ScientificEvidence(
            evidence_id=row["evidence_id"],
            title=row["title"],
            reference_ids=tuple(_loads(row["reference_ids"], [])),
            study_design=_enum(StudyDesign, row["study_design"], StudyDesign.OTHER),
            population=row["population"],
            intervention=row["intervention"],
            comparator=row["comparator"],
            outcomes=tuple(_loads(row["outcomes"], [])),
            quantitative_results=_loads(row["quantitative_results"], {}),
            limitations=tuple(_loads(row["limitations"], [])),
            clinical_applicability=row["clinical_applicability"],
            uncertainties=tuple(_loads(row["uncertainties"], [])),
            biases=tuple(_loads(row["biases"], [])),
            editorial_status=row["editorial_status"] or "NONE",
            corrections=tuple(_loads(row["corrections"], [])),
            retraction_notes=row["retraction_notes"],
            methodology=_loads(row["methodology"], {}),
            domain=row["domain"],
            curation_status=_enum(CurationStatus, row["curation_status"], CurationStatus.IMPORTED_UNVERIFIED),
            version=row["version"] or 1,
            origin=_enum(KnowledgeOrigin, row["origin"], KnowledgeOrigin.IMPORTED),
            superseded_by=row["superseded_by"],
            created_at=parse_dt(row["created_at"]) if row["created_at"] else None,
            updated_at=parse_dt(row["updated_at"]) if row["updated_at"] else None,
            content_hash_value=row["content_hash"],
        )


# ---------------------------------------------------------------------------
# Claims
# ---------------------------------------------------------------------------
class ClinicalClaimRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def save(self, claim: ClinicalClaim, *, commit: bool = True) -> ClinicalClaim:
        claim.validate()
        claim.content_hash_value = claim.content_hash()
        with self.database.write_lock:
            existing = self.conn.execute(
                "SELECT created_at, review_history FROM clinical_claims WHERE claim_id = ?",
                (claim.claim_id,),
            ).fetchone()
            created = parse_dt(existing["created_at"]) if existing and existing["created_at"] else None
            claim.created_at = claim.created_at or created or now_utc()
            claim.updated_at = now_utc() if existing else claim.created_at
            self.conn.execute(
                """
                INSERT OR REPLACE INTO clinical_claims (
                    claim_id, text, favorable_evidence_ids, contrary_evidence_ids,
                    inconclusive_evidence_ids, population_context, applicability, limitations,
                    certainty_level, certainty_framework, curation_status, version,
                    content_hash, origin, review_history, superseded_by, created_at, updated_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    claim.claim_id,
                    claim.text,
                    dumps(list(claim.favorable_evidence_ids)),
                    dumps(list(claim.contrary_evidence_ids)),
                    dumps(list(claim.inconclusive_evidence_ids)),
                    claim.population_context,
                    claim.applicability,
                    dumps(list(claim.limitations)),
                    claim.certainty_level.value,
                    claim.certainty_framework.value,
                    claim.curation_status.value,
                    claim.version,
                    claim.content_hash_value,
                    claim.origin.value,
                    dumps(list(claim.review_history)),
                    claim.superseded_by,
                    to_iso(claim.created_at),
                    to_iso(claim.updated_at),
                ),
            )
            if commit:
                self.conn.commit()
        return claim

    def get(self, claim_id: str) -> ClinicalClaim | None:
        row = self.conn.execute(
            "SELECT * FROM clinical_claims WHERE claim_id = ?", (claim_id,)
        ).fetchone()
        return self._row(row) if row else None

    def list(self, *, status: str | None = None) -> list[ClinicalClaim]:
        sql = "SELECT * FROM clinical_claims"
        params: list[Any] = []
        if status is not None:
            sql += " WHERE curation_status = ?"
            params.append(status)
        sql += " ORDER BY claim_id"
        return [self._row(r) for r in self.conn.execute(sql, params).fetchall()]

    def claims_referencing_evidence(self, evidence_id: str) -> list[ClinicalClaim]:
        return [c for c in self.list() if evidence_id in c.all_evidence_ids()]

    @staticmethod
    def _row(row: Any) -> ClinicalClaim:
        return ClinicalClaim(
            claim_id=row["claim_id"],
            text=row["text"],
            favorable_evidence_ids=tuple(_loads(row["favorable_evidence_ids"], [])),
            contrary_evidence_ids=tuple(_loads(row["contrary_evidence_ids"], [])),
            inconclusive_evidence_ids=tuple(_loads(row["inconclusive_evidence_ids"], [])),
            population_context=row["population_context"],
            applicability=row["applicability"],
            limitations=tuple(_loads(row["limitations"], [])),
            certainty_level=_enum(CertaintyLevel, row["certainty_level"], CertaintyLevel.NOT_ASSESSED),
            certainty_framework=_enum(
                CertaintyFramework, row["certainty_framework"], CertaintyFramework.NONE
            ),
            curation_status=_enum(CurationStatus, row["curation_status"], CurationStatus.IMPORTED_UNVERIFIED),
            version=row["version"] or 1,
            origin=_enum(KnowledgeOrigin, row["origin"], KnowledgeOrigin.IMPORTED),
            review_history=tuple(_loads(row["review_history"], [])),
            superseded_by=row["superseded_by"],
            created_at=parse_dt(row["created_at"]) if row["created_at"] else None,
            updated_at=parse_dt(row["updated_at"]) if row["updated_at"] else None,
            content_hash_value=row["content_hash"],
        )


# ---------------------------------------------------------------------------
# Evidence links (GATE 4)
# ---------------------------------------------------------------------------
class EvidenceLinkRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def save(self, link: EvidenceLink, *, commit: bool = True) -> EvidenceLink:
        from ..core import ids

        with self.database.write_lock:
            link.link_id = link.link_id or ids.new_id("link")
            link.created_at = link.created_at or now_utc()
            self.conn.execute(
                """
                INSERT OR REPLACE INTO evidence_links (
                    link_id, subject_type, subject_id, target_type, target_id,
                    target_version, relation, applicability, created_by, created_at,
                    justification, verification_status, link_version
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    link.link_id,
                    link.subject_type.value,
                    link.subject_id,
                    link.target_type.value,
                    link.target_id,
                    link.target_version,
                    link.relation.value,
                    link.applicability,
                    link.created_by,
                    to_iso(link.created_at),
                    link.justification,
                    link.verification_status,
                    link.link_version,
                ),
            )
            if commit:
                self.conn.commit()
        return link

    def for_target(
        self, target_type: LinkTargetType, target_id: str, *, target_version: int | None = None
    ) -> list[EvidenceLink]:
        sql = "SELECT * FROM evidence_links WHERE target_type = ? AND target_id = ?"
        params: list[Any] = [target_type.value, target_id]
        if target_version is not None:
            sql += " AND (target_version IS NULL OR target_version = ?)"
            params.append(target_version)
        return [self._row(r) for r in self.conn.execute(sql, params).fetchall()]

    def for_subject(self, subject_type: CurationSubjectType, subject_id: str) -> list[EvidenceLink]:
        rows = self.conn.execute(
            "SELECT * FROM evidence_links WHERE subject_type = ? AND subject_id = ?",
            (subject_type.value, subject_id),
        ).fetchall()
        return [self._row(r) for r in rows]

    @staticmethod
    def _row(row: Any) -> EvidenceLink:
        keys = row.keys()
        return EvidenceLink(
            link_id=row["link_id"],
            subject_type=_enum(CurationSubjectType, row["subject_type"], CurationSubjectType.EVIDENCE),
            subject_id=row["subject_id"],
            target_type=_enum(LinkTargetType, row["target_type"], LinkTargetType.FORMULA),
            target_id=row["target_id"],
            relation=_enum(EvidenceRelation, row["relation"], EvidenceRelation.DISCUSSION),
            target_version=row["target_version"],
            applicability=row["applicability"],
            created_by=row["created_by"],
            created_at=parse_dt(row["created_at"]) if row["created_at"] else None,
            justification=row["justification"] if "justification" in keys else None,
            verification_status=row["verification_status"] if "verification_status" in keys and row["verification_status"] else "UNVERIFIED",
            link_version=row["link_version"] if "link_version" in keys and row["link_version"] else 1,
        )


# ---------------------------------------------------------------------------
# Curation events (audit)
# ---------------------------------------------------------------------------
class CurationEventRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def append(self, event: CurationEvent, *, commit: bool = True) -> CurationEvent:
        from ..core import ids

        with self.database.write_lock:
            event.event_id = event.event_id or ids.new_id("curev")
            event.created_at = event.created_at or now_utc()
            self.conn.execute(
                """
                INSERT INTO curation_events (
                    event_id, subject_type, subject_id, from_status, to_status, actor,
                    justification, version, created_at
                ) VALUES (?,?,?,?,?,?,?,?,?)
                """,
                (
                    event.event_id,
                    event.subject_type.value,
                    event.subject_id,
                    event.from_status.value if event.from_status else None,
                    event.to_status.value,
                    event.actor,
                    event.justification,
                    event.version,
                    to_iso(event.created_at),
                ),
            )
            if commit:
                self.conn.commit()
        return event

    def history(self, subject_type: CurationSubjectType, subject_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM curation_events WHERE subject_type = ? AND subject_id = ? ORDER BY created_at",
            (subject_type.value, subject_id),
        ).fetchall()
        return [dict(row) for row in rows]


# ---------------------------------------------------------------------------
# Search (GATE 6)
# ---------------------------------------------------------------------------
def _match(query: str) -> str:
    terms = _TERM_RE.findall(query or "")
    return " AND ".join(f'"{t}"*' for t in terms)


class ScientificSearch:
    def __init__(self, database: Database) -> None:
        self.conn = database.knowledge

    def search_references(
        self,
        query: str = "",
        *,
        limit: int = 25,
        status: str | None = None,
        publication_type: str | None = None,
        year: int | None = None,
        author: str | None = None,
        bibliographic_status: str | None = None,
        content_review_status: str | None = None,
        only_ids: set[str] | None = None,
        exclude_ids: set[str] | None = None,
    ) -> list[dict[str, Any]]:
        ids: list[str] | None = None
        if query.strip():
            ids = self._fts_ids("reference_fts", "reference_id", query, limit)
        rows = self.conn.execute("SELECT * FROM scientific_references").fetchall()
        results = []
        for row in rows:
            data = dict(row)
            if ids is not None and data["reference_id"] not in ids:
                continue
            if only_ids is not None and data["reference_id"] not in only_ids:
                continue
            if exclude_ids and data["reference_id"] in exclude_ids:
                continue
            if status and data["curation_status"] != status:
                continue
            if publication_type and data["publication_type"] != publication_type:
                continue
            if year is not None and data["publication_year"] != year:
                continue
            if bibliographic_status and data.get("bibliographic_status") != bibliographic_status:
                continue
            if content_review_status and data.get("content_review_status") != content_review_status:
                continue
            if author:
                authors = " ".join(_loads(data["authors"], [])).lower()
                if author.lower() not in authors:
                    continue
            results.append(data)
        if ids is not None:
            order = {rid: i for i, rid in enumerate(ids)}
            results.sort(key=lambda d: order.get(d["reference_id"], 1_000_000))
        return results[:limit]

    def _fts_ids(self, table: str, id_column: str, query: str, limit: int) -> list[str]:
        expression = _match(query)
        if not expression:
            return []
        try:
            rows = self.conn.execute(
                f"SELECT {id_column} FROM {table} WHERE {table} MATCH ? ORDER BY rank LIMIT ?",
                (expression, limit),
            ).fetchall()
            ids = [row[id_column] for row in rows]
            if ids:
                return ids
        except sqlite3.OperationalError:
            pass
        # Safe LIKE fallback against the base table (never the fts table name).
        base_table = _FTS_BASE.get(table)
        if base_table is None:
            return []
        like = f"%{query.strip()}%"
        rows = self.conn.execute(
            f"SELECT {id_column} FROM {base_table} WHERE title LIKE ? LIMIT ?",
            (like, limit),
        ).fetchall()
        return [row[id_column] for row in rows]
