"""Prototype evaluator for formula candidates (R2C-A GATE 5).

This module exists ONLY to validate candidate definitions mathematically in tests.
It is deliberately NOT wired into clinical synthesis and never produces
interpretation or diagnosis. Statuses are values, never silent substitutions.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from ..core.enums import InputSemantics, TemporalRequirement
from ..core.expression import compile_expression
from ..core.timeutil import parse_dt, same_calendar_day
from ..core.units import convert, is_known, same_dimension
from ..errors import ExpressionError, UnitConversionError, UnknownUnitError
from .applicability import APPLICABILITY_NOT_ESTABLISHED, NOT_APPLICABLE
from .formula_candidates import FormulaCandidate
from .input_semantics import InputValue


@dataclass
class PrototypeResult:
    status: str
    value: float | None = None
    unit: str | None = None
    resolved: list[dict[str, Any]] = None  # type: ignore[assignment]
    reason: str | None = None

    def __post_init__(self) -> None:
        if self.resolved is None:
            self.resolved = []

    @property
    def is_valid(self) -> bool:
        return self.status == "VALID"


def _temporal_ok(candidate: FormulaCandidate, inputs: dict[str, InputValue]) -> tuple[bool, str]:
    requirement = candidate.temporal_requirement
    if requirement in (TemporalRequirement.LATEST_AVAILABLE, TemporalRequirement.OTHER_EXPLICIT_RULE):
        return True, ""
    stamps = [parse_dt(v.effective_at) for v in inputs.values() if v.effective_at]
    if len(stamps) != len(inputs):
        return False, "temporal requirement set but some inputs lack a clinical date (UNKNOWN)"
    if requirement is TemporalRequirement.SAME_COLLECTION:
        return (len(set(stamps)) == 1, "inputs are not from the same collection")
    if requirement is TemporalRequirement.SAME_DAY:
        first = stamps[0]
        return (all(same_calendar_day(first, s) for s in stamps), "inputs are not from the same day")
    if requirement is TemporalRequirement.WITHIN_N_DAYS:
        window = candidate.temporal_window_days
        if window is None:
            return False, "WITHIN_N_DAYS without a window"
        span = (max(stamps) - min(stamps)).total_seconds() / 86400.0
        return (span <= window, f"inputs span {span:.1f} days > {window}")
    return True, ""


def evaluate_candidate_prototype(
    candidate: FormulaCandidate,
    inputs: dict[str, InputValue],
    *,
    population: str | None = None,
    device: str | None = None,
) -> PrototypeResult:
    """Evaluate a candidate in a *prototype* context. Not for clinical use."""
    if candidate.applicability.has_constraints():
        applicability = candidate.applicability.evaluate(population=population, device=device)
        if applicability["status"] in (NOT_APPLICABLE, APPLICABILITY_NOT_ESTABLISHED):
            return PrototypeResult(status=applicability["status"], reason=applicability["reason"])

    # Presence.
    for var in candidate.variables:
        if var.required:
            value = inputs.get(var.name)
            if value is None or value.value is None:
                return PrototypeResult(
                    status="INSUFFICIENT_INPUT",
                    reason=f"missing required input {var.name!r} (never treated as zero)",
                )

    # Semantics and units.
    resolved: list[dict[str, Any]] = []
    variables: dict[str, float] = {}
    for var in candidate.variables:
        value = inputs.get(var.name)
        if value is None or value.value is None:
            continue
        if value.semantics not in var.allowed_semantics:
            return PrototypeResult(
                status="SEMANTICS_MISMATCH",
                reason=(
                    f"input {var.name!r} is {value.semantics.value}; allowed "
                    f"{[s.value for s in var.allowed_semantics]}"
                ),
            )
        if not is_known(value.unit):
            return PrototypeResult(status="UNIT_INCOMPATIBLE", reason=f"unknown unit {value.unit!r}")
        try:
            if not same_dimension(value.unit, var.unit):
                return PrototypeResult(
                    status="UNIT_INCOMPATIBLE",
                    reason=f"{var.name!r}: {value.unit!r} is not dimensionally compatible with {var.unit!r}",
                )
            normalized = convert(value.value, value.unit, var.unit)
        except (UnitConversionError, UnknownUnitError) as exc:
            return PrototypeResult(status="UNIT_INCOMPATIBLE", reason=str(exc))
        if not math.isfinite(normalized):
            return PrototypeResult(status="NOT_FINITE", reason=f"{var.name!r} is not finite")
        variables[var.name] = normalized
        resolved.append(
            {
                "name": var.name,
                "semantics": value.semantics.value,
                "original_value": value.value,
                "original_unit": value.unit,
                "normalized_value": normalized,
                "normalized_unit": var.unit,
                "device": value.device,
                "provenance": value.provenance(),
            }
        )

    # Refusal conditions (defined domain).
    for condition in candidate.refusal_conditions:
        try:
            if bool(compile_expression(condition).evaluate(variables)):
                return PrototypeResult(
                    status="OUTSIDE_DEFINED_DOMAIN",
                    reason=f"refusal condition met: {condition}",
                    resolved=resolved,
                )
        except ExpressionError as exc:
            return PrototypeResult(status="ERROR", reason=str(exc), resolved=resolved)

    # Temporal alignment.
    ok, reason = _temporal_ok(candidate, {k: inputs[k] for k in variables})
    if not ok:
        return PrototypeResult(status="TEMPORALLY_INCOMPATIBLE", reason=reason, resolved=resolved)

    # Evaluate.
    try:
        value = float(compile_expression(candidate.expression).evaluate(variables))
    except ZeroDivisionError:
        return PrototypeResult(status="DIVISION_BY_ZERO", resolved=resolved)
    except ExpressionError as exc:
        return PrototypeResult(status="ERROR", reason=str(exc), resolved=resolved)
    if not math.isfinite(value):
        return PrototypeResult(status="NOT_FINITE", resolved=resolved)
    return PrototypeResult(status="VALID", value=value, unit=candidate.output_unit, resolved=resolved)
