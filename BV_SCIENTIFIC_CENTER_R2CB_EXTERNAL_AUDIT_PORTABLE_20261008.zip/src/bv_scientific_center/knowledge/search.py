"""Full-text search over the knowledge repository (SQLite FTS5, offline).

No cloud vector database is required. Embeddings, if ever added, are an index -
the citation database remains the source of truth and stays usable without them.
"""

from __future__ import annotations

import re
import sqlite3
from typing import Any

from .models import ScientificKnowledgeItem

_TERM_RE = re.compile(r"\w+", re.UNICODE)


def index_item(conn: sqlite3.Connection, item: ScientificKnowledgeItem) -> None:
    conn.execute("DELETE FROM knowledge_fts WHERE knowledge_id = ?", (item.knowledge_id,))
    conn.execute(
        """
        INSERT INTO knowledge_fts (knowledge_id, title, summary, key_points, topic, tags)
        VALUES (?,?,?,?,?,?)
        """,
        (
            item.knowledge_id,
            item.title,
            item.summary,
            " ".join(item.key_points),
            item.topic,
            " ".join(item.tags),
        ),
    )


def remove_item(conn: sqlite3.Connection, knowledge_id: str) -> None:
    conn.execute("DELETE FROM knowledge_fts WHERE knowledge_id = ?", (knowledge_id,))


def _match_expression(query: str) -> str:
    terms = _TERM_RE.findall(query or "")
    return " AND ".join(f'"{t}"*' for t in terms)


def search_knowledge_ids(
    conn: sqlite3.Connection, query: str, limit: int = 25
) -> list[str]:
    """Return knowledge ids ranked by relevance; falls back to LIKE search."""
    match = _match_expression(query)
    if not match:
        return []
    try:
        rows = conn.execute(
            """
            SELECT knowledge_id FROM knowledge_fts
            WHERE knowledge_fts MATCH ?
            ORDER BY rank
            LIMIT ?
            """,
            (match, limit),
        ).fetchall()
        ids = [row["knowledge_id"] for row in rows]
        if ids:
            return ids
    except sqlite3.OperationalError:
        pass  # fall through to LIKE

    like = f"%{query.strip()}%"
    rows = conn.execute(
        """
        SELECT knowledge_id FROM knowledge_items
        WHERE title LIKE ? OR summary LIKE ? OR key_points LIKE ? OR topic LIKE ?
        LIMIT ?
        """,
        (like, like, like, like, limit),
    ).fetchall()
    return [row["knowledge_id"] for row in rows]


def search_items(
    conn: sqlite3.Connection, query: str, limit: int = 25
) -> list[dict[str, Any]]:
    ids = search_knowledge_ids(conn, query, limit)
    if not ids:
        return []
    placeholders = ",".join("?" for _ in ids)
    rows = conn.execute(
        f"SELECT * FROM knowledge_items WHERE knowledge_id IN ({placeholders})", ids
    ).fetchall()
    by_id = {row["knowledge_id"]: row for row in rows}
    return [dict(by_id[i]) for i in ids if i in by_id]
