"""Persistence for knowledge items, claims, references and packages.

The knowledge database holds NO patient data (spec §85). This module never reads
from the clinical database.
"""

from __future__ import annotations

import json
from typing import Any

from ..core.enums import KnowledgeOrigin, KnowledgeStatus, PackageReviewStatus
from ..core.serialization import dumps
from ..core.timeutil import now_utc, parse_dt, to_iso
from ..errors import (
    CitationRequiredError,
    ImmutablePublishError,
    KnowledgeGovernanceError,
)
from ..storage.database import Database
from . import search
from .models import KnowledgeReference, ScientificClaim, ScientificKnowledgeItem
from .packages import KnowledgePackage


def _loads(value: str | None, default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return default


class KnowledgeRepository:
    def __init__(self, database: Database) -> None:
        self.conn = database.knowledge

    # -- items -------------------------------------------------------------
    def save_item(
        self, item: ScientificKnowledgeItem, *, require_citation: bool = True
    ) -> ScientificKnowledgeItem:
        if item.status is KnowledgeStatus.APPROVED:
            if item.origin is KnowledgeOrigin.SYNTHETIC_TEST:
                raise KnowledgeGovernanceError(
                    f"Knowledge item {item.knowledge_id!r} is SYNTHETIC_TEST content and can "
                    "never be APPROVED for clinical use"
                )
            if not item.can_approve(require_citation=require_citation):
                raise CitationRequiredError(
                    f"Knowledge item {item.knowledge_id!r} cannot be APPROVED without "
                    "citation metadata"
                )
        # Preserve the original registration/review timestamps across updates
        # (INSERT OR REPLACE must not silently reset metadata).
        existing = self.conn.execute(
            "SELECT created_at, reviewed_at FROM knowledge_items WHERE knowledge_id = ?",
            (item.knowledge_id,),
        ).fetchone()
        created_at = item.created_at
        if created_at is None and existing is not None and existing["created_at"]:
            created_at = parse_dt(existing["created_at"])
        created_at = created_at or now_utc()
        reviewed_at = item.reviewed_at
        if reviewed_at is None and existing is not None and existing["reviewed_at"]:
            reviewed_at = parse_dt(existing["reviewed_at"])
        if item.status is KnowledgeStatus.APPROVED and reviewed_at is None:
            reviewed_at = now_utc()
        self.conn.execute(
            """
            INSERT OR REPLACE INTO knowledge_items (
                knowledge_id, title, topic, subtopic, summary, key_points, source_type,
                publication_year, authors, journal, doi, url, citation, evidence_level,
                evidence_framework, evidence_grade, certainty, reviewer, target_type,
                origin, tags, status, package_id, package_version, created_at, reviewed_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                item.knowledge_id,
                item.title,
                item.topic,
                item.subtopic,
                item.summary,
                dumps(item.key_points),
                item.source_type.value,
                item.publication_year,
                dumps(item.authors),
                item.journal,
                item.doi,
                item.url,
                item.citation,
                item.evidence_level,
                item.evidence_framework,
                item.evidence_grade,
                item.certainty,
                item.reviewer,
                item.target_type.value if item.target_type else None,
                item.origin.value,
                dumps(item.tags),
                item.status.value,
                item.package_id,
                item.package_version,
                to_iso(created_at),
                to_iso(reviewed_at),
            ),
        )
        search.index_item(self.conn, item)
        self.conn.commit()
        return item

    def get_item(self, knowledge_id: str) -> ScientificKnowledgeItem | None:
        row = self.conn.execute(
            "SELECT * FROM knowledge_items WHERE knowledge_id = ?", (knowledge_id,)
        ).fetchone()
        return self._row_to_item(row) if row else None

    def list_items(self, *, topic: str | None = None, status: str | None = None) -> list[ScientificKnowledgeItem]:
        sql = "SELECT * FROM knowledge_items"
        clauses: list[str] = []
        params: list[Any] = []
        if topic:
            clauses.append("topic = ?")
            params.append(topic)
        if status:
            clauses.append("status = ?")
            params.append(status)
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY title"
        rows = self.conn.execute(sql, params).fetchall()
        return [self._row_to_item(r) for r in rows]

    def delete_item(self, knowledge_id: str) -> None:
        self.conn.execute("DELETE FROM knowledge_items WHERE knowledge_id = ?", (knowledge_id,))
        search.remove_item(self.conn, knowledge_id)
        self.conn.commit()

    def set_status(self, knowledge_id: str, status: KnowledgeStatus) -> None:
        item = self.get_item(knowledge_id)
        if item is None:
            raise KeyError(f"Unknown knowledge item: {knowledge_id!r}")
        item.status = status
        # Governance (synthetic/citation) is enforced inside save_item.
        self.save_item(item)

    # -- claims & references ----------------------------------------------
    def save_claim(self, claim: ScientificClaim) -> ScientificClaim:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO knowledge_claims (
                claim_id, text, knowledge_item_id, supporting_reference_ids,
                review_status, created_at
            ) VALUES (?,?,?,?,?,?)
            """,
            (
                claim.claim_id,
                claim.text,
                claim.knowledge_item_id,
                dumps(claim.supporting_reference_ids),
                claim.review_status.value,
                to_iso(claim.created_at or now_utc()),
            ),
        )
        self.conn.commit()
        return claim

    def claims_for_item(self, knowledge_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM knowledge_claims WHERE knowledge_item_id = ?", (knowledge_id,)
        ).fetchall()
        result = []
        for row in rows:
            data = dict(row)
            data["supporting_reference_ids"] = _loads(data.get("supporting_reference_ids"), [])
            result.append(data)
        return result

    def save_reference(self, reference: KnowledgeReference) -> KnowledgeReference:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO knowledge_references (
                reference_id, citation, title, source, year, doi, url, item_id, created_at
            ) VALUES (?,?,?,?,?,?,?,?,?)
            """,
            (
                reference.reference_id,
                reference.citation,
                reference.title,
                reference.source,
                reference.year,
                reference.doi,
                reference.url,
                reference.item_id,
                to_iso(reference.created_at or now_utc()),
            ),
        )
        self.conn.commit()
        return reference

    def get_reference(self, reference_id: str) -> KnowledgeReference | None:
        row = self.conn.execute(
            "SELECT * FROM knowledge_references WHERE reference_id = ?", (reference_id,)
        ).fetchone()
        if not row:
            return None
        return KnowledgeReference(
            reference_id=row["reference_id"],
            citation=row["citation"],
            title=row["title"],
            source=row["source"],
            year=row["year"],
            doi=row["doi"],
            url=row["url"],
            item_id=row["item_id"],
        )

    # -- search ------------------------------------------------------------
    def search(self, query: str, limit: int = 25) -> list[dict[str, Any]]:
        return search.search_items(self.conn, query, limit)

    @staticmethod
    def _row_to_item(row: Any) -> ScientificKnowledgeItem:
        from ..core.enums import KnowledgeOrigin, KnowledgeSourceType, TargetType

        return ScientificKnowledgeItem(
            knowledge_id=row["knowledge_id"],
            title=row["title"],
            topic=row["topic"] or "",
            subtopic=row["subtopic"],
            summary=row["summary"] or "",
            key_points=tuple(_loads(row["key_points"], [])),
            source_type=KnowledgeSourceType(row["source_type"] or "OTHER"),
            publication_year=row["publication_year"],
            authors=tuple(_loads(row["authors"], [])),
            journal=row["journal"],
            doi=row["doi"],
            url=row["url"],
            citation=row["citation"] or "",
            evidence_level=row["evidence_level"],
            evidence_framework=row["evidence_framework"],
            evidence_grade=row["evidence_grade"],
            certainty=row["certainty"],
            reviewer=row["reviewer"],
            target_type=TargetType(row["target_type"]) if row["target_type"] else None,
            tags=tuple(_loads(row["tags"], [])),
            status=KnowledgeStatus(row["status"]),
            origin=KnowledgeOrigin(row["origin"])
            if "origin" in row.keys() and row["origin"]
            else KnowledgeOrigin.IMPORTED,
            package_id=row["package_id"],
            package_version=row["package_version"],
            created_at=parse_dt(row["created_at"]) if row["created_at"] else None,
            reviewed_at=parse_dt(row["reviewed_at"]) if row["reviewed_at"] else None,
        )


class PackageRepository:
    def __init__(self, database: Database) -> None:
        self.conn = database.knowledge

    def save(self, package: KnowledgePackage) -> KnowledgePackage:
        package.validate()
        existing = self.get(package.package_id, package.version)
        if existing is not None:
            if existing["hash"] != package.hash():
                raise ImmutablePublishError(
                    f"Knowledge package {package.package_id!r} v{package.version} already "
                    "exists with different content; publish a new version"
                )
            return package
        payload = package.to_payload()
        self.conn.execute(
            """
            INSERT INTO knowledge_packages (
                package_id, version, name, domain, payload, source_manifest,
                review_status, created_at, activated_at, is_active
            ) VALUES (?,?,?,?,?,?,?,?,?,0)
            """,
            (
                package.package_id,
                package.version,
                package.name,
                package.domain,
                dumps(payload),
                dumps(package.source_manifest),
                package.review_status.value,
                to_iso(package.created_at or now_utc()),
                None,
            ),
        )
        self.conn.commit()
        return package

    def get(self, package_id: str, version: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM knowledge_packages WHERE package_id = ? AND version = ?",
            (package_id, version),
        ).fetchone()
        if not row:
            return None
        return self._row(row)

    def list_packages(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM knowledge_packages ORDER BY package_id, version"
        ).fetchall()
        return [self._row(r) for r in rows]

    def activate(self, package_id: str, version: str) -> dict[str, Any]:
        if self.get(package_id, version) is None:
            raise KeyError(f"Unknown package {package_id!r} v{version}")
        self.conn.execute("UPDATE knowledge_packages SET is_active = 0")
        self.conn.execute(
            """
            UPDATE knowledge_packages
            SET is_active = 1, review_status = ?, activated_at = ?
            WHERE package_id = ? AND version = ?
            """,
            (PackageReviewStatus.ACTIVATED.value, to_iso(now_utc()), package_id, version),
        )
        self.conn.commit()
        return self.get(package_id, version)  # type: ignore[return-value]

    def deactivate(self, package_id: str, version: str) -> None:
        self.conn.execute(
            """
            UPDATE knowledge_packages
            SET is_active = 0, review_status = ?
            WHERE package_id = ? AND version = ?
            """,
            (PackageReviewStatus.DEACTIVATED.value, package_id, version),
        )
        self.conn.commit()

    def active_package(self) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM knowledge_packages WHERE is_active = 1 LIMIT 1"
        ).fetchone()
        return self._row(row) if row else None

    @staticmethod
    def _row(row: Any) -> dict[str, Any]:
        payload = _loads(row["payload"], {})
        return {
            "package_id": row["package_id"],
            "version": row["version"],
            "name": row["name"],
            "domain": row["domain"],
            "review_status": row["review_status"],
            "is_active": bool(row["is_active"]),
            "activated_at": row["activated_at"],
            "created_at": row["created_at"],
            "payload": payload,
            "source_manifest": _loads(row["source_manifest"], []),
            "hash": KnowledgePackage.from_dict(payload).hash() if payload else None,
        }
