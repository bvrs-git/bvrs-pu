"""Knowledge repository domain models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core.enums import (
    ClaimReviewStatus,
    KnowledgeOrigin,
    KnowledgeSourceType,
    KnowledgeStatus,
    TargetType,
)


@dataclass
class KnowledgeReference:
    reference_id: str
    citation: str = ""
    title: str | None = None
    source: str | None = None          # journal / publisher / institution
    year: int | None = None
    doi: str | None = None
    url: str | None = None
    item_id: str | None = None
    created_at: datetime | None = None

    def has_minimum_citation(self) -> bool:
        """A claim cannot be APPROVED without usable citation metadata."""
        locator = bool(self.doi or self.url or self.source)
        return bool(self.citation.strip()) and self.year is not None and locator

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "KnowledgeReference":
        return cls(
            reference_id=data.get("reference_id", ""),
            citation=data.get("citation", ""),
            title=data.get("title"),
            source=data.get("source"),
            year=data.get("year"),
            doi=data.get("doi"),
            url=data.get("url"),
            item_id=data.get("item_id"),
        )


@dataclass
class ScientificKnowledgeItem:
    knowledge_id: str
    title: str
    topic: str = ""
    subtopic: str | None = None
    summary: str = ""
    key_points: tuple[str, ...] = ()
    source_type: KnowledgeSourceType = KnowledgeSourceType.OTHER
    publication_year: int | None = None
    authors: tuple[str, ...] = ()
    journal: str | None = None
    doi: str | None = None
    url: str | None = None
    citation: str = ""
    evidence_level: str | None = None
    evidence_framework: str | None = None
    evidence_grade: str | None = None
    certainty: str | None = None
    reviewer: str | None = None
    target_type: TargetType | None = None
    tags: tuple[str, ...] = ()
    status: KnowledgeStatus = KnowledgeStatus.DRAFT
    origin: KnowledgeOrigin = KnowledgeOrigin.IMPORTED
    package_id: str | None = None
    package_version: str | None = None
    created_at: datetime | None = None
    reviewed_at: datetime | None = None

    def has_minimum_citation(self) -> bool:
        locator = bool(self.doi or self.url or self.journal)
        return bool(self.citation.strip()) and self.publication_year is not None and locator

    def can_approve(self, *, require_citation: bool = True) -> bool:
        # Governance: synthetic test content can never be approved for clinical
        # use, regardless of citation metadata (spec R1.1 GATE 4 / restriction 9).
        if self.origin is KnowledgeOrigin.SYNTHETIC_TEST:
            return False
        if require_citation and not self.has_minimum_citation():
            return False
        return True

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScientificKnowledgeItem":
        from ..core.definition import coerce_enum

        source_type = data.get("source_type", "OTHER")
        status = data.get("status", "DRAFT")
        target_type = data.get("target_type")
        return cls(
            knowledge_id=data["knowledge_id"],
            title=data["title"],
            topic=data.get("topic", ""),
            subtopic=data.get("subtopic"),
            summary=data.get("summary", ""),
            key_points=tuple(data.get("key_points", ())),
            source_type=coerce_enum(KnowledgeSourceType, source_type),
            publication_year=data.get("publication_year"),
            authors=tuple(data.get("authors", ())),
            journal=data.get("journal"),
            doi=data.get("doi"),
            url=data.get("url"),
            citation=data.get("citation", ""),
            evidence_level=data.get("evidence_level"),
            evidence_framework=data.get("evidence_framework"),
            evidence_grade=data.get("evidence_grade"),
            certainty=data.get("certainty"),
            reviewer=data.get("reviewer"),
            target_type=coerce_enum(TargetType, target_type) if target_type else None,
            tags=tuple(data.get("tags", ())),
            status=coerce_enum(KnowledgeStatus, status),
            origin=coerce_enum(KnowledgeOrigin, data.get("origin", "IMPORTED")),
            package_id=data.get("package_id"),
            package_version=data.get("package_version"),
        )


@dataclass
class ScientificClaim:
    claim_id: str
    text: str
    knowledge_item_id: str | None = None
    supporting_reference_ids: tuple[str, ...] = ()
    review_status: ClaimReviewStatus = ClaimReviewStatus.UNREVIEWED
    created_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


@dataclass
class TargetRange:
    """A target is never conflated with a lab reference range (spec §44)."""

    target_type: TargetType
    population: str | None
    source: str
    version: str
    evidence_refs: tuple[str, ...] = ()
    low: float | None = None
    high: float | None = None
    unit: str | None = None
    note: str | None = None

    def attribution(self) -> dict[str, Any]:
        return {
            "target_type": self.target_type.value,
            "population": self.population,
            "source": self.source,
            "version": self.version,
            "evidence_refs": list(self.evidence_refs),
        }
