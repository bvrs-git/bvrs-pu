"""Curation workflow service (R2A GATE 2).

Enforces the curation state machine, requires explicit human approval
(reviewer + justification + version), guards synthetic content, and records an
audit event for every transition. A retracted/rejected/superseded item can no
longer be presented as current evidence for clinical grounding.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from ..core.enums import KnowledgeOrigin
from ..core.timeutil import now_utc
from ..errors import (
    CurationApprovalError,
    CurationTransitionError,
    EvidenceGovernanceError,
)
from .scientific import (
    CurationEvent,
    CurationStatus,
    CurationSubjectType,
    is_clinically_usable,
    require_approval_actor,
)
from .scientific_repository import (
    ClinicalClaimRepository,
    CurationEventRepository,
    ScientificEvidenceRepository,
    ScientificReferenceRepository,
)


def _subject_type(value) -> CurationSubjectType:
    if isinstance(value, CurationSubjectType):
        return value
    text = str(value).strip().upper()
    try:
        return CurationSubjectType(text)
    except ValueError as exc:
        raise KeyError(f"Unknown curation subject type: {value!r}") from exc


@dataclass
class CurationOutcome:
    subject_type: CurationSubjectType
    subject_id: str
    from_status: CurationStatus | None
    to_status: CurationStatus
    version: int
    actor: str | None
    justification: str | None
    created_at: datetime

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


class CurationService:
    def __init__(
        self,
        *,
        references: ScientificReferenceRepository,
        evidence: ScientificEvidenceRepository,
        claims: ClinicalClaimRepository,
        events: CurationEventRepository,
    ) -> None:
        self.references = references
        self.evidence = evidence
        self.claims = claims
        self.events = events

    # -- subject load/save -------------------------------------------------
    def _load(self, subject_type: CurationSubjectType, subject_id: str):
        subject_type = _subject_type(subject_type)
        loaders = {
            CurationSubjectType.REFERENCE: self.references.get,
            CurationSubjectType.EVIDENCE: self.evidence.get,
            CurationSubjectType.CLAIM: self.claims.get,
        }
        subject = loaders[subject_type](subject_id)
        if subject is None:
            raise KeyError(f"Unknown {subject_type.value} subject: {subject_id!r}")
        return subject

    def _save(self, subject_type: CurationSubjectType, subject) -> None:
        subject_type = _subject_type(subject_type)
        savers = {
            CurationSubjectType.REFERENCE: self.references.save,
            CurationSubjectType.EVIDENCE: self.evidence.save,
            CurationSubjectType.CLAIM: self.claims.save,
        }
        savers[subject_type](subject)

    # -- core transition ---------------------------------------------------
    def transition(
        self,
        subject_type: CurationSubjectType,
        subject_id: str,
        to_status: CurationStatus,
        *,
        actor: str | None = None,
        justification: str | None = None,
    ) -> CurationOutcome:
        from .scientific import can_transition

        subject_type = _subject_type(subject_type)
        to_status = CurationStatus(to_status) if not isinstance(to_status, CurationStatus) else to_status
        subject = self._load(subject_type, subject_id)
        current = CurationStatus(subject.curation_status)

        if to_status is current:
            raise CurationTransitionError(
                f"{subject_id!r} is already {current.value}; no-op transitions are not recorded"
            )
        if not can_transition(current, to_status):
            raise CurationTransitionError(
                f"Illegal curation transition for {subject_id!r}: "
                f"{current.value} -> {to_status.value}"
            )

        if to_status is CurationStatus.APPROVED:
            if getattr(subject, "origin", KnowledgeOrigin.IMPORTED) is KnowledgeOrigin.SYNTHETIC_TEST:
                raise EvidenceGovernanceError(
                    f"{subject_id!r} is SYNTHETIC_TEST content and can never be APPROVED"
                )
            require_approval_actor(actor, justification)
            if hasattr(subject, "can_approve") and not subject.can_approve():
                raise EvidenceGovernanceError(
                    f"{subject_id!r} does not meet approval requirements "
                    "(verification, stable identifier, or supporting evidence)"
                )
            if getattr(subject, "is_retracted", lambda: False)():
                raise EvidenceGovernanceError(f"{subject_id!r} is retracted and cannot be APPROVED")

        subject.curation_status = to_status
        subject.version = (subject.version or 1) + 1
        if getattr(subject, "superseded_by", None) is not None and to_status is CurationStatus.SUPERSEDED:
            subject.superseded_by = subject.superseded_by
        self._save(subject_type, subject)

        event = CurationEvent(
            event_id="",
            subject_type=subject_type,
            subject_id=subject_id,
            from_status=current,
            to_status=to_status,
            actor=actor,
            justification=justification,
            version=subject.version,
            created_at=now_utc(),
        )
        self.events.append(event)
        return CurationOutcome(
            subject_type=subject_type,
            subject_id=subject_id,
            from_status=current,
            to_status=to_status,
            version=subject.version,
            actor=actor,
            justification=justification,
            created_at=event.created_at,  # type: ignore[arg-type]
        )

    # -- convenience -------------------------------------------------------
    def screen(self, subject_type, subject_id, *, actor, justification=None):
        return self.transition(subject_type, subject_id, CurationStatus.SCREENED, actor=actor, justification=justification)

    def curate(self, subject_type, subject_id, *, actor, justification):
        return self.transition(subject_type, subject_id, CurationStatus.CURATED, actor=actor, justification=justification)

    def approve(self, subject_type, subject_id, *, reviewer, justification):
        return self.transition(
            subject_type, subject_id, CurationStatus.APPROVED, actor=reviewer, justification=justification
        )

    def reject(self, subject_type, subject_id, *, actor, justification):
        return self.transition(subject_type, subject_id, CurationStatus.REJECTED, actor=actor, justification=justification)

    def supersede(self, subject_type, subject_id, *, actor, justification, superseded_by=None):
        outcome = self.transition(
            subject_type, subject_id, CurationStatus.SUPERSEDED, actor=actor, justification=justification
        )
        if superseded_by is not None:
            subject = self._load(subject_type, subject_id)
            subject.superseded_by = superseded_by
            self._save(subject_type, subject)
        return outcome

    def retract(self, subject_type, subject_id, *, actor, reason):
        if not reason or not reason.strip():
            raise CurationApprovalError("Retraction requires a reason")
        outcome = self.transition(
            subject_type, subject_id, CurationStatus.RETRACTED, actor=actor, justification=reason
        )
        subject = self._load(subject_type, subject_id)
        if hasattr(subject, "retraction_reason"):
            subject.retraction_reason = reason
        if hasattr(subject, "editorial_status"):
            subject.editorial_status = "RETRACTED"
            subject.retraction_notes = reason
        self._save(subject_type, subject)
        return outcome

    # -- read models -------------------------------------------------------
    def history(self, subject_type: CurationSubjectType, subject_id: str) -> list[dict[str, Any]]:
        return self.events.history(_subject_type(subject_type), subject_id)

    def active_references(self) -> list:
        return [
            r
            for r in self.references.list(status=CurationStatus.APPROVED.value)
            if is_clinically_usable(r.curation_status)
        ]

    def is_clinically_usable(self, subject_type: CurationSubjectType, subject_id: str) -> bool:
        return is_clinically_usable(self._load(_subject_type(subject_type), subject_id).curation_status)

    def claims_impacted_by_retraction(self, evidence_id: str) -> list[dict[str, Any]]:
        """Claims that reference evidence which is now retracted/rejected/superseded."""
        evidence = self.evidence.get(evidence_id)
        if evidence is None:
            return []
        broken = evidence.is_retracted() or evidence.curation_status in {
            CurationStatus.RETRACTED,
            CurationStatus.REJECTED,
            CurationStatus.SUPERSEDED,
        }
        if not broken:
            return []
        impacted = []
        for claim in self.claims.claims_referencing_evidence(evidence_id):
            impacted.append(
                {
                    "claim_id": claim.claim_id,
                    "text": claim.text,
                    "curation_status": claim.curation_status.value,
                    "warning": "referenced evidence is retracted/rejected; claim is not current",
                }
            )
        return impacted
