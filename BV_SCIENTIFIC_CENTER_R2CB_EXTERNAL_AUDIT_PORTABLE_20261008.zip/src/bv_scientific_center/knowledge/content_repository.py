"""Persistence for acquired content snapshots and medical review decisions."""

from __future__ import annotations

import json
from typing import Any

from ..bibliography.content import ContentSnapshot
from ..core import ids
from ..core.serialization import dumps
from ..core.timeutil import now_utc, to_iso
from ..storage.database import Database


def _loads(value: Any, default: Any) -> Any:
    if not value:
        return default
    if isinstance(value, (list, dict)):
        return value
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return default


class AcquiredContentRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def save(self, snapshot: ContentSnapshot, *, commit: bool = True) -> ContentSnapshot:
        # Never persist text when storage is not permitted.
        text = snapshot.text if snapshot.storage_permitted else None
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO acquired_content (
                    content_id, reference_id, source, endpoint, queried_at, content_type,
                    identifiers_json, source_version, sha256, license, availability,
                    storage_permitted, storage_note, locator, text, created_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    snapshot.content_id,
                    snapshot.reference_id,
                    snapshot.source,
                    snapshot.endpoint,
                    to_iso(snapshot.queried_at),
                    snapshot.content_type.value,
                    dumps(snapshot.identifiers),
                    snapshot.source_version,
                    snapshot.sha256,
                    snapshot.license,
                    snapshot.availability.value,
                    1 if snapshot.storage_permitted else 0,
                    snapshot.storage_note,
                    snapshot.locator,
                    text,
                    to_iso(now_utc()),
                ),
            )
            if commit:
                self.conn.commit()
        return snapshot

    def latest(self, reference_id: str, content_type: str | None = None) -> dict[str, Any] | None:
        sql = "SELECT * FROM acquired_content WHERE reference_id = ?"
        params: list[Any] = [reference_id]
        if content_type:
            sql += " AND content_type = ?"
            params.append(content_type)
        sql += " ORDER BY created_at DESC LIMIT 1"
        row = self.conn.execute(sql, params).fetchone()
        return self._row(row) if row else None

    def for_reference(self, reference_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM acquired_content WHERE reference_id = ? ORDER BY created_at",
            (reference_id,),
        ).fetchall()
        return [self._row(r) for r in rows]

    def has_abstract(self, reference_id: str) -> bool:
        row = self.conn.execute(
            "SELECT COUNT(*) AS c FROM acquired_content WHERE reference_id = ? AND content_type = 'ABSTRACT'",
            (reference_id,),
        ).fetchone()
        return bool(row["c"])

    def count_by_availability(self) -> dict[str, int]:
        rows = self.conn.execute(
            "SELECT availability, COUNT(DISTINCT reference_id) AS n FROM acquired_content GROUP BY availability"
        ).fetchall()
        return {row["availability"]: row["n"] for row in rows}

    @staticmethod
    def _row(row: Any) -> dict[str, Any]:
        data = dict(row)
        data["identifiers"] = _loads(data.get("identifiers_json"), {})
        data["storage_permitted"] = bool(data.get("storage_permitted"))
        return data


class ReviewDecisionRepository:
    """Human medical decisions. The system records, never executes them."""

    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def record(
        self,
        *,
        reference_id: str,
        decision: str,
        actor: str,
        justification: str,
        reference_version: int | None = None,
        content_hash: str | None = None,
        commit: bool = True,
    ) -> str:
        if not actor or not actor.strip():
            raise ValueError("A review decision requires a declared actor identity")
        if not justification or not justification.strip():
            raise ValueError("A review decision requires a justification")
        decision_id = ids.new_id("decision")
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT INTO review_decisions (
                    decision_id, reference_id, decision, actor, justification,
                    reference_version, content_hash, created_at
                ) VALUES (?,?,?,?,?,?,?,?)
                """,
                (
                    decision_id,
                    reference_id,
                    decision,
                    actor,
                    justification,
                    reference_version,
                    content_hash,
                    to_iso(now_utc()),
                ),
            )
            if commit:
                self.conn.commit()
        return decision_id

    def for_reference(self, reference_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM review_decisions WHERE reference_id = ? ORDER BY created_at",
            (reference_id,),
        ).fetchall()
        return [dict(row) for row in rows]


class ContentExtractionRepository:
    """Citation-grounded extraction records (idempotent by content + version)."""

    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def save(self, extraction) -> str:
        with self.database.write_lock:
            # Idempotent: the same source + version maps to the same primary key.
            self.conn.execute(
                """
                INSERT OR IGNORE INTO content_extractions (
                    extraction_id, reference_id, content_id, source_kind, source_sha256,
                    extraction_version, fields_json, pending_fields_json, created_at
                ) VALUES (?,?,?,?,?,?,?,?,?)
                """,
                (
                    extraction.extraction_id,
                    extraction.reference_id,
                    extraction.content_id,
                    extraction.source_kind,
                    extraction.source_sha256,
                    extraction.extraction_version,
                    dumps({name: f.to_dict() for name, f in extraction.fields.items()}),
                    dumps(extraction.pending_fields()),
                    to_iso(extraction.created_at),
                ),
            )
            self.conn.commit()
        return extraction.extraction_id

    def _row(self, row: Any) -> dict[str, Any]:
        data = dict(row)
        data["fields"] = _loads(data.pop("fields_json", None), {})
        data["pending_fields"] = _loads(data.pop("pending_fields_json", None), [])
        return data

    def latest(self, reference_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM content_extractions WHERE reference_id = ? "
            "ORDER BY created_at DESC, extraction_id DESC LIMIT 1",
            (reference_id,),
        ).fetchone()
        return self._row(row) if row else None

    def for_reference(self, reference_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM content_extractions WHERE reference_id = ? ORDER BY created_at",
            (reference_id,),
        ).fetchall()
        return [self._row(r) for r in rows]

    def count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) AS c FROM content_extractions").fetchone()["c"]


class EditorialCheckRepository:
    """Editorial currency checks (GATE 8). Never deletes a prior check."""

    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def record(
        self,
        *,
        reference_id: str,
        provider: str,
        outcome: str,
        details: str,
        currency_known: bool,
        commit: bool = True,
    ) -> str:
        check_id = ids.new_id("echeck")
        with self.database.write_lock:
            self.conn.execute(
                "INSERT INTO editorial_checks (check_id, reference_id, provider, checked_at, outcome, details, currency_known) "
                "VALUES (?,?,?,?,?,?,?)",
                (
                    check_id,
                    reference_id,
                    provider,
                    to_iso(now_utc()),
                    outcome,
                    details,
                    1 if currency_known else 0,
                ),
            )
            if commit:
                self.conn.commit()
        return check_id

    def for_reference(self, reference_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM editorial_checks WHERE reference_id = ? ORDER BY checked_at",
            (reference_id,),
        ).fetchall()
        result = []
        for row in rows:
            data = dict(row)
            data["currency_known"] = bool(data.get("currency_known"))
            result.append(data)
        return result

    def latest(self, reference_id: str) -> dict[str, Any] | None:
        rows = self.for_reference(reference_id)
        return rows[-1] if rows else None
