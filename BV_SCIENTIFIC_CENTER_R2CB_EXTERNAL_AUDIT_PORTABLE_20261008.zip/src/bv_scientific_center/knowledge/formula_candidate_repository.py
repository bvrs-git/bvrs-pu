"""Persistence for scientific formula candidates (non-operational)."""

from __future__ import annotations

import json
from typing import Any

from ..core.definition import content_hash
from ..core.serialization import dumps
from ..core.timeutil import now_utc, to_iso
from ..storage.database import Database
from .formula_candidates import FormulaCandidate


class FormulaCandidateRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def save(self, candidate: FormulaCandidate, *, commit: bool = True) -> FormulaCandidate:
        candidate.validate()
        payload = candidate.to_dict()
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO formula_candidates (
                    candidate_id, version, candidate_type, status, content_hash, payload,
                    created_at, primary_reference_id
                ) VALUES (?,?,?,?,?,?,?,?)
                """,
                (
                    candidate.candidate_id,
                    candidate.version,
                    candidate.candidate_type.value,
                    candidate.review_status.value,
                    candidate.content_hash(),
                    dumps(payload),
                    to_iso(now_utc()),
                    candidate.reference_ids[0] if candidate.reference_ids else None,
                ),
            )
            if commit:
                self.conn.commit()
        return candidate

    def get(self, candidate_id: str, version: int | None = None) -> FormulaCandidate | None:
        if version is None:
            row = self.conn.execute(
                "SELECT * FROM formula_candidates WHERE candidate_id = ? ORDER BY version DESC LIMIT 1",
                (candidate_id,),
            ).fetchone()
        else:
            row = self.conn.execute(
                "SELECT * FROM formula_candidates WHERE candidate_id = ? AND version = ?",
                (candidate_id, version),
            ).fetchone()
        if row is None:
            return None
        return FormulaCandidate.from_dict(json.loads(row["payload"]))

    def list(self) -> list[FormulaCandidate]:
        rows = self.conn.execute(
            "SELECT * FROM formula_candidates ORDER BY candidate_id, version"
        ).fetchall()
        return [FormulaCandidate.from_dict(json.loads(r["payload"])) for r in rows]

    def load_all_into(self, registry) -> int:
        count = 0
        for candidate in self.list():
            registry.publish(candidate)
            count += 1
        return count
