"""Input semantics: a device estimate must never become a measurement.

The chain MEASURED -> DEVICE_ESTIMATED -> FORMULA_DERIVED is strictly preserved.
Device metadata (brand, model, method, algorithm, conditions) is carried along;
unknown fields stay UNKNOWN. A derived value can never claim to be MEASURED.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.enums import InputSemantics
from ..errors import EvidenceGovernanceError

# Directness order: lower index = more directly measured.
_DIRECTNESS = {
    InputSemantics.MEASURED: 0,
    InputSemantics.CLINICIAN_ASSESSED: 1,
    InputSemantics.PATIENT_REPORTED: 2,
    InputSemantics.DEVICE_ESTIMATED: 3,
    InputSemantics.FORMULA_DERIVED: 4,
    InputSemantics.UNKNOWN: 5,
}


@dataclass(frozen=True)
class InputValue:
    name: str
    value: float | None
    unit: str
    semantics: InputSemantics
    source_ref: str | None = None
    device: str | None = None
    model: str | None = None
    method: str | None = None
    algorithm: str | None = None
    conditions: dict[str, Any] = field(default_factory=dict)
    derived_from: tuple[str, ...] = ()
    effective_at: str | None = None

    def is_missing(self) -> bool:
        return self.value is None

    def provenance(self) -> dict[str, Any]:
        return {
            "source_ref": self.source_ref,
            "device": self.device,
            "model": self.model,
            "method": self.method,
            "algorithm": self.algorithm,
            "conditions": dict(self.conditions),
            "derived_from": list(self.derived_from),
            "effective_at": self.effective_at,
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "unit": self.unit,
            "semantics": self.semantics.value,
            **self.provenance(),
        }


def measurement(name: str, value: float | None, unit: str, **kwargs) -> InputValue:
    return InputValue(name=name, value=value, unit=unit, semantics=InputSemantics.MEASURED, **kwargs)


def device_estimate(
    name: str,
    value: float | None,
    unit: str,
    *,
    device: str | None = None,
    model: str | None = None,
    algorithm: str | None = None,
    method: str | None = None,
    **kwargs,
) -> InputValue:
    return InputValue(
        name=name,
        value=value,
        unit=unit,
        semantics=InputSemantics.DEVICE_ESTIMATED,
        device=device,
        model=model,
        algorithm=algorithm,
        method=method,
        **kwargs,
    )


def clinician_assessed(name: str, value: float | None, unit: str, **kwargs) -> InputValue:
    return InputValue(
        name=name, value=value, unit=unit, semantics=InputSemantics.CLINICIAN_ASSESSED, **kwargs
    )


def patient_reported(name: str, value: float | None, unit: str, **kwargs) -> InputValue:
    return InputValue(
        name=name, value=value, unit=unit, semantics=InputSemantics.PATIENT_REPORTED, **kwargs
    )


def derived(
    name: str,
    value: float | None,
    unit: str,
    *,
    parents: tuple[InputValue, ...],
    **kwargs,
) -> InputValue:
    """Build a FORMULA_DERIVED value, refusing to upgrade its parents' nature."""
    assert_no_semantics_upgrade(parents, InputSemantics.FORMULA_DERIVED)
    return InputValue(
        name=name,
        value=value,
        unit=unit,
        semantics=InputSemantics.FORMULA_DERIVED,
        derived_from=tuple(p.name for p in parents),
        **kwargs,
    )


def assert_no_semantics_upgrade(
    parents: tuple[InputValue, ...], child_semantics: InputSemantics
) -> None:
    """A derived value must not be more 'direct' than any of its inputs."""
    child_rank = _DIRECTNESS[child_semantics]
    for parent in parents:
        if child_rank < _DIRECTNESS[parent.semantics]:
            raise EvidenceGovernanceError(
                f"Semantics upgrade forbidden: {parent.name} is {parent.semantics.value} "
                f"but derived value claims {child_semantics.value}"
            )


def semantics_allows(candidate_semantics: InputSemantics, declared: InputSemantics) -> bool:
    """True when a value of ``candidate_semantics`` satisfies a ``declared`` requirement."""
    return _DIRECTNESS[candidate_semantics] <= _DIRECTNESS[declared]
