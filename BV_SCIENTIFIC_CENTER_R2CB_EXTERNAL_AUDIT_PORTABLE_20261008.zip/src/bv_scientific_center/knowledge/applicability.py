"""Clinical applicability profiles (R2C-A GATE 6).

Restrictions are based on available evidence. When a context is not validated,
the explicit marker ``APPLICABILITY_NOT_ESTABLISHED`` is used — absence of
evidence is never presented as evidence of absence.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

APPLICABILITY_NOT_ESTABLISHED = "APPLICABILITY_NOT_ESTABLISHED"
APPLICABLE = "APPLICABLE"
NOT_APPLICABLE = "NOT_APPLICABLE"

# Canonical population / condition codes.
POPULATIONS: dict[str, str] = {
    "ADULT": "Adults",
    "PEDIATRIC": "Pediatric",
    "PREGNANT": "Pregnancy",
    "ELDERLY": "Older adults",
    "ATHLETE": "Athletes",
    "SEVERE_OBESITY": "Severe obesity",
    "HYDRATION_CHANGE": "Significant hydration change",
    "EDEMA_ASCITES": "Edema / ascites",
    "ACUTE_CONDITION": "Acute conditions",
    "DEVICE_SPECIFIC": "Specific devices/methods",
}


@dataclass
class ApplicabilityProfile:
    applicable_populations: tuple[str, ...] = ()
    not_validated_populations: tuple[str, ...] = ()
    contraindications: tuple[str, ...] = ()
    device_requirements: tuple[str, ...] = ()
    notes: str | None = None
    evidence_refs: tuple[str, ...] = ()

    def has_constraints(self) -> bool:
        return bool(
            self.applicable_populations
            or self.not_validated_populations
            or self.contraindications
            or self.device_requirements
        )

    def evaluate(self, *, population: str | None = None, device: str | None = None) -> dict[str, Any]:
        if population and population in self.contraindications:
            return {
                "status": NOT_APPLICABLE,
                "reason": f"population {population} is a declared contraindication",
            }
        if self.device_requirements:
            if device is None:
                return {
                    "status": NOT_APPLICABLE,
                    "reason": "device requirement not satisfied (device unknown)",
                }
            if device not in self.device_requirements:
                return {
                    "status": NOT_APPLICABLE,
                    "reason": f"device {device!r} is not in the required set",
                }
        if population and population in self.applicable_populations:
            return {"status": APPLICABLE, "reason": f"population {population} is validated"}
        return {
            "status": APPLICABILITY_NOT_ESTABLISHED,
            "reason": (
                f"no validation recorded for population {population!r}"
                if population
                else "no population context provided (UNKNOWN)"
            ),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "applicable_populations": list(self.applicable_populations),
            "not_validated_populations": list(self.not_validated_populations),
            "contraindications": list(self.contraindications),
            "device_requirements": list(self.device_requirements),
            "notes": self.notes,
            "evidence_refs": list(self.evidence_refs),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ApplicabilityProfile":
        return cls(
            applicable_populations=tuple(data.get("applicable_populations", ())),
            not_validated_populations=tuple(data.get("not_validated_populations", ())),
            contraindications=tuple(data.get("contraindications", ())),
            device_requirements=tuple(data.get("device_requirements", ())),
            notes=data.get("notes"),
            evidence_refs=tuple(data.get("evidence_refs", ())),
        )
