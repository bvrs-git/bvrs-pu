"""Canonical scientific model (R2A GATE 1).

Distinguishes three governance levels, kept explicit in schema and API:

    ScientificReference  - a bibliographic source (metadata only)
    ScientificEvidence   - a study/evidence record with methodology
    ClinicalClaim        - a bounded scientific statement supported (or not)
                           by evidence

Central principle:

    imported evidence is not validated evidence;
    validated evidence is not automatically a clinical recommendation.

Missing fields are never invented. Certainty of evidence is kept separate from
the strength of any eventual recommendation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from ..core.definition import content_hash
from ..core.enums import (
    BibliographicVerification,
    ContentReviewStatus,
    KnowledgeOrigin,
)
from ..errors import CurationApprovalError, EvidenceGovernanceError
from .models import KnowledgeReference  # noqa: F401  (kept for compatibility)


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------
class PublicationType(str, Enum):
    JOURNAL_ARTICLE = "JOURNAL_ARTICLE"
    CLINICAL_GUIDELINE = "CLINICAL_GUIDELINE"
    CONSENSUS_STATEMENT = "CONSENSUS_STATEMENT"
    REPORT = "REPORT"
    BOOK = "BOOK"
    PREPRINT = "PREPRINT"
    DATASET = "DATASET"
    OTHER = "OTHER"


class StudyDesign(str, Enum):
    """Methodological taxonomy. Not a rigid universal quality hierarchy."""

    SYSTEMATIC_REVIEW = "SYSTEMATIC_REVIEW"
    META_ANALYSIS = "META_ANALYSIS"
    RCT = "RCT"
    COHORT = "COHORT"
    CASE_CONTROL = "CASE_CONTROL"
    CROSS_SECTIONAL = "CROSS_SECTIONAL"
    DIAGNOSTIC_ACCURACY = "DIAGNOSTIC_ACCURACY"
    INSTRUMENT_VALIDATION = "INSTRUMENT_VALIDATION"
    CLINICAL_GUIDELINE = "CLINICAL_GUIDELINE"
    CONSENSUS = "CONSENSUS"
    CASE_SERIES = "CASE_SERIES"
    CASE_REPORT = "CASE_REPORT"
    PRECLINICAL = "PRECLINICAL"
    OTHER = "OTHER"


class VerificationStatus(str, Enum):
    VERIFIED = "VERIFIED"
    PARTIALLY_VERIFIED = "PARTIALLY_VERIFIED"
    VERIFY_PENDING = "VERIFY_PENDING"
    UNVERIFIED = "UNVERIFIED"


class CurationStatus(str, Enum):
    IMPORTED_UNVERIFIED = "IMPORTED_UNVERIFIED"
    SCREENED = "SCREENED"
    CURATED = "CURATED"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    SUPERSEDED = "SUPERSEDED"
    RETRACTED = "RETRACTED"


class EvidenceRelation(str, Enum):
    """How evidence relates to a formula/score/rule.

    The R2A values (FOUNDATIONAL, VALIDATION, DISCUSSION) are preserved for
    backward compatibility; R2C-A adds finer-grained relations.
    """

    FOUNDATIONAL = "FOUNDATIONAL"   # grounds the creation/definition (legacy)
    VALIDATION = "VALIDATION"       # evaluates performance (legacy)
    DISCUSSION = "DISCUSSION"       # discusses use/context (legacy)
    DERIVATION_ORIGINAL = "DERIVATION_ORIGINAL"
    METHODOLOGICAL_FOUNDATION = "METHODOLOGICAL_FOUNDATION"
    INTERNAL_VALIDATION = "INTERNAL_VALIDATION"
    EXTERNAL_VALIDATION = "EXTERNAL_VALIDATION"
    CLINICAL_APPLICATION = "CLINICAL_APPLICATION"
    LIMITATION = "LIMITATION"
    CONTRADICTORY_EVIDENCE = "CONTRADICTORY_EVIDENCE"


class CertaintyLevel(str, Enum):
    HIGH = "HIGH"
    MODERATE = "MODERATE"
    LOW = "LOW"
    VERY_LOW = "VERY_LOW"
    NOT_ASSESSED = "NOT_ASSESSED"


class CertaintyFramework(str, Enum):
    GRADE = "GRADE"
    OTHER = "OTHER"
    NONE = "NONE"


class MetadataSource(str, Enum):
    CROSSREF = "CROSSREF"
    PUBMED = "PUBMED"
    MANUAL = "MANUAL"
    GPT_WORK = "GPT_WORK"
    SYNTHETIC = "SYNTHETIC"


class CurationSubjectType(str, Enum):
    REFERENCE = "REFERENCE"
    EVIDENCE = "EVIDENCE"
    CLAIM = "CLAIM"


class LinkTargetType(str, Enum):
    FORMULA = "FORMULA"
    SCORE = "SCORE"
    RULE = "RULE"
    REFERENCE_RANGE = "REFERENCE_RANGE"
    INCLUSION_CRITERION = "INCLUSION_CRITERION"
    FORMULA_CANDIDATE = "FORMULA_CANDIDATE"


# ---------------------------------------------------------------------------
# Curation state machine (GATE 2)
# ---------------------------------------------------------------------------
CURATION_TRANSITIONS: dict[CurationStatus, frozenset[CurationStatus]] = {
    CurationStatus.IMPORTED_UNVERIFIED: frozenset(
        {CurationStatus.SCREENED, CurationStatus.REJECTED, CurationStatus.RETRACTED}
    ),
    CurationStatus.SCREENED: frozenset(
        {
            CurationStatus.CURATED,
            CurationStatus.REJECTED,
            CurationStatus.SUPERSEDED,
            CurationStatus.RETRACTED,
        }
    ),
    CurationStatus.CURATED: frozenset(
        {
            CurationStatus.APPROVED,
            CurationStatus.REJECTED,
            CurationStatus.SUPERSEDED,
            CurationStatus.RETRACTED,
        }
    ),
    CurationStatus.APPROVED: frozenset(
        {CurationStatus.SUPERSEDED, CurationStatus.RETRACTED, CurationStatus.REJECTED}
    ),
    CurationStatus.REJECTED: frozenset({CurationStatus.SUPERSEDED, CurationStatus.RETRACTED}),
    CurationStatus.SUPERSEDED: frozenset(),
    CurationStatus.RETRACTED: frozenset(),
}

# Statuses that may be presented as current evidence for clinical grounding.
CLINICALLY_USABLE_STATUSES = frozenset({CurationStatus.APPROVED})


def allowed_transitions(status: CurationStatus) -> frozenset[CurationStatus]:
    return CURATION_TRANSITIONS.get(status, frozenset())


def can_transition(current: CurationStatus, target: CurationStatus) -> bool:
    return target in allowed_transitions(current)


def is_terminal(status: CurationStatus) -> bool:
    return not allowed_transitions(status)


def is_clinically_usable(status: CurationStatus) -> bool:
    return status in CLINICALLY_USABLE_STATUSES


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
@dataclass
class ScientificReference:
    reference_id: str
    title: str
    authors: tuple[str, ...] = ()
    organization: str | None = None
    publication_year: int | None = None
    venue: str | None = None
    publication_type: PublicationType = PublicationType.OTHER
    doi: str | None = None
    pmid: str | None = None
    isbn: str | None = None
    issn: tuple[str, ...] = ()
    url: str | None = None
    accessed_at: datetime | None = None
    metadata_source: MetadataSource = MetadataSource.MANUAL
    verification_status: VerificationStatus = VerificationStatus.UNVERIFIED
    # R2B GATE 3: two independent dimensions, distinct from editorial curation.
    bibliographic_status: BibliographicVerification = BibliographicVerification.PENDING
    content_review_status: ContentReviewStatus = ContentReviewStatus.NOT_REVIEWED
    last_checked_at: datetime | None = None
    curation_status: CurationStatus = CurationStatus.IMPORTED_UNVERIFIED
    version: int = 1
    origin: KnowledgeOrigin = KnowledgeOrigin.IMPORTED
    superseded_by: str | None = None
    retraction_reason: str | None = None
    notes: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    # Stored content hash (populated on save/read). Distinct from the
    # ``content_hash()`` method so the method is never shadowed (R2B RR-7 fix).
    content_hash_value: str | None = None

    def stable_identifier(self) -> tuple[str, str] | None:
        """Stable external identifier, if any (DOI > PMID > ISBN > URL)."""
        for kind, value in (("doi", self.doi), ("pmid", self.pmid), ("isbn", self.isbn), ("url", self.url)):
            if value:
                return (kind, value.strip().lower() if kind != "url" else value.strip())
        return None

    def is_synthetic(self) -> bool:
        return self.origin is KnowledgeOrigin.SYNTHETIC_TEST

    def content_hash(self) -> str:
        return content_hash(
            {
                "title": self.title,
                "authors": list(self.authors),
                "organization": self.organization,
                "publication_year": self.publication_year,
                "venue": self.venue,
                "publication_type": self.publication_type.value,
                "doi": self.doi,
                "pmid": self.pmid,
                "isbn": self.isbn,
                "url": self.url,
                "metadata_source": self.metadata_source.value,
                "verification_status": self.verification_status.value,
                "version": self.version,
                "origin": self.origin.value,
            }
        )

    def can_approve(self) -> bool:
        if self.is_synthetic():
            return False
        if self.verification_status not in {
            VerificationStatus.VERIFIED,
            VerificationStatus.PARTIALLY_VERIFIED,
        }:
            return False
        return self.stable_identifier() is not None

    def validate(self) -> None:
        if not self.reference_id or not self.title:
            raise EvidenceGovernanceError("Reference requires reference_id and title")
        if self.curation_status is CurationStatus.APPROVED and not self.can_approve():
            raise EvidenceGovernanceError(
                f"Reference {self.reference_id!r} cannot be APPROVED: synthetic origin, "
                "unverified metadata, or missing stable identifier"
            )

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


@dataclass
class ScientificEvidence:
    evidence_id: str
    title: str
    reference_ids: tuple[str, ...] = ()
    study_design: StudyDesign = StudyDesign.OTHER
    population: str | None = None
    intervention: str | None = None
    comparator: str | None = None
    outcomes: tuple[str, ...] = ()
    quantitative_results: dict[str, Any] = field(default_factory=dict)
    limitations: tuple[str, ...] = ()
    clinical_applicability: str | None = None
    uncertainties: tuple[str, ...] = ()
    biases: tuple[str, ...] = ()
    editorial_status: str = "NONE"
    corrections: tuple[str, ...] = ()
    retraction_notes: str | None = None
    methodology: dict[str, Any] = field(default_factory=dict)
    domain: str | None = None
    curation_status: CurationStatus = CurationStatus.IMPORTED_UNVERIFIED
    version: int = 1
    origin: KnowledgeOrigin = KnowledgeOrigin.IMPORTED
    superseded_by: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    content_hash_value: str | None = None

    def is_synthetic(self) -> bool:
        return self.origin is KnowledgeOrigin.SYNTHETIC_TEST

    def is_retracted(self) -> bool:
        return self.curation_status is CurationStatus.RETRACTED or (
            self.editorial_status or ""
        ).upper() == "RETRACTED"

    def needs_reference(self) -> bool:
        return not self.reference_ids

    def content_hash(self) -> str:
        return content_hash(
            {
                "title": self.title,
                "reference_ids": list(self.reference_ids),
                "study_design": self.study_design.value,
                "population": self.population,
                "intervention": self.intervention,
                "comparator": self.comparator,
                "outcomes": list(self.outcomes),
                "quantitative_results": self.quantitative_results,
                "limitations": list(self.limitations),
                "clinical_applicability": self.clinical_applicability,
                "uncertainties": list(self.uncertainties),
                "biases": list(self.biases),
                "editorial_status": self.editorial_status,
                "corrections": list(self.corrections),
                "methodology": self.methodology,
                "domain": self.domain,
                "version": self.version,
                "origin": self.origin.value,
            }
        )

    def validate(self) -> None:
        if not self.evidence_id or not self.title:
            raise EvidenceGovernanceError("Evidence requires evidence_id and title")
        if self.curation_status is CurationStatus.APPROVED:
            if self.is_synthetic():
                raise EvidenceGovernanceError(
                    f"Evidence {self.evidence_id!r} is synthetic and cannot be APPROVED"
                )
            if self.needs_reference():
                raise EvidenceGovernanceError(
                    f"Evidence {self.evidence_id!r} cannot be APPROVED without a reference"
                )
            if self.is_retracted():
                raise EvidenceGovernanceError(
                    f"Evidence {self.evidence_id!r} is retracted and cannot be APPROVED"
                )

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


@dataclass
class ClinicalClaim:
    claim_id: str
    text: str
    favorable_evidence_ids: tuple[str, ...] = ()
    contrary_evidence_ids: tuple[str, ...] = ()
    inconclusive_evidence_ids: tuple[str, ...] = ()
    population_context: str | None = None
    applicability: str | None = None
    limitations: tuple[str, ...] = ()
    certainty_level: CertaintyLevel = CertaintyLevel.NOT_ASSESSED
    certainty_framework: CertaintyFramework = CertaintyFramework.NONE
    curation_status: CurationStatus = CurationStatus.IMPORTED_UNVERIFIED
    version: int = 1
    origin: KnowledgeOrigin = KnowledgeOrigin.IMPORTED
    review_history: tuple[dict[str, Any], ...] = ()
    superseded_by: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    content_hash_value: str | None = None

    def all_evidence_ids(self) -> tuple[str, ...]:
        return (
            self.favorable_evidence_ids
            + self.contrary_evidence_ids
            + self.inconclusive_evidence_ids
        )

    def is_synthetic(self) -> bool:
        return self.origin is KnowledgeOrigin.SYNTHETIC_TEST

    def content_hash(self) -> str:
        return content_hash(
            {
                "text": self.text,
                "favorable_evidence_ids": list(self.favorable_evidence_ids),
                "contrary_evidence_ids": list(self.contrary_evidence_ids),
                "inconclusive_evidence_ids": list(self.inconclusive_evidence_ids),
                "population_context": self.population_context,
                "applicability": self.applicability,
                "limitations": list(self.limitations),
                "certainty_level": self.certainty_level.value,
                "certainty_framework": self.certainty_framework.value,
                "version": self.version,
                "origin": self.origin.value,
            }
        )

    def validate(self) -> None:
        if not self.claim_id or not self.text:
            raise EvidenceGovernanceError("Claim requires claim_id and text")
        if self.curation_status is CurationStatus.APPROVED:
            if self.is_synthetic():
                raise EvidenceGovernanceError(
                    f"Claim {self.claim_id!r} is synthetic and cannot be APPROVED"
                )
            if not self.favorable_evidence_ids:
                raise EvidenceGovernanceError(
                    f"Claim {self.claim_id!r} cannot be APPROVED without supporting evidence"
                )

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


@dataclass
class EvidenceLink:
    link_id: str
    subject_type: CurationSubjectType
    subject_id: str
    target_type: LinkTargetType
    target_id: str
    relation: EvidenceRelation
    target_version: int | None = None
    applicability: str | None = None
    created_by: str | None = None
    created_at: datetime | None = None
    # R2C-A: every link carries a justification, a verification state and a version.
    justification: str | None = None
    verification_status: str = "UNVERIFIED"
    link_version: int = 1

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


@dataclass
class CurationEvent:
    event_id: str
    subject_type: CurationSubjectType
    subject_id: str
    to_status: CurationStatus
    from_status: CurationStatus | None = None
    actor: str | None = None
    justification: str | None = None
    version: int | None = None
    created_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


def require_approval_actor(actor: str | None, justification: str | None) -> None:
    """Human approval must be explicit and justified (GATE 2)."""
    if not actor or not actor.strip():
        raise CurationApprovalError("Approval requires an identified reviewer (actor)")
    if not justification or not justification.strip():
        raise CurationApprovalError("Approval requires a justification")
