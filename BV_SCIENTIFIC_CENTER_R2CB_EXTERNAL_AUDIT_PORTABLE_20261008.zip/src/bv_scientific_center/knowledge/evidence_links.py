"""Evidence links to formulas, scores and rules (R2A GATE 4).

Distinguishes FOUNDATIONAL (grounds the definition), VALIDATION (evaluates
performance) and DISCUSSION (context). Linking evidence never mutates a clinical
calculation; historical syntheses keep the versions they used.
"""

from __future__ import annotations

from typing import Any

from ..core import ids
from ..errors import EvidenceGovernanceError
from .scientific import (
    CurationSubjectType,
    EvidenceLink,
    EvidenceRelation,
    LinkTargetType,
)
from .scientific_repository import (
    EvidenceLinkRepository,
    ScientificEvidenceRepository,
    ScientificReferenceRepository,
)


class EvidenceLinkService:
    def __init__(
        self,
        *,
        links: EvidenceLinkRepository,
        references: ScientificReferenceRepository,
        evidence: ScientificEvidenceRepository,
    ) -> None:
        self.links = links
        self.references = references
        self.evidence = evidence

    def link(
        self,
        *,
        subject_type: CurationSubjectType,
        subject_id: str,
        target_type: LinkTargetType,
        target_id: str,
        relation: EvidenceRelation,
        actor: str,
        target_version: int | None = None,
        applicability: str | None = None,
        justification: str | None = None,
        verification_status: str = "UNVERIFIED",
    ) -> EvidenceLink:
        # The subject must exist.
        if subject_type is CurationSubjectType.REFERENCE and self.references.get(subject_id) is None:
            raise EvidenceGovernanceError(f"Unknown reference: {subject_id!r}")
        if subject_type is CurationSubjectType.EVIDENCE and self.evidence.get(subject_id) is None:
            raise EvidenceGovernanceError(f"Unknown evidence: {subject_id!r}")

        link = EvidenceLink(
            link_id=ids.new_id("link"),
            subject_type=subject_type,
            subject_id=subject_id,
            target_type=target_type,
            target_id=target_id,
            relation=relation,
            target_version=target_version,
            applicability=applicability,
            created_by=actor,
            justification=justification,
            verification_status=verification_status,
            link_version=1,
        )
        return self.links.save(link)

    def links_for_target(
        self, target_type: LinkTargetType, target_id: str, *, target_version: int | None = None
    ) -> list[dict[str, Any]]:
        return [link.to_dict() for link in self.links.for_target(target_type, target_id, target_version=target_version)]

    def formula_provenance(self, formula_id: str, version: int) -> dict[str, Any]:
        """Evidence grounding a specific formula version (FOUNDATIONAL/VALIDATION)."""
        links = self.links.for_target(LinkTargetType.FORMULA, formula_id, target_version=version)
        return {
            "formula_id": formula_id,
            "version": version,
            "foundational": [l.to_dict() for l in links if l.relation is EvidenceRelation.FOUNDATIONAL],
            "validation": [l.to_dict() for l in links if l.relation is EvidenceRelation.VALIDATION],
            "discussion": [l.to_dict() for l in links if l.relation is EvidenceRelation.DISCUSSION],
        }

    def evidence_for_subject(self, subject_type: CurationSubjectType, subject_id: str) -> list[dict[str, Any]]:
        return [link.to_dict() for link in self.links.for_subject(subject_type, subject_id)]
