"""Scientific formula candidates (R2C-A GATE 3/4/5/6/7).

This registry is SEPARATE from the operational ``FormulaRegistry`` and is
deliberately **non-operational**: it stores definitions, evidence links and
review state, and never exposes an execution path into clinical synthesis.

It distinguishes algebraic indices, predictive equations and interpretive
criteria. A mathematically correct index does NOT imply clinically validated
cutoffs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core import ids
from ..core.definition import content_hash
from ..core.enums import FormulaCandidateStatus, FormulaCandidateType, InputSemantics, TemporalRequirement
from ..core.expression import compile_expression
from ..core.units import is_known
from ..errors import EvidenceGovernanceError, ExpressionError
from .applicability import ApplicabilityProfile


@dataclass(frozen=True)
class CandidateVariable:
    name: str
    unit: str
    description: str = ""
    required: bool = True
    allowed_semantics: tuple[InputSemantics, ...] = (
        InputSemantics.MEASURED,
        InputSemantics.CLINICIAN_ASSESSED,
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "unit": self.unit,
            "description": self.description,
            "required": self.required,
            "allowed_semantics": [s.value for s in self.allowed_semantics],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CandidateVariable":
        return cls(
            name=data["name"],
            unit=data["unit"],
            description=data.get("description", ""),
            required=bool(data.get("required", True)),
            allowed_semantics=tuple(
                InputSemantics(s) for s in data.get("allowed_semantics", ["MEASURED"])
            ),
        )


@dataclass
class FormulaCandidate:
    candidate_id: str
    name: str
    display_name: str
    version: int
    candidate_type: FormulaCandidateType
    expression: str
    output_unit: str
    output_domain: str = ""
    variables: tuple[CandidateVariable, ...] = ()
    temporal_requirement: TemporalRequirement = TemporalRequirement.LATEST_AVAILABLE
    temporal_window_days: int | None = None
    applicability: ApplicabilityProfile = field(default_factory=ApplicabilityProfile)
    refusal_conditions: tuple[str, ...] = ()
    reference_ids: tuple[str, ...] = ()
    validation_evidence_ids: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    review_status: FormulaCandidateStatus = FormulaCandidateStatus.DRAFT
    metadata: dict[str, Any] = field(default_factory=dict)
    content_hash_value: str | None = None

    # -- invariants --------------------------------------------------------
    @property
    def operational(self) -> bool:
        """Candidate definitions are never operational in R2C-A."""
        return False

    @property
    def key(self) -> tuple[str, int]:
        return (self.candidate_id, self.version)

    def has_references(self) -> bool:
        return bool(self.reference_ids) or bool(self.validation_evidence_ids)

    def variable(self, name: str) -> CandidateVariable | None:
        for var in self.variables:
            if var.name == name:
                return var
        return None

    def content_hash(self) -> str:
        return content_hash(
            {
                "candidate_id": self.candidate_id,
                "version": self.version,
                "name": self.name,
                "display_name": self.display_name,
                "candidate_type": self.candidate_type.value,
                "expression": self.expression,
                "output_unit": self.output_unit,
                "output_domain": self.output_domain,
                "variables": [v.to_dict() for v in self.variables],
                "temporal_requirement": self.temporal_requirement.value,
                "temporal_window_days": self.temporal_window_days,
                "applicability": self.applicability.to_dict(),
                "refusal_conditions": list(self.refusal_conditions),
                "reference_ids": list(self.reference_ids),
                "validation_evidence_ids": list(self.validation_evidence_ids),
                "limitations": list(self.limitations),
                "review_status": self.review_status.value,
            }
        )

    def validate(self) -> None:
        if not self.candidate_id or not self.name:
            raise EvidenceGovernanceError("Formula candidate requires candidate_id and name")
        if self.operational:  # pragma: no cover - defensive
            raise EvidenceGovernanceError("Formula candidates must remain non-operational")
        # Expression must be valid and use only declared variables.
        compiled = compile_expression(self.expression)
        declared = {v.name for v in self.variables}
        undeclared = compiled.names - declared
        if undeclared:
            raise ExpressionError(
                f"Candidate {self.candidate_id} expression uses undeclared variables: {sorted(undeclared)}"
            )
        for var in self.variables:
            if not is_known(var.unit):
                raise EvidenceGovernanceError(f"Unknown unit for {var.name!r}: {var.unit!r}")
        if not is_known(self.output_unit):
            raise EvidenceGovernanceError(f"Unknown output unit: {self.output_unit!r}")
        for condition in self.refusal_conditions:
            compile_expression(condition)
        if not self.has_references() and self.review_status is not FormulaCandidateStatus.DRAFT:
            raise EvidenceGovernanceError(
                f"Candidate {self.candidate_id} has no reference/evidence and must remain DRAFT"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "name": self.name,
            "display_name": self.display_name,
            "version": self.version,
            "candidate_type": self.candidate_type.value,
            "expression": self.expression,
            "output_unit": self.output_unit,
            "output_domain": self.output_domain,
            "variables": [v.to_dict() for v in self.variables],
            "temporal_requirement": self.temporal_requirement.value,
            "temporal_window_days": self.temporal_window_days,
            "applicability": self.applicability.to_dict(),
            "refusal_conditions": list(self.refusal_conditions),
            "reference_ids": list(self.reference_ids),
            "validation_evidence_ids": list(self.validation_evidence_ids),
            "limitations": list(self.limitations),
            "review_status": self.review_status.value,
            "operational": self.operational,
            "content_hash": self.content_hash(),
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FormulaCandidate":
        from ..core.definition import coerce_enum

        return cls(
            candidate_id=data["candidate_id"],
            name=data["name"],
            display_name=data.get("display_name", data["name"]),
            version=int(data.get("version", 1)),
            candidate_type=coerce_enum(FormulaCandidateType, data.get("candidate_type", "ALGEBRAIC_INDEX")),
            expression=data.get("expression", ""),
            output_unit=data.get("output_unit", "1"),
            output_domain=data.get("output_domain", ""),
            variables=tuple(CandidateVariable.from_dict(v) for v in data.get("variables", ())),
            temporal_requirement=coerce_enum(
                TemporalRequirement, data.get("temporal_requirement", "LATEST_AVAILABLE")
            ),
            temporal_window_days=data.get("temporal_window_days"),
            applicability=ApplicabilityProfile.from_dict(data.get("applicability", {})),
            refusal_conditions=tuple(data.get("refusal_conditions", ())),
            reference_ids=tuple(data.get("reference_ids", ())),
            validation_evidence_ids=tuple(data.get("validation_evidence_ids", ())),
            limitations=tuple(data.get("limitations", ())),
            review_status=coerce_enum(
                FormulaCandidateStatus, data.get("review_status", "DRAFT")
            ),
            metadata=dict(data.get("metadata", {})),
        )


class ScientificFormulaCandidateRegistryV1:
    """Versioned, non-operational candidate registry (own id+version store)."""

    def __init__(self) -> None:
        self._store: dict[tuple[str, int], FormulaCandidate] = {}

    def publish(self, candidate: FormulaCandidate) -> FormulaCandidate:
        candidate.validate()
        key = candidate.key
        existing = self._store.get(key)
        if existing is not None:
            if existing.content_hash() != candidate.content_hash():
                raise EvidenceGovernanceError(
                    f"Candidate {candidate.candidate_id} v{candidate.version} already exists "
                    "with different content; bump the version"
                )
            return existing
        self._store[key] = candidate
        return candidate

    def get(self, candidate_id: str, version: int | None = None) -> FormulaCandidate:
        versions = self.versions(candidate_id)
        if not versions:
            raise KeyError(f"Unknown candidate: {candidate_id!r}")
        version = version if version is not None else versions[-1]
        return self._store[(candidate_id, version)]

    def versions(self, candidate_id: str) -> list[int]:
        return sorted(v for (c, v) in self._store if c == candidate_id)

    def all_latest(self) -> list[FormulaCandidate]:
        latest: dict[str, FormulaCandidate] = {}
        for candidate in self._store.values():
            current = latest.get(candidate.candidate_id)
            if current is None or candidate.version > current.version:
                latest[candidate.candidate_id] = candidate
        return sorted(latest.values(), key=lambda c: c.candidate_id)

    def all(self) -> list[FormulaCandidate]:
        return list(self._store.values())
