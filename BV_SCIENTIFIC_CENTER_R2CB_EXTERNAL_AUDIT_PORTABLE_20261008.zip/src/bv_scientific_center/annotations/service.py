"""Clinical review services: signal review, annotations and pins.

Accepting a signal as relevant does NOT create a diagnosis and writes nothing to
the Prontuario (spec §76). Physician annotations never mutate source
observations (spec §54).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from ..core import ids
from ..core.enums import SignalStatus
from ..core.timeutil import now_utc
from ..events.bus import EventBus
from ..rules.signals import SignalReview
from ..storage.repositories import AnnotationRepository, PinRepository, SignalRepository

# Physician-facing actions mapped to an internal status. ACCEPT_AS_RELEVANT is
# deliberately NOT mapped to a diagnosis.
SIGNAL_ACTIONS: dict[str, SignalStatus | None] = {
    "ACKNOWLEDGE": SignalStatus.REVIEWED,
    "ACCEPT_AS_RELEVANT": SignalStatus.ACCEPTED,
    "DISMISS": SignalStatus.DISMISSED,
    "ADD_NOTE": None,
    "OPEN_SOURCE_DATA": None,
}


class ClinicalReviewService:
    def __init__(
        self,
        *,
        signals: SignalRepository,
        annotations: AnnotationRepository,
        pins: PinRepository,
        event_bus: EventBus | None = None,
    ) -> None:
        self.signals = signals
        self.annotations = annotations
        self.pins = pins
        self.event_bus = event_bus or EventBus()

    # -- signals -----------------------------------------------------------
    def review_signal(
        self,
        signal_id: str,
        action: str,
        *,
        note: str | None = None,
        reviewer: str | None = None,
    ) -> dict[str, Any]:
        if action not in SIGNAL_ACTIONS:
            raise ValueError(f"Unknown signal action: {action!r}")
        signal = self.signals.get(signal_id)
        if signal is None:
            raise KeyError(f"Unknown signal: {signal_id!r}")

        new_status = SIGNAL_ACTIONS[action]
        status = SignalStatus(signal["status"]) if new_status is None else new_status
        review = SignalReview(
            signal_id=signal_id,
            status=status,
            note=note,
            reviewer=reviewer,
            reviewed_at=now_utc(),
        )
        self.signals.add_review(review)
        self.signals.set_status(signal_id, status)
        self.event_bus.emit(
            "ClinicalSignalReviewed",
            payload={
                "signal_id": signal_id,
                "action": action,
                "status": status.value,
                "reviewer": reviewer,
            },
            patient_id=signal.get("patient_id"),
        )
        return {"signal_id": signal_id, "action": action, "status": status.value}

    # -- annotations -------------------------------------------------------
    def annotate(
        self,
        *,
        patient_id: str,
        target_type: str,
        target_id: str,
        text: str,
        author: str,
    ) -> str:
        annotation_id = ids.annotation_id()
        self.annotations.add(
            annotation_id=annotation_id,
            patient_id=patient_id,
            target_type=target_type,
            target_id=target_id,
            text=text,
            author=author,
        )
        return annotation_id

    # -- pins --------------------------------------------------------------
    def pin(
        self,
        *,
        patient_id: str,
        target_type: str,
        target_id: str,
        note: str | None = None,
    ) -> str:
        pin_id = ids.pin_id()
        self.pins.add(
            pin_id=pin_id,
            patient_id=patient_id,
            target_type=target_type,
            target_id=target_id,
            note=note,
        )
        return pin_id

    # -- promotion draft (future Prontuario hand-off, spec §77) ------------
    def build_prontuario_promotion_draft(
        self, signal_id: str, *, author: str
    ) -> dict[str, Any]:
        """Build a clinician-reviewable draft. Never a direct diagnosis insert."""
        signal = self.signals.get(signal_id)
        if signal is None:
            raise KeyError(f"Unknown signal: {signal_id!r}")
        return {
            "kind": "PROMOTION_DRAFT",
            "target_module": "PRONTUARIO",
            "requires_clinician_review": True,
            "creates_diagnosis_automatically": False,
            "author": author,
            "label": f"Scientific Center signal: {signal['title']}",
            "source_signal_id": signal_id,
            "authority": "SYSTEM_DERIVED",
            "created_at": now_utc().isoformat(),
        }
