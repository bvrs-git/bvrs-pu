"""Clinician annotations and pins (never mutate source observations)."""
