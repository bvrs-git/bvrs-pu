"""JSON-safe serialization helpers (standard library only)."""

from __future__ import annotations

import dataclasses
import json
from datetime import datetime
from enum import Enum
from typing import Any

from .timeutil import to_iso


def dump(obj: Any) -> Any:
    """Recursively convert dataclasses/enums/datetimes into JSON-safe values."""
    if obj is None:
        return None
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: dump(getattr(obj, f.name)) for f in dataclasses.fields(obj)}
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, datetime):
        return to_iso(obj)
    if isinstance(obj, (list, tuple, set, frozenset)):
        return [dump(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): dump(v) for k, v in obj.items()}
    if isinstance(obj, (str, int, float, bool)):
        return obj
    return str(obj)


def dumps(obj: Any, *, indent: int | None = None) -> str:
    return json.dumps(dump(obj), ensure_ascii=False, indent=indent)


def loads(text: str) -> Any:
    return json.loads(text)


def as_dict(obj: Any) -> dict:
    return dump(obj)  # type: ignore[return-value]
