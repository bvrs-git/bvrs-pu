"""Canonical enumerations for the BV Scientific Center (R0/R1).

These enums make the core separation rules explicit and type-checkable:

    MEASURED_DATA          != DERIVED_METRIC
    DERIVED_METRIC         != CLINICAL_SIGNAL
    CLINICAL_SIGNAL        != DIAGNOSTIC_HYPOTHESIS
    DIAGNOSTIC_HYPOTHESIS  != CONFIRMED_DIAGNOSIS

Nothing in this module stores or infers a diagnosis.
"""

from __future__ import annotations

from enum import Enum


# ---------------------------------------------------------------------------
# Authority / provenance of a statement
# ---------------------------------------------------------------------------
class Authority(str, Enum):
    """Accountability for a statement, independent of where it is stored."""

    MEASURED = "MEASURED"                    # raw measurement owned by a source module
    PATIENT_REPORTED = "PATIENT_REPORTED"    # reported by / about the patient
    SYSTEM_DERIVED = "SYSTEM_DERIVED"        # computed by this module
    CLINICIAN_CONFIRMED = "CLINICIAN_CONFIRMED"
    AI_DRAFT = "AI_DRAFT"                    # AI output, never auto-confirmed
    AI_SUGGESTION = "AI_SUGGESTION"          # AI output, never auto-confirmed


class ObservationAuthority(str, Enum):
    """Confirmation state of an incoming observation reference.

    Only :data:`CONFIRMED_OBSERVATION_AUTHORITIES` are accepted by formulas
    that declare ``requires_confirmed_source``. A document-extracted but
    unreviewed value resolves to ``SOURCE_UNCONFIRMED`` instead of being used.
    """

    LAB_CONFIRMED = "LAB_CONFIRMED"
    CLINICIAN_CONFIRMED = "CLINICIAN_CONFIRMED"
    DOCUMENT_EXTRACTED_REVIEWED = "DOCUMENT_EXTRACTED_REVIEWED"
    DOCUMENT_EXTRACTED_UNREVIEWED = "DOCUMENT_EXTRACTED_UNREVIEWED"
    PATIENT_REPORTED = "PATIENT_REPORTED"
    IMPORTED_UNVERIFIED = "IMPORTED_UNVERIFIED"
    UNKNOWN = "UNKNOWN"


CONFIRMED_OBSERVATION_AUTHORITIES = frozenset(
    {
        ObservationAuthority.LAB_CONFIRMED,
        ObservationAuthority.CLINICIAN_CONFIRMED,
        ObservationAuthority.DOCUMENT_EXTRACTED_REVIEWED,
    }
)


def is_confirmed_authority(authority: ObservationAuthority) -> bool:
    return authority in CONFIRMED_OBSERVATION_AUTHORITIES


# ---------------------------------------------------------------------------
# Map layers (UI toggles; keep categories visually distinct)
# ---------------------------------------------------------------------------
class MapLayer(str, Enum):
    OBJECTIVE = "OBJECTIVE"                    # measured data
    PATIENT_REPORTED = "PATIENT_REPORTED"      # questionnaires / reported facts
    DERIVED = "DERIVED"                        # derived metrics / scores
    CLINICIAN_CONFIRMED = "CLINICIAN_CONFIRMED"
    SIGNALS = "SIGNALS"                        # clinical signal candidates


# ---------------------------------------------------------------------------
# Engine status & policy enums
# ---------------------------------------------------------------------------
class CalculationStatus(str, Enum):
    """Outcome of a derived computation. Failures are values, not exceptions."""

    VALID = "VALID"
    INSUFFICIENT_INPUT = "INSUFFICIENT_INPUT"
    UNIT_INCOMPATIBLE = "UNIT_INCOMPATIBLE"
    TEMPORALLY_INCOMPATIBLE = "TEMPORALLY_INCOMPATIBLE"
    SOURCE_UNCONFIRMED = "SOURCE_UNCONFIRMED"
    OUTSIDE_DEFINED_DOMAIN = "OUTSIDE_DEFINED_DOMAIN"
    ERROR = "ERROR"

    @property
    def is_valid(self) -> bool:
        return self is CalculationStatus.VALID

    @property
    def is_refusal(self) -> bool:
        return self is not CalculationStatus.VALID


class TemporalRequirement(str, Enum):
    SAME_COLLECTION = "SAME_COLLECTION"
    SAME_DAY = "SAME_DAY"
    WITHIN_N_DAYS = "WITHIN_N_DAYS"
    LATEST_AVAILABLE = "LATEST_AVAILABLE"
    OTHER_EXPLICIT_RULE = "OTHER_EXPLICIT_RULE"


class DefinitionStatus(str, Enum):
    """Lifecycle status for formulas, scores and rules."""

    DRAFT = "DRAFT"
    VALIDATED_FOR_USE = "VALIDATED_FOR_USE"
    RETIRED = "RETIRED"

    @property
    def is_usable(self) -> bool:
        return self is DefinitionStatus.VALIDATED_FOR_USE


class Severity(str, Enum):
    INFO = "INFO"
    LOW = "LOW"
    MODERATE = "MODERATE"
    HIGH = "HIGH"


class SignalStatus(str, Enum):
    NEW = "NEW"
    REVIEWED = "REVIEWED"
    ACCEPTED = "ACCEPTED"
    DISMISSED = "DISMISSED"
    SUPERSEDED = "SUPERSEDED"


class ScoreBandDirection(str, Enum):
    HIGHER_IS_HIGHER = "HIGHER_IS_HIGHER"
    LOWER_IS_HIGHER = "LOWER_IS_HIGHER"
    NON_DIRECTIONAL = "NON_DIRECTIONAL"


# ---------------------------------------------------------------------------
# Context enums (never inferred unless supplied)
# ---------------------------------------------------------------------------
class FastingStatus(str, Enum):
    FASTING = "FASTING"
    NON_FASTING = "NON_FASTING"
    UNKNOWN = "UNKNOWN"


class SexContext(str, Enum):
    MALE = "MALE"
    FEMALE = "FEMALE"
    OTHER = "OTHER"
    UNKNOWN = "UNKNOWN"


class PopulationContext(str, Enum):
    ADULT = "ADULT"
    PEDIATRIC = "PEDIATRIC"
    PREGNANT = "PREGNANT"
    UNKNOWN = "UNKNOWN"


class TargetType(str, Enum):
    """A laboratory range is NOT the same thing as a clinical target."""

    LAB_REFERENCE = "LAB_REFERENCE"
    GUIDELINE_TARGET = "GUIDELINE_TARGET"
    OPTIMAL_RANGE = "OPTIMAL_RANGE"
    CLINICIAN_TARGET = "CLINICIAN_TARGET"


# ---------------------------------------------------------------------------
# Clinical domain taxonomy (extensible; carries no conclusion)
# ---------------------------------------------------------------------------
class ClinicalDomain(str, Enum):
    METABOLIC = "METABOLIC"
    GLYCEMIC = "GLYCEMIC"
    LIPID = "LIPID"
    INFLAMMATORY = "INFLAMMATORY"
    THYROID = "THYROID"
    ADRENAL = "ADRENAL"
    GONADAL = "GONADAL"
    MICRONUTRIENT = "MICRONUTRIENT"
    BODY_COMPOSITION = "BODY_COMPOSITION"
    GI = "GI"
    SLEEP = "SLEEP"
    RECOVERY = "RECOVERY"
    STRESS = "STRESS"
    NUTRITION = "NUTRITION"
    CARDIOVASCULAR = "CARDIOVASCULAR"
    RENAL = "RENAL"
    HEPATIC = "HEPATIC"


# ---------------------------------------------------------------------------
# Clinical map
# ---------------------------------------------------------------------------
class NodeType(str, Enum):
    SYMPTOM = "SYMPTOM"
    QUESTIONNAIRE_DOMAIN = "QUESTIONNAIRE_DOMAIN"
    LAB_MARKER = "LAB_MARKER"
    BODY_COMPOSITION = "BODY_COMPOSITION"
    NUTRITION = "NUTRITION"
    MEDICATION = "MEDICATION"
    DIAGNOSIS = "DIAGNOSIS"
    DERIVED_METRIC = "DERIVED_METRIC"
    CLINICAL_SIGNAL = "CLINICAL_SIGNAL"
    LIFESTYLE_FACTOR = "LIFESTYLE_FACTOR"


class EdgeType(str, Enum):
    """Typed relationships. Default labels are deliberately non-causal."""

    MEASURED_WITH = "MEASURED_WITH"
    DERIVED_FROM = "DERIVED_FROM"
    ASSOCIATED_WITH = "ASSOCIATED_WITH"
    SUPPORTS_SIGNAL = "SUPPORTS_SIGNAL"
    CONTRADICTS = "CONTRADICTS"
    TEMPORALLY_FOLLOWS = "TEMPORALLY_FOLLOWS"
    REPORTED_WITH = "REPORTED_WITH"
    MEDICATED_BY = "MEDICATED_BY"
    RELATED_TO = "RELATED_TO"
    # Causal type: only usable when a validated scientific model supports it.
    CAUSAL_MODEL_SUPPORTED = "CAUSAL_MODEL_SUPPORTED"


NON_CAUSAL_EDGE_TYPES = frozenset(e for e in EdgeType if e is not EdgeType.CAUSAL_MODEL_SUPPORTED)


# ---------------------------------------------------------------------------
# Knowledge repository
# ---------------------------------------------------------------------------
class KnowledgeSourceType(str, Enum):
    GUIDELINE = "GUIDELINE"
    REVIEW = "REVIEW"
    META_ANALYSIS = "META_ANALYSIS"
    RCT = "RCT"
    OBSERVATIONAL = "OBSERVATIONAL"
    BOOK = "BOOK"
    CONSENSUS = "CONSENSUS"
    OTHER = "OTHER"


class KnowledgeStatus(str, Enum):
    DRAFT = "DRAFT"
    IN_REVIEW = "IN_REVIEW"
    APPROVED = "APPROVED"
    RETIRED = "RETIRED"


class KnowledgeOrigin(str, Enum):
    """Formal separation of knowledge provenance (spec R1.1 GATE 4).

    SYNTHETIC_TEST content can never be APPROVED for clinical use.
    """

    SYNTHETIC_TEST = "SYNTHETIC_TEST"   # architecture fixtures only
    IMPORTED = "IMPORTED"               # imported from a knowledge package
    CURATED = "CURATED"                 # human-curated, citation-backed


class ReviewStatus(str, Enum):
    DRAFT = "DRAFT"
    IN_REVIEW = "IN_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class PackageReviewStatus(str, Enum):
    DRAFT = "DRAFT"
    IN_REVIEW = "IN_REVIEW"
    APPROVED = "APPROVED"
    ACTIVATED = "ACTIVATED"
    DEACTIVATED = "DEACTIVATED"


class ClaimReviewStatus(str, Enum):
    UNREVIEWED = "UNREVIEWED"
    IN_REVIEW = "IN_REVIEW"
    SUPPORTED = "SUPPORTED"
    UNSUPPORTED = "UNSUPPORTED"


class BibliographicVerification(str, Enum):
    """Bibliographic metadata verification (R2B GATE 3). Independent of the
    scientific content review status and of editorial curation status."""

    PENDING = "PENDING"
    VERIFIED = "VERIFIED"
    CONFLICT = "CONFLICT"
    UNAVAILABLE = "UNAVAILABLE"


class ContentReviewStatus(str, Enum):
    """Critical scientific review of the content (R2B GATE 3)."""

    NOT_REVIEWED = "NOT_REVIEWED"
    ABSTRACT_REVIEWED = "ABSTRACT_REVIEWED"
    FULL_TEXT_REVIEWED = "FULL_TEXT_REVIEWED"
    CRITICALLY_APPRAISED = "CRITICALLY_APPRAISED"
    INSUFFICIENT_INFORMATION = "INSUFFICIENT_INFORMATION"


class EditorialAlertType(str, Enum):
    RETRACTION = "RETRACTION"
    CORRECTION = "CORRECTION"
    ERRATUM = "ERRATUM"
    EXPRESSION_OF_CONCERN = "EXPRESSION_OF_CONCERN"
    REPUBLICATION = "REPUBLICATION"


# ---------------------------------------------------------------------------
# R2C-A - input semantics, formula candidates, appraisal provenance
# ---------------------------------------------------------------------------
class InputSemantics(str, Enum):
    """Nature of an input value. An estimate must never become a measurement."""

    MEASURED = "MEASURED"
    DEVICE_ESTIMATED = "DEVICE_ESTIMATED"
    FORMULA_DERIVED = "FORMULA_DERIVED"
    PATIENT_REPORTED = "PATIENT_REPORTED"
    CLINICIAN_ASSESSED = "CLINICIAN_ASSESSED"
    UNKNOWN = "UNKNOWN"


class AppraisalFieldProvenance(str, Enum):
    """Provenance of a single appraisal field (never conflate extraction with review)."""

    EXTRACTED_UNVERIFIED = "EXTRACTED_UNVERIFIED"
    SOURCE_VERIFIED = "SOURCE_VERIFIED"
    HUMAN_REVIEWED = "HUMAN_REVIEWED"
    INSUFFICIENT_INFORMATION = "INSUFFICIENT_INFORMATION"


class FormulaCandidateType(str, Enum):
    """Distinguishes algebraic indices, predictive equations and interpretive criteria."""

    ALGEBRAIC_INDEX = "ALGEBRAIC_INDEX"
    PREDICTIVE_EQUATION = "PREDICTIVE_EQUATION"
    INTERPRETIVE_CRITERION = "INTERPRETIVE_CRITERION"


class FormulaCandidateStatus(str, Enum):
    """Candidate lifecycle. There is deliberately NO 'approved for clinical use'."""

    DRAFT = "DRAFT"
    TECHNICALLY_VALIDATED = "TECHNICALLY_VALIDATED"
    UNDER_SCIENTIFIC_REVIEW = "UNDER_SCIENTIFIC_REVIEW"
    RETIRED = "RETIRED"


class ContentAvailability(str, Enum):
    """Accessibility/licensing of acquired scientific content (R2C-B GATE 2)."""

    ABSTRACT_AVAILABLE = "ABSTRACT_AVAILABLE"
    FULL_TEXT_AVAILABLE = "FULL_TEXT_AVAILABLE"
    FULL_TEXT_ACCESS_RESTRICTED = "FULL_TEXT_ACCESS_RESTRICTED"
    FULL_TEXT_LICENSE_UNKNOWN = "FULL_TEXT_LICENSE_UNKNOWN"
    FULL_TEXT_REUSE_PERMITTED = "FULL_TEXT_REUSE_PERMITTED"
    SOURCE_UNAVAILABLE = "SOURCE_UNAVAILABLE"


class ContentType(str, Enum):
    ABSTRACT = "ABSTRACT"
    FULL_TEXT_XML = "FULL_TEXT_XML"


class CacheFreshness(str, Enum):
    FRESH = "FRESH"
    EXPIRED = "EXPIRED"
    UNKNOWN = "UNKNOWN"


class ReviewDecision(str, Enum):
    ACCEPT_FOR_CONSIDERATION = "ACCEPT_FOR_CONSIDERATION"
    REQUEST_REVISION = "REQUEST_REVISION"
    REJECT = "REJECT"
    KEEP_PENDING = "KEEP_PENDING"


# ---------------------------------------------------------------------------
# Synthesis run
# ---------------------------------------------------------------------------
class SynthesisRunStatus(str, Enum):
    STARTED = "STARTED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    PARTIAL = "PARTIAL"


# ---------------------------------------------------------------------------
# Signal generation type (used by rules; a signal is not a diagnosis)
# ---------------------------------------------------------------------------
class SignalType(str, Enum):
    OBSERVATION_FLAG = "OBSERVATION_FLAG"
    TREND_FLAG = "TREND_FLAG"
    COMBINATION_FLAG = "COMBINATION_FLAG"
    CONTEXT_WARNING = "CONTEXT_WARNING"
    SYNTHESIS_HINT = "SYNTHESIS_HINT"


# ---------------------------------------------------------------------------
# Precedence of refusal reasons. Documented so behaviour is deterministic.
# ---------------------------------------------------------------------------
REFUSAL_PRECEDENCE: tuple[CalculationStatus, ...] = (
    CalculationStatus.INSUFFICIENT_INPUT,
    CalculationStatus.SOURCE_UNCONFIRMED,
    CalculationStatus.UNIT_INCOMPATIBLE,
    CalculationStatus.TEMPORALLY_INCOMPATIBLE,
    CalculationStatus.OUTSIDE_DEFINED_DOMAIN,
    CalculationStatus.ERROR,
)
