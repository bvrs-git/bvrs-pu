"""Time helpers.

All timestamps in the Scientific Center are stored as timezone-aware UTC ISO
8601 strings. Comparison, grouping by calendar day and temporal-window checks
flow through this module so that behaviour is consistent everywhere.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from ..errors import NaiveTimestampError

ISO_FORMAT = "%Y-%m-%dT%H:%M:%S.%f%z"


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def parse_dt(value: str | datetime | None) -> datetime | None:
    """Parse an ISO 8601 string (or accept a datetime) into aware UTC.

    Naive datetimes are assumed UTC. This permissive behavior is used for
    storage round-trips only; the *clinical boundary* must use
    :func:`parse_clinical_dt`, which rejects naive timestamps.
    """
    if value is None:
        return None
    dt: datetime
    if isinstance(value, datetime):
        dt = value
    else:
        text = value.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def parse_clinical_dt(value: str | datetime | None, *, field: str = "timestamp") -> datetime | None:
    """Strict clinical parser: a timezone offset is mandatory.

    Rejects naive timestamps so chronology is never silently reinterpreted
    (R1.2 GATE 4). Returns ``None`` only when ``value`` is ``None``.
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        text = value.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        raise NaiveTimestampError(
            f"{field} must include a timezone offset (got naive {value!r})"
        )
    return dt.astimezone(timezone.utc)


def to_iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    return parse_dt(dt).strftime(ISO_FORMAT)


def calendar_day(dt: datetime) -> date:
    return parse_dt(dt).date()


def days_between(a: datetime, b: datetime) -> float:
    return abs((parse_dt(a) - parse_dt(b)).total_seconds()) / 86400.0


def same_calendar_day(a: datetime, b: datetime) -> bool:
    return calendar_day(a) == calendar_day(b)


def span_days(values: list[datetime]) -> float:
    if not values:
        return 0.0
    parsed = [parse_dt(v) for v in values]
    return (max(parsed) - min(parsed)).total_seconds() / 86400.0


def within_days(values: list[datetime], max_days: float) -> bool:
    return span_days(values) <= max_days


def add_days(dt: datetime, days: int) -> datetime:
    return parse_dt(dt) + timedelta(days=days)
