"""Constrained expression evaluator (FORMULA / SCORE / RULE SANDBOX).

Scientific content may arrive from imported knowledge packages. That content
must never execute arbitrary Python or JavaScript. This module compiles a small,
whitelisted arithmetic/boolean expression language and interprets it with an
explicit AST walker - ``eval``/``exec`` are never used.

Allowed
-------
* literals: int, float, bool, str, None
* names: identifiers resolved from the supplied variable mapping
* arithmetic: ``+ - * / // % **`` (``**`` bounded, see below)
* comparison: ``== != < <= > >= in not in``
* boolean: ``and or not``
* conditional: ``a if cond else b``
* containers: list/tuple literals
* functions: abs, min, max, round, floor, ceil, sqrt, log, ln, exp, clamp

Forbidden
---------
attribute access, subscripting, lambdas, comprehensions, assignment, imports,
``await``/``yield``, starred args, keyword args, names starting with ``_``.
"""

from __future__ import annotations

import ast
import math
import operator
from dataclasses import dataclass, field

from ..errors import ExpressionError

# ---------------------------------------------------------------------------
# Whitelisted functions and operators
# ---------------------------------------------------------------------------
def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


FUNCTIONS: dict[str, object] = {
    "abs": abs,
    "min": min,
    "max": max,
    "round": round,
    "floor": math.floor,
    "ceil": math.ceil,
    "sqrt": math.sqrt,
    "log": math.log,
    "ln": math.log,
    "exp": math.exp,
    "clamp": _clamp,
}

_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}

_UNARY_OPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
    ast.Not: operator.not_,
}

_COMPARE_OPS = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.In: lambda a, b: a in b,
    ast.NotIn: lambda a, b: a not in b,
}

_MAX_POW_EXPONENT = 12.0

_ALLOWED_NODES = (
    ast.Expression,
    ast.BinOp,
    ast.UnaryOp,
    ast.BoolOp,
    ast.Compare,
    ast.IfExp,
    ast.Name,
    ast.Load,
    ast.Constant,
    ast.Call,
    ast.List,
    ast.Tuple,
    ast.And,
    ast.Or,
) + tuple(_BIN_OPS) + tuple(_UNARY_OPS) + tuple(_COMPARE_OPS)


@dataclass(frozen=True)
class CompiledExpression:
    source: str
    _body: ast.AST = field(repr=False)
    names: frozenset[str] = frozenset()

    def evaluate(self, variables: dict[str, object]) -> object:
        return _eval(self._body, variables)


def _validate_node(node: ast.AST) -> None:
    if not isinstance(node, _ALLOWED_NODES):
        raise ExpressionError(f"Forbidden expression construct: {type(node).__name__}")
    if isinstance(node, ast.Name) and node.id.startswith("_"):
        raise ExpressionError(f"Forbidden identifier: {node.id!r}")
    if isinstance(node, ast.Attribute):  # defensive: never allowed
        raise ExpressionError("Attribute access is forbidden in expressions")


def _collect_names(node: ast.AST) -> set[str]:
    names: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and not isinstance(child.ctx, ast.Store):
            names.add(child.id)
    return names


def compile_expression(source: str) -> CompiledExpression:
    """Parse and validate ``source``; return a reusable compiled expression."""
    if not isinstance(source, str) or not source.strip():
        raise ExpressionError("Expression source must be a non-empty string")
    try:
        tree = ast.parse(source, mode="eval")
    except SyntaxError as exc:
        raise ExpressionError(f"Invalid expression syntax: {exc}") from exc
    for node in ast.walk(tree):
        _validate_node(node)
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name):
                raise ExpressionError("Only direct calls to whitelisted functions are allowed")
            if node.func.id not in FUNCTIONS:
                raise ExpressionError(f"Unknown function: {node.func.id!r}")
            if node.keywords:
                raise ExpressionError("Keyword arguments are not allowed")
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow):
            right = node.right
            if not (isinstance(right, ast.Constant) and isinstance(right.value, (int, float))):
                raise ExpressionError("Exponent must be a numeric literal")
            if abs(float(right.value)) > _MAX_POW_EXPONENT:
                raise ExpressionError("Exponent magnitude is out of the allowed range")
    return CompiledExpression(source=source, _body=tree.body, names=frozenset(_collect_names(tree)))


def _eval(node: ast.AST, variables: dict[str, object]) -> object:
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        if node.id not in variables:
            raise ExpressionError(f"Undefined variable in expression: {node.id!r}")
        return variables[node.id]
    if isinstance(node, ast.List):
        return [_eval(e, variables) for e in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_eval(e, variables) for e in node.elts)
    if isinstance(node, ast.BinOp):
        op = _BIN_OPS[type(node.op)]
        return op(_eval(node.left, variables), _eval(node.right, variables))
    if isinstance(node, ast.UnaryOp):
        op = _UNARY_OPS[type(node.op)]
        return op(_eval(node.operand, variables))
    if isinstance(node, ast.BoolOp):
        if isinstance(node.op, ast.And):
            result: object = True
            for value in node.values:
                result = _eval(value, variables)
                if not result:
                    return result
            return result
        result = False
        for value in node.values:
            result = _eval(value, variables)
            if result:
                return result
        return result
    if isinstance(node, ast.Compare):
        left = _eval(node.left, variables)
        for op_node, comparator in zip(node.ops, node.comparators):
            right = _eval(comparator, variables)
            if not _COMPARE_OPS[type(op_node)](left, right):
                return False
            left = right
        return True
    if isinstance(node, ast.IfExp):
        return _eval(node.body, variables) if _eval(node.test, variables) else _eval(node.orelse, variables)
    if isinstance(node, ast.Call):
        func = FUNCTIONS[node.func.id]  # type: ignore[index]
        args = [_eval(a, variables) for a in node.args]
        return func(*args)  # type: ignore[operator]
    raise ExpressionError(f"Unsupported node at evaluation: {type(node).__name__}")


def evaluate(source: str, variables: dict[str, object]) -> object:
    """Convenience: compile and evaluate in one call."""
    return compile_expression(source).evaluate(variables)


def evaluate_condition(source: str, variables: dict[str, object]) -> bool:
    """Evaluate a boolean condition; non-boolean results are coerced safely."""
    return bool(evaluate(source, variables))
