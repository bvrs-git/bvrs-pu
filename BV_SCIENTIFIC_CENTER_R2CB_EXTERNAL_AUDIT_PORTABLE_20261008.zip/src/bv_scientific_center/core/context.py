"""Evaluation context (population, sex, age, fasting, pregnancy).

Context is *supplied* by authoritative source projections. It is never inferred
by this module. Rules/formulas may require context and refuse
(``OUTSIDE_DEFINED_DOMAIN``) when it is incompatible.
"""

from __future__ import annotations

from dataclasses import dataclass

from .enums import FastingStatus, PopulationContext, SexContext


@dataclass(frozen=True)
class EvaluationContext:
    sex: SexContext = SexContext.UNKNOWN
    age_years: float | None = None
    population: PopulationContext = PopulationContext.UNKNOWN
    fasting_status: FastingStatus = FastingStatus.UNKNOWN
    pregnant: bool | None = None
    on_hormone_therapy: bool | None = None
    contraception: bool | None = None
    menopause: bool | None = None

    @classmethod
    def from_patient_context(cls, projection) -> "EvaluationContext":
        return cls(
            sex=projection.sex,
            age_years=projection.age_years,
            population=projection.population,
            on_hormone_therapy=projection.on_hormone_therapy,
            contraception=projection.contraception,
            menopause=projection.menopause,
        )

    def with_pregnancy(self, is_pregnant: bool | None) -> "EvaluationContext":
        population = self.population
        if is_pregnant:
            population = PopulationContext.PREGNANT
        return EvaluationContext(
            sex=self.sex,
            age_years=self.age_years,
            population=population,
            fasting_status=self.fasting_status,
            pregnant=is_pregnant,
            on_hormone_therapy=self.on_hormone_therapy,
            contraception=self.contraception,
            menopause=self.menopause,
        )

    def with_pediatric(self, is_pediatric: bool | None) -> "EvaluationContext":
        population = self.population
        if is_pediatric:
            population = PopulationContext.PEDIATRIC
        return EvaluationContext(
            sex=self.sex,
            age_years=self.age_years,
            population=population,
            fasting_status=self.fasting_status,
            pregnant=self.pregnant,
            on_hormone_therapy=self.on_hormone_therapy,
            contraception=self.contraception,
            menopause=self.menopause,
        )
