"""Core primitives shared by every sub-engine (enums, units, time, ids)."""
