"""Shared versioning primitives for formulas, scores and rules.

Published versions are immutable. A definition change must create a new version.
Historical results keep the version (and a content hash) they were computed with.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field

from .enums import DefinitionStatus
from .serialization import dump, dumps


def content_hash(obj: object) -> str:
    return hashlib.sha256(dumps(obj).encode("utf-8")).hexdigest()


def coerce_enum(enum_cls, value):
    """Return ``value`` as a member of ``enum_cls`` (idempotent)."""
    if isinstance(value, enum_cls):
        return value
    return enum_cls(str(value))


@dataclass(frozen=True)
class VersionedDefinition:
    definition_id: str = ""
    name: str = ""
    version: int = 1
    description: str = ""
    status: DefinitionStatus = DefinitionStatus.DRAFT
    evidence_refs: tuple[str, ...] = ()
    metadata: dict = field(default_factory=dict)

    @property
    def key(self) -> tuple[str, int]:
        return (self.definition_id, self.version)

    @property
    def is_usable(self) -> bool:
        return self.status.is_usable

    def to_dict(self) -> dict:
        return dump(self)

    def hash(self) -> str:
        return content_hash(self)
