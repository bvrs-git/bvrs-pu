"""Canonical clinical concept codes.

The Scientific Center keys inputs and formulas by *concept*, not by any other
module's column names. This keeps the module decoupled from BV Clinical
persistence and makes the knowledge repository portable.
"""

from __future__ import annotations

# --- Glycemic / metabolic -------------------------------------------------
GLUCOSE_FASTING = "GLUCOSE_FASTING"
INSULIN_FASTING = "INSULIN_FASTING"
HBA1C = "HBA1C"
HOMA_IR = "HOMA_IR"

# --- Lipid ----------------------------------------------------------------
TOTAL_CHOLESTEROL = "TOTAL_CHOLESTEROL"
HDL_CHOLESTEROL = "HDL_CHOLESTEROL"
LDL_CHOLESTEROL = "LDL_CHOLESTEROL"
TRIGLYCERIDES = "TRIGLYCERIDES"
NON_HDL_CHOLESTEROL = "NON_HDL_CHOLESTEROL"
REMNANT_CHOLESTEROL = "REMNANT_CHOLESTEROL"

# --- Inflammatory ---------------------------------------------------------
C_REACTIVE_PROTEIN = "C_REACTIVE_PROTEIN"
NEUTROPHILS_ABSOLUTE = "NEUTROPHILS_ABSOLUTE"
LYMPHOCYTES_ABSOLUTE = "LYMPHOCYTES_ABSOLUTE"
PLATELETS = "PLATELETS"

# --- Thyroid --------------------------------------------------------------
TSH = "TSH"
FREE_T4 = "FREE_T4"

# --- Adrenal / gonadal ----------------------------------------------------
DHEAS = "DHEAS"
CORTISOL = "CORTISOL"
TESTOSTERONE_TOTAL = "TESTOSTERONE_TOTAL"
ESTRADIOL = "ESTRADIOL"
SHBG = "SHBG"

# --- Micronutrient --------------------------------------------------------
VITAMIN_D_25OH = "VITAMIN_D_25OH"
SELENIUM = "SELENIUM"
VITAMIN_B12 = "VITAMIN_B12"
FERRITIN = "FERRITIN"

# --- Body composition / anthropometry ------------------------------------
WEIGHT = "WEIGHT"
HEIGHT = "HEIGHT"
BMI = "BMI"
BODY_FAT_PERCENT = "BODY_FAT_PERCENT"
FAT_MASS = "FAT_MASS"
FAT_FREE_MASS = "FAT_FREE_MASS"
SKELETAL_MUSCLE_MASS = "SKELETAL_MUSCLE_MASS"
WAIST_CIRCUMFERENCE = "WAIST_CIRCUMFERENCE"
FFMI = "FFMI"
FMI = "FMI"
WAIST_HEIGHT_RATIO = "WAIST_HEIGHT_RATIO"

# --- Derived ratios -------------------------------------------------------
TESTOSTERONE_ESTRADIOL_RATIO = "TESTOSTERONE_ESTRADIOL_RATIO"
TRIGLYCERIDE_HDL_RATIO = "TRIGLYCERIDE_HDL_RATIO"
NEUTROPHIL_LYMPHOCYTE_RATIO = "NEUTROPHIL_LYMPHOCYTE_RATIO"
PLATELET_LYMPHOCYTE_RATIO = "PLATELET_LYMPHOCYTE_RATIO"
DHEA_CORTISOL_RATIO = "DHEA_CORTISOL_RATIO"

# --- Nutrition ------------------------------------------------------------
ENERGY_TARGET = "ENERGY_TARGET"
PROTEIN_TARGET = "PROTEIN_TARGET"
PROTEIN_INTAKE = "PROTEIN_INTAKE"

# --- Reported / questionnaire domains -------------------------------------
SLEEP_QUALITY = "SLEEP_QUALITY"
ENERGY_LEVEL = "ENERGY_LEVEL"
GI_SYMPTOMS = "GI_SYMPTOMS"
STRESS_LEVEL = "STRESS_LEVEL"
LIBIDO = "LIBIDO"

# --- Lifestyle factors ----------------------------------------------------
PHYSICAL_ACTIVITY_MIN_WEEK = "PHYSICAL_ACTIVITY_MIN_WEEK"
ALCOHOL_UNITS_WEEK = "ALCOHOL_UNITS_WEEK"
SMOKING_STATUS = "SMOKING_STATUS"
