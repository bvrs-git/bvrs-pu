"""Generic immutable definition registry, shared by formulas, scores and rules."""

from __future__ import annotations

from typing import Callable, Generic, TypeVar

from .definition import VersionedDefinition
from ..errors import DuplicateDefinitionError, ImmutablePublishError

T = TypeVar("T", bound=VersionedDefinition)


class DefinitionRegistry(Generic[T]):
    """Stores versioned definitions and enforces publish immutability."""

    def __init__(self, kind: str, validator: Callable[[T], None] | None = None) -> None:
        self.kind = kind
        self._validator = validator
        self._store: dict[tuple[str, int], T] = {}

    # -- introspection -----------------------------------------------------
    def __contains__(self, key: tuple[str, int]) -> bool:
        return key in self._store

    def versions(self, definition_id: str) -> list[int]:
        return sorted(v for (i, v) in self._store if i == definition_id)

    def get(self, definition_id: str, version: int | None = None) -> T:
        if version is None:
            available = self.versions(definition_id)
            if not available:
                raise KeyError(f"Unknown {self.kind}: {definition_id!r}")
            version = available[-1]
        try:
            return self._store[(definition_id, version)]
        except KeyError as exc:
            raise KeyError(f"Unknown {self.kind}: {definition_id!r} v{version}") from exc

    def latest(self, definition_id: str) -> T:
        return self.get(definition_id, None)

    def all(self) -> list[T]:
        return list(self._store.values())

    def all_latest(self) -> list[T]:
        latest: dict[str, T] = {}
        for definition in self._store.values():
            current = latest.get(definition.definition_id)
            if current is None or definition.version > current.version:
                latest[definition.definition_id] = definition
        return sorted(latest.values(), key=lambda d: d.definition_id)

    # -- mutation ----------------------------------------------------------
    def publish(self, definition: T) -> T:
        """Validate and store. Re-publishing the identical version is idempotent."""
        if self._validator is not None:
            self._validator(definition)
        key = definition.key
        existing = self._store.get(key)
        if existing is not None:
            if existing.hash() != definition.hash():
                raise DuplicateDefinitionError(
                    f"{self.kind} {definition.definition_id!r} v{definition.version} "
                    "already exists with different content; bump the version"
                )
            return existing
        self._store[key] = definition
        return definition

    def _freeze(self, definition_id: str, version: int) -> None:
        if (definition_id, version) in self._store:
            raise ImmutablePublishError(
                f"Cannot mutate published {self.kind} {definition_id!r} v{version}"
            )

    def remove(self, definition_id: str, version: int) -> None:
        self._store.pop((definition_id, version), None)
