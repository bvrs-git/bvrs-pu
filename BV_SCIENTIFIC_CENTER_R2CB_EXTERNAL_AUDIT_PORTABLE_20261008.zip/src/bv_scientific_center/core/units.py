"""Unit registry and explicit conversions (UNIT SAFETY).

Design rules
------------
* Every unit symbol maps to exactly one *dimension* and one affine transform to
  that dimension's canonical unit. ``canonical = value * factor + offset``.
* Two values may only be combined arithmetically after both are expressed in the
  units declared by the formula. The engine converts with :func:`convert`, which
  is explicit, validated and recorded.
* ``ng/dL`` and ``pg/mL`` are the *same dimension* (mass concentration) so a
  cross-unit ratio is computable, but only because the formula declares the
  required units and the conversion factor is applied deterministically. The raw
  numbers are never divided as if the units were silently interchangeable.
* A unit from a different dimension (e.g. ``IU`` vs ``ug``) raises
  :class:`UnitConversionError`; the engine surfaces this as
  ``UNIT_INCOMPATIBLE`` and refuses to compute.

Unit symbols are normalised (micro sign -> ``u``, superscripts -> ``^n``) before
lookup so that ``µg/dL`` and ``ug/dL`` are the same unit.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..errors import UnitConversionError, UnknownUnitError

# ---------------------------------------------------------------------------
# Dimensions
# ---------------------------------------------------------------------------
DIMENSIONLESS = "DIMENSIONLESS"
MASS_CONCENTRATION = "MASS_CONCENTRATION"
AMOUNT_CONCENTRATION = "AMOUNT_CONCENTRATION"
ACTIVITY_CONCENTRATION = "ACTIVITY_CONCENTRATION"
ENZYME_ACTIVITY = "ENZYME_ACTIVITY"
CELL_CONCENTRATION = "CELL_CONCENTRATION"
MASS = "MASS"
MASS_PER_AREA = "MASS_PER_AREA"
LENGTH = "LENGTH"
AREA = "AREA"
VOLUME = "VOLUME"
TIME = "TIME"
TEMPERATURE = "TEMPERATURE"
PRESSURE = "PRESSURE"
RATE = "RATE"
ENERGY = "ENERGY"
PERCENT = "PERCENT"
INTERNATIONAL_UNIT = "INTERNATIONAL_UNIT"

_SUPERSCRIPTS = {"²": "^2", "³": "^3", "⁻¹": "^-1"}
_MICRO = {"µ", "μ"}


def normalize_unit(symbol: str) -> str:
    if symbol is None:
        raise UnknownUnitError("unit symbol is None")
    text = symbol.strip()
    for char in _MICRO:
        text = text.replace(char, "u")
    for sup, plain in _SUPERSCRIPTS.items():
        text = text.replace(sup, plain)
    return text


@dataclass(frozen=True)
class UnitDef:
    symbol: str          # normalised canonical symbol
    dimension: str
    factor: float        # canonical = value * factor + offset
    offset: float = 0.0


def _u(symbol: str, dimension: str, factor: float, offset: float = 0.0) -> tuple[str, UnitDef]:
    key = normalize_unit(symbol)
    return key, UnitDef(symbol=key, dimension=dimension, factor=factor, offset=offset)


_UNIT_LIST = [
    # DIMENSIONLESS -------------------------------------------------------
    _u("1", DIMENSIONLESS, 1.0),
    _u("ratio", DIMENSIONLESS, 1.0),
    _u("index", DIMENSIONLESS, 1.0),
    # PERCENT (canonical %) ----------------------------------------------
    _u("%", PERCENT, 1.0),
    _u("pct", PERCENT, 1.0),
    _u("fraction", PERCENT, 100.0),
    # MASS CONCENTRATION (canonical g/L) ---------------------------------
    _u("g/L", MASS_CONCENTRATION, 1.0),
    _u("mg/mL", MASS_CONCENTRATION, 1.0),
    _u("g/dL", MASS_CONCENTRATION, 10.0),
    _u("mg/dL", MASS_CONCENTRATION, 1e-2),
    _u("mg/L", MASS_CONCENTRATION, 1e-3),
    _u("ug/dL", MASS_CONCENTRATION, 1e-5),
    _u("ug/L", MASS_CONCENTRATION, 1e-6),
    _u("ng/mL", MASS_CONCENTRATION, 1e-6),
    _u("ng/dL", MASS_CONCENTRATION, 1e-8),
    _u("pg/mL", MASS_CONCENTRATION, 1e-9),
    _u("pg/dL", MASS_CONCENTRATION, 1e-11),
    # AMOUNT CONCENTRATION (canonical mol/L) -----------------------------
    _u("mol/L", AMOUNT_CONCENTRATION, 1.0),
    _u("mmol/L", AMOUNT_CONCENTRATION, 1e-3),
    _u("umol/L", AMOUNT_CONCENTRATION, 1e-6),
    _u("nmol/L", AMOUNT_CONCENTRATION, 1e-9),
    _u("pmol/L", AMOUNT_CONCENTRATION, 1e-12),
    # ACTIVITY CONCENTRATION (canonical uU/mL) ---------------------------
    _u("uU/mL", ACTIVITY_CONCENTRATION, 1.0),
    _u("uIU/mL", ACTIVITY_CONCENTRATION, 1.0),
    _u("mIU/L", ACTIVITY_CONCENTRATION, 1.0),
    _u("mU/L", ACTIVITY_CONCENTRATION, 1.0),
    _u("mIU/mL", ACTIVITY_CONCENTRATION, 1e3),
    _u("IU/L", ACTIVITY_CONCENTRATION, 1e3),
    # ENZYME ACTIVITY (canonical U/L) ------------------------------------
    _u("U/L", ENZYME_ACTIVITY, 1.0),
    _u("IU/L", ENZYME_ACTIVITY, 1.0),
    _u("mU/mL", ENZYME_ACTIVITY, 1.0),
    # CELL CONCENTRATION (canonical 10^3/uL) -----------------------------
    _u("10^3/uL", CELL_CONCENTRATION, 1.0),
    _u("10^9/L", CELL_CONCENTRATION, 1.0),
    _u("10^6/mL", CELL_CONCENTRATION, 1.0),
    _u("cells/uL", CELL_CONCENTRATION, 1e-3),
    _u("/mm3", CELL_CONCENTRATION, 1e-3),
    # MASS (canonical kg) -------------------------------------------------
    _u("kg", MASS, 1.0),
    _u("g", MASS, 1e-3),
    _u("mg", MASS, 1e-6),
    _u("ug", MASS, 1e-9),
    _u("lb", MASS, 0.45359237),
    # MASS PER AREA (canonical kg/m^2) -----------------------------------
    _u("kg/m^2", MASS_PER_AREA, 1.0),
    # LENGTH (canonical cm) ----------------------------------------------
    _u("cm", LENGTH, 1.0),
    _u("m", LENGTH, 100.0),
    _u("mm", LENGTH, 0.1),
    _u("in", LENGTH, 2.54),
    # AREA (canonical cm^2) ----------------------------------------------
    _u("cm^2", AREA, 1.0),
    _u("m^2", AREA, 1e4),
    # VOLUME (canonical L) -----------------------------------------------
    _u("L", VOLUME, 1.0),
    _u("dL", VOLUME, 0.1),
    _u("mL", VOLUME, 1e-3),
    # TIME (canonical day) -----------------------------------------------
    _u("day", TIME, 1.0),
    _u("h", TIME, 1.0 / 24.0),
    _u("min", TIME, 1.0 / 1440.0),
    # TEMPERATURE (canonical degC, affine) -------------------------------
    _u("degC", TEMPERATURE, 1.0, 0.0),
    _u("C", TEMPERATURE, 1.0, 0.0),
    _u("F", TEMPERATURE, 5.0 / 9.0, -160.0 / 9.0),
    # PRESSURE (canonical mmHg) ------------------------------------------
    _u("mmHg", PRESSURE, 1.0),
    _u("kPa", PRESSURE, 7.50062),
    # RATE (canonical bpm) -----------------------------------------------
    _u("bpm", RATE, 1.0),
    # ENERGY (canonical kcal) --------------------------------------------
    _u("kcal", ENERGY, 1.0),
    _u("kJ", ENERGY, 0.239006),
    # INTERNATIONAL UNIT (substance-specific; no cross-dimension convert) -
    _u("IU", INTERNATIONAL_UNIT, 1.0),
    _u("UI", INTERNATIONAL_UNIT, 1.0),
]

UNITS: dict[str, UnitDef] = {key: value for key, value in _UNIT_LIST}

# Friendly aliases (degC is the canonical temperature symbol; accept these).
UNITS["°c"] = UNITS["C"]
UNITS["°f"] = UNITS["F"]


def is_known(symbol: str) -> bool:
    return symbol is not None and normalize_unit(symbol) in UNITS


def unit_def(symbol: str) -> UnitDef:
    key = normalize_unit(symbol)
    try:
        return UNITS[key]
    except KeyError as exc:  # pragma: no cover - defensive
        raise UnknownUnitError(f"Unknown unit: {symbol!r}") from exc


def dimension_of(symbol: str) -> str:
    return unit_def(symbol).dimension


def same_dimension(a: str, b: str) -> bool:
    return dimension_of(a) == dimension_of(b)


def _to_canonical(value: float, definition: UnitDef) -> float:
    return value * definition.factor + definition.offset


def _from_canonical(value: float, definition: UnitDef) -> float:
    return (value - definition.offset) / definition.factor


def convert(value: float, from_unit: str, to_unit: str) -> float:
    """Convert ``value`` from ``from_unit`` to ``to_unit`` explicitly.

    Raises :class:`UnknownUnitError` for unregistered symbols and
    :class:`UnitConversionError` when the dimensions differ.
    """
    src = unit_def(from_unit)
    dst = unit_def(to_unit)
    if src.dimension != dst.dimension:
        raise UnitConversionError(
            f"Cannot convert {from_unit!r} ({src.dimension}) to {to_unit!r} ({dst.dimension})"
        )
    if src.symbol == dst.symbol:
        return value
    return _from_canonical(_to_canonical(value, src), dst)
