"""Stable, sortable, prefixed identifiers.

Ids are opaque strings. Prefixes make log/trace output readable without
exposing persistence internals (R1 clinical_map contract requirement).
"""

from __future__ import annotations

import hashlib
import uuid


def new_id(prefix: str) -> str:
    """Return a prefixed, url-safe, time-sortable-enough identifier."""
    return f"{prefix}_{uuid.uuid4().hex}"


def stable_id(prefix: str, *parts: object, length: int = 24) -> str:
    """Deterministic identifier derived from a natural key.

    Used for idempotent ingestion: re-ingesting the same source observation must
    produce the same reference id and therefore not duplicate rows.
    """
    raw = "|".join("" if part is None else str(part) for part in parts)
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:length]
    return f"{prefix}_{digest}"


def observation_ref_id() -> str:
    return new_id("obsref")


def metric_id() -> str:
    return new_id("metric")


def score_result_id() -> str:
    return new_id("score")


def signal_id() -> str:
    return new_id("signal")


def run_id() -> str:
    return new_id("run")


def knowledge_id() -> str:
    return new_id("know")


def claim_id() -> str:
    return new_id("claim")


def reference_id() -> str:
    return new_id("ref")


def package_id() -> str:
    return new_id("pkg")


def annotation_id() -> str:
    return new_id("annot")


def pin_id() -> str:
    return new_id("pin")


def event_id() -> str:
    return new_id("evt")


def node_id() -> str:
    return new_id("node")


def edge_id() -> str:
    return new_id("edge")
