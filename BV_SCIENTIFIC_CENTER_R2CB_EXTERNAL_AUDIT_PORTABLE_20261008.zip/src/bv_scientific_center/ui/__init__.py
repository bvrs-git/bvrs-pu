"""Minimal clinician-facing UI (standard library http.server)."""
