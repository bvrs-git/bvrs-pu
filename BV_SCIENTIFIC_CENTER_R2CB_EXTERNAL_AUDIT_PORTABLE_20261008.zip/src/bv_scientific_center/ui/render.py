"""HTML rendering for the minimal clinician-facing UI (no template engine).

Everything is escaped with :func:`html.escape`. Imported knowledge content is
treated as untrusted text and never injected as raw HTML.
"""

from __future__ import annotations

from html import escape
from typing import Any

from ..core.enums import MapLayer

_STYLE = """
:root { color-scheme: light dark; }
body { font-family: system-ui, sans-serif; margin: 0; line-height: 1.45; }
header { padding: .75rem 1rem; border-bottom: 1px solid #8884; display:flex; gap:1rem; flex-wrap:wrap; align-items:center;}
header .mode { display:flex; gap:.5rem; }
nav a { margin-right: .75rem; }
main { padding: 1rem; max-width: 1200px; }
h1 { font-size: 1.35rem; } h2 { font-size: 1.1rem; margin-top: 1.5rem; }
table { border-collapse: collapse; width: 100%; margin: .5rem 0 1rem; }
th, td { text-align: left; padding: .35rem .5rem; border-bottom: 1px solid #8883; vertical-align: top; }
code { background: #8882; padding: 0 .25rem; border-radius: 4px; }
.badge { display:inline-block; padding: 0 .4rem; border-radius: 999px; border: 1px solid #8886; font-size: .78rem; margin-right:.25rem;}
.layer-OBJECTIVE { border-color:#3b82f6; }
.layer-PATIENT_REPORTED { border-color:#a855f7; }
.layer-DERIVED { border-color:#22c55e; }
.layer-CLINICIAN_CONFIRMED { border-color:#0ea5e9; }
.layer-SIGNALS { border-color:#f59e0b; }
.muted { color: #8889; font-size: .85rem; }
details { margin:.25rem 0; }
.warn { color:#b45309; }
.grid { display:grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap:.75rem; }
.card { border:1px solid #8884; border-radius:8px; padding:.6rem .75rem; }
.disclaimer { border-left: 3px solid #f59e0b; padding-left:.6rem; }
"""


def page(title: str, body: str, *, header: str = "", mode: str = "clinician") -> str:
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{escape(title)}</title><style>{_STYLE}</style></head>
<body>
<header>
  <strong>BV Scientific Center</strong>
  <span class="mode"><a href="/knowledge">Knowledge mode</a> <a href="/patient">Patient mode</a></span>
  <span class="muted">{escape(mode)}</span>
  {header}
</header>
<main>{body}</main>
</body></html>"""


def home(app) -> str:
    domains = [
        "METABOLIC",
        "HORMONAL (ADRENAL/GONADAL)",
        "MICRONUTRIENTS",
        "INFLAMMATION",
        "BODY COMPOSITION",
        "GI",
        "SLEEP / RECOVERY",
    ]
    cards = "".join(f'<div class="card"><strong>{escape(d)}</strong></div>' for d in domains)
    body = f"""
    <h1>Scientific Center home</h1>
    <p class="muted">Standalone R1 module. Consumes versioned projections; never writes
    to BV Clinical. No real patient data.</p>
    <div class="grid">{cards}</div>
    <h2>Modes</h2>
    <ul>
      <li><a href="/patient">Patient mode</a> - clinical synthesis for a specific patient.</li>
      <li><a href="/knowledge">Knowledge mode</a> - repository search and references.</li>
    </ul>
    """
    return page("Scientific Center", body)


def patient_index(app, patients: list[str]) -> str:
    rows = "".join(
        f'<li><a href="/patient/{escape(p)}">{escape(p)}</a></li>' for p in patients
    ) or "<li class='muted'>No patients yet.</li>"
    body = f"<h1>Patient mode</h1><ul>{rows}</ul>"
    return page("Patient mode", body)


def patient_overview(app, patient_id: str, overview: dict[str, Any], run: dict | None) -> str:
    counts = overview["counts"]
    run_info = ""
    if run:
        run_info = (
            f"<p class='muted'>Latest run <code>{escape(run['run_id'])}</code> · "
            f"package <code>{escape(str(run.get('knowledge_package_version')))}</code> · "
            f"status {escape(str(run.get('status')))}</p>"
        )
    nav = " ".join(
        f'<a href="/patient/{escape(patient_id)}/{section}">{section.title()}</a>'
        for section in ("map", "domains", "metrics", "signals", "timeline", "compare")
    )
    cards = "".join(
        f'<div class="card"><div class="muted">{escape(k)}</div><div><strong>{v}</strong></div></div>'
        for k, v in counts.items()
    )
    body = f"""
    <h1>Patient {escape(patient_id)}</h1>
    {run_info}
    <p>{nav}</p>
    <h2>Overview</h2><div class="grid">{cards}</div>
    <p class="disclaimer muted">Derived metrics, scores and signals are SYSTEM_DERIVED
    and are never diagnoses. Missing values are never treated as zero.</p>
    """
    return page(f"Patient {patient_id}", body)


def patient_domains(app, patient_id: str, domains: dict[str, list[dict]]) -> str:
    parts = []
    for domain, entries in sorted(domains.items()):
        rows = "".join(_domain_row(e) for e in entries)
        parts.append(
            f"<h2>{escape(domain)}</h2><table><tr><th>Kind</th><th>Label</th>"
            f"<th>Value</th><th>Authority</th><th>When</th></tr>{rows}</table>"
        )
    body = f"<h1>Domains · {escape(patient_id)}</h1>" + ("".join(parts) or "<p class='muted'>None.</p>")
    return page("Domains", body)


def _domain_row(entry: dict) -> str:
    value = ""
    if entry.get("kind") == "SIGNAL":
        value = f"{entry.get('severity','')} · {entry.get('status','')}"
    else:
        val = entry.get("value")
        value = f"{val:g} {entry.get('unit') or ''}".strip() if isinstance(val, (int, float)) else ""
    return (
        f"<tr><td>{escape(str(entry.get('kind')))}</td><td>{escape(str(entry.get('label')))}</td>"
        f"<td>{escape(value)}</td><td>{escape(str(entry.get('authority','')))}</td>"
        f"<td class='muted'>{escape(str(entry.get('effective_at') or ''))}</td></tr>"
    )


def patient_metrics(app, patient_id: str, metrics: list) -> str:
    rows = []
    for m in metrics:
        status = m.calculation_status.value
        value = "" if m.value is None else f"{m.value:g} {m.unit}"
        warn = " ".join(escape(w) for w in m.warnings)
        refs = ", ".join(
            f"<code>{escape(r.get('concept'))}={escape(str(r.get('value')))} "
            f"{escape(str(r.get('unit')))}</code>"
            for r in m.input_refs
        )
        rows.append(
            f"<tr><td>{escape(m.metric_definition_id)}</td>"
            f"<td>v{m.metric_definition_version}</td>"
            f"<td>{escape(m.authority.value)}</td>"
            f"<td>{escape(value)}</td><td>{escape(status)}</td>"
            f"<td>{refs}</td><td class='warn'>{warn}</td></tr>"
        )
    table = (
        "<table><tr><th>Metric</th><th>Version</th><th>Authority</th><th>Value</th>"
        "<th>Status</th><th>Inputs</th><th>Warnings</th></tr>"
        + "".join(rows)
        + "</table>"
    )
    body = f"<h1>Derived metrics · {escape(patient_id)}</h1>{table or '<p class=muted>None.</p>'}"
    return page("Derived metrics", body)


def patient_signals(app, patient_id: str, signals: list[dict]) -> str:
    rows = []
    for s in signals:
        rows.append(
            f"<tr><td><a href='/signal/{escape(s['signal_id'])}'>{escape(s['title'])}</a></td>"
            f"<td>{escape(s['severity'])}</td><td>{escape(s['status'])}</td>"
            f"<td>{escape(s['rule_id'])} v{s['rule_version']}</td>"
            f"<td class='muted'>{escape(str(s['generated_at']))}</td></tr>"
        )
    table = (
        "<table><tr><th>Signal</th><th>Severity</th><th>Status</th><th>Rule</th>"
        "<th>Generated</th></tr>" + "".join(rows) + "</table>"
    )
    body = (
        f"<h1>Signals · {escape(patient_id)}</h1>"
        "<p class='disclaimer'>Signals are candidates for review. They are not diagnoses "
        "and acceptance does not create a diagnosis.</p>"
        f"{table or '<p class=muted>None.</p>'}"
    )
    return page("Signals", body)


def signal_detail(app, signal: dict) -> str:
    explanation = signal.get("explanation", {})
    inputs = explanation.get("inputs", [])
    input_rows = "".join(
        f"<tr><td>{escape(str(i.get('label')))}</td><td>{escape(str(i.get('concept')))}</td>"
        f"<td>{escape(str(i.get('value')))} {escape(str(i.get('unit')))}</td>"
        f"<td>{escape(str(i.get('original_value')))} {escape(str(i.get('original_unit')))}</td>"
        f"<td class='muted'>{escape(str(i.get('effective_at')))}</td>"
        f"<td>{escape(str(i.get('ref_kind')))}</td></tr>"
        for i in inputs
    )
    evidence = "".join(f"<li>{escape(str(e))}</li>" for e in explanation.get("evidence_refs", []))
    actions = " ".join(
        f'<a href="/signal/{escape(signal["signal_id"])}/review?action={a}">{a}</a>'
        for a in ("ACKNOWLEDGE", "ACCEPT_AS_RELEVANT", "DISMISS")
    )
    body = f"""
    <h1>{escape(signal['title'])}</h1>
    <p><span class="badge layer-SIGNALS">{escape(signal['severity'])}</span>
       <span class="badge">{escape(signal['status'])}</span>
       <span class="badge">rule {escape(signal['rule_id'])} v{signal['rule_version']}</span></p>
    <h2>WHY AM I SEEING THIS?</h2>
    <p>{escape(explanation.get('rendered') or '')}</p>
    <p class="muted">{escape(explanation.get('disclaimer',''))}</p>
    <h2>Inputs</h2>
    <table><tr><th>Input</th><th>Concept</th><th>Value</th><th>Original</th><th>When</th><th>Kind</th></tr>
    {input_rows}</table>
    <h2>Logic</h2>
    <p>Combine: <code>{escape(str(explanation.get('combine')))}</code></p>
    <ul>{''.join(f'<li><code>{escape(c)}</code></li>' for c in explanation.get('conditions', []))}</ul>
    <h2>Evidence</h2><ul>{evidence or "<li class='muted'>None</li>"}</ul>
    <h2>Review</h2>
    <p>{actions}</p>
    <p class="muted">Viewing only. Accepting a signal does not create a diagnosis and
    writes nothing to the Prontuario.</p>
    """
    return page(signal["title"], body)


def patient_timeline(app, patient_id: str, entries: list[dict]) -> str:
    rows = "".join(
        f"<tr><td class='muted'>{escape(str(e['effective_at']))}</td>"
        f"<td><span class='badge layer-{escape(e['layer'])}'>{escape(e['kind'])}</span></td>"
        f"<td>{escape(e['label'])}</td><td class='muted'>{escape(e['source'])}</td></tr>"
        for e in entries
    )
    body = (
        f"<h1>Timeline · {escape(patient_id)}</h1>"
        "<table><tr><th>When</th><th>Kind</th><th>Entry</th><th>Source</th></tr>"
        f"{rows}</table>"
        "<p class='muted'>Unified scientific timeline. Treatment effects are not inferred.</p>"
    )
    return page("Timeline", body)


def patient_map(app, patient_id: str, projection, active_layers: list[str]) -> str:
    data = projection.to_dict()
    toggles = " ".join(
        f"<a href='/patient/{escape(patient_id)}/map?layers={l.value}'>{l.value}</a>"
        for l in MapLayer
    )
    node_ids = {n["node_id"]: n for n in data["nodes"]}
    nodes_by_layer: dict[str, list[dict]] = {}
    for node in data["nodes"]:
        nodes_by_layer.setdefault(node["layer"], []).append(node)

    layer_sections = []
    for layer, nodes in sorted(nodes_by_layer.items()):
        rows = "".join(
            f"<tr><td>{escape(n['node_type'])}</td><td>{escape(n['label'])}</td>"
            f"<td>{escape(str(n['authority']))}</td>"
            f"<td class='muted'>{escape(_prov(n))}</td></tr>"
            for n in nodes
        )
        layer_sections.append(
            f"<h2><span class='badge layer-{escape(layer)}'>{escape(layer)}</span></h2>"
            f"<table><tr><th>Type</th><th>Node</th><th>Authority</th><th>Provenance</th></tr>{rows}</table>"
        )

    edge_rows = "".join(
        f"<tr><td>{escape(node_ids.get(e['source_node_id'],{}).get('label','?'))}</td>"
        f"<td>{escape(e['relation'])}</td>"
        f"<td>{escape(node_ids.get(e['target_node_id'],{}).get('label','?'))}</td>"
        f"<td class='muted'>{escape(_why(e))}</td></tr>"
        for e in data["edges"]
    )
    meta = data["metadata"]
    body = f"""
    <h1>Clinical map · {escape(patient_id)}</h1>
    <p class="muted">Package <code>{escape(str(meta.get('knowledge_package_version')))}</code> ·
    temporal mode {escape(meta.get('temporal_mode',''))} · run <code>{escape(str(meta.get('run_id')))}</code></p>
    <p>Layers: {toggles} · <a href="/patient/{escape(patient_id)}/map">all</a></p>
    <p class="muted">Active layers: {escape(', '.join(active_layers))}</p>
    {''.join(layer_sections)}
    <h2>Edges (WHY CONNECTED?)</h2>
    <table><tr><th>From</th><th>Relation</th><th>To</th><th>Why</th></tr>{edge_rows}</table>
    <p class="disclaimer muted">Edges are typed and non-causal unless explicitly a validated
    causal model. Association is not causation.</p>
    """
    return page("Clinical map", body)


def _prov(node: dict) -> str:
    p = node.get("provenance", {})
    bits = []
    if p.get("source_ref"):
        bits.append(f"source={p['source_ref']}")
    if p.get("formula_id"):
        bits.append(f"formula={p['formula_id']}@{p.get('formula_version')}")
    if p.get("score_id"):
        bits.append(f"score={p['score_id']}@{p.get('score_version')}")
    if p.get("rule_id"):
        bits.append(f"rule={p['rule_id']}@{p.get('rule_version')}")
    return "; ".join(bits) or "UNTRACEABLE"


def _why(edge: dict) -> str:
    p = edge.get("provenance", {})
    bits = [f"relation={edge['relation']}"]
    if p.get("formula_id"):
        bits.append(f"formula={p['formula_id']}@{p.get('formula_version')}")
    if p.get("rule_id"):
        bits.append(f"rule={p['rule_id']}@{p.get('rule_version')}")
    if p.get("note"):
        bits.append(p["note"])
    if p.get("evidence_refs"):
        bits.append("evidence=" + ",".join(p["evidence_refs"]))
    return " | ".join(bits)


def patient_compare(app, patient_id: str, result: dict) -> str:
    rows = "".join(
        f"<tr><td>{escape(str(c['concept']))}</td><td>{escape(str(c.get('t0','')))}</td>"
        f"<td>{escape(str(c.get('t1','')))}</td><td>{escape(str(c.get('unit','')))}</td>"
        f"<td>{escape(str(c.get('absolute_change','')))}</td>"
        f"<td>{escape(str(c.get('percent_change','')))}</td></tr>"
        if c.get("comparable")
        else f"<tr><td>{escape(str(c['concept']))}</td><td colspan=5 class='muted'>"
        f"not comparable: {escape(str(c.get('reason','')))}</td></tr>"
        for c in result["changes"]
    )
    body = f"""
    <h1>Compare · {escape(patient_id)}</h1>
    <p class="muted">T0 {escape(result['t0'])} → T1 {escape(result['t1'])}</p>
    <table><tr><th>Concept</th><th>T0</th><th>T1</th><th>Unit</th><th>Δ</th><th>Δ%</th></tr>{rows}</table>
    <p class="disclaimer muted">{escape(result['disclaimer'])}</p>
    """
    return page("Compare", body)


def knowledge_home(app, query: str, results: dict | None) -> str:
    items = app.knowledge.list_items()
    rows = "".join(
        f"<tr><td><a href='/knowledge/item/{escape(i.knowledge_id)}'>{escape(i.title)}</a></td>"
        f"<td>{escape(i.topic)}</td><td>{escape(i.source_type.value)}</td>"
        f"<td>{escape(str(i.publication_year))}</td><td>{escape(i.status.value)}</td></tr>"
        for i in items
    )
    search_block = f"""
    <form method="get" action="/knowledge/search">
      <input name="q" value="{escape(query)}" placeholder="cortisol DHEA, selenio, massa muscular ...">
      <button type="submit">Search</button>
    </form>
    """
    results_block = ""
    if results is not None:
        rrows = "".join(
            f"<tr><td><a href='/knowledge/item/{escape(str(r['knowledge_id']))}'>{escape(str(r['title']))}</a></td>"
            f"<td>{escape(str(r.get('topic') or ''))}</td><td>{escape(str(r.get('citation') or ''))}</td></tr>"
            for r in results["items"]
        )
        related = ""
        if results["related_formulas"] or results["related_scores"] or results["related_rules"]:
            related = "<p class='muted'>Related definitions: " + ", ".join(
                [f"<code>{escape(d['definition_id'])}</code>"
                 for d in results["related_formulas"] + results["related_scores"] + results["related_rules"]]
            ) + "</p>"
        results_block = (
            f"<h2>Results for “{escape(results['query'])}”</h2>"
            f"<table><tr><th>Title</th><th>Topic</th><th>Citation</th></tr>{rrows}</table>"
            f"{related or '<p class=\'muted\'>No related definitions.</p>'}"
        )
    body = f"""
    <h1>Knowledge mode</h1>
    {search_block}
    <p class="muted">Repository contains no patient data. Search is local (SQLite FTS5).</p>
    <h2>Repository items</h2>
    <table><tr><th>Title</th><th>Topic</th><th>Source type</th><th>Year</th><th>Status</th></tr>{rows}</table>
    <p class="muted"><a href="/knowledge/formulas">Formulas</a> ·
    <a href="/knowledge/packages">Knowledge packages</a> ·
    <a href="/knowledge/references">Scientific references</a> ·
    <a href="/knowledge/curation">Curation dashboard</a></p>
    {results_block}
    """
    return page("Knowledge mode", body)


def knowledge_item(app, item, claims: list[dict]) -> str:
    points = "".join(f"<li>{escape(p)}</li>" for p in item.key_points)
    claim_rows = "".join(
        f"<tr><td>{escape(str(c.get('text')))}</td><td>{escape(str(c.get('review_status')))}</td></tr>"
        for c in claims
    )
    citation_link = ""
    if item.url:
        citation_link = f' · <a href="{escape(item.url)}">View source</a>'
    body = f"""
    <h1>{escape(item.title)}</h1>
    <p class="muted">{escape(item.topic)}{(' / ' + escape(item.subtopic)) if item.subtopic else ''}</p>
    <p>{escape(item.summary)}</p>
    <h2>Key points</h2><ul>{points}</ul>
    <h2>Citation</h2>
    <p>{escape(item.citation)}<br>{escape(str(item.journal) or '')} {escape(str(item.publication_year) or '')}{citation_link}</p>
    <p class="muted">Evidence: {escape(str(item.evidence_framework) or '-')} / {escape(str(item.evidence_grade) or '-')}</p>
    <h2>Claims</h2>
    <table><tr><th>Claim</th><th>Review status</th></tr>{claim_rows or "<tr><td colspan=2 class='muted'>None</td></tr>"}</table>
    """
    return page(item.title, body)


def knowledge_formulas(app, formulas: list) -> str:
    rows = "".join(
        f"<tr><td>{escape(f.definition_id)}</td><td>v{f.version}</td>"
        f"<td>{escape(f.status.value)}</td><td><code>{escape(f.expression)}</code></td>"
        f"<td>{escape(f.output_unit)}</td><td>{escape(f.temporal_requirement.value)}</td></tr>"
        for f in formulas
    )
    body = (
        "<h1>Formulas</h1>"
        "<table><tr><th>Id</th><th>Version</th><th>Status</th><th>Expression</th>"
        f"<th>Output unit</th><th>Temporal</th></tr>{rows}</table>"
        "<p class='muted'>Published formula versions are immutable.</p>"
    )
    return page("Formulas", body)


def knowledge_packages(app, packages: list[dict]) -> str:
    rows = "".join(
        f"<tr><td>{escape(p['package_id'])}</td><td>{escape(p['version'])}</td>"
        f"<td>{escape(str(p['review_status']))}</td><td>{'yes' if p['is_active'] else 'no'}</td>"
        f"<td>{escape(str(p['activated_at']) or '')}</td></tr>"
        for p in packages
    )
    body = (
        "<h1>Knowledge packages</h1>"
        "<table><tr><th>Package</th><th>Version</th><th>Status</th><th>Active</th>"
        f"<th>Activated</th></tr>{rows}</table>"
        "<p class='muted'>Published versions are immutable; a new version is required "
        "for new literature. Activation can be rolled back.</p>"
    )
    return page("Packages", body)


def scientific_references(app, query: str, filters: dict, results: list[dict]) -> str:
    rows = "".join(
        f"<tr><td><a href='/knowledge/reference/{escape(str(r['reference_id']))}'>"
        f"{escape(str(r['title'])[:90])}</a></td>"
        f"<td>{escape(str(r['publication_year']) or '')}</td>"
        f"<td>{escape(str(r['venue']) or '')}</td>"
        f"<td>{escape(str(r['publication_type']) or '')}</td>"
        f"<td>{escape(str(r['verification_status']) or '')}</td>"
        f"<td><span class='badge'>{escape(str(r['curation_status']))}</span></td>"
        f"<td>{escape(str(r['origin']) or '')}</td></tr>"
        for r in results
    )
    form = f"""
    <form method="get" action="/knowledge/references">
      <input name="q" value="{escape(query)}" placeholder="title, author, DOI, PMID ...">
      <input name="author" value="{escape(filters.get('author') or '')}" placeholder="author">
      <input name="year" value="{escape(str(filters.get('year') or ''))}" placeholder="year" size="6">
      <input name="status" value="{escape(filters.get('status') or '')}" placeholder="curation status">
      <input name="type" value="{escape(filters.get('type') or '')}" placeholder="publication type">
      <button type="submit">Search</button>
    </form>
    """
    body = (
        f"<h1>Scientific references</h1>{form}"
        f"<p class='muted'>{len(results)} result(s). Read-only view; approvals are not "
        "available over HTTP (local administrative flow only).</p>"
        "<table><tr><th>Title</th><th>Year</th><th>Venue</th><th>Type</th>"
        f"<th>Verification</th><th>Curation</th><th>Origin</th></tr>{rows}</table>"
        "<p class='muted'><a href='/knowledge/curation'>Curation dashboard</a> · "
        "<a href='/knowledge/review-queue'>Review queue</a> · "
        "<a href='/knowledge'>Knowledge mode</a></p>"
    )
    return page("Scientific references", body)


def scientific_reference_detail(app, view: dict) -> str:
    r = view["reference"]
    authors = ", ".join(r.get("authors") or []) or "-"
    identifiers = []
    for key, label in (("doi", "DOI"), ("pmid", "PMID"), ("isbn", "ISBN"), ("url", "URL")):
        if r.get(key):
            identifiers.append(f"<li>{label}: <code>{escape(str(r[key]))}</code></li>")
    history = "".join(
        f"<tr><td class='muted'>{escape(str(h.get('created_at') or ''))}</td>"
        f"<td>{escape(str(h.get('from_status') or ''))} &rarr; {escape(str(h.get('to_status') or ''))}</td>"
        f"<td>{escape(str(h.get('actor') or ''))}</td>"
        f"<td>{escape(str(h.get('justification') or ''))}</td></tr>"
        for h in view["history"]
    )
    evidence = "".join(
        f"<tr><td>{escape(str(e['evidence_id']))}</td><td>{escape(str(e['title']))}</td>"
        f"<td>{escape(str(e['study_design']))}</td>"
        f"<td><span class='badge'>{escape(str(e['curation_status']))}</span></td></tr>"
        for e in view["evidence"]
    )
    links = "".join(
        f"<tr><td>{escape(str(l['target_type']))} {escape(str(l['target_id']))}"
        f"@{escape(str(l.get('target_version') or ''))}</td>"
        f"<td>{escape(str(l['relation']))}</td></tr>"
        for l in view["links"]
    )
    alerts = "".join(
        f"<tr><td>{escape(str(a['alert_type']))}</td><td>{escape(str(a['source']))}</td>"
        f"<td>{escape(str(a['details']))}</td><td>{escape(str(a['detected_at']))}</td></tr>"
        for a in view.get("editorial_alerts", [])
    )
    acquisitions = "".join(
        f"<tr><td>{escape(str(a['provider']))}</td><td>{escape(str(a['queried_at']))}</td>"
        f"<td><code>{escape(str(a.get('payload_sha256') or '')[:16])}</code></td>"
        f"<td>{escape(str(a.get('verification_status') or ''))}</td></tr>"
        for a in view.get("acquisitions", [])
    )
    appraisals = "".join(
        f"<tr><td>{escape(str(a.get('reviewer') or ''))}</td>"
        f"<td>{escape(str(a.get('content_review_status') or ''))}</td>"
        f"<td>{escape(str(a.get('reviewer_interpretation') or ''))}</td></tr>"
        for a in view.get("appraisals", [])
    )
    usable = "YES" if view["clinically_usable"] else "NO"
    retracted = " — RETRACTION ALERT" if view.get("has_retraction") else ""
    body = f"""
    <h1>{escape(str(r['title']))}</h1>
    <p class="muted">{escape(authors)} {escape(str(r.get('venue') or ''))} {escape(str(r.get('publication_year') or ''))}</p>
    <p><span class="badge">{escape(str(r['curation_status']))}</span>
       <span class="badge">{escape(str(r['verification_status']))}</span>
       <span class="badge">{escape(str(r.get('bibliographic_status') or ''))}</span>
       <span class="badge">{escape(str(r.get('content_review_status') or ''))}</span>
       <span class="badge">{escape(str(r['origin']))}</span>
       metadata source: {escape(str(r.get('metadata_source') or ''))}</p>
    <p>Clinically usable as current evidence: <strong>{usable}</strong>{escape(retracted)}</p>
    <h2>Identifiers</h2>
    <ul>{''.join(identifiers) or '<li class="muted">None recorded (VERIFY_PENDING)</li>'}</ul>
    <p class="muted">{escape(str(r.get('notes') or ''))}</p>
    <h2>Editorial alerts</h2>
    <table><tr><th>Type</th><th>Source</th><th>Details</th><th>Detected</th></tr>
    {alerts or '<tr><td colspan=4 class="muted">None.</td></tr>'}</table>
    <h2>Acquisition provenance</h2>
    <table><tr><th>Provider</th><th>Queried</th><th>Payload sha256</th><th>Verification</th></tr>
    {acquisitions or '<tr><td colspan=4 class="muted">None.</td></tr>'}</table>
    <h2>Critical appraisals</h2>
    <table><tr><th>Reviewer</th><th>Content review</th><th>Interpretation</th></tr>
    {appraisals or '<tr><td colspan=3 class="muted">None.</td></tr>'}</table>
    <h2>Curation history</h2>
    <table><tr><th>When</th><th>Transition</th><th>Actor</th><th>Justification</th></tr>
    {history or '<tr><td colspan=4 class="muted">No curation events yet.</td></tr>'}</table>
    <h2>Evidence</h2>
    <table><tr><th>Id</th><th>Title</th><th>Design</th><th>Status</th></tr>
    {evidence or '<tr><td colspan=4 class="muted">None.</td></tr>'}</table>
    <h2>Links</h2>
    <table><tr><th>Target</th><th>Relation</th></tr>
    {links or '<tr><td colspan=2 class="muted">None.</td></tr>'}</table>
    <p class="disclaimer muted">Approval is a human, local administrative action and is not
    available through this read-only interface.</p>
    """
    return page(str(r["title"]), body)


def human_review_page(app, queue: dict) -> str:
    def table(rows, columns):
        body = "".join(
            "<tr>" + "".join(f"<td>{escape(str(r.get(c) or ''))}</td>" for c in columns) + "</tr>"
            for r in rows
        ) or f"<tr><td colspan={len(columns)} class='muted'>None</td></tr>"
        head = "".join(f"<th>{escape(c)}</th>" for c in columns)
        return f"<table><tr>{head}</tr>{body}</table>"

    body = f"""
    <h1>Human review queue</h1>
    <p class="disclaimer muted">Read-only. A local reviewer identity is declared, not
    authenticated. There is no approval action over HTTP.</p>
    <h2>References pending ({len(queue['references_pending'])})</h2>
    {table(queue['references_pending'], ['reference_id','title','bibliographic_status','content_review_status','curation_status','editorial_alerts'])}
    <h2>Claims pending ({len(queue['claims_pending'])})</h2>
    {table(queue['claims_pending'], ['claim_id','text','curation_status','certainty_level'])}
    <h2>Formula candidates pending ({len(queue['formula_candidates_pending'])})</h2>
    {table(queue['formula_candidates_pending'], ['candidate_id','version','display_name','candidate_type','review_status','operational','references'])}
    <p class="muted"><a href="/knowledge/candidates">Formula candidates</a></p>
    """
    return page("Human review queue", body)


def candidate_list(app, candidates: list[dict]) -> str:
    rows = "".join(
        f"<tr><td><a href='/knowledge/candidate/{escape(str(c['candidate_id']))}'>"
        f"{escape(str(c['display_name']))}</a></td>"
        f"<td>{escape(str(c['candidate_type']))}</td>"
        f"<td><code>{escape(str(c['expression']))}</code></td>"
        f"<td>{escape(str(c['output_unit']))}</td>"
        f"<td>{escape(str(c['review_status']))}</td>"
        f"<td>{'yes' if c['operational'] else 'no'}</td></tr>"
        for c in candidates
    )
    body = (
        "<h1>Formula candidates</h1>"
        "<p class='muted'>Non-operational scientific candidates. No clinical execution; "
        "no cutoff imported as a diagnostic criterion.</p>"
        "<table><tr><th>Candidate</th><th>Type</th><th>Expression</th><th>Output</th>"
        f"<th>Review</th><th>Operational</th></tr>{rows}</table>"
        "<p class='muted'><a href='/knowledge/human-review'>Human review queue</a></p>"
    )
    return page("Formula candidates", body)


def candidate_detail(app, view: dict) -> str:
    c = view["candidate"]
    variables = "".join(
        f"<tr><td>{escape(str(v['name']))}</td><td>{escape(str(v['unit']))}</td>"
        f"<td>{escape(', '.join(v['allowed_semantics']))}</td>"
        f"<td>{escape(str(v['description']))}</td></tr>"
        for v in c["variables"]
    )
    limitations = "".join(f"<li>{escape(x)}</li>" for x in c["limitations"])
    references = "".join(
        f"<tr><td><a href='/knowledge/reference/{escape(str(r['reference_id']))}'>"
        f"{escape(str(r['title'])[:70])}</a></td><td>{escape(str(r.get('doi') or ''))}</td></tr>"
        for r in view["references"]
    )
    links = "".join(
        f"<tr><td>{escape(str(l['relation']))}</td><td>{escape(str(l['subject_id']))}</td>"
        f"<td>{escape(str(l.get('justification') or ''))}</td></tr>"
        for l in view["evidence_links"]
    )
    body = f"""
    <h1>{escape(str(c['display_name']))} <span class="muted">({escape(str(c['candidate_id']))} v{c['version']})</span></h1>
    <p><span class="badge">{escape(str(c['candidate_type']))}</span>
       <span class="badge">{escape(str(c['review_status']))}</span>
       operational: <strong>{'yes' if c['operational'] else 'no'}</strong></p>
    <p>Expression: <code>{escape(str(c['expression']))}</code> → {escape(str(c['output_unit']))}</p>
    <p class="muted">Domain: {escape(str(c.get('output_domain') or ''))}</p>
    <h2>Variables</h2>
    <table><tr><th>Name</th><th>Unit</th><th>Allowed semantics</th><th>Description</th></tr>{variables}</table>
    <h2>Applicability</h2><p class="muted">{escape(str(c['applicability']))}</p>
    <h2>Limitations</h2><ul>{limitations or '<li class="muted">None</li>'}</ul>
    <h2>References</h2>
    <table><tr><th>Title</th><th>DOI</th></tr>{references or '<tr><td colspan=2 class="muted">None</td></tr>'}</table>
    <h2>Evidence links</h2>
    <table><tr><th>Relation</th><th>Subject</th><th>Justification</th></tr>{links or '<tr><td colspan=3 class="muted">None</td></tr>'}</table>
    <p class="disclaimer muted">Non-operational. No clinical approval; not for patient use.</p>
    """
    return page(str(c["display_name"]), body)


def review_queue_page(app, queue: list[dict]) -> str:
    rows = "".join(
        f"<tr><td><a href='/knowledge/reference/{escape(str(q['reference_id']))}'>"
        f"{escape(str(q['title'])[:70])}</a></td>"
        f"<td>{escape(str(q['bibliographic_status']))}</td>"
        f"<td>{escape(str(q['content_review_status']))}</td>"
        f"<td>{escape(str(q['curation_status']))}</td>"
        f"<td>{len(q['editorial_alerts'])}</td>"
        f"<td>{len(q['links'])}</td>"
        f"<td>{'yes' if q['clinically_usable'] else 'no'}</td></tr>"
        for q in queue
    )
    body = (
        "<h1>Medical review queue</h1>"
        "<p class='disclaimer muted'>Read-only. Approval requires an explicit local "
        "administrative action (reviewer + justification); it is never automatic and "
        "never available over HTTP. A local reviewer string is not authentication.</p>"
        f"<p class='muted'>{len(queue)} item(s) pending review.</p>"
        "<table><tr><th>Reference</th><th>Bibliographic</th><th>Content review</th>"
        f"<th>Curation</th><th>Alerts</th><th>Links</th><th>Usable</th></tr>{rows}</table>"
        "<p class='muted'>Export: <code>python -m bv_scientific_center review-export "
        "--format json|csv</code></p>"
    )
    return page("Review queue", body)


def curation_dashboard(app, dashboard: dict, taxonomy: dict) -> str:
    def counts_table(counts: dict) -> str:
        rows = "".join(
            f"<tr><td>{escape(str(k))}</td><td>{v}</td></tr>" for k, v in sorted(counts.items())
        ) or "<tr><td colspan=2 class='muted'>None</td></tr>"
        return f"<table><tr><th>Status</th><th>Count</th></tr>{rows}</table>"

    designs = ", ".join(escape(d) for d in taxonomy["study_designs"])
    body = f"""
    <h1>Curation dashboard</h1>
    <p class="muted">Read-only. Approval requires an explicit, audited local
    administrative action (reviewer + justification); it is never automatic and
    never available over HTTP.</p>
    <h2>References</h2>{counts_table(dashboard['references'])}
    <h2>Evidence</h2>{counts_table(dashboard['evidence'])}
    <h2>Claims</h2>{counts_table(dashboard['claims'])}
    <h2>Study design taxonomy</h2><p class="muted">{designs}</p>
    <p class="muted"><a href="/knowledge/references">Scientific references</a></p>
    """
    return page("Curation dashboard", body)


def dossier_index_page(app, index: list[dict]) -> str:
    rows = "".join(
        f"<tr><td><a href='/knowledge/dossier/{escape(str(r['reference_id']))}'>"
        f"{escape(str(r['title'])[:80])}</a></td>"
        f"<td>{escape(str(r['doi']))}</td>"
        f"<td>{'yes' if r['abstract_available'] else 'no'}</td>"
        f"<td>{'yes' if r.get('extraction_available') else 'no'}</td>"
        f"<td class='muted'>{escape(', '.join(r['availability']))}</td>"
        f"<td>{len(r['pending_fields'])}</td></tr>"
        for r in index
    )
    body = (
        "<h1>Medical dossiers</h1>"
        "<p class='muted'>Prepared for human review. No decision is executed automatically. "
        "Accepting for consideration does NOT approve any formula for clinical use.</p>"
        "<table><tr><th>Publication</th><th>DOI</th><th>Abstract</th><th>Extraction</th>"
        f"<th>Availability</th><th>Pending fields</th></tr>{rows}</table>"
    )
    return page("Medical dossiers", body)


def dossier_detail_page(app, data: dict) -> str:
    r = data["reference"]
    content_rows = "".join(
        f"<tr><td>{escape(str(c['content_type']))}</td><td>{escape(str(c['source']))}</td>"
        f"<td>{escape(str(c['availability']))}</td><td>{escape(str(c.get('license') or ''))}</td>"
        f"<td><code>{escape(str(c.get('sha256') or '')[:16])}</code></td>"
        f"<td>{escape(str(c.get('locator') or ''))}</td>"
        f"<td>{'stored' if c.get('storage_permitted') else 'withheld'}</td></tr>"
        for c in data["content_accessed"]
    ) or "<tr><td colspan=7 class='muted'>No content acquired.</td></tr>"

    extraction = data.get("structured_extraction")
    if extraction:
        field_rows = "".join(
            f"<tr><td>{escape(name)}</td>"
            f"<td>{escape(str(f.get('value')))}</td>"
            f"<td>{escape(str(f.get('provenance')))}</td>"
            f"<td class='muted'>{escape(str(f.get('locator') or ''))}</td>"
            f"<td class='muted'>{escape(str(f.get('verbatim') or '')[:60])}</td></tr>"
            for name, f in extraction["fields"].items()
        )
        extraction_block = (
            f"<p class='muted'>source={escape(str(extraction['source_kind']))} "
            f"sha256={escape(str(extraction['source_sha256'])[:16])} "
            f"version={escape(str(extraction['extraction_version']))}</p>"
            "<table><tr><th>Field</th><th>Value</th><th>Provenance</th><th>Locator</th>"
            f"<th>Verbatim span</th></tr>{field_rows}</table>"
            "<p class='disclaimer muted'>Automated extraction is not human critical review. "
            "Values are EXTRACTED_UNVERIFIED; each maps to a verbatim source span.</p>"
        )
    else:
        extraction_block = (
            "<p class='muted'>No abstract available; no fields extracted "
            "(INSUFFICIENT_INFORMATION).</p>"
        )

    links = "".join(
        f"<li>{escape(str(link['target_id']))} ({escape(str(link['relation']))})</li>"
        for link in data["linked_formula_candidates"]
    ) or "<li class='muted'>None</li>"

    alerts = "".join(
        f"<li>{escape(str(a['alert_type']))}: {escape(str(a['details']))}</li>"
        for a in data["editorial"]["alerts"]
    )
    currency = data.get("currency")
    currency_text = (
        f"last check {escape(str(currency['checked_at']))} via {escape(str(currency['provider']))} "
        f"({escape(str(currency['outcome']))}, currency_known={currency['currency_known']})"
        if currency
        else "currency not verified (no provider check recorded)"
    )
    decisions = "".join(
        f"<li>{escape(str(d['decision']))} by {escape(str(d.get('actor') or ''))} "
        f"({escape(str(d.get('justification') or ''))})</li>"
        for d in data["review_decisions"]
    ) or "<li class='muted'>No decisions recorded.</li>"
    questions = "".join(
        f"<li>{escape(str(q))}</li>" for q in data["medical_questions"]
    ) or "<li class='muted'>None</li>"

    body = f"""
    <h1>{escape(str(r['title']))}</h1>
    <p class="muted">{escape(str(r.get('venue') or ''))} ({escape(str(r.get('publication_year') or ''))})
    · DOI {escape(str(r.get('doi') or ''))} · PMID {escape(str(r.get('pmid') or ''))}</p>
    <p><span class="badge">{escape(str(data['editorial']['curation_status']))}</span>
       <span class="badge">{escape(str(data['editorial']['content_review_status']))}</span>
       abstract: <strong>{'yes' if data['abstract_available'] else 'no'}</strong>
       full text: <strong>{'yes' if data['full_text_available'] else 'no'}</strong></p>
    <h2>Content accessed</h2>
    <table><tr><th>Type</th><th>Source</th><th>Availability</th><th>License</th>
    <th>SHA-256</th><th>Locator</th><th>Text</th></tr>{content_rows}</table>
    <h2>Structured extraction</h2>{extraction_block}
    <h2>Methodology (body composition)</h2>
    <p class="muted">Risk of bias: {escape(str(data['methodology']['risk_of_bias']['status']))} —
    {escape(str(data['methodology']['risk_of_bias']['reason']))}</p>
    <h2>Linked formula candidates</h2><ul>{links}</ul>
    <h2>Editorial alerts</h2><ul>{alerts or "<li class='muted'>None</li>"}</ul>
    <p class="muted">{currency_text}</p>
    <h2>Medical decision (prepared, not executed)</h2>
    <ul>{questions}</ul>
    <p class="disclaimer muted">Decisions are recorded only through an explicit local
    administrative action with a declared actor and justification. There is no decision
    or approval action over HTTP. A local reviewer string is not authentication.</p>
    <h2>Recorded decisions</h2><ul>{decisions}</ul>
    <p class="muted"><a href="/knowledge/dossiers">Back to dossier index</a></p>
    """
    return page(str(r["title"]), body)
