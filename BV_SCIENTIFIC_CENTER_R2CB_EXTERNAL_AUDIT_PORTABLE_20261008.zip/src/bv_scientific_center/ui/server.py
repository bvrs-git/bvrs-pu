"""Minimal clinician-facing HTTP UI (standard library only).

Read-only by design except for an explicit signal-review action link. This is a
prototype surface for R1 - it is NOT exposed to patients (spec §81).
"""

from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse

from ..core.enums import MapLayer
from ..core.timeutil import parse_dt, to_iso
from . import render


class ScientificCenterHandler(BaseHTTPRequestHandler):
    app: Any = None  # set on the server instance
    server_version = "BVScientificCenter/0.1"

    # -- plumbing ----------------------------------------------------------
    def _send_html(self, html: str, status: int = 200) -> None:
        payload = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, fmt: str, *args) -> None:  # quieter console
        return

    def do_GET(self) -> None:  # noqa: N802
        try:
            self._route()
        except KeyError as exc:
            self._send_html(render.page("Not found", f"<p>Not found: {exc}</p>"), status=404)
        except Exception as exc:  # pragma: no cover - prototype error surface
            self._send_html(
                render.page("Error", f"<p>Error: {type(exc).__name__}: {exc}</p>"), status=500
            )

    # -- routing -----------------------------------------------------------
    def _route(self) -> None:
        app = self.app
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        query = parse_qs(parsed.query)
        parts = [p for p in path.split("/") if p]

        if path == "/":
            return self._send_html(render.home(app))

        if path == "/patient":
            return self._send_html(render.patient_index(app, app.list_patients()))

        if parts and parts[0] == "patient" and len(parts) >= 2:
            return self._patient(app, parts, query)

        if parts and parts[0] == "signal" and len(parts) >= 2:
            return self._signal(app, parts, query)

        if path == "/knowledge":
            return self._send_html(render.knowledge_home(app, "", None))
        if path == "/knowledge/search":
            q = (query.get("q") or [""])[0]
            return self._send_html(render.knowledge_home(app, q, app.knowledge_search(q)))
        if path == "/knowledge/formulas":
            return self._send_html(render.knowledge_formulas(app, app.formulas.all_latest()))
        if path == "/knowledge/packages":
            return self._send_html(render.knowledge_packages(app, app.packages.list_packages()))
        if path == "/knowledge/curation":
            return self._send_html(
                render.curation_dashboard(app, app.curation_dashboard(), app.methodology_taxonomy())
            )
        if path == "/knowledge/review-queue":
            return self._send_html(render.review_queue_page(app, app.review_queue()))
        if path == "/knowledge/human-review":
            return self._send_html(render.human_review_page(app, app.human_review_queue()))
        if path == "/knowledge/candidates":
            return self._send_html(render.candidate_list(app, app.formula_candidates_list()))
        if parts[:2] == ["knowledge", "candidate"] and len(parts) == 3:
            return self._send_html(render.candidate_detail(app, app.candidate_view(parts[2])))
        if path == "/knowledge/dossiers":
            return self._send_html(render.dossier_index_page(app, app.dossier_index()))
        if parts[:2] == ["knowledge", "dossier"] and len(parts) == 3:
            return self._send_html(render.dossier_detail_page(app, app._dossier_dict(parts[2])))
        if path == "/knowledge/references":
            query_text = (query.get("q") or [""])[0]
            year_raw = (query.get("year") or [""])[0].strip()
            filters = {
                "author": (query.get("author") or [""])[0] or None,
                "status": (query.get("status") or [""])[0] or None,
                "type": (query.get("type") or [""])[0] or None,
                "year": int(year_raw) if year_raw.isdigit() else None,
            }
            results = app.scientific_search_references(
                query_text,
                author=filters["author"],
                status=filters["status"],
                publication_type=filters["type"],
                year=filters["year"],
            )
            return self._send_html(render.scientific_references(app, query_text, filters, results))
        if parts[:2] == ["knowledge", "reference"] and len(parts) == 3:
            return self._send_html(render.scientific_reference_detail(app, app.reference_view(parts[2])))
        if parts[:2] == ["knowledge", "item"] and len(parts) == 3:
            item = app.knowledge.get_item(parts[2])
            if item is None:
                raise KeyError(parts[2])
            return self._send_html(render.knowledge_item(app, item, app.knowledge.claims_for_item(item.knowledge_id)))

        return self._send_html(render.page("Not found", "<p>Unknown page.</p>"), status=404)

    def _patient(self, app, parts: list[str], query: dict) -> None:
        patient_id = parts[1]
        section = parts[2] if len(parts) > 2 else "overview"
        run = app.latest_run(patient_id)

        if section == "overview":
            overview = app.patient_overview(patient_id)
            return self._send_html(render.patient_overview(app, patient_id, overview, run))
        if section == "domains":
            return self._send_html(render.patient_domains(app, patient_id, app.domain_dashboard(patient_id)))
        if section == "metrics":
            return self._send_html(render.patient_metrics(app, patient_id, app.metrics.list_for_patient(patient_id)))
        if section == "signals":
            return self._send_html(render.patient_signals(app, patient_id, app.signals.list_for_patient(patient_id)))
        if section == "timeline":
            return self._send_html(render.patient_timeline(app, patient_id, app.timeline(patient_id)))
        if section == "map":
            layers_param = (query.get("layers") or [None])[0]
            layers = None
            active = [l.value for l in MapLayer]
            if layers_param:
                layers = [MapLayer(v) for v in layers_param.split(",")]
                active = [l.value for l in layers]
            # Prefer deterministic reconstruction from the stored run; fall back
            # to recomputation when no completed run is available.
            stored = app.latest_run(patient_id)
            if stored and stored.get("status") == "COMPLETED":
                run_result = app.rebuild_run(patient_id, stored["run_id"])
            else:
                run_result = app.reproduce_run(patient_id)
            projection = app.build_map(run_result, layers=layers)
            return self._send_html(render.patient_map(app, patient_id, projection, active))
        if section == "compare":
            t0, t1 = self._compare_window(app, patient_id, query)
            return self._send_html(render.patient_compare(app, patient_id, app.compare(patient_id, t0, t1)))

        return self._send_html(render.page("Not found", "<p>Unknown patient section.</p>"), status=404)

    @staticmethod
    def _compare_window(app, patient_id: str, query: dict) -> tuple[str, str]:
        obs = app.observations.list_for_patient(patient_id)
        dates = sorted({to_iso(r.effective_at) for r in obs if r.effective_at})
        default_t0 = dates[0] if dates else to_iso(parse_dt("2026-01-01T00:00:00+00:00"))
        default_t1 = dates[-1] if dates else to_iso(parse_dt("2026-12-31T00:00:00+00:00"))
        t0 = (query.get("t0") or [default_t0])[0]
        t1 = (query.get("t1") or [default_t1])[0]
        return t0, t1

    def _signal(self, app, parts: list[str], query: dict) -> None:
        signal_id = parts[1]
        if len(parts) >= 3 and parts[2] == "review":
            action = (query.get("action") or ["ACKNOWLEDGE"])[0]
            app.review.review_signal(signal_id, action, reviewer="clinician-ui")
        signal = app.signals.get(signal_id)
        if signal is None:
            raise KeyError(signal_id)
        return self._send_html(render.signal_detail(app, signal))


def make_server(app, host: str = "127.0.0.1", port: int = 8787) -> ThreadingHTTPServer:
    handler = type("BoundHandler", (ScientificCenterHandler,), {"app": app})
    return ThreadingHTTPServer((host, port), handler)


def serve(app, host: str = "127.0.0.1", port: int = 8787) -> None:
    httpd = make_server(app, host, port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:  # pragma: no cover
        pass
    finally:
        httpd.server_close()
