"""AI drafting boundary.

R1 does not implement production AI reasoning (spec §99). This module exists to
enforce the *labelling contract*: any AI-produced text is labelled ``AI_DRAFT``
or ``AI_SUGGESTION`` and can never become ``CLINICIAN_CONFIRMED`` on its own
(spec §19).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core.enums import Authority
from ..core.timeutil import now_utc

_AI_AUTHORITIES = {Authority.AI_DRAFT, Authority.AI_SUGGESTION}


@dataclass
class AIDraft:
    text: str
    kind: Authority = Authority.AI_DRAFT
    prompt_context: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=now_utc)

    def __post_init__(self) -> None:
        if self.kind not in _AI_AUTHORITIES:
            raise ValueError(
                "AI output must be labelled AI_DRAFT or AI_SUGGESTION, never "
                f"{self.kind.value}"
            )

    @property
    def is_clinician_confirmed(self) -> bool:
        return False

    def label(self) -> str:
        return f"[{self.kind.value}] {self.text}"


def placeholder_summary(knowledge_titles: list[str]) -> AIDraft:
    """Deterministic placeholder used only to exercise the labelling contract."""
    text = (
        "Draft synthesis placeholder. No AI reasoning is performed in R1. "
        f"Referenced repository items: {', '.join(knowledge_titles) or 'none'}."
    )
    return AIDraft(text=text, kind=Authority.AI_DRAFT)
