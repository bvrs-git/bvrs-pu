"""AI labelling only. No production AI reasoning in R1 (spec §19, §99)."""
