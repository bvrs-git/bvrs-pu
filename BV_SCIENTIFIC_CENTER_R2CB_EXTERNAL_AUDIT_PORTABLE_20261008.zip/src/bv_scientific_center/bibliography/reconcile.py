"""Cross-provider reconciliation by persistent identifiers (never by title)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.enums import BibliographicVerification
from .models import BibliographicRecord

_COMPARE_FIELDS = ("title", "journal", "year")
_NORMALIZERS = {
    "title": lambda v: (v or "").strip().lower().rstrip("."),
    "journal": lambda v: (v or "").strip().lower(),
    "year": lambda v: v,
}


@dataclass
class ReconciliationResult:
    identity: tuple[str, str]
    records: list[BibliographicRecord] = field(default_factory=list)
    divergences: dict[str, dict[str, Any]] = field(default_factory=dict)
    status: BibliographicVerification = BibliographicVerification.PENDING
    notes: list[str] = field(default_factory=list)

    @property
    def providers(self) -> list[str]:
        return sorted({r.provider for r in self.records})

    def to_dict(self) -> dict[str, Any]:
        return {
            "identity": list(self.identity),
            "providers": self.providers,
            "status": self.status.value,
            "divergences": self.divergences,
            "notes": self.notes,
            "records": [r.to_dict() for r in self.records],
        }


def reconcile(records: list[BibliographicRecord]) -> list[ReconciliationResult]:
    """Group records by persistent identity (DOI preferred, then PMID).

    Records are never merged by title similarity. A preprint (posted-content) and
    a published article keep their own identities even when related.
    """
    groups: dict[tuple[str, str], list[BibliographicRecord]] = {}
    for record in records:
        groups.setdefault(record.identity(), []).append(record)

    results: list[ReconciliationResult] = []
    for identity, group in groups.items():
        providers = {r.provider for r in group}
        if len(providers) < 2:
            status = BibliographicVerification.VERIFIED if group[0].doi or group[0].pmid else BibliographicVerification.PENDING
            results.append(ReconciliationResult(identity=identity, records=group, status=status))
            continue

        divergences: dict[str, dict[str, Any]] = {}
        for field_name in _COMPARE_FIELDS:
            values = {}
            for record in group:
                raw = getattr(record, field_name)
                values[record.provider] = _NORMALIZERS[field_name](raw)
            if len(set(values.values())) > 1:
                divergences[field_name] = values

        status = BibliographicVerification.CONFLICT if divergences else BibliographicVerification.VERIFIED
        notes = []
        if any(r.is_preprint for r in group):
            notes.append("Group includes a preprint; preprint and article identities kept separate.")
        results.append(
            ReconciliationResult(
                identity=identity,
                records=group,
                divergences=divergences,
                status=status,
                notes=notes,
            )
        )
    return results
