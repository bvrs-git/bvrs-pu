"""Normalized bibliographic records and identifier handling."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

PROCESSING_VERSION = "r2b-1"

_DOI_PREFIX_RE = re.compile(r"^\s*(https?://(dx\.)?doi\.org/|doi:\s*)", re.IGNORECASE)


def normalize_doi(value: str | None) -> str | None:
    """Normalize a DOI to lowercase bare form (no URL prefix)."""
    if not value:
        return None
    text = _DOI_PREFIX_RE.sub("", value.strip())
    return text.lower() or None


def normalize_pmid(value: str | None) -> str | None:
    if not value:
        return None
    text = str(value).strip()
    return text or None


def content_sha256(payload: Any) -> str:
    import json

    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode("utf-8")).hexdigest()


@dataclass
class BibliographicRecord:
    """A single provider record, normalized and provenance-tagged."""

    provider: str
    provider_record_id: str
    endpoint: str
    request_params: dict[str, Any] = field(default_factory=dict)
    queried_at: datetime | None = None
    doi: str | None = None
    pmid: str | None = None
    title: str | None = None
    authors: tuple[str, ...] = ()
    journal: str | None = None
    issn: tuple[str, ...] = ()
    year: int | None = None
    publication_type: str | None = None
    url: str | None = None
    related: dict[str, list[str]] = field(default_factory=dict)
    editorial_notes: tuple[str, ...] = ()
    raw: dict[str, Any] = field(default_factory=dict)
    payload_sha256: str = ""
    processing_version: str = PROCESSING_VERSION

    def __post_init__(self) -> None:
        self.doi = normalize_doi(self.doi)
        self.pmid = normalize_pmid(self.pmid)
        if not self.payload_sha256:
            self.payload_sha256 = content_sha256(self.raw or {"id": self.provider_record_id})

    @property
    def is_preprint(self) -> bool:
        ptype = (self.publication_type or "").lower()
        return "posted-content" in ptype or "preprint" in ptype

    def identity(self) -> tuple[str, str]:
        """Persistent identifier used for reconciliation (DOI preferred)."""
        if self.doi:
            return ("doi", self.doi)
        if self.pmid:
            return ("pmid", self.pmid)
        return (self.provider, self.provider_record_id)

    def sanitized_params(self) -> dict[str, Any]:
        """Request params with any secret-like value removed."""
        cleaned: dict[str, Any] = {}
        for key, value in self.request_params.items():
            if any(token in key.lower() for token in ("key", "token", "secret", "mail", "email", "password")):
                cleaned[key] = "<redacted>"
            else:
                cleaned[key] = value
        return cleaned

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BibliographicRecord":
        from ..core.timeutil import parse_dt

        return cls(
            provider=data["provider"],
            provider_record_id=data.get("provider_record_id", ""),
            endpoint=data.get("endpoint", ""),
            request_params=dict(data.get("request_params", {})),
            queried_at=parse_dt(data.get("queried_at")),
            doi=data.get("doi"),
            pmid=data.get("pmid"),
            title=data.get("title"),
            authors=tuple(data.get("authors", ())),
            journal=data.get("journal"),
            issn=tuple(data.get("issn", ())),
            year=data.get("year"),
            publication_type=data.get("publication_type"),
            url=data.get("url"),
            related=dict(data.get("related", {})),
            editorial_notes=tuple(data.get("editorial_notes", ())),
            raw=dict(data.get("raw", {})),
            payload_sha256=data.get("payload_sha256", ""),
            processing_version=data.get("processing_version", PROCESSING_VERSION),
        )
