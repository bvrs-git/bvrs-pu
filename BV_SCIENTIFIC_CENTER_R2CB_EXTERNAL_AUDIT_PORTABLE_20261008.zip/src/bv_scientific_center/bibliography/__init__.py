"""Bibliographic acquisition adapters (Crossref, PubMed) — offline-first.

The adapters never fabricate metadata: they normalize exactly what a provider
returns and record the provenance of every acquisition. Network access goes
through an injected transport, so automated tests use frozen fixtures and never
depend on Crossref/PubMed availability.
"""

from .models import BibliographicRecord, normalize_doi, normalize_pmid
from .transport import (
    HttpTransport,
    HttpResponse,
    HttpStatusError,
    RateLimited,
    RateLimiter,
    RetryPolicy,
    UrllibTransport,
)

__all__ = [
    "BibliographicRecord",
    "normalize_doi",
    "normalize_pmid",
    "HttpTransport",
    "HttpResponse",
    "HttpStatusError",
    "RateLimited",
    "RateLimiter",
    "RetryPolicy",
    "UrllibTransport",
]
