"""Offline cache for bibliographic responses (enables offline consultation)."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from ..core.timeutil import now_utc, to_iso
from ..storage.database import Database
from .transport import HttpResponse


def cache_key(provider: str, endpoint: str, params: dict | None) -> str:
    payload = json.dumps(
        {"provider": provider, "endpoint": endpoint, "params": params or {}}, sort_keys=True
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class BibliographyCache:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.knowledge

    def get(self, provider: str, endpoint: str, params: dict | None = None) -> HttpResponse | None:
        key = cache_key(provider, endpoint, params)
        row = self.conn.execute(
            "SELECT * FROM bibliography_cache WHERE cache_key = ?", (key,)
        ).fetchone()
        if row is None:
            return None
        return HttpResponse(
            status=row["status_code"] or 200,
            url=endpoint,
            headers={},
            body=(row["response_json"] or "").encode("utf-8"),
        )

    def put(self, provider: str, endpoint: str, params: dict | None, response: HttpResponse) -> None:
        key = cache_key(provider, endpoint, params)
        digest = hashlib.sha256(response.body).hexdigest()
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO bibliography_cache (
                    cache_key, provider, request_json, response_json, response_sha256,
                    status_code, created_at
                ) VALUES (?,?,?,?,?,?,?)
                """,
                (
                    key,
                    provider,
                    json.dumps({"endpoint": endpoint, "params": params or {}}, sort_keys=True),
                    response.body.decode("utf-8", errors="replace"),
                    digest,
                    response.status,
                    to_iso(now_utc()),
                ),
            )
            self.conn.commit()

    def count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) AS c FROM bibliography_cache").fetchone()["c"]

    def freshness(
        self, provider: str, endpoint: str, params: dict | None = None, *, ttl_seconds: int = 86400
    ) -> str:
        """Return FRESH / EXPIRED / UNKNOWN for a cached entry (never deletes it)."""
        from ..core.timeutil import parse_dt
        from datetime import timezone

        key = cache_key(provider, endpoint, params)
        row = self.conn.execute(
            "SELECT created_at FROM bibliography_cache WHERE cache_key = ?", (key,)
        ).fetchone()
        if row is None or not row["created_at"]:
            return "UNKNOWN"
        age = (now_utc() - parse_dt(row["created_at"])).total_seconds()
        return "FRESH" if age <= ttl_seconds else "EXPIRED"

    def entries(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT cache_key, provider, response_sha256, status_code, created_at FROM bibliography_cache"
        ).fetchall()
        return [dict(row) for row in rows]
