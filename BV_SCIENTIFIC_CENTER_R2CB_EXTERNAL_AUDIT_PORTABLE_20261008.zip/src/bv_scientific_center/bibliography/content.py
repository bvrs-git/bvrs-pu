"""Content availability, licensing and storage decisions (R2C-B GATE 1/2).

Availability of access is NOT the same as permission to store or redistribute the
full text. Only metadata, locators, minimal permitted excerpts and (for
permissive licenses) versioned snapshots are stored.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core.enums import ContentAvailability, ContentType

# Licenses that permit internal storage of a snapshot; redistribution is stricter.
_PERMISSIVE_PREFIXES = ("cc by", "cc0", "cc-by", "public domain")
_REDISTRIBUTABLE_PREFIXES = ("cc by", "cc0", "cc-by", "public domain")
# Redistribution-restricting suffixes a permissive license may still carry.
_RESTRICTIVE_SUFFIXES = ("-nc", "-nd", " nc", " nd", "noncommercial", "non-commercial")


def classify_license(license_value: str | None) -> tuple[bool, bool, str]:
    """Return (storage_permitted, redistribution_permitted, note).

    Internal storage and public redistribution are distinct permissions. A
    ``cc by-nc`` / ``cc by-nd`` license allows storage but forbids redistribution.
    """
    if not license_value:
        return False, False, "license unknown: snapshot not stored"
    normalized = license_value.strip().lower()
    storage = any(normalized.startswith(p) for p in _PERMISSIVE_PREFIXES)
    restricts = any(suffix in normalized for suffix in _RESTRICTIVE_SUFFIXES)
    redistribution = (
        any(normalized.startswith(p) for p in _REDISTRIBUTABLE_PREFIXES) and not restricts
    )
    if storage:
        note = f"license {license_value!r} permits internal storage"
        if not redistribution:
            note += "; redistribution restricted (non-commercial / no-derivatives)"
    else:
        note = f"license {license_value!r} does not permit storing the full text"
    return storage, redistribution, note


def decide_availability(
    *,
    abstract: str | None,
    is_open_access: str | None,
    in_pmc: str | None,
    license_value: str | None,
    has_full_text_urls: bool,
) -> tuple[ContentAvailability, str]:
    open_access = (is_open_access or "").upper() == "Y"
    in_pmc_flag = (in_pmc or "").upper() == "Y"
    if open_access and in_pmc_flag:
        storage, redistribution, _ = classify_license(license_value)
        if storage:
            return ContentAvailability.FULL_TEXT_REUSE_PERMITTED, "open access with permissive license"
        return ContentAvailability.FULL_TEXT_LICENSE_UNKNOWN, "open access but license not permissive/known"
    if has_full_text_urls and not open_access:
        if abstract:
            return ContentAvailability.FULL_TEXT_ACCESS_RESTRICTED, "full text restricted; abstract available"
        return ContentAvailability.FULL_TEXT_ACCESS_RESTRICTED, "full text restricted"
    if abstract:
        return ContentAvailability.ABSTRACT_AVAILABLE, "abstract available"
    return ContentAvailability.SOURCE_UNAVAILABLE, "no abstract or full text available"


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass
class ContentSnapshot:
    content_id: str
    reference_id: str
    source: str
    endpoint: str
    queried_at: datetime | None
    content_type: ContentType
    identifiers: dict[str, Any] = field(default_factory=dict)
    source_version: str | None = None
    sha256: str = ""
    license: str | None = None
    availability: ContentAvailability = ContentAvailability.SOURCE_UNAVAILABLE
    storage_permitted: bool = False
    storage_note: str = ""
    locator: str | None = None
    text: str | None = None

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        payload = dump(self)
        if self.text and not self.storage_permitted:
            payload["text"] = None
            payload["storage_note"] = (payload.get("storage_note") or "") + "; text withheld (license)"
        return payload
