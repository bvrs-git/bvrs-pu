"""NCBI PubMed E-utilities adapter (esearch / esummary / efetch)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from ..core.timeutil import now_utc
from .cache import BibliographyCache
from .models import BibliographicRecord
from .transport import HttpTransport

PROVIDER = "PUBMED"
BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"

# Publication types that indicate an editorial alert.
_RETRACTION_TYPES = {"retracted publication", "retraction of publication"}
_CORRECTION_TYPES = {"published erratum", "corrected and republished article", "correction"}


def _year(pubdate: str | None) -> int | None:
    if not pubdate:
        return None
    token = pubdate.strip().split(" ")[0]
    return int(token) if token.isdigit() else None


def parse_summary(item: dict[str, Any], *, endpoint: str, params: dict, queried_at: datetime) -> BibliographicRecord:
    uids = item.get("uids") or []
    pmid = (uids[0] if uids else str(item.get("uid", ""))).split(";")[0].strip()
    authors = tuple(author.get("name", "") for author in item.get("authors", []) if author.get("name"))
    doi = None
    for article_id in item.get("articleids", []) or []:
        if article_id.get("idtype") == "doi":
            doi = article_id.get("value")
            break
    if doi is None:
        for article_id in item.get("articleids", []) or []:
            if article_id.get("idtype") == "elocationid" and "10." in str(article_id.get("value", "")):
                doi = article_id.get("value")
                break
    pubtypes = tuple(item.get("pubtype", []) or [])
    notes: list[str] = []
    lowered = {p.lower() for p in pubtypes}
    for label in pubtypes:
        low = label.lower()
        if low in _RETRACTION_TYPES or low in _CORRECTION_TYPES:
            notes.append(f"pubtype: {label}")
    related: dict[str, list[str]] = {}
    if lowered & _RETRACTION_TYPES:
        related["retraction"] = []
    if lowered & _CORRECTION_TYPES:
        related["correction"] = []

    return BibliographicRecord(
        provider=PROVIDER,
        provider_record_id=pmid,
        endpoint=endpoint,
        request_params=params,
        queried_at=queried_at,
        doi=doi,
        pmid=pmid or None,
        title=item.get("title"),
        authors=authors,
        journal=item.get("fulljournalname") or item.get("source"),
        issn=tuple(item.get("issn", []) or []),
        year=_year(item.get("pubdate")),
        publication_type="; ".join(pubtypes) if pubtypes else None,
        url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/" if pmid else None,
        related=related,
        editorial_notes=tuple(notes),
        raw=item,
    )


class PubMedAdapter:
    def __init__(
        self,
        transport: HttpTransport,
        *,
        cache: BibliographyCache | None = None,
        api_key: str | None = None,
        base_url: str = BASE_URL,
        retmax: int = 5,
    ) -> None:
        self.transport = transport
        self.cache = cache
        self.api_key = api_key
        self.base_url = base_url
        self.retmax = retmax

    def _get(self, tool: str, params: dict[str, Any]) -> dict[str, Any]:
        endpoint = f"{self.base_url}/{tool}.fcgi"
        params = dict(params)
        params.setdefault("retmode", "json")
        if self.api_key:
            params["api_key"] = self.api_key
        if self.cache is not None:
            cached = self.cache.get(PROVIDER, endpoint, params)
            if cached is not None:
                return cached.json()
        response = self.transport.get(endpoint, params)
        if self.cache is not None:
            self.cache.put(PROVIDER, endpoint, params, response)
        return response.json()

    def esearch(self, term: str, *, retmax: int | None = None) -> list[str]:
        data = self._get(
            "esearch",
            {"db": "pubmed", "term": term, "retmax": retmax or self.retmax},
        )
        result = data.get("esearchresult") or {}
        return [str(uid) for uid in result.get("idlist", [])]

    def esummary(self, pmids: list[str]) -> list[BibliographicRecord]:
        if not pmids:
            return []
        endpoint = f"{self.base_url}/esummary.fcgi"
        data = self._get("esummary", {"db": "pubmed", "id": ",".join(pmids)})
        result = data.get("result") or {}
        records = []
        for uid in result.get("uids", []):
            item = result.get(uid)
            if item:
                records.append(
                    parse_summary(
                        item, endpoint=endpoint, params={"id": uid}, queried_at=now_utc()
                    )
                )
        return records

    def fetch_by_pmid(self, pmid: str) -> BibliographicRecord | None:
        records = self.esummary([str(pmid)])
        return records[0] if records else None

    def fetch_by_doi(self, doi: str) -> BibliographicRecord | None:
        pmids = self.esearch(f"{doi}[DOI]")
        return self.fetch_by_pmid(pmids[0]) if pmids else None

    def search(self, term: str, *, retmax: int | None = None) -> list[BibliographicRecord]:
        return self.esummary(self.esearch(term, retmax=retmax))
