"""Initial controlled biomedical corpus (R2B GATE 4).

Scope: anthropometry, body composition and nutritional assessment. The corpus is
defined by explicit subdomain queries and inclusion/exclusion criteria. Records
are acquired from real providers (Crossref/PubMed) and frozen into a JSON
snapshot with provenance; the snapshot is what tests and offline use consume, so
the suite never depends on provider availability.

No cutoff value or equation is imported for clinical execution. Population
contexts (adult, pediatric, pregnant, athletes, clinical conditions) are recorded,
when available, as metadata only.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import BibliographicRecord
from .service import BibliographyService

DEFAULT_CORPUS_PATH = "data/seed/corpus_bibliography.json"

# Subdomain -> Crossref bibliographic query. Chosen for topical relevance, not
# popularity.
CORPUS_QUERIES: dict[str, str] = {
    "BMI_DEFINITION_USE": "body mass index definition classification limitations",
    "WAIST_ANTHROPOMETRY": "waist circumference waist-to-height ratio anthropometric measurement",
    "FAT_MASS_INDEX": "fat mass index reference values",
    "FAT_FREE_MASS_INDEX": "fat-free mass index reference values",
    "BIOIMPEDANCE_PRINCIPLES": "bioelectrical impedance analysis body composition validity limitations",
    "LONGITUDINAL_BODY_COMPOSITION": "longitudinal change body composition follow-up",
}

INCLUSION_CRITERIA = (
    "Relevant to anthropometry, body composition or nutritional assessment.",
    "Journal article, review meta-analysis/guideline or instrument validation.",
    "Provides methodological, definitional or reference-value content.",
)

EXCLUSION_CRITERIA = (
    "Not selected by popularity or citation count.",
    "Cannot be imported automatically as a clinical cutoff or equation.",
    "Preprints kept with their own identity; not merged with the published article.",
)

POPULATION_NOTE = (
    "Population contexts (adult, pediatric, pregnant, athletes, clinical "
    "conditions) are recorded as metadata only and never imported as cutoff values."
)


def acquire_corpus(
    crossref,
    path: str | Path = DEFAULT_CORPUS_PATH,
    *,
    rows: int = 3,
    subdomains: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Fetch records for each subdomain and freeze them into a JSON snapshot."""
    subdomains = subdomains or CORPUS_QUERIES
    records_by_identity: dict[tuple[str, str], BibliographicRecord] = {}
    queries: list[dict[str, Any]] = []
    for subdomain, query in subdomains.items():
        try:
            found = crossref.search(query, rows=rows, type_filter="journal-article")
        except Exception as exc:  # noqa: BLE001
            queries.append({"subdomain": subdomain, "query": query, "error": str(exc)})
            continue
        kept = 0
        for record in found:
            identity = record.identity()
            if identity in records_by_identity:
                continue
            if not record.doi:
                continue
            records_by_identity[identity] = record
            kept += 1
        queries.append({"subdomain": subdomain, "query": query, "kept": kept})

    snapshot = {
        "generated_at": _now(),
        "provider": "CROSSREF",
        "domain": "ANTHROPOMETRY_BODY_COMPOSITION_NUTRITION",
        "inclusion_criteria": list(INCLUSION_CRITERIA),
        "exclusion_criteria": list(EXCLUSION_CRITERIA),
        "population_note": POPULATION_NOTE,
        "queries": queries,
        "records": [record.to_dict() for record in records_by_identity.values()],
    }
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    return {
        "path": str(path),
        "records": len(records_by_identity),
        "subdomains": len(subdomains),
    }


def load_corpus(path: str | Path = DEFAULT_CORPUS_PATH) -> tuple[dict[str, Any], list[BibliographicRecord]]:
    path = Path(path)
    snapshot = json.loads(path.read_text(encoding="utf-8"))
    records = [BibliographicRecord.from_dict(item) for item in snapshot.get("records", [])]
    return snapshot, records


def import_corpus(app, path: str | Path = DEFAULT_CORPUS_PATH) -> dict[str, Any]:
    """Import a frozen corpus offline (idempotent; never approves anything)."""
    snapshot, records = load_corpus(path)
    imported = 0
    for record in records:
        app.bibliography.import_record(record)
        imported += 1
    return {
        "path": str(path),
        "imported": imported,
        "subdomains": len(snapshot.get("queries", [])),
        "domain": snapshot.get("domain"),
    }


def _now() -> str:
    from ..core.timeutil import now_utc, to_iso

    return to_iso(now_utc())
