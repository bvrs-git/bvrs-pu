"""Bibliographic acquisition service: fetch, reconcile, persist with provenance.

Distinguishes the four independent operations:

1. identify a publication; 2. verify its metadata; 3. critically appraise its
content; 4. explicitly approve clinical use. None implies another.
"""

from __future__ import annotations

from typing import Any

from ..core import ids
from ..core.enums import (
    BibliographicVerification,
    ContentAvailability,
    ContentReviewStatus,
    ContentType,
    EditorialAlertType,
    KnowledgeOrigin,
)
from ..core.timeutil import now_utc
from ..knowledge.bibliographic_repository import (
    AcquisitionRepository,
    AppraisalRepository,
    EditorialAlertRepository,
)
from ..knowledge.content_repository import AcquiredContentRepository
from ..knowledge.scientific import (
    MetadataSource,
    PublicationType,
    ScientificReference,
    VerificationStatus,
)
from ..knowledge.scientific_repository import ScientificReferenceRepository
from .content import ContentSnapshot, classify_license, decide_availability, sha256_text
from .crossref import CrossrefAdapter
from .europepmc import EuropePmcAdapter, extract_content_fields
from .models import BibliographicRecord, normalize_doi
from .pubmed import PubMedAdapter
from .reconcile import reconcile

_TYPE_MAP = {
    "journal-article": PublicationType.JOURNAL_ARTICLE,
    "posted-content": PublicationType.PREPRINT,
    "proceedings-article": PublicationType.JOURNAL_ARTICLE,
    "book-chapter": PublicationType.BOOK,
    "book": PublicationType.BOOK,
    "report": PublicationType.REPORT,
    "guideline": PublicationType.CLINICAL_GUIDELINE,
    "dataset": PublicationType.DATASET,
}


def map_publication_type(record: BibliographicRecord) -> PublicationType:
    raw = (record.publication_type or "").lower()
    if record.is_preprint:
        return PublicationType.PREPRINT
    for token, value in _TYPE_MAP.items():
        if token in raw:
            return value
    if "guideline" in raw or "practice guideline" in raw:
        return PublicationType.CLINICAL_GUIDELINE
    if "consensus" in raw:
        return PublicationType.CONSENSUS_STATEMENT
    if "academic journal" in raw:
        return PublicationType.JOURNAL_ARTICLE
    return PublicationType.OTHER


def reference_id_for(record: BibliographicRecord) -> str:
    if record.doi:
        return ids.stable_id("REF-DOI", record.doi)
    if record.pmid:
        return ids.stable_id("REF-PMID", record.pmid)
    return ids.stable_id("REF", record.provider, record.provider_record_id)


def content_id_for(
    reference_id: str,
    content_type: str,
    sha256: str,
    availability: str,
    locator: str | None,
) -> str:
    """Stable content identity: re-ingesting identical content is idempotent.

    A genuinely changed source (different SHA-256) yields a new id, so history is
    preserved rather than silently overwritten.
    """
    return ids.stable_id(
        "content", reference_id, content_type, sha256 or "", availability, locator or ""
    )


def record_to_reference(
    record: BibliographicRecord,
    *,
    bibliographic_status: BibliographicVerification = BibliographicVerification.VERIFIED,
    reference_id: str | None = None,
) -> ScientificReference:
    source = MetadataSource.CROSSREF if record.provider == "CROSSREF" else MetadataSource.PUBMED
    return ScientificReference(
        reference_id=reference_id or reference_id_for(record),
        title=record.title or "(title unavailable)",
        authors=record.authors,
        publication_year=record.year,
        venue=record.journal,
        publication_type=map_publication_type(record),
        doi=record.doi,
        pmid=record.pmid,
        issn=record.issn,
        url=record.url,
        accessed_at=record.queried_at or now_utc(),
        metadata_source=source,
        verification_status=VerificationStatus.VERIFIED,
        bibliographic_status=bibliographic_status,
        content_review_status=ContentReviewStatus.NOT_REVIEWED,
        last_checked_at=record.queried_at or now_utc(),
        origin=KnowledgeOrigin.IMPORTED,
        notes=f"Acquired from {record.provider}; payload {record.payload_sha256[:16]}.",
    )


class BibliographyService:
    def __init__(
        self,
        *,
        references: ScientificReferenceRepository,
        acquisitions: AcquisitionRepository,
        alerts: EditorialAlertRepository,
        appraisals: AppraisalRepository,
        crossref: CrossrefAdapter | None = None,
        pubmed: PubMedAdapter | None = None,
        europepmc: EuropePmcAdapter | None = None,
        content: AcquiredContentRepository | None = None,
    ) -> None:
        self.references = references
        self.acquisitions = acquisitions
        self.alerts = alerts
        self.appraisals = appraisals
        self.crossref = crossref
        self.pubmed = pubmed
        self.europepmc = europepmc
        self.content = content
    def acquire_by_doi(self, doi: str) -> dict[str, Any]:
        """Acquire by DOI from available providers, reconcile and import."""
        records: list[BibliographicRecord] = []
        crossref_record = None
        pubmed_record = None
        if self.crossref is not None:
            crossref_record = self.crossref.fetch_by_doi(doi)
            if crossref_record:
                records.append(crossref_record)
        if self.pubmed is not None:
            try:
                pubmed_record = self.pubmed.fetch_by_doi(doi)
            except Exception:
                pubmed_record = None
            if pubmed_record:
                records.append(pubmed_record)

        if not records:
            return {"doi": doi, "status": BibliographicVerification.UNAVAILABLE.value, "imported": False}

        results = reconcile(records)
        result = results[0] if results else None
        status = result.status if result else BibliographicVerification.PENDING
        divergences = result.divergences if result else {}

        primary = crossref_record or pubmed_record
        assert primary is not None
        reference_id = reference_id_for(primary)
        reference = record_to_reference(primary, bibliographic_status=status, reference_id=reference_id)

        # Idempotent import with conflict detection.
        imported = self.references.ingest(reference)

        # Provenance for every provider record.
        for record in records:
            self.acquisitions.append(
                reference_id=reference_id,
                provider=record.provider,
                endpoint=record.endpoint,
                params=record.sanitized_params(),
                queried_at=record.queried_at,
                record_identity=record.provider_record_id,
                identifiers={
                    "doi": record.doi,
                    "pmid": record.pmid,
                    "issn": list(record.issn),
                    "original_doi": record.raw.get("DOI") if isinstance(record.raw, dict) else None,
                },
                payload_sha256=record.payload_sha256,
                processing_version=record.processing_version,
                verification_status=status.value,
                divergences=divergences if record.provider == primary.provider else {},
            )
            self._detect_editorial_alerts(reference_id, record)

        return {
            "doi": doi,
            "reference_id": reference_id,
            "status": status.value,
            "providers": [r.provider for r in records],
            "divergences": divergences,
            "imported": True,
            "curation_status": imported.curation_status.value,
        }

    def import_record(
        self,
        record: BibliographicRecord,
        *,
        bibliographic_status: BibliographicVerification = BibliographicVerification.VERIFIED,
        divergences: dict[str, Any] | None = None,
    ) -> ScientificReference:
        reference_id = reference_id_for(record)
        reference = record_to_reference(record, bibliographic_status=bibliographic_status, reference_id=reference_id)
        imported = self.references.ingest(reference)
        self.acquisitions.append(
            reference_id=reference_id,
            provider=record.provider,
            endpoint=record.endpoint,
            params=record.sanitized_params(),
            queried_at=record.queried_at,
            record_identity=record.provider_record_id,
            identifiers={"doi": record.doi, "pmid": record.pmid, "issn": list(record.issn)},
            payload_sha256=record.payload_sha256,
            processing_version=record.processing_version,
            verification_status=bibliographic_status.value,
            divergences=divergences or {},
        )
        self._detect_editorial_alerts(reference_id, record)
        return imported

    # -- editorial alerts (GATE 6) ----------------------------------------
    def _detect_editorial_alerts(self, reference_id: str, record: BibliographicRecord) -> None:
        for note in record.editorial_notes:
            lowered = note.lower()
            if "retract" in lowered:
                alert_type = EditorialAlertType.RETRACTION
                is_retraction = True
            elif "erratum" in lowered:
                alert_type = EditorialAlertType.ERRATUM
                is_retraction = False
            elif "correct" in lowered:
                alert_type = EditorialAlertType.CORRECTION
                is_retraction = False
            elif "concern" in lowered:
                alert_type = EditorialAlertType.EXPRESSION_OF_CONCERN
                is_retraction = False
            else:
                continue
            self.alerts.add(
                reference_id=reference_id,
                alert_type=alert_type.value,
                source=record.provider,
                details=note,
                is_retraction=is_retraction,
                detected_at=record.queried_at,
            )

    def check_editorial(self, reference_id: str) -> list[dict[str, Any]]:
        """Re-check the provider for editorial notices and record any alerts."""
        reference = self.references.get(reference_id)
        if reference is None:
            raise KeyError(reference_id)
        detected: list[dict[str, Any]] = []
        reloaded = None
        if self.crossref is not None and reference.doi:
            try:
                reloaded = self.crossref.fetch_by_doi(reference.doi)
            except Exception:
                reloaded = None
        if reloaded is None and self.pubmed is not None and (reference.pmid or reference.doi):
            try:
                reloaded = (
                    self.pubmed.fetch_by_pmid(reference.pmid)
                    if reference.pmid
                    else self.pubmed.fetch_by_doi(reference.doi)
                )
            except Exception:
                reloaded = None
        if reloaded is None:
            # Offline: preserve last known state, flag unverifiable currency.
            self.alerts.add(
                reference_id=reference_id,
                alert_type=EditorialAlertType.EXPRESSION_OF_CONCERN.value,
                source="LOCAL",
                details="Provider unavailable: currency could not be verified.",
                is_retraction=False,
            )
            return self.alerts.for_reference(reference_id)
        self._detect_editorial_alerts(reference_id, reloaded)
        return self.alerts.for_reference(reference_id)

    def is_clinically_usable(self, reference_id: str) -> bool:
        """Approved AND free of a known retraction alert."""
        reference = self.references.get(reference_id)
        if reference is None:
            return False
        from ..knowledge.scientific import is_clinically_usable

        if not is_clinically_usable(reference.curation_status):
            return False
        return not self.alerts.has_retraction(reference_id)

    def retraction_impacts(self, reference_id: str) -> dict[str, Any]:
        evidence_ids = [
            e.evidence_id for e in self._all_evidence() if reference_id in e.reference_ids
        ]
        return {
            "reference_id": reference_id,
            "has_retraction": self.alerts.has_retraction(reference_id),
            "evidence_ids": evidence_ids,
            "alerts": self.alerts.for_reference(reference_id),
        }

    # -- appraisal (GATE 5) -----------------------------------------------
    def record_appraisal(self, appraisal: dict[str, Any]) -> str:
        return self.appraisals.save(appraisal)

    def appraisals_for(self, reference_id: str) -> list[dict[str, Any]]:
        return self.appraisals.for_reference(reference_id)

    def acquire_content(
        self,
        reference_id: str,
        *,
        doi: str | None = None,
        pmid: str | None = None,
    ) -> list[ContentSnapshot]:
        """Acquire abstract/full-text availability for a reference (Europe PMC).

        Identifiers are verified before content is associated; mismatches are
        recorded as SOURCE_UNAVAILABLE and never linked to the reference.
        """
        if self.europepmc is None or self.content is None:
            return []
        reference = self.references.get(reference_id)
        requested_doi = normalize_doi(doi or (reference.doi if reference else None))
        requested_pmid = pmid or (reference.pmid if reference else None)

        fetched = None
        if requested_doi:
            fetched = self.europepmc.fetch_by_doi(requested_doi)
        if fetched is None and requested_pmid:
            fetched = self.europepmc.fetch_by_pmid(requested_pmid)

        if fetched is None:
            snapshot = ContentSnapshot(
                content_id=content_id_for(
                    reference_id, ContentType.ABSTRACT.value, "", ContentAvailability.SOURCE_UNAVAILABLE.value, None
                ),
                reference_id=reference_id,
                source="EUROPEPMC",
                endpoint="",
                queried_at=now_utc(),
                content_type=ContentType.ABSTRACT,
                availability=ContentAvailability.SOURCE_UNAVAILABLE,
                storage_note="source unavailable or not found",
            )
            self.content.save(snapshot)
            return [snapshot]

        item, record = fetched
        # Verify identifiers before associating content (never by title only).
        if requested_doi and normalize_doi(record.doi) != requested_doi:
            snapshot = ContentSnapshot(
                content_id=content_id_for(
                    reference_id, ContentType.ABSTRACT.value, "", ContentAvailability.SOURCE_UNAVAILABLE.value, None
                ),
                reference_id=reference_id,
                source="EUROPEPMC",
                endpoint=record.endpoint,
                queried_at=record.queried_at,
                content_type=ContentType.ABSTRACT,
                availability=ContentAvailability.SOURCE_UNAVAILABLE,
                storage_note=(
                    f"identifier mismatch: requested DOI {requested_doi!r} but source returned "
                    f"{record.doi!r}; content not associated"
                ),
            )
            self.content.save(snapshot)
            return [snapshot]

        fields = extract_content_fields(item)
        availability, availability_note = decide_availability(
            abstract=fields["abstract"],
            is_open_access=fields["is_open_access"],
            in_pmc=fields["in_pmc"],
            license_value=fields["license"],
            has_full_text_urls=bool(fields["full_text_urls"]),
        )
        storage, redistribution, license_note = classify_license(fields["license"])
        identifiers = {
            "doi": normalize_doi(record.doi),
            "pmid": record.pmid,
            "pmcid": fields["pmcid"],
        }
        snapshots: list[ContentSnapshot] = []

        abstract = fields["abstract"]
        if abstract:
            abstract_sha = sha256_text(abstract)
            snapshots.append(
                ContentSnapshot(
                    content_id=content_id_for(
                        reference_id, ContentType.ABSTRACT.value, abstract_sha, availability.value, "abstract"
                    ),
                    reference_id=reference_id,
                    source="EUROPEPMC",
                    endpoint=record.endpoint,
                    queried_at=record.queried_at,
                    content_type=ContentType.ABSTRACT,
                    identifiers=identifiers,
                    source_version=str(fields.get("date_of_revision") or ""),
                    sha256=abstract_sha,
                    license=fields["license"],
                    availability=availability,
                    storage_permitted=True,
                    storage_note=(
                        "abstract stored for internal annotation (not for redistribution); "
                        + availability_note
                    ),
                    locator="abstract",
                    text=abstract,
                )
            )

        if availability is ContentAvailability.FULL_TEXT_REUSE_PERMITTED and fields["pmcid"]:
            xml = self.europepmc.full_text_xml(fields["pmcid"])
            if xml:
                fulltext_locator = f"fullTextXML:{fields['pmcid']}"
                xml_sha = sha256_text(xml)
                snapshots.append(
                    ContentSnapshot(
                        content_id=content_id_for(
                            reference_id,
                            ContentType.FULL_TEXT_XML.value,
                            xml_sha,
                            ContentAvailability.FULL_TEXT_REUSE_PERMITTED.value,
                            fulltext_locator,
                        ),
                        reference_id=reference_id,
                        source="EUROPEPMC",
                        endpoint=record.endpoint,
                        queried_at=record.queried_at,
                        content_type=ContentType.FULL_TEXT_XML,
                        identifiers=identifiers,
                        source_version=str(fields.get("date_of_revision") or ""),
                        sha256=xml_sha,
                        license=fields["license"],
                        availability=ContentAvailability.FULL_TEXT_REUSE_PERMITTED,
                        storage_permitted=storage,
                        storage_note=license_note,
                        locator=fulltext_locator,
                        text=xml if storage else None,
                    )
                )

        if not snapshots:
            snapshots.append(
                ContentSnapshot(
                    content_id=content_id_for(
                        reference_id, ContentType.ABSTRACT.value, "", availability.value, None
                    ),
                    reference_id=reference_id,
                    source="EUROPEPMC",
                    endpoint=record.endpoint,
                    queried_at=record.queried_at,
                    content_type=ContentType.ABSTRACT,
                    identifiers=identifiers,
                    license=fields["license"],
                    availability=availability,
                    storage_note=availability_note,
                )
            )

        for snapshot in snapshots:
            self.content.save(snapshot)
        return snapshots

    # -- acquisition -------------------------------------------------------
    def _all_evidence(self):
        # Evidence listing is provided lazily to avoid a hard dependency cycle.
        repo = getattr(self, "_evidence_repo", None)
        return repo.list() if repo is not None else []

    def bind_evidence_repository(self, repo) -> None:
        self._evidence_repo = repo
