"""Crossref REST API adapter (normalizes exactly what Crossref returns)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from ..core.timeutil import now_utc
from .cache import BibliographyCache
from .models import BibliographicRecord
from .transport import HttpTransport

PROVIDER = "CROSSREF"
BASE_URL = "https://api.crossref.org"


def _authors(message: dict[str, Any]) -> tuple[str, ...]:
    names: list[str] = []
    for author in message.get("author", []) or []:
        family = author.get("family")
        given = author.get("given")
        literal = author.get("name")
        if family and given:
            names.append(f"{family}, {given}")
        elif family:
            names.append(family)
        elif literal:
            names.append(literal)
    return tuple(names)


def _year(message: dict[str, Any]) -> int | None:
    for key in ("issued", "published-print", "published-online", "created"):
        parts = (message.get(key) or {}).get("date-parts")
        if parts and parts[0] and parts[0][0]:
            return int(parts[0][0])
    return None


def _editorial(message: dict[str, Any]) -> tuple[tuple[str, ...], dict[str, list[str]]]:
    notes: list[str] = []
    related: dict[str, list[str]] = {}
    for update in message.get("update-to", []) or []:
        update_type = update.get("type", "update")
        doi = update.get("DOI")
        if doi:
            related.setdefault(update_type, []).append(doi.lower())
        notes.append(f"{update_type}: {doi}")
    for update in message.get("updated-by", []) or []:
        update_type = update.get("type", "update")
        doi = update.get("DOI")
        if doi:
            related.setdefault(f"updated-by:{update_type}", []).append(doi.lower())
        notes.append(f"updated-by {update_type}: {doi}")
    for relation, items in (message.get("relation") or {}).items():
        for item in items:
            if item.get("id-type") == "doi" and item.get("id"):
                related.setdefault(relation, []).append(item["id"].lower())
    return tuple(notes), related


def parse_work(message: dict[str, Any], *, endpoint: str, params: dict, queried_at: datetime) -> BibliographicRecord:
    doi = message.get("DOI")
    titles = message.get("title") or []
    containers = message.get("container-title") or []
    notes, related = _editorial(message)
    return BibliographicRecord(
        provider=PROVIDER,
        provider_record_id=doi or "",
        endpoint=endpoint,
        request_params=params,
        queried_at=queried_at,
        doi=doi,
        title=titles[0] if titles else None,
        authors=_authors(message),
        journal=containers[0] if containers else None,
        issn=tuple(message.get("ISSN", []) or []),
        year=_year(message),
        publication_type=message.get("type"),
        url=message.get("URL") or (f"https://doi.org/{doi}" if doi else None),
        related=related,
        editorial_notes=notes,
        raw=message,
    )


class CrossrefAdapter:
    def __init__(
        self,
        transport: HttpTransport,
        *,
        cache: BibliographyCache | None = None,
        mailto: str | None = None,
        base_url: str = BASE_URL,
    ) -> None:
        self.transport = transport
        self.cache = cache
        self.mailto = mailto
        self.base_url = base_url

    def _get(self, endpoint: str, params: dict | None = None) -> dict[str, Any]:
        params = dict(params or {})
        if self.mailto:
            params["mailto"] = self.mailto
        if self.cache is not None:
            cached = self.cache.get(PROVIDER, endpoint, params)
            if cached is not None:
                return cached.json()
        response = self.transport.get(endpoint, params)
        if self.cache is not None:
            self.cache.put(PROVIDER, endpoint, params, response)
        return response.json()

    def fetch_by_doi(self, doi: str) -> BibliographicRecord | None:
        endpoint = f"{self.base_url}/works/{doi}"
        try:
            data = self._get(endpoint, {})
        except Exception:
            return None
        message = data.get("message")
        if not message:
            return None
        return parse_work(message, endpoint=endpoint, params={"doi": doi}, queried_at=now_utc())

    def search(self, query: str, *, rows: int = 5, type_filter: str | None = None) -> list[BibliographicRecord]:
        endpoint = f"{self.base_url}/works"
        params: dict[str, Any] = {
            "query.bibliographic": query,
            "rows": rows,
            "select": "DOI,title,author,issued,container-title,type,ISSN,URL,update-to,relation",
        }
        if type_filter:
            params["filter"] = f"type:{type_filter}"
        data = self._get(endpoint, params)
        items = (data.get("message") or {}).get("items", [])
        return [
            parse_work(item, endpoint=endpoint, params={"query": query}, queried_at=now_utc())
            for item in items
        ]
