"""Europe PMC REST adapter (abstracts, licenses, full-text availability).

Europe PMC aggregates MEDLINE (PubMed) records with abstracts and links to PMC
open-access full text. Content is only stored when the license permits reuse;
otherwise only metadata, locators and minimal permitted excerpts are kept.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from ..core.timeutil import now_utc
from .cache import BibliographyCache
from .models import BibliographicRecord
from .transport import HttpTransport

PROVIDER = "EUROPEPMC"
BASE_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest"


def _first(value: Any) -> Any:
    if isinstance(value, list):
        return value[0] if value else None
    return value


def core_to_record(item: dict[str, Any], *, endpoint: str, params: dict, queried_at: datetime) -> BibliographicRecord:
    journal = ((item.get("journalInfo") or {}).get("journal") or {}).get("title")
    pubtypes = (item.get("pubTypeList") or {}).get("pubType") or []
    notes: list[str] = []
    status = item.get("publicationStatus")
    if status and status.lower() in {"retracted", "retraction"}:
        notes.append("publicationStatus: retracted")
    return BibliographicRecord(
        provider=PROVIDER,
        provider_record_id=item.get("id") or item.get("pmid") or item.get("doi") or "",
        endpoint=endpoint,
        request_params=params,
        queried_at=queried_at,
        doi=item.get("doi"),
        pmid=item.get("pmid"),
        title=item.get("title"),
        authors=tuple(a.strip() for a in (item.get("authorString") or "").split(",") if a.strip()),
        journal=journal,
        issn=tuple(
            x for x in ((item.get("journalInfo") or {}).get("journal") or {}).values() if isinstance(x, str) and "-" in x
        ),
        year=int(item["pubYear"]) if str(item.get("pubYear", "")).isdigit() else None,
        publication_type="; ".join(pubtypes) if pubtypes else None,
        url=f"https://europepmc.org/article/{item.get('source', 'MED')}/{item.get('id')}",
        editorial_notes=tuple(notes),
        raw=item,
    )


def extract_content_fields(item: dict[str, Any]) -> dict[str, Any]:
    """Fields needed for content/licensing decisions (not for scientific inference)."""
    license_value = item.get("license")
    availability_urls = (item.get("fullTextUrlList") or {}).get("fullTextUrl") or []
    return {
        "pmcid": item.get("pmcid"),
        "abstract": item.get("abstractText"),
        "license": license_value,
        "is_open_access": item.get("isOpenAccess"),
        "in_epmc": item.get("inEPMC"),
        "in_pmc": item.get("inPMC"),
        "has_pdf": item.get("hasPDF"),
        "publication_status": item.get("publicationStatus"),
        "publication_types": (item.get("pubTypeList") or {}).get("pubType") or [],
        "first_publication_date": item.get("firstPublicationDate"),
        "date_of_revision": item.get("dateOfRevision"),
        "mesh_terms": [
            m.get("descriptorName") for m in (item.get("meshHeadingList") or {}).get("meshHeading", [])
        ],
        "full_text_urls": availability_urls,
    }


class EuropePmcAdapter:
    def __init__(
        self,
        transport: HttpTransport,
        *,
        cache: BibliographyCache | None = None,
        base_url: str = BASE_URL,
    ) -> None:
        self.transport = transport
        self.cache = cache
        self.base_url = base_url

    def _get_json(self, endpoint: str, params: dict[str, Any]) -> dict[str, Any]:
        params = dict(params)
        params.setdefault("format", "json")
        if self.cache is not None:
            cached = self.cache.get(PROVIDER, endpoint, params)
            if cached is not None:
                return cached.json()
        response = self.transport.get(endpoint, params)
        if self.cache is not None:
            self.cache.put(PROVIDER, endpoint, params, response)
        return response.json()

    def _search(self, query: str) -> dict[str, Any] | None:
        endpoint = f"{self.base_url}/search"
        try:
            data = self._get_json(endpoint, {"query": query, "resultType": "core", "pageSize": 1})
        except Exception:
            return None
        results = (data.get("resultList") or {}).get("result") or []
        return results[0] if results else None

    def fetch_by_doi(self, doi: str) -> tuple[dict[str, Any], BibliographicRecord] | None:
        item = self._search(f'DOI:"{doi}"')
        if item is None:
            return None
        return item, core_to_record(item, endpoint=f"{self.base_url}/search", params={"query": f'DOI:"{doi}"'}, queried_at=now_utc())

    def fetch_by_pmid(self, pmid: str) -> tuple[dict[str, Any], BibliographicRecord] | None:
        item = self._search(f"EXT_ID:{pmid} AND SRC:MED")
        if item is None:
            return None
        return item, core_to_record(item, endpoint=f"{self.base_url}/search", params={"query": f"EXT_ID:{pmid}"}, queried_at=now_utc())

    def full_text_xml(self, pmcid: str) -> str | None:
        endpoint = f"{self.base_url}/{pmcid}/fullTextXML"
        if self.cache is not None:
            cached = self.cache.get(PROVIDER, endpoint, {})
            if cached is not None:
                return cached.text
        try:
            response = self.transport.get(endpoint, None)
        except Exception:
            return None
        if self.cache is not None:
            self.cache.put(PROVIDER, endpoint, {}, response)
        return response.text
