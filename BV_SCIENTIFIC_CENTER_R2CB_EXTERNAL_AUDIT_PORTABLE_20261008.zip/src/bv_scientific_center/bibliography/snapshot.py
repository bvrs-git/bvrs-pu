"""Frozen Europe PMC content snapshots: generation, replay and offline reuse.

The live providers are never required at test time. A snapshot freezes the raw
Europe PMC ``core`` records (and, when a permissive license allows it, the
full-text XML) together with the query provenance. The :class:`SnapshotTransport`
replays those frozen responses through the *unmodified* adapter and service code,
so offline tests exercise exactly the same identification, licensing and
provenance logic as a live acquisition.

Text for a non-permissive license is never written to a snapshot file.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ..core.timeutil import now_utc, to_iso
from .content import classify_license, sha256_text
from .europepmc import BASE_URL, EuropePmcAdapter
from .transport import HttpResponse

DEFAULT_CONTENT_SNAPSHOT = "data/seed/europepmc_corpus.json"
DEFAULT_FULLTEXT_DIR = "europepmc_fulltext"

_DOI_QUERY = re.compile(r'DOI:"([^"]+)"')
_EXT_ID_QUERY = re.compile(r"EXT_ID:(\S+)")


def normalize_key(doi: str | None) -> str:
    return (doi or "").strip().lower()


class SnapshotTransport:
    """Deterministic transport that replays a frozen Europe PMC snapshot.

    Implements the same ``get(url, params)`` contract as a network transport.
    Unknown requests fail closed with HTTP 404.
    """

    def __init__(
        self,
        records_by_doi: dict[str, dict[str, Any]],
        fulltext_by_pmcid: dict[str, str] | None = None,
    ) -> None:
        self.records_by_doi = {normalize_key(k): v for k, v in records_by_doi.items()}
        self.fulltext_by_pmcid = fulltext_by_pmcid or {}
        self.calls: list[tuple[str, dict | None]] = []

    def get(self, url: str, params: dict | None = None) -> HttpResponse:
        self.calls.append((url, params))
        if url.rstrip("/").endswith("/fullTextXML"):
            pmcid = url.rstrip("/").rsplit("/", 2)[-2]
            xml = self.fulltext_by_pmcid.get(pmcid)
            if xml is None:
                return HttpResponse(404, url, {}, b"not found")
            return HttpResponse(200, url, {}, xml.encode("utf-8"))
        if "/search" in url and params:
            query = str(params.get("query") or "")
            doi_match = _DOI_QUERY.search(query)
            if doi_match:
                core = self.records_by_doi.get(normalize_key(doi_match.group(1)))
                if core is not None:
                    return _json_response(url, {"resultList": {"result": [core]}})
                return _json_response(url, {"resultList": {"result": []}})
            ext_match = _EXT_ID_QUERY.search(query)
            if ext_match:
                pmid = ext_match.group(1)
                for core in self.records_by_doi.values():
                    if str(core.get("pmid")) == pmid:
                        return _json_response(url, {"resultList": {"result": [core]}})
                return _json_response(url, {"resultList": {"result": []}})
        return HttpResponse(404, url, {}, b"not found")


def _json_response(url: str, payload: dict[str, Any]) -> HttpResponse:
    body = json.dumps(payload).encode("utf-8")
    return HttpResponse(200, url, {}, body)


def EuropePmcSnapshotAdapter(
    snapshot: dict[str, Any], *, path: str | Path = DEFAULT_CONTENT_SNAPSHOT
) -> EuropePmcAdapter:
    """Build a real :class:`EuropePmcAdapter` backed by a frozen snapshot."""
    records_by_doi: dict[str, dict[str, Any]] = {}
    fulltext_by_pmcid: dict[str, str] = {}
    base = Path(path)
    for entry in snapshot.get("records", []):
        if not entry.get("found"):
            continue
        records_by_doi[normalize_key(entry.get("doi"))] = entry["core"]
        xml_file = entry.get("full_text_xml_file")
        pmcid = (entry.get("core") or {}).get("pmcid")
        if xml_file and pmcid:
            fulltext_by_pmcid[pmcid] = (base.parent / xml_file).read_text(encoding="utf-8")
    transport = SnapshotTransport(records_by_doi, fulltext_by_pmcid)
    return EuropePmcAdapter(transport, base_url=snapshot.get("base_url", BASE_URL))


def load_content_snapshot(path: str | Path = DEFAULT_CONTENT_SNAPSHOT) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def freeze_europepmc_corpus(
    adapter: EuropePmcAdapter,
    dois: tuple[str, ...],
    path: str | Path = DEFAULT_CONTENT_SNAPSHOT,
    *,
    fulltext_dir: str = DEFAULT_FULLTEXT_DIR,
) -> dict[str, Any]:
    """Fetch the given DOIs live and freeze raw responses into a snapshot file.

    Full-text XML is only frozen when the license permits storage. The snapshot
    records the query provenance and a SHA-256 per frozen artifact.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fulltext_path = path.parent / fulltext_dir
    records: list[dict[str, Any]] = []
    for doi in dois:
        query = f'DOI:"{doi}"'
        fetched = adapter.fetch_by_doi(doi)
        if fetched is None:
            records.append({"doi": doi, "query": query, "found": False, "reason": "not found in Europe PMC"})
            continue
        item, _record = fetched
        entry: dict[str, Any] = {"doi": doi, "query": query, "found": True, "core": item}
        pmcid = item.get("pmcid")
        storage, _redistribution, _note = classify_license(item.get("license"))
        if (
            pmcid
            and str(item.get("isOpenAccess") or "").upper() == "Y"
            and str(item.get("inPMC") or "").upper() == "Y"
            and storage
        ):
            xml = adapter.full_text_xml(pmcid)
            if xml:
                fulltext_path.mkdir(parents=True, exist_ok=True)
                target = fulltext_path / f"{pmcid}.xml"
                target.write_text(xml, encoding="utf-8")
                entry["full_text_xml_file"] = f"{fulltext_dir}/{pmcid}.xml"
                entry["full_text_xml_sha256"] = sha256_text(xml)
        records.append(entry)

    snapshot = {
        "generated_at": to_iso(now_utc()),
        "provider": "EUROPEPMC",
        "base_url": adapter.base_url,
        "licensing_policy": (
            "Abstracts are stored for internal annotation. Full-text XML is frozen only "
            "when the license permits internal storage; restricted text is never written."
        ),
        "records": records,
    }
    path.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False), encoding="utf-8")
    return {
        "path": str(path),
        "records": len(records),
        "found": sum(1 for r in records if r.get("found")),
        "full_text_frozen": sum(1 for r in records if r.get("full_text_xml_file")),
    }
