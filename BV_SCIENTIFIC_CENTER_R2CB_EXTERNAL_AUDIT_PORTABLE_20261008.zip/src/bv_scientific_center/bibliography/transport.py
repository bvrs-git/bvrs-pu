"""HTTP transport with rate limiting, retry/backoff and no embedded secrets.

The transport is injectable so tests never touch the network. ``UrllibTransport``
uses only the standard library and sends an identifiable ``User-Agent``; any
contact information is supplied by configuration (never hardcoded).
"""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Protocol


@dataclass
class HttpResponse:
    status: int
    url: str
    headers: dict[str, str] = field(default_factory=dict)
    body: bytes = b""

    def json(self):
        return json.loads(self.body.decode("utf-8"))

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")


class HttpStatusError(Exception):
    def __init__(self, status: int, url: str, body: bytes = b"") -> None:
        super().__init__(f"HTTP {status} for {url}")
        self.status = status
        self.url = url
        self.body = body


class RateLimited(Exception):
    """Raised when a provider returns HTTP 429 and retries are exhausted."""

    def __init__(self, url: str, retry_after: float | None) -> None:
        super().__init__(f"Rate limited by {url} (retry_after={retry_after})")
        self.url = url
        self.retry_after = retry_after


class HttpTransport(Protocol):
    def get(self, url: str, params: dict | None = None) -> HttpResponse:  # pragma: no cover
        ...


class RateLimiter:
    """Thread-safe minimum-interval limiter (default 3 requests/second)."""

    def __init__(self, max_per_second: float = 3.0) -> None:
        self.min_interval = 1.0 / max_per_second if max_per_second > 0 else 0.0
        self._lock = threading.Lock()
        self._last = 0.0

    def acquire(self) -> None:
        with self._lock:
            now = time.monotonic()
            wait = self.min_interval - (now - self._last)
            if wait > 0:
                time.sleep(wait)
                now = time.monotonic()
            self._last = now


@dataclass
class RetryPolicy:
    max_attempts: int = 4
    base_delay: float = 0.5
    max_delay: float = 8.0

    def delay_for(self, attempt: int, retry_after: float | None = None) -> float:
        if retry_after is not None:
            return min(max(retry_after, 0.0), self.max_delay)
        return min(self.base_delay * (2 ** attempt), self.max_delay)


class UrllibTransport:
    def __init__(
        self,
        *,
        user_agent: str = "BVScientificCenter/0.1 (mailto:contact@example.invalid)",
        timeout: float = 20.0,
        rate_limiter: RateLimiter | None = None,
        retry_policy: RetryPolicy | None = None,
        sleeper=time.sleep,
    ) -> None:
        self.user_agent = user_agent
        self.timeout = timeout
        self.rate_limiter = rate_limiter or RateLimiter(3.0)
        self.retry_policy = retry_policy or RetryPolicy()
        self._sleep = sleeper

    def get(self, url: str, params: dict | None = None) -> HttpResponse:
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"
        last_retry_after: float | None = None
        for attempt in range(self.retry_policy.max_attempts):
            self.rate_limiter.acquire()
            request = urllib.request.Request(url, headers={"User-Agent": self.user_agent})
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    return HttpResponse(
                        status=response.status,
                        url=response.geturl(),
                        headers=dict(response.headers.items()),
                        body=response.read(),
                    )
            except urllib.error.HTTPError as exc:
                if exc.code == 429:
                    last_retry_after = _retry_after(exc.headers)
                    if attempt < self.retry_policy.max_attempts - 1:
                        self._sleep(self.retry_policy.delay_for(attempt, last_retry_after))
                        continue
                    raise RateLimited(url, last_retry_after) from exc
                if 500 <= exc.code < 600 and attempt < self.retry_policy.max_attempts - 1:
                    self._sleep(self.retry_policy.delay_for(attempt))
                    continue
                raise HttpStatusError(exc.code, url, exc.read()) from exc
            except urllib.error.URLError as exc:
                if attempt < self.retry_policy.max_attempts - 1:
                    self._sleep(self.retry_policy.delay_for(attempt))
                    continue
                raise HttpStatusError(0, url, str(exc).encode()) from exc
        raise RateLimited(url, last_retry_after)


def _retry_after(headers) -> float | None:
    if not headers:
        return None
    value = headers.get("Retry-After")
    if not value:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
