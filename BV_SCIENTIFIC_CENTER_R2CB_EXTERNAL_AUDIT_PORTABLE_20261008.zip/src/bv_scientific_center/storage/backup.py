"""Safe SQLite backup and verification (R2A GATE 0).

``shutil.copy2`` copies only the main database file. If the database is in WAL
mode with a non-empty ``-wal`` file, the copy can be an inconsistent snapshot
missing committed transactions. This module therefore uses the official
:meth:`sqlite3.Connection.backup` API, which produces a transactionally
consistent snapshot (including WAL content), and then verifies the artifact.

A backup that fails verification is rejected and removed: the procedure fails
explicitly rather than leaving an unusable artifact behind.
"""

from __future__ import annotations

import hashlib
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

from ..errors import BackupVerificationError


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_database(path: str | Path) -> dict:
    """Run integrity and foreign-key checks; return a structured report."""
    path = Path(path)
    conn = sqlite3.connect(str(path))
    try:
        try:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            fk_violations = len(conn.execute("PRAGMA foreign_key_check").fetchall())
            journal_mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        except sqlite3.DatabaseError as exc:
            return {
                "path": str(path),
                "integrity_check": f"not a database: {exc}",
                "foreign_key_violations": -1,
                "journal_mode": None,
                "ok": False,
            }
    finally:
        conn.close()
    return {
        "path": str(path),
        "integrity_check": integrity,
        "foreign_key_violations": fk_violations,
        "journal_mode": journal_mode,
        "ok": integrity == "ok" and fk_violations == 0,
    }


def _readonly_uri(path: Path) -> str:
    # URI mode=ro so the source is never written and no -wal/-shm is created.
    return "file:" + quote(path.resolve().as_posix(), safe="/:") + "?mode=ro"


def safe_backup(
    source: str | Path,
    destination_dir: str | Path,
    *,
    label: str | None = None,
    require_valid: bool = True,
) -> dict:
    """Create a consistent backup of ``source`` and verify it.

    Returns a report with ``destination``, ``sha256``, ``integrity_check``,
    ``foreign_key_violations`` and ``ok``. When ``require_valid`` is True a
    failed verification removes the artifact and raises
    :class:`BackupVerificationError`.
    """
    source = Path(source)
    destination_dir = Path(destination_dir)
    if not source.exists():
        raise BackupVerificationError(f"Source database not found: {source}")
    destination_dir.mkdir(parents=True, exist_ok=True)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    suffix = f"_{label}" if label else ""
    destination = destination_dir / f"{source.stem}{suffix}_{stamp}{source.suffix}"
    if destination.exists():  # never overwrite an existing backup
        raise BackupVerificationError(f"Backup already exists: {destination}")

    src = sqlite3.connect(_readonly_uri(source), uri=True)
    dst = sqlite3.connect(str(destination))
    try:
        try:
            src.backup(dst)  # consistent snapshot, includes committed WAL content
        except sqlite3.DatabaseError as exc:
            dst.close()
            src.close()
            Path(destination).unlink(missing_ok=True)
            raise BackupVerificationError(f"Source is not a valid database: {source}") from exc
    finally:
        try:
            dst.close()
        finally:
            src.close()

    report = verify_database(destination)
    report["sha256"] = sha256_file(destination)
    report["source"] = str(source)
    report["destination"] = str(destination)
    report["backup_method"] = "sqlite3.Connection.backup"

    if require_valid and not report["ok"]:
        Path(destination).unlink(missing_ok=True)
        raise BackupVerificationError(
            f"Backup verification failed for {source}: {report['integrity_check']}, "
            f"{report['foreign_key_violations']} FK violation(s)"
        )
    return report


def restore_to(backup: str | Path, target: str | Path, *, require_valid: bool = True) -> dict:
    """Restore a verified backup into ``target`` (used for restore drills).

    The backup artifact is never modified. The restored target is verified.
    """
    backup = Path(backup)
    target = Path(target)
    if require_valid and not verify_database(backup)["ok"]:
        raise BackupVerificationError(f"Refusing to restore invalid backup: {backup}")

    src = sqlite3.connect(_readonly_uri(backup), uri=True)
    dst = sqlite3.connect(str(target))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return verify_database(target)
