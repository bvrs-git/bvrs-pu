"""Repositories for the clinical (derived) database.

Repositories translate between domain objects and SQLite rows. They never touch
the knowledge database and never read from another BV module.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from typing import Any, Iterable

from ..core.enums import (
    Authority,
    CalculationStatus,
    FastingStatus,
    MapLayer,
    ObservationAuthority,
    Severity,
    SignalStatus,
    SignalType,
    SynthesisRunStatus,
)
from ..core.serialization import dump, dumps, loads
from ..core.timeutil import now_utc, to_iso
from ..errors import IngestionConflictError
from ..formulas.engine import DerivedClinicalMetric, InputResolution
from ..observations.refs import ScientificObservationRef
from ..rules.signals import ClinicalSignalCandidate, SignalReview
from ..scores.engine import ClinicalScoreResult
from .database import Database


def _json_loads(value: str | None, default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return default


# ---------------------------------------------------------------------------
# Observation identity / content fingerprint (R1.2 GATE 2)
# ---------------------------------------------------------------------------
# The stable identity of an observation is its *source* identity:
#   (patient_id, source_module, source_entity_type, source_entity_id,
#    source_version, concept, effective_at)
# encoded in ``observation_ref_id``. The content fingerprint additionally covers
# the clinical payload so a divergent re-send can be detected. It deliberately
# EXCLUDES ingestion/registration time (volatile).
def _fingerprint(*parts: Any) -> str:
    return hashlib.sha256(dumps(list(parts)).encode("utf-8")).hexdigest()


def ref_fingerprint(ref: ScientificObservationRef) -> str:
    return _fingerprint(
        ref.patient_id,
        ref.concept,
        ref.value,
        ref.unit,
        to_iso(ref.effective_at),
        ref.source_module,
        ref.source_entity_type,
        ref.source_entity_id,
        ref.source_version,
        ref.authority.value,
        ref.layer.value,
        dumps(ref.provenance),
        ref.fasting_status.value,
        dumps(ref.context),
        dumps(ref.labels),
    )


def _row_fingerprint(row: Any) -> str:
    return _fingerprint(
        row["patient_id"],
        row["concept"],
        row["value"],
        row["unit"],
        row["effective_at"],
        row["source_module"],
        row["source_entity_type"],
        row["source_entity_id"],
        row["source_version"],
        row["authority"],
        row["layer"],
        dumps(_json_loads(row["provenance"], {})),
        row["fasting_status"],
        dumps(_json_loads(row["context"], {})),
        dumps(_json_loads(row["labels"], {})),
    )


class ObservationRepository:
    """Persists observation references with controlled, non-destructive identity.

    ``save`` is an **UPSERT with semantic verification**, never a blind
    ``INSERT OR REPLACE``:

    * identical re-ingestion -> idempotent no-op (original ``created_at`` and
      ``ingested_at`` are preserved);
    * divergent content for the same stable identity -> ``IngestionConflictError``
      by default (fail-closed), or an explicit revision when
      ``on_conflict="REVISE"`` (the original row is preserved and the new row
      records ``provenance.revision_of``).
    """

    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.clinical

    def _insert(self, ref: ScientificObservationRef) -> None:
        self.conn.execute(
            """
            INSERT INTO observations (
                observation_ref_id, patient_id, concept, value, unit, effective_at,
                ingested_at, source_module, source_entity_type, source_entity_id,
                source_version, authority, layer, provenance, fasting_status, context,
                labels, created_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                ref.observation_ref_id,
                ref.patient_id,
                ref.concept,
                ref.value,
                ref.unit,
                to_iso(ref.effective_at),
                to_iso(ref.ingested_at),
                ref.source_module,
                ref.source_entity_type,
                ref.source_entity_id,
                ref.source_version,
                ref.authority.value,
                ref.layer.value,
                dumps(ref.provenance),
                ref.fasting_status.value,
                dumps(ref.context),
                dumps(ref.labels),
                to_iso(now_utc()),
            ),
        )

    def save(
        self,
        ref: ScientificObservationRef,
        *,
        commit: bool = True,
        on_conflict: str = "REFUSE",
    ) -> ScientificObservationRef:
        with self.database.write_lock:
            row = self.conn.execute(
                "SELECT * FROM observations WHERE observation_ref_id = ?",
                (ref.observation_ref_id,),
            ).fetchone()
            if row is None:
                self._insert(ref)
                if commit:
                    self.conn.commit()
                return ref
            if _row_fingerprint(row) == ref_fingerprint(ref):
                # Exact duplicate: idempotent, provenance and dates preserved.
                return ref
            if on_conflict == "REVISE":
                return self._insert_revision(ref, row, commit=commit)
            if on_conflict != "REFUSE":
                raise ValueError(f"Unknown on_conflict policy: {on_conflict!r}")
            raise IngestionConflictError(
                f"observation {ref.observation_ref_id!r} already exists with divergent "
                f"content (source {ref.source_module}.{ref.source_entity_type} "
                f"id={ref.source_entity_id} v{ref.source_version}, concept "
                f"{ref.concept!r}). Bump source_version, or use on_conflict='REVISE' "
                "to record an explicit revision (the original is preserved)."
            )

    def _insert_revision(
        self, ref: ScientificObservationRef, existing: Any, *, commit: bool
    ) -> ScientificObservationRef:
        from ..core import ids

        revision_id = ids.stable_id(
            "obsref-rev", ref.observation_ref_id, ref_fingerprint(ref)
        )
        provenance = dict(ref.provenance)
        provenance["revision_of"] = existing["observation_ref_id"]
        revised = replace(ref, observation_ref_id=revision_id, provenance=provenance)
        self._insert(revised)
        if commit:
            self.conn.commit()
        return revised

    def save_many(
        self,
        refs: Iterable[ScientificObservationRef],
        *,
        commit: bool = True,
        on_conflict: str = "REFUSE",
    ) -> list[ScientificObservationRef]:
        saved: list[ScientificObservationRef] = []
        for ref in refs:
            saved.append(self.save(ref, commit=False, on_conflict=on_conflict))
        if commit:
            self.conn.commit()
        return saved

    def get(self, observation_ref_id: str) -> ScientificObservationRef | None:
        row = self.conn.execute(
            "SELECT * FROM observations WHERE observation_ref_id = ?", (observation_ref_id,)
        ).fetchone()
        return self._row_to_ref(row) if row else None

    def list_for_patient(self, patient_id: str) -> list[ScientificObservationRef]:
        rows = self.conn.execute(
            "SELECT * FROM observations WHERE patient_id = ? ORDER BY effective_at",
            (patient_id,),
        ).fetchall()
        return [self._row_to_ref(r) for r in rows]

    def refs_by_concept(self, patient_id: str) -> dict[str, list[ScientificObservationRef]]:
        grouped: dict[str, list[ScientificObservationRef]] = {}
        for ref in self.list_for_patient(patient_id):
            grouped.setdefault(ref.concept, []).append(ref)
        return grouped

    def list_patients(self) -> list[str]:
        rows = self.conn.execute(
            "SELECT DISTINCT patient_id FROM observations ORDER BY patient_id"
        ).fetchall()
        return [row["patient_id"] for row in rows]

    @staticmethod
    def _row_to_ref(row: Any) -> ScientificObservationRef:
        from ..core.timeutil import parse_dt

        # ``ingested_at`` may be NULL for legacy rows: keep it UNKNOWN explicitly
        # rather than fabricating a retrospective timestamp (R1.2 GATE 4).
        ingested = None
        if "ingested_at" in row.keys() and row["ingested_at"]:
            ingested = parse_dt(row["ingested_at"])
        return ScientificObservationRef(
            observation_ref_id=row["observation_ref_id"],
            patient_id=row["patient_id"],
            concept=row["concept"],
            value=row["value"],
            unit=row["unit"],
            effective_at=parse_dt(row["effective_at"]),
            ingested_at=ingested,
            source_module=row["source_module"],
            source_entity_type=row["source_entity_type"],
            source_entity_id=row["source_entity_id"],
            source_version=row["source_version"],
            authority=ObservationAuthority(row["authority"]),
            layer=MapLayer(row["layer"]),
            provenance=_json_loads(row["provenance"], {}),
            fasting_status=FastingStatus(row["fasting_status"] or "UNKNOWN"),
            context=_json_loads(row["context"], {}),
            labels=_json_loads(row["labels"], {}),
        )


class DerivedMetricRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.clinical

    def save(
        self,
        metric: DerivedClinicalMetric,
        run_id: str | None = None,
        *,
        commit: bool = True,
    ) -> None:
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO derived_metrics (
                    metric_id, patient_id, metric_definition_id, metric_definition_version,
                    value, unit, computed_at, effective_at, calculation_status, authority,
                    input_refs, input_resolutions, formula_snapshot, warnings, missing_inputs,
                    refusal_reason, domain, run_id
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    metric.metric_id,
                metric.patient_id,
                metric.metric_definition_id,
                metric.metric_definition_version,
                metric.value,
                metric.unit,
                to_iso(metric.computed_at),
                to_iso(metric.effective_at),
                metric.calculation_status.value,
                metric.authority.value,
                dumps(metric.input_refs),
                dumps(metric.input_resolutions),
                dumps(metric.formula_snapshot),
                dumps(metric.warnings),
                dumps(metric.missing_inputs),
                metric.refusal_reason,
                    metric.domain,
                    run_id,
                ),
            )
            if commit:
                self.conn.commit()

    def list_for_patient(self, patient_id: str) -> list[DerivedClinicalMetric]:
        rows = self.conn.execute(
            "SELECT * FROM derived_metrics WHERE patient_id = ? ORDER BY computed_at",
            (patient_id,),
        ).fetchall()
        return [self._row_to_metric(r) for r in rows]

    def by_definition(
        self, patient_id: str, definition_id: str
    ) -> list[DerivedClinicalMetric]:
        return [
            m
            for m in self.list_for_patient(patient_id)
            if m.metric_definition_id == definition_id
        ]

    def list_for_run(self, patient_id: str, run_id: str) -> list[DerivedClinicalMetric]:
        rows = self.conn.execute(
            "SELECT * FROM derived_metrics WHERE patient_id = ? AND run_id = ? "
            "ORDER BY metric_definition_id",
            (patient_id, run_id),
        ).fetchall()
        return [self._row_to_metric(r) for r in rows]

    @staticmethod
    def _row_to_metric(row: Any) -> DerivedClinicalMetric:
        from ..core.timeutil import parse_dt

        resolutions = [
            InputResolution(**r) for r in _json_loads(row["input_resolutions"], [])
        ]
        return DerivedClinicalMetric(
            metric_id=row["metric_id"],
            patient_id=row["patient_id"],
            metric_definition_id=row["metric_definition_id"],
            metric_definition_version=row["metric_definition_version"],
            value=row["value"],
            unit=row["unit"],
            computed_at=parse_dt(row["computed_at"]),
            effective_at=parse_dt(row["effective_at"]) if row["effective_at"] else None,
            calculation_status=CalculationStatus(row["calculation_status"]),
            input_refs=_json_loads(row["input_refs"], []),
            input_resolutions=resolutions,
            formula_snapshot=_json_loads(row["formula_snapshot"], {}),
            authority=Authority(row["authority"]),
            warnings=_json_loads(row["warnings"], []),
            missing_inputs=_json_loads(row["missing_inputs"], []),
            refusal_reason=row["refusal_reason"],
            domain=row["domain"],
        )


class ScoreResultRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.clinical

    def save(
        self,
        result: ClinicalScoreResult,
        run_id: str | None = None,
        *,
        commit: bool = True,
    ) -> None:
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO score_results (
                    score_result_id, patient_id, score_id, score_version, value, unit,
                    band, band_interpretation, computed_at, effective_at, calculation_status,
                    authority, inputs, warnings, refusal_reason, domain, run_id
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    result.score_result_id,
                    result.patient_id,
                    result.score_id,
                    result.score_version,
                    result.value,
                    result.unit,
                    result.band,
                    result.band_interpretation,
                    to_iso(result.computed_at),
                    to_iso(result.effective_at),
                    result.calculation_status.value,
                    result.authority.value,
                    dumps(result.inputs),
                    dumps(result.warnings),
                    result.refusal_reason,
                    result.domain,
                    run_id,
                ),
            )
            if commit:
                self.conn.commit()

    def list_for_patient(self, patient_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM score_results WHERE patient_id = ? ORDER BY computed_at",
            (patient_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def list_for_run(self, patient_id: str, run_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM score_results WHERE patient_id = ? AND run_id = ? "
            "ORDER BY score_id",
            (patient_id, run_id),
        ).fetchall()
        return [dict(row) for row in rows]


class SignalRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.clinical

    def save(
        self,
        signal: ClinicalSignalCandidate,
        run_id: str | None = None,
        *,
        commit: bool = True,
    ) -> None:
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO signals (
                    signal_id, patient_id, rule_id, rule_version, title, category, severity,
                    signal_type, supporting_refs, generated_at, explanation, authority, status,
                    run_id, domain, interpretation_warning
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    signal.signal_id,
                    signal.patient_id,
                    signal.rule_id,
                    signal.rule_version,
                    signal.title,
                    signal.category,
                    signal.severity.value,
                    signal.signal_type.value,
                    dumps(signal.supporting_refs),
                    to_iso(signal.generated_at),
                    dumps(signal.explanation),
                    signal.authority.value,
                    signal.status.value,
                    run_id or signal.run_id,
                    signal.domain,
                    signal.interpretation_warning,
                ),
            )
            if commit:
                self.conn.commit()

    def get(self, signal_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM signals WHERE signal_id = ?", (signal_id,)
        ).fetchone()
        return self._row_to_dict(row) if row else None

    def list_for_patient(self, patient_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM signals WHERE patient_id = ? ORDER BY generated_at DESC",
            (patient_id,),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def list_for_run(self, patient_id: str, run_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM signals WHERE patient_id = ? AND run_id = ? "
            "ORDER BY signal_id",
            (patient_id, run_id),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def set_status(self, signal_id: str, status: SignalStatus) -> None:
        self.conn.execute(
            "UPDATE signals SET status = ? WHERE signal_id = ?", (status.value, signal_id)
        )
        self.conn.commit()

    def add_review(self, review: SignalReview) -> None:
        self.conn.execute(
            """
            INSERT INTO signal_reviews (signal_id, status, note, reviewer, reviewed_at)
            VALUES (?,?,?,?,?)
            """,
            (
                review.signal_id,
                review.status.value,
                review.note,
                review.reviewer,
                to_iso(review.reviewed_at),
            ),
        )
        self.conn.commit()

    def reviews_for(self, signal_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM signal_reviews WHERE signal_id = ? ORDER BY review_id",
            (signal_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _row_to_dict(row: Any) -> dict[str, Any]:
        data = dict(row)
        data["supporting_refs"] = _json_loads(data.get("supporting_refs"), [])
        data["explanation"] = _json_loads(data.get("explanation"), {})
        return data


class SynthesisRunRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.clinical

    def save(self, run: dict[str, Any], *, commit: bool = True) -> None:
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO synthesis_runs (
                    run_id, patient_id, knowledge_package_version, input_snapshot,
                    formula_versions, score_versions, rule_versions, started_at, completed_at,
                    status, meta
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    run["run_id"],
                    run["patient_id"],
                    run.get("knowledge_package_version"),
                    dumps(run.get("input_snapshot", [])),
                    dumps(run.get("formula_versions", {})),
                    dumps(run.get("score_versions", {})),
                    dumps(run.get("rule_versions", {})),
                    run.get("started_at"),
                    run.get("completed_at"),
                    run.get("status", SynthesisRunStatus.STARTED.value),
                    dumps(run.get("meta", {})),
                ),
            )
            if commit:
                self.conn.commit()

    def get(self, run_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM synthesis_runs WHERE run_id = ?", (run_id,)
        ).fetchone()
        if not row:
            return None
        data = dict(row)
        for key in ("input_snapshot", "formula_versions", "score_versions", "rule_versions", "meta"):
            data[key] = _json_loads(data.get(key), {} if key != "input_snapshot" else [])
        return data

    def list_for_patient(self, patient_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT run_id FROM synthesis_runs WHERE patient_id = ? ORDER BY started_at DESC",
            (patient_id,),
        ).fetchall()
        return [self.get(r["run_id"]) for r in rows]  # type: ignore[misc]


class AnnotationRepository:
    """Clinician-authored annotations. They never mutate source observations."""

    def __init__(self, database: Database) -> None:
        self.conn = database.clinical

    def add(
        self,
        *,
        annotation_id: str,
        patient_id: str,
        target_type: str,
        target_id: str,
        text: str,
        author: str,
    ) -> None:
        self.conn.execute(
            """
            INSERT INTO annotations (annotation_id, patient_id, target_type, target_id, text, author, created_at)
            VALUES (?,?,?,?,?,?,?)
            """,
            (annotation_id, patient_id, target_type, target_id, text, author, to_iso(now_utc())),
        )
        self.conn.commit()

    def list_for_patient(self, patient_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM annotations WHERE patient_id = ? ORDER BY created_at",
            (patient_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def for_target(self, patient_id: str, target_type: str, target_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM annotations WHERE patient_id = ? AND target_type = ? AND target_id = ?",
            (patient_id, target_type, target_id),
        ).fetchall()
        return [dict(row) for row in rows]


class PinRepository:
    def __init__(self, database: Database) -> None:
        self.conn = database.clinical

    def add(self, *, pin_id: str, patient_id: str, target_type: str, target_id: str, note: str | None = None) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO pins (pin_id, patient_id, target_type, target_id, note, created_at) VALUES (?,?,?,?,?,?)",
            (pin_id, patient_id, target_type, target_id, note, to_iso(now_utc())),
        )
        self.conn.commit()

    def list_for_patient(self, patient_id: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM pins WHERE patient_id = ? ORDER BY created_at", (patient_id,)
        ).fetchall()
        return [dict(row) for row in rows]


class EventRepository:
    def __init__(self, database: Database) -> None:
        self.database = database
        self.conn = database.clinical

    def append(self, event: dict[str, Any]) -> None:
        with self.database.write_lock:
            self.conn.execute(
                """
                INSERT INTO events (event_id, event_type, patient_id, run_id, payload, created_at)
                VALUES (?,?,?,?,?,?)
                """,
                (
                    event["event_id"],
                    event["event_type"],
                    event.get("patient_id"),
                    event.get("run_id"),
                    dumps(event.get("payload", {})),
                    event.get("created_at") or to_iso(now_utc()),
                ),
            )
            self.conn.commit()

    def list_all(self) -> list[dict[str, Any]]:
        rows = self.conn.execute("SELECT * FROM events ORDER BY created_at").fetchall()
        result = []
        for row in rows:
            data = dict(row)
            data["payload"] = _json_loads(data.get("payload"), {})
            result.append(data)
        return result
