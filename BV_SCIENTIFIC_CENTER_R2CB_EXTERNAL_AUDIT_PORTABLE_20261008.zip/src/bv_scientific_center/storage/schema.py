"""SQLite schema definitions for the two Scientific Center databases."""

from __future__ import annotations

KNOWLEDGE_SCHEMA = """
CREATE TABLE IF NOT EXISTS knowledge_items (
    knowledge_id        TEXT PRIMARY KEY,
    title               TEXT NOT NULL,
    topic               TEXT,
    subtopic            TEXT,
    summary             TEXT,
    key_points          TEXT,
    source_type         TEXT,
    publication_year    INTEGER,
    authors             TEXT,
    journal             TEXT,
    doi                 TEXT,
    url                 TEXT,
    citation            TEXT,
    evidence_level      TEXT,
    evidence_framework  TEXT,
    evidence_grade      TEXT,
    certainty           TEXT,
    reviewer            TEXT,
    target_type         TEXT,
    origin              TEXT,
    tags                TEXT,
    status              TEXT NOT NULL DEFAULT 'DRAFT',
    package_id          TEXT,
    package_version     TEXT,
    created_at          TEXT,
    reviewed_at         TEXT
);

CREATE TABLE IF NOT EXISTS knowledge_claims (
    claim_id                    TEXT PRIMARY KEY,
    text                        TEXT NOT NULL,
    knowledge_item_id           TEXT,
    supporting_reference_ids    TEXT,
    review_status               TEXT,
    created_at                  TEXT
);

CREATE TABLE IF NOT EXISTS knowledge_references (
    reference_id    TEXT PRIMARY KEY,
    citation        TEXT,
    title           TEXT,
    source          TEXT,
    year            INTEGER,
    doi             TEXT,
    url             TEXT,
    item_id         TEXT,
    created_at      TEXT
);

CREATE TABLE IF NOT EXISTS knowledge_packages (
    package_id      TEXT NOT NULL,
    version         TEXT NOT NULL,
    name            TEXT,
    domain          TEXT,
    payload         TEXT,
    source_manifest TEXT,
    review_status   TEXT,
    created_at      TEXT,
    activated_at    TEXT,
    is_active       INTEGER DEFAULT 0,
    PRIMARY KEY (package_id, version)
);

CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(
    knowledge_id UNINDEXED,
    title,
    summary,
    key_points,
    topic,
    tags
);

-- --------------------------------------------------------------------------
-- R2A - scientific curation and evidence governance
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scientific_references (
    reference_id        TEXT PRIMARY KEY,
    title               TEXT NOT NULL,
    authors             TEXT,
    organization        TEXT,
    publication_year    INTEGER,
    venue               TEXT,
    publication_type    TEXT,
    doi                 TEXT,
    pmid                TEXT,
    isbn                TEXT,
    url                 TEXT,
    accessed_at         TEXT,
    metadata_source     TEXT,
    verification_status TEXT,
    curation_status     TEXT NOT NULL DEFAULT 'IMPORTED_UNVERIFIED',
    version             INTEGER NOT NULL DEFAULT 1,
    content_hash        TEXT,
    origin              TEXT,
    superseded_by       TEXT,
    retraction_reason   TEXT,
    notes               TEXT,
    created_at          TEXT,
    updated_at          TEXT
);

CREATE TABLE IF NOT EXISTS scientific_evidence (
    evidence_id             TEXT PRIMARY KEY,
    title                   TEXT NOT NULL,
    reference_ids           TEXT,
    study_design            TEXT,
    population              TEXT,
    intervention            TEXT,
    comparator              TEXT,
    outcomes                TEXT,
    quantitative_results    TEXT,
    limitations             TEXT,
    clinical_applicability  TEXT,
    uncertainties           TEXT,
    biases                  TEXT,
    editorial_status        TEXT,
    corrections             TEXT,
    retraction_notes        TEXT,
    methodology             TEXT,
    domain                  TEXT,
    curation_status         TEXT NOT NULL DEFAULT 'IMPORTED_UNVERIFIED',
    version                 INTEGER NOT NULL DEFAULT 1,
    content_hash            TEXT,
    origin                  TEXT,
    superseded_by           TEXT,
    created_at              TEXT,
    updated_at              TEXT
);

CREATE TABLE IF NOT EXISTS clinical_claims (
    claim_id                TEXT PRIMARY KEY,
    text                    TEXT NOT NULL,
    favorable_evidence_ids  TEXT,
    contrary_evidence_ids   TEXT,
    inconclusive_evidence_ids TEXT,
    population_context      TEXT,
    applicability           TEXT,
    limitations             TEXT,
    certainty_level         TEXT,
    certainty_framework     TEXT,
    curation_status         TEXT NOT NULL DEFAULT 'IMPORTED_UNVERIFIED',
    version                 INTEGER NOT NULL DEFAULT 1,
    content_hash            TEXT,
    origin                  TEXT,
    review_history          TEXT,
    superseded_by           TEXT,
    created_at              TEXT,
    updated_at              TEXT
);

CREATE TABLE IF NOT EXISTS evidence_links (
    link_id             TEXT PRIMARY KEY,
    subject_type        TEXT NOT NULL,
    subject_id          TEXT NOT NULL,
    target_type         TEXT NOT NULL,
    target_id           TEXT NOT NULL,
    target_version      INTEGER,
    relation            TEXT NOT NULL,
    applicability       TEXT,
    created_by          TEXT,
    created_at          TEXT,
    justification       TEXT,
    verification_status TEXT,
    link_version        INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_evidence_links_target
    ON evidence_links (target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_evidence_links_subject
    ON evidence_links (subject_type, subject_id);

CREATE TABLE IF NOT EXISTS curation_events (
    event_id        TEXT PRIMARY KEY,
    subject_type    TEXT NOT NULL,
    subject_id      TEXT NOT NULL,
    from_status     TEXT,
    to_status       TEXT NOT NULL,
    actor           TEXT,
    justification   TEXT,
    version         INTEGER,
    created_at      TEXT
);
CREATE INDEX IF NOT EXISTS idx_curation_events_subject
    ON curation_events (subject_type, subject_id);

CREATE VIRTUAL TABLE IF NOT EXISTS reference_fts USING fts5(
    reference_id UNINDEXED,
    title,
    authors,
    venue,
    doi,
    pmid,
    organization
);

CREATE VIRTUAL TABLE IF NOT EXISTS evidence_fts USING fts5(
    evidence_id UNINDEXED,
    title,
    population,
    outcomes,
    domain
);

-- --------------------------------------------------------------------------
-- R2B - bibliographic acquisition, provenance, editorial alerts, appraisal
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bibliography_cache (
    cache_key       TEXT PRIMARY KEY,
    provider        TEXT NOT NULL,
    request_json    TEXT,
    response_json   TEXT,
    response_sha256 TEXT,
    status_code     INTEGER,
    created_at      TEXT
);

CREATE TABLE IF NOT EXISTS acquisition_records (
    acquisition_id      TEXT PRIMARY KEY,
    reference_id        TEXT,
    provider            TEXT NOT NULL,
    endpoint            TEXT,
    params_json         TEXT,
    queried_at          TEXT,
    record_identity     TEXT,
    identifiers_json    TEXT,
    payload_sha256      TEXT,
    processing_version  TEXT,
    verification_status TEXT,
    divergences_json    TEXT,
    created_at          TEXT
);
CREATE INDEX IF NOT EXISTS idx_acquisition_reference
    ON acquisition_records (reference_id);

CREATE TABLE IF NOT EXISTS editorial_alerts (
    alert_id        TEXT PRIMARY KEY,
    reference_id    TEXT NOT NULL,
    alert_type      TEXT NOT NULL,
    source          TEXT,
    detected_at     TEXT,
    details         TEXT,
    is_retraction   INTEGER DEFAULT 0,
    created_at      TEXT
);
CREATE INDEX IF NOT EXISTS idx_editorial_alerts_reference
    ON editorial_alerts (reference_id);

CREATE TABLE IF NOT EXISTS formula_candidates (
    candidate_id    TEXT NOT NULL,
    version         INTEGER NOT NULL,
    candidate_type  TEXT,
    status          TEXT,
    content_hash    TEXT,
    payload         TEXT,
    created_at      TEXT,
    primary_reference_id TEXT,
    PRIMARY KEY (candidate_id, version)
);

CREATE TABLE IF NOT EXISTS review_appraisals (
    appraisal_id            TEXT PRIMARY KEY,
    reference_id            TEXT NOT NULL,
    reviewer                TEXT,
    created_at              TEXT,
    content_review_status   TEXT,
    scientific_question     TEXT,
    study_design            TEXT,
    population              TEXT,
    sample_size             TEXT,
    inclusion_criteria      TEXT,
    exclusion_criteria      TEXT,
    reference_method        TEXT,
    intervention            TEXT,
    comparator              TEXT,
    outcomes                TEXT,
    quantitative_results    TEXT,
    confidence_intervals    TEXT,
    limitations             TEXT,
    risk_of_bias            TEXT,
    clinical_applicability  TEXT,
    author_conclusions      TEXT,
    reviewer_interpretation TEXT,
    provenance_locations    TEXT,
    pending_fields          TEXT,
    field_provenance        TEXT,
    validation_metrics      TEXT,
    field_provenance_note   TEXT
);
CREATE INDEX IF NOT EXISTS idx_review_appraisals_reference
    ON review_appraisals (reference_id);

-- --------------------------------------------------------------------------
-- R2C-B - acquired content, licensing and medical review decisions
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS acquired_content (
    content_id          TEXT PRIMARY KEY,
    reference_id        TEXT NOT NULL,
    source              TEXT,
    endpoint            TEXT,
    queried_at          TEXT,
    content_type        TEXT,
    identifiers_json    TEXT,
    source_version      TEXT,
    sha256              TEXT,
    license             TEXT,
    availability        TEXT,
    storage_permitted   INTEGER DEFAULT 0,
    storage_note        TEXT,
    locator             TEXT,
    text                TEXT,
    created_at          TEXT
);
CREATE INDEX IF NOT EXISTS idx_acquired_content_reference
    ON acquired_content (reference_id);

CREATE TABLE IF NOT EXISTS review_decisions (
    decision_id         TEXT PRIMARY KEY,
    reference_id        TEXT NOT NULL,
    decision            TEXT NOT NULL,
    actor               TEXT,
    justification       TEXT,
    reference_version   INTEGER,
    content_hash        TEXT,
    created_at          TEXT
);
CREATE INDEX IF NOT EXISTS idx_review_decisions_reference
    ON review_decisions (reference_id);

-- R2C-B - structured, citation-grounded content extraction (GATE 3/4)
CREATE TABLE IF NOT EXISTS content_extractions (
    extraction_id       TEXT PRIMARY KEY,
    reference_id        TEXT NOT NULL,
    content_id          TEXT,
    source_kind         TEXT,
    source_sha256       TEXT,
    extraction_version  TEXT,
    fields_json         TEXT,
    pending_fields_json TEXT,
    created_at          TEXT
);
CREATE INDEX IF NOT EXISTS idx_content_extractions_reference
    ON content_extractions (reference_id);

-- R2C-B - editorial currency checks (GATE 8)
CREATE TABLE IF NOT EXISTS editorial_checks (
    check_id        TEXT PRIMARY KEY,
    reference_id    TEXT NOT NULL,
    provider        TEXT,
    checked_at      TEXT,
    outcome         TEXT,
    details         TEXT,
    currency_known  INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_editorial_checks_reference
    ON editorial_checks (reference_id);

CREATE TABLE IF NOT EXISTS bibliography_cache_meta (
    cache_key   TEXT PRIMARY KEY,
    provider    TEXT,
    fetched_at  TEXT,
    expires_at  TEXT
);
"""


CLINICAL_SCHEMA = """
CREATE TABLE IF NOT EXISTS observations (
    observation_ref_id  TEXT PRIMARY KEY,
    patient_id          TEXT NOT NULL,
    concept             TEXT NOT NULL,
    value               REAL,
    unit                TEXT,
    effective_at        TEXT,
    ingested_at         TEXT,
    source_module       TEXT,
    source_entity_type  TEXT,
    source_entity_id    TEXT,
    source_version      TEXT,
    authority           TEXT,
    layer               TEXT,
    provenance          TEXT,
    fasting_status      TEXT,
    context             TEXT,
    labels              TEXT,
    created_at          TEXT
);
CREATE INDEX IF NOT EXISTS idx_observations_patient_concept
    ON observations (patient_id, concept);

CREATE TABLE IF NOT EXISTS derived_metrics (
    metric_id                   TEXT PRIMARY KEY,
    patient_id                  TEXT NOT NULL,
    metric_definition_id        TEXT NOT NULL,
    metric_definition_version   INTEGER NOT NULL,
    value                       REAL,
    unit                        TEXT,
    computed_at                 TEXT,
    effective_at                TEXT,
    calculation_status          TEXT,
    authority                   TEXT,
    input_refs                  TEXT,
    input_resolutions           TEXT,
    formula_snapshot            TEXT,
    warnings                    TEXT,
    missing_inputs              TEXT,
    refusal_reason              TEXT,
    domain                      TEXT,
    run_id                      TEXT
);
CREATE INDEX IF NOT EXISTS idx_metrics_patient_definition
    ON derived_metrics (patient_id, metric_definition_id);

CREATE TABLE IF NOT EXISTS score_results (
    score_result_id     TEXT PRIMARY KEY,
    patient_id          TEXT NOT NULL,
    score_id            TEXT NOT NULL,
    score_version       INTEGER NOT NULL,
    value               REAL,
    unit                TEXT,
    band                TEXT,
    band_interpretation TEXT,
    computed_at         TEXT,
    effective_at        TEXT,
    calculation_status  TEXT,
    authority           TEXT,
    inputs              TEXT,
    warnings            TEXT,
    refusal_reason      TEXT,
    domain              TEXT,
    run_id              TEXT
);

CREATE TABLE IF NOT EXISTS signals (
    signal_id               TEXT PRIMARY KEY,
    patient_id              TEXT NOT NULL,
    rule_id                 TEXT NOT NULL,
    rule_version            INTEGER NOT NULL,
    title                   TEXT,
    category                TEXT,
    severity                TEXT,
    signal_type             TEXT,
    supporting_refs         TEXT,
    generated_at            TEXT,
    explanation             TEXT,
    authority               TEXT,
    status                  TEXT,
    run_id                  TEXT,
    domain                  TEXT,
    interpretation_warning  TEXT
);
CREATE INDEX IF NOT EXISTS idx_signals_patient ON signals (patient_id);

CREATE TABLE IF NOT EXISTS signal_reviews (
    review_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_id   TEXT NOT NULL,
    status      TEXT NOT NULL,
    note        TEXT,
    reviewer    TEXT,
    reviewed_at TEXT
);

CREATE TABLE IF NOT EXISTS synthesis_runs (
    run_id                      TEXT PRIMARY KEY,
    patient_id                  TEXT NOT NULL,
    knowledge_package_version   TEXT,
    input_snapshot              TEXT,
    formula_versions            TEXT,
    score_versions              TEXT,
    rule_versions               TEXT,
    started_at                  TEXT,
    completed_at                TEXT,
    status                      TEXT,
    meta                        TEXT
);

CREATE TABLE IF NOT EXISTS annotations (
    annotation_id   TEXT PRIMARY KEY,
    patient_id      TEXT NOT NULL,
    target_type     TEXT NOT NULL,
    target_id       TEXT NOT NULL,
    text            TEXT,
    author          TEXT,
    created_at      TEXT
);

CREATE TABLE IF NOT EXISTS pins (
    pin_id      TEXT PRIMARY KEY,
    patient_id  TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id   TEXT NOT NULL,
    note        TEXT,
    created_at  TEXT
);

CREATE TABLE IF NOT EXISTS events (
    event_id    TEXT PRIMARY KEY,
    event_type  TEXT NOT NULL,
    patient_id  TEXT,
    run_id      TEXT,
    payload     TEXT,
    created_at  TEXT
);
"""
