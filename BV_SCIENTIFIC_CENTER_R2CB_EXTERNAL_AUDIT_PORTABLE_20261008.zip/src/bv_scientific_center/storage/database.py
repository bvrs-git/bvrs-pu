"""Database connection management for the two SQLite databases.

R1.2 hardening:

* ``isolation_level = None`` so the module controls transactions explicitly
  (no implicit, partially-committed writes).
* ``busy_timeout`` to tolerate short lock contention; ``WAL`` journal for file
  databases to allow concurrent readers with a writer.
* A per-database :class:`threading.RLock` serializes writes on the shared
  connection (the UI uses a threaded server).
* :meth:`Database.transaction` provides an explicit ``BEGIN IMMEDIATE ... COMMIT``
  unit with rollback on failure.

Atomicity is **per database**. ``knowledge.db`` and ``derived.db`` are separate
files: the module never assumes cross-database atomicity.
"""

from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .schema import CLINICAL_SCHEMA, KNOWLEDGE_SCHEMA

BUSY_TIMEOUT_MS = 5000


class Database:
    """Owns the ``knowledge.db`` and ``derived.db`` connections."""

    def __init__(self, base_dir: str | Path, *, memory: bool = False) -> None:
        self.base_dir = Path(base_dir)
        self.memory = memory
        if not memory:
            self.base_dir.mkdir(parents=True, exist_ok=True)
        self._knowledge: sqlite3.Connection | None = None
        self._clinical: sqlite3.Connection | None = None
        self._write_lock = threading.RLock()

    # -- connections -------------------------------------------------------
    @property
    def write_lock(self) -> threading.RLock:
        return self._write_lock

    def _connect(self, name: str) -> sqlite3.Connection:
        if self.memory:
            conn = sqlite3.connect(
                ":memory:", check_same_thread=False, isolation_level=None
            )
        else:
            conn = sqlite3.connect(
                self.base_dir / name, check_same_thread=False, isolation_level=None
            )
            # WAL allows readers to proceed while a writer holds the lock.
            conn.execute("PRAGMA journal_mode = WAL")
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute(f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS}")
        return conn

    @property
    def knowledge(self) -> sqlite3.Connection:
        if self._knowledge is None:
            self._knowledge = self._connect("knowledge.db")
            self._knowledge.executescript(KNOWLEDGE_SCHEMA)
            _migrate(self._knowledge, "knowledge_items", {"origin": "TEXT"})
            _migrate(
                self._knowledge,
                "scientific_references",
                {
                    "bibliographic_status": "TEXT",
                    "content_review_status": "TEXT",
                    "issn": "TEXT",
                    "last_checked_at": "TEXT",
                },
            )
            _migrate(
                self._knowledge,
                "evidence_links",
                {
                    "justification": "TEXT",
                    "verification_status": "TEXT",
                    "link_version": "INTEGER",
                },
            )
            _migrate(
                self._knowledge,
                "review_appraisals",
                {
                    "field_provenance": "TEXT",
                    "validation_metrics": "TEXT",
                    "field_provenance_note": "TEXT",
                },
            )
        return self._knowledge

    @property
    def clinical(self) -> sqlite3.Connection:
        if self._clinical is None:
            self._clinical = self._connect("derived.db")
            self._clinical.executescript(CLINICAL_SCHEMA)
            _migrate(self._clinical, "observations", {"ingested_at": "TEXT"})
        return self._clinical

    # -- transactions ------------------------------------------------------
    @contextmanager
    def transaction(self, namespace: str = "clinical") -> Iterator[sqlite3.Connection]:
        """Explicit, serialized ``BEGIN IMMEDIATE ... COMMIT`` unit.

        On any exception the transaction is rolled back and the exception
        re-raised. Not re-entrant; do not nest transactions on the same database.
        """
        conn = self.clinical if namespace == "clinical" else self.knowledge
        with self._write_lock:
            conn.execute("BEGIN IMMEDIATE")
            try:
                yield conn
            except BaseException:
                conn.rollback()
                raise
            else:
                conn.commit()

    def initialize(self) -> "Database":
        _ = self.knowledge
        _ = self.clinical
        return self

    def commit(self) -> None:
        if self._knowledge is not None:
            self._knowledge.commit()
        if self._clinical is not None:
            self._clinical.commit()

    def close(self) -> None:
        for conn in (self._knowledge, self._clinical):
            if conn is not None:
                conn.close()
        self._knowledge = None
        self._clinical = None

    def __enter__(self) -> "Database":
        return self.initialize()

    def __exit__(self, *exc: object) -> None:
        self.commit()
        self.close()


def _migrate(conn: sqlite3.Connection, table: str, columns: dict[str, str]) -> None:
    """Additive, non-destructive migration.

    Adds missing columns only; never drops or rewrites existing data.
    """
    existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
    for column, ddl in columns.items():
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
