"""Storage layer (standard library sqlite3 only).

Two physically separate databases enforce the privacy boundary:

* ``knowledge.db`` - scientific knowledge, formulas, scores, rules, packages.
  Contains NO patient data.
* ``derived.db``   - observation references, derived metrics, score results,
  signal candidates, synthesis runs, annotations, pins, events.

The module never opens a BV Clinical database.
"""

from .database import Database
from .repositories import (
    AnnotationRepository,
    DerivedMetricRepository,
    EventRepository,
    ObservationRepository,
    PinRepository,
    ScoreResultRepository,
    SignalRepository,
    SynthesisRunRepository,
)

__all__ = [
    "Database",
    "AnnotationRepository",
    "DerivedMetricRepository",
    "EventRepository",
    "ObservationRepository",
    "PinRepository",
    "ScoreResultRepository",
    "SignalRepository",
    "SynthesisRunRepository",
]
