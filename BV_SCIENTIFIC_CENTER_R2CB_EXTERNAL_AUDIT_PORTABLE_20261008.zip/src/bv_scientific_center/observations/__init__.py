"""Observation reference builders (projection -> ScientificObservationRef)."""
