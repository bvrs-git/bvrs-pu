"""Scientific observation references and the projection ingestor.

The Scientific Center references source observations, it does not clone source
tables. Each :class:`ScientificObservationRef` is an immutable, provenance-rich
pointer to an observation owned by another module.

Provenance distinction (R1.1 GATE 2A):

* ``effective_at``  - the **clinical** date/time of the measurement (when the
  sample/measurement was taken).
* ``ingested_at``   - when the observation was **registered/imported** into this
  module. It is set at ingestion time and never rewritten.

MISSING semantics: an observation whose value is absent keeps ``value is None``.
It is never coerced to ``0``.

Idempotency: ``observation_ref_id`` is derived deterministically from the source
natural key, so re-ingesting the same projection does not create a duplicate row.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Iterable

from ..contracts.inputs import (
    BioimpedanceSummaryProjection,
    DiagnosisSummaryProjection,
    IntegrativeIntakeSummary,
    LabObservationProjection,
    MedicationSummaryProjection,
    NutritionAssessmentProjection,
    PatientReportedFact,
)
from ..core import ids
from ..core.concepts import (
    ENERGY_TARGET,
    PROTEIN_TARGET,
)
from ..core.enums import (
    Authority,
    FastingStatus,
    MapLayer,
    ObservationAuthority,
)
from ..core.timeutil import now_utc, parse_clinical_dt, to_iso
from ..errors import ContractViolation


@dataclass(frozen=True)
class ScientificObservationRef:
    observation_ref_id: str
    patient_id: str
    concept: str
    value: float | None
    unit: str
    effective_at: datetime
    source_module: str
    source_entity_type: str
    source_entity_id: str
    source_version: str
    authority: ObservationAuthority
    layer: MapLayer
    provenance: dict[str, Any] = field(default_factory=dict)
    fasting_status: FastingStatus = FastingStatus.UNKNOWN
    context: dict[str, Any] = field(default_factory=dict)
    labels: dict[str, str] = field(default_factory=dict)
    # Registration time into the Scientific Center. ``None`` means UNKNOWN
    # (legacy rows); it is never fabricated retroactively.
    ingested_at: datetime | None = field(default_factory=now_utc)

    @property
    def display_authority(self) -> Authority:
        if self.authority is ObservationAuthority.PATIENT_REPORTED:
            return Authority.PATIENT_REPORTED
        if self.authority is ObservationAuthority.CLINICIAN_CONFIRMED:
            return Authority.CLINICIAN_CONFIRMED
        return Authority.MEASURED

    def snapshot(self) -> dict[str, Any]:
        """Immutable value snapshot used for reproducibility and provenance.

        Carries both the clinical date (``effective_at``) and the ingestion date
        (``ingested_at``) so the two are never conflated.
        """
        return {
            "observation_ref_id": self.observation_ref_id,
            "concept": self.concept,
            "value": self.value,
            "unit": self.unit,
            "effective_at": self.effective_at,
            "ingested_at": self.ingested_at,
            "source_module": self.source_module,
            "source_entity_type": self.source_entity_type,
            "source_entity_id": self.source_entity_id,
            "source_version": self.source_version,
            "authority": self.authority,
            "fasting_status": self.fasting_status,
        }

    def label(self) -> str:
        return self.labels.get("label", self.concept)


def _stable_ref_id(
    *,
    patient_id: str,
    source_module: str,
    source_entity_type: str,
    source_entity_id: str,
    source_version: str,
    concept: str,
    effective_at: datetime,
) -> str:
    return ids.stable_id(
        "obsref",
        patient_id,
        source_module,
        source_entity_type,
        source_entity_id,
        source_version,
        concept,
        to_iso(effective_at),
    )


def _require_effective_at(value: str | None, *, entity: str) -> datetime:
    dt = parse_clinical_dt(value, field=f"{entity}.effective_at")
    if dt is None:
        raise ContractViolation(f"{entity} observation requires effective_at/collection_at")
    return dt


def lab_to_ref(projection: LabObservationProjection) -> ScientificObservationRef:
    effective = _require_effective_at(
        projection.effective_at or projection.collection_at, entity="LAB"
    )
    provenance = projection.provenance()
    provenance["collection_at"] = projection.collection_at or projection.effective_at
    return ScientificObservationRef(
        observation_ref_id=_stable_ref_id(
            patient_id=projection.patient_id,
            source_module=projection.source_module,
            source_entity_type=projection.source_entity_type,
            source_entity_id=projection.source_entity_id,
            source_version=projection.source_version,
            concept=projection.concept,
            effective_at=effective,
        ),
        patient_id=projection.patient_id,
        concept=projection.concept,
        value=projection.value,
        unit=projection.unit,
        effective_at=effective,
        source_module=projection.source_module,
        source_entity_type=projection.source_entity_type,
        source_entity_id=projection.source_entity_id,
        source_version=projection.source_version,
        authority=projection.authority,
        layer=MapLayer.OBJECTIVE,
        provenance=provenance,
        fasting_status=projection.fasting_status,
        context=dict(projection.context),
        labels={"label": projection.concept},
    )


def bioimpedance_to_refs(
    projection: BioimpedanceSummaryProjection,
) -> list[ScientificObservationRef]:
    effective = _require_effective_at(projection.effective_at, entity="BIOIMPEDANCE")
    refs: list[ScientificObservationRef] = []
    for measurement in projection.measurements:
        refs.append(
            ScientificObservationRef(
                observation_ref_id=_stable_ref_id(
                    patient_id=projection.patient_id,
                    source_module=projection.source_module,
                    source_entity_type=projection.source_entity_type,
                    source_entity_id=projection.source_entity_id,
                    source_version=projection.source_version,
                    concept=measurement.concept,
                    effective_at=effective,
                ),
                patient_id=projection.patient_id,
                concept=measurement.concept,
                value=measurement.value,
                unit=measurement.unit,
                effective_at=effective,
                source_module=projection.source_module,
                source_entity_type=projection.source_entity_type,
                source_entity_id=projection.source_entity_id,
                source_version=projection.source_version,
                authority=projection.authority,
                layer=MapLayer.OBJECTIVE,
                provenance=projection.provenance(),
                context={},
                labels={"label": measurement.concept},
            )
        )
    return refs


def nutrition_to_refs(
    projection: NutritionAssessmentProjection,
) -> list[ScientificObservationRef]:
    effective = _require_effective_at(projection.effective_at, entity="NUTROLOGIA")
    refs: list[ScientificObservationRef] = []

    def _make(concept: str, value: float, unit: str, label: str) -> ScientificObservationRef:
        return ScientificObservationRef(
            observation_ref_id=_stable_ref_id(
                patient_id=projection.patient_id,
                source_module=projection.source_module,
                source_entity_type=projection.source_entity_type,
                source_entity_id=projection.source_entity_id,
                source_version=projection.source_version,
                concept=concept,
                effective_at=effective,
            ),
            patient_id=projection.patient_id,
            concept=concept,
            value=value,
            unit=unit,
            effective_at=effective,
            source_module=projection.source_module,
            source_entity_type=projection.source_entity_type,
            source_entity_id=projection.source_entity_id,
            source_version=projection.source_version,
            authority=projection.authority,
            layer=MapLayer.DERIVED,
            labels={"label": label},
        )

    if projection.energy_target_kcal is not None:
        refs.append(_make(ENERGY_TARGET, projection.energy_target_kcal, "kcal", "Energy target"))
    if projection.protein_target_g is not None:
        refs.append(_make(PROTEIN_TARGET, projection.protein_target_g, "g", "Protein target"))
    return refs


def integrative_to_refs(
    projection: IntegrativeIntakeSummary,
) -> list[ScientificObservationRef]:
    effective = _require_effective_at(projection.effective_at, entity="INTEGRATIVA")
    refs: list[ScientificObservationRef] = []
    for response in projection.responses:
        refs.append(
            ScientificObservationRef(
                observation_ref_id=_stable_ref_id(
                    patient_id=projection.patient_id,
                    source_module=projection.source_module,
                    source_entity_type=projection.source_entity_type,
                    source_entity_id=projection.source_entity_id,
                    source_version=projection.source_version,
                    concept=response.question_code,
                    effective_at=effective,
                ),
                patient_id=projection.patient_id,
                concept=response.question_code,
                value=response.value,
                unit=response.unit,
                effective_at=effective,
                source_module=projection.source_module,
                source_entity_type=projection.source_entity_type,
                source_entity_id=projection.source_entity_id,
                source_version=projection.source_version,
                authority=projection.authority,
                layer=MapLayer.PATIENT_REPORTED,
                context={"domain": response.domain},
                labels={"label": response.question_code},
            )
        )
    return refs


def patient_reported_to_ref(projection: PatientReportedFact) -> ScientificObservationRef:
    effective = _require_effective_at(projection.effective_at, entity="PATIENT_AREA")
    return ScientificObservationRef(
        observation_ref_id=_stable_ref_id(
            patient_id=projection.patient_id,
            source_module=projection.source_module,
            source_entity_type=projection.source_entity_type,
            source_entity_id=projection.source_entity_id,
            source_version=projection.source_version,
            concept=projection.concept,
            effective_at=effective,
        ),
        patient_id=projection.patient_id,
        concept=projection.concept,
        value=projection.value,
        unit=projection.unit,
        effective_at=effective,
        source_module=projection.source_module,
        source_entity_type=projection.source_entity_type,
        source_entity_id=projection.source_entity_id,
        source_version=projection.source_version,
        authority=projection.authority,
        layer=MapLayer.PATIENT_REPORTED,
        labels={"label": projection.concept},
    )


def medication_to_ref(projection: MedicationSummaryProjection) -> ScientificObservationRef:
    effective = _require_effective_at(
        projection.started_at, entity="PRONTUARIO medication"
    )
    return ScientificObservationRef(
        observation_ref_id=_stable_ref_id(
            patient_id=projection.patient_id,
            source_module=projection.source_module,
            source_entity_type=projection.source_entity_type,
            source_entity_id=projection.source_entity_id,
            source_version=projection.source_version,
            concept="MEDICATION",
            effective_at=effective,
        ),
        patient_id=projection.patient_id,
        concept="MEDICATION",
        value=None,
        unit="1",
        effective_at=effective,
        source_module=projection.source_module,
        source_entity_type=projection.source_entity_type,
        source_entity_id=projection.source_entity_id,
        source_version=projection.source_version,
        authority=projection.authority,
        layer=MapLayer.CLINICIAN_CONFIRMED,
        context={
            "name": projection.name,
            "dose": projection.dose,
            "unit": projection.unit,
            "frequency": projection.frequency,
            "stopped_at": projection.stopped_at,
        },
        labels={"label": projection.name},
    )


def diagnosis_to_ref(projection: DiagnosisSummaryProjection) -> ScientificObservationRef:
    effective = _require_effective_at(
        projection.confirmed_at, entity="PRONTUARIO diagnosis"
    )
    return ScientificObservationRef(
        observation_ref_id=_stable_ref_id(
            patient_id=projection.patient_id,
            source_module=projection.source_module,
            source_entity_type=projection.source_entity_type,
            source_entity_id=projection.source_entity_id,
            source_version=projection.source_version,
            concept=projection.code or projection.label,
            effective_at=effective,
        ),
        patient_id=projection.patient_id,
        concept=projection.code or projection.label,
        value=None,
        unit="1",
        effective_at=effective,
        source_module=projection.source_module,
        source_entity_type=projection.source_entity_type,
        source_entity_id=projection.source_entity_id,
        source_version=projection.source_version,
        authority=ObservationAuthority.CLINICIAN_CONFIRMED,
        layer=MapLayer.CLINICIAN_CONFIRMED,
        context={"status": projection.status, "label": projection.label},
        labels={"label": projection.label or projection.code},
    )


class ProjectionIngestor:
    """Normalizes any supported inbound projection into observation refs."""

    def ingest(self, projection: Any) -> list[ScientificObservationRef]:
        if isinstance(projection, LabObservationProjection):
            return [lab_to_ref(projection)]
        if isinstance(projection, BioimpedanceSummaryProjection):
            return bioimpedance_to_refs(projection)
        if isinstance(projection, NutritionAssessmentProjection):
            return nutrition_to_refs(projection)
        if isinstance(projection, IntegrativeIntakeSummary):
            return integrative_to_refs(projection)
        if isinstance(projection, PatientReportedFact):
            return [patient_reported_to_ref(projection)]
        if isinstance(projection, MedicationSummaryProjection):
            return [medication_to_ref(projection)]
        if isinstance(projection, DiagnosisSummaryProjection):
            return [diagnosis_to_ref(projection)]
        raise ContractViolation(f"Unsupported projection type: {type(projection).__name__}")

    def ingest_many(self, projections: Iterable[Any]) -> list[ScientificObservationRef]:
        refs: list[ScientificObservationRef] = []
        for projection in projections:
            refs.extend(self.ingest(projection))
        return refs
