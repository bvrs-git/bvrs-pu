"""Formula registry: definitions, versioning and immutability."""
