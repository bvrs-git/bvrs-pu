"""Derived clinical metric engine.

Computes :class:`DerivedClinicalMetric` values from a formula and observation
references. The engine is deterministic, explainable and *refuses* to compute
when constraints fail. Failures are values (:class:`CalculationStatus`), never
silent substitutions and never exceptions.

Refusal precedence (documented, deterministic):

1. ``INSUFFICIENT_INPUT``    - a required input has no numeric observation
2. ``SOURCE_UNCONFIRMED``    - a required input is not from a confirmed source
3. ``UNIT_INCOMPATIBLE``     - an available input cannot be converted
4. ``TEMPORALLY_INCOMPATIBLE`` - no aligned observation set exists
5. ``OUTSIDE_DEFINED_DOMAIN`` - context/validity constraint not satisfied
6. ``ERROR``                 - expression failed at evaluation time
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ..core import ids
from ..core.context import EvaluationContext
from ..core.enums import (
    Authority,
    CalculationStatus,
    FastingStatus,
    PopulationContext,
    SexContext,
)
from ..core.expression import compile_expression
from ..core.timeutil import now_utc, span_days
from ..core.units import convert, is_known, same_dimension
from ..errors import ExpressionError, UnitConversionError, UnknownUnitError
from ..observations.refs import ScientificObservationRef
from .alignment import AlignmentResult, align_inputs
from .definition import ClinicalFormulaDefinition, FormulaInputRequirement


@dataclass
class InputResolution:
    name: str
    concept: str
    observation_ref_id: str
    original_value: float
    original_unit: str
    normalized_value: float
    normalized_unit: str
    conversion_applied: bool
    conversion_ref: str | None = None
    effective_at: str | None = None
    source_module: str | None = None
    laboratory: str | None = None
    method: str | None = None


@dataclass
class DerivedClinicalMetric:
    metric_id: str
    patient_id: str
    metric_definition_id: str
    metric_definition_version: int
    value: float | None
    unit: str
    computed_at: datetime
    effective_at: datetime | None
    calculation_status: CalculationStatus
    input_refs: list[dict[str, Any]] = field(default_factory=list)
    input_resolutions: list[InputResolution] = field(default_factory=list)
    formula_snapshot: dict[str, Any] = field(default_factory=dict)
    authority: Authority = Authority.SYSTEM_DERIVED
    warnings: list[str] = field(default_factory=list)
    missing_inputs: list[str] = field(default_factory=list)
    refusal_reason: str | None = None
    domain: str | None = None

    @property
    def is_valid(self) -> bool:
        return self.calculation_status.is_valid

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)


def _confirmed(ref: ScientificObservationRef) -> bool:
    from ..core.enums import is_confirmed_authority

    return is_confirmed_authority(ref.authority)


def _unit_compatible(ref: ScientificObservationRef, required_unit: str) -> bool:
    if not is_known(ref.unit):
        return False
    try:
        return same_dimension(ref.unit, required_unit)
    except UnknownUnitError:
        return False


def _refusal(
    formula: ClinicalFormulaDefinition,
    patient_id: str,
    status: CalculationStatus,
    *,
    computed_at: datetime,
    reason: str,
    missing_inputs: list[str] | None = None,
    input_refs: list[dict[str, Any]] | None = None,
) -> DerivedClinicalMetric:
    return DerivedClinicalMetric(
        metric_id=ids.metric_id(),
        patient_id=patient_id,
        metric_definition_id=formula.definition_id,
        metric_definition_version=formula.version,
        value=None,
        unit=formula.output_unit,
        computed_at=computed_at,
        effective_at=None,
        calculation_status=status,
        input_refs=input_refs or [],
        formula_snapshot=formula.to_dict(),
        warnings=list(formula.warnings),
        missing_inputs=missing_inputs or [],
        refusal_reason=reason,
        domain=formula.domain,
    )


def _context_mismatch(
    formula: ClinicalFormulaDefinition, context: EvaluationContext
) -> str | None:
    constraints = formula.population_constraints or {}
    if "sex" in constraints and context.sex.value not in constraints["sex"]:
        return f"requires sex in {constraints['sex']}, context={context.sex.value}"
    if "population" in constraints and context.population.value not in constraints["population"]:
        return (
            f"requires population in {constraints['population']}, "
            f"context={context.population.value}"
        )
    if context.population is PopulationContext.PREGNANT and not constraints.get(
        "allow_pregnancy", [False]
    )[0]:
        return "formula is not validated for pregnancy"
    if context.population is PopulationContext.PEDIATRIC and not constraints.get(
        "allow_pediatric", [False]
    )[0]:
        return "adult formula must not be applied to a pediatric patient"
    if "min_age" in constraints:
        if context.age_years is None:
            return "age context is required but unknown"
        if context.age_years < float(constraints["min_age"][0]):
            return f"age {context.age_years} below minimum {constraints['min_age'][0]}"
    if "max_age" in constraints:
        if context.age_years is None:
            return "age context is required but unknown"
        if context.age_years > float(constraints["max_age"][0]):
            return f"age {context.age_years} above maximum {constraints['max_age'][0]}"
    return None


def compute_metric(
    formula: ClinicalFormulaDefinition,
    refs_by_concept: dict[str, list[ScientificObservationRef]],
    *,
    patient_id: str,
    context: EvaluationContext | None = None,
    computed_at: datetime | None = None,
) -> DerivedClinicalMetric:
    """Compute a derived metric or a typed refusal."""
    context = context or EvaluationContext()
    computed_at = computed_at or now_utc()

    available_snapshots: list[dict[str, Any]] = []
    for refs in refs_by_concept.values():
        available_snapshots.extend(r.snapshot() for r in refs)

    # --- 1. presence of numeric observations ------------------------------
    candidates_by_name: dict[str, list[ScientificObservationRef]] = {}
    missing: list[str] = []
    for requirement in formula.inputs:
        numeric = [
            r
            for r in refs_by_concept.get(requirement.concept, [])
            if r.value is not None
        ]
        if not numeric:
            if requirement.required:
                missing.append(requirement.name)
            continue
        candidates_by_name[requirement.name] = numeric
    if missing:
        return _refusal(
            formula,
            patient_id,
            CalculationStatus.INSUFFICIENT_INPUT,
            computed_at=computed_at,
            reason=f"missing required input(s): {', '.join(missing)}",
            missing_inputs=missing,
            input_refs=available_snapshots,
        )

    # --- 2. source authority ---------------------------------------------
    by_name = {r.name: r for r in formula.inputs}
    for name, candidates in list(candidates_by_name.items()):
        requirement = by_name[name]
        if requirement.requires_confirmed_source:
            confirmed = [r for r in candidates if _confirmed(r)]
            if not confirmed:
                return _refusal(
                    formula,
                    patient_id,
                    CalculationStatus.SOURCE_UNCONFIRMED,
                    computed_at=computed_at,
                    reason=f"input {name!r} is not from a confirmed source",
                    input_refs=[r.snapshot() for r in candidates],
                )
            candidates_by_name[name] = confirmed

    # --- 3. unit compatibility --------------------------------------------
    for name, candidates in list(candidates_by_name.items()):
        requirement = by_name[name]
        compatible = [r for r in candidates if _unit_compatible(r, requirement.required_unit)]
        if not compatible:
            return _refusal(
                formula,
                patient_id,
                CalculationStatus.UNIT_INCOMPATIBLE,
                computed_at=computed_at,
                reason=(
                    f"input {name!r} cannot be expressed in {requirement.required_unit!r}"
                ),
                input_refs=[r.snapshot() for r in candidates],
            )
        candidates_by_name[name] = compatible

    # --- 4. temporal alignment --------------------------------------------
    alignment: AlignmentResult = align_inputs(
        candidates_by_name, formula.temporal_requirement, formula.temporal_window_days
    )
    if not alignment.ok or alignment.effective_at is None:
        return _refusal(
            formula,
            patient_id,
            CalculationStatus.TEMPORALLY_INCOMPATIBLE,
            computed_at=computed_at,
            reason=alignment.reason,
            input_refs=available_snapshots,
        )

    # --- 5. explicit, validated conversion --------------------------------
    resolutions: list[InputResolution] = []
    variables: dict[str, Any] = {}
    for name, ref in alignment.mapping.items():
        requirement = by_name[name]
        original = float(ref.value)  # value checked non-None above
        try:
            normalized = convert(original, ref.unit, requirement.required_unit)
        except (UnitConversionError, UnknownUnitError) as exc:
            return _refusal(
                formula,
                patient_id,
                CalculationStatus.UNIT_INCOMPATIBLE,
                computed_at=computed_at,
                reason=f"input {name!r}: {exc}",
                input_refs=[ref.snapshot()],
            )
        conversion_applied = normalized != original or ref.unit != requirement.required_unit
        resolutions.append(
            InputResolution(
                name=name,
                concept=requirement.concept,
                observation_ref_id=ref.observation_ref_id,
                original_value=original,
                original_unit=ref.unit,
                normalized_value=normalized,
                normalized_unit=requirement.required_unit,
                conversion_applied=conversion_applied,
                conversion_ref=(
                    f"{ref.unit}->{requirement.required_unit}" if conversion_applied else None
                ),
                effective_at=ref.effective_at.isoformat(),
                source_module=ref.source_module,
                laboratory=ref.provenance.get("laboratory"),
                method=ref.provenance.get("method"),
            )
        )
        variables[name] = normalized

    input_refs = [ref.snapshot() for ref in alignment.mapping.values()]

    # --- 6. context / population domain -----------------------------------
    mismatch = _context_mismatch(formula, context)
    if mismatch is not None:
        return _refusal(
            formula,
            patient_id,
            CalculationStatus.OUTSIDE_DEFINED_DOMAIN,
            computed_at=computed_at,
            reason=mismatch,
            input_refs=input_refs,
        )

    # --- 7. validity constraints (defined domain) -------------------------
    for constraint in formula.validity_constraints:
        try:
            ok = bool(compile_expression(constraint).evaluate(variables))
        except ExpressionError as exc:
            return _refusal(
                formula,
                patient_id,
                CalculationStatus.ERROR,
                computed_at=computed_at,
                reason=f"validity constraint failed: {exc}",
                input_refs=input_refs,
            )
        if not ok:
            return _refusal(
                formula,
                patient_id,
                CalculationStatus.OUTSIDE_DEFINED_DOMAIN,
                computed_at=computed_at,
                reason=f"validity constraint not satisfied: {constraint}",
                input_refs=input_refs,
            )

    # --- 8. evaluate the constrained expression ---------------------------
    try:
        value = float(compile_expression(formula.expression).evaluate(variables))
    except ExpressionError as exc:
        return _refusal(
            formula,
            patient_id,
            CalculationStatus.ERROR,
            computed_at=computed_at,
            reason=f"expression error: {exc}",
            input_refs=input_refs,
        )
    except (ZeroDivisionError, ValueError, TypeError) as exc:
        return _refusal(
            formula,
            patient_id,
            CalculationStatus.ERROR,
            computed_at=computed_at,
            reason=f"computation error: {exc}",
            input_refs=input_refs,
        )

    warnings = list(formula.warnings)
    warnings.extend(_context_warnings(resolutions, alignment))

    return DerivedClinicalMetric(
        metric_id=ids.metric_id(),
        patient_id=patient_id,
        metric_definition_id=formula.definition_id,
        metric_definition_version=formula.version,
        value=value,
        unit=formula.output_unit,
        computed_at=computed_at,
        effective_at=alignment.effective_at,
        calculation_status=CalculationStatus.VALID,
        input_refs=input_refs,
        input_resolutions=resolutions,
        formula_snapshot=formula.to_dict(),
        warnings=warnings,
        domain=formula.domain,
    )


def _context_warnings(
    resolutions: list[InputResolution], alignment: AlignmentResult
) -> list[str]:
    warnings: list[str] = []
    if any(r.conversion_applied for r in resolutions):
        conversions = ", ".join(
            f"{r.name}:{r.conversion_ref}" for r in resolutions if r.conversion_applied
        )
        warnings.append(f"UNIT_CONVERSION_APPLIED ({conversions})")
    labs = {r.laboratory for r in resolutions if r.laboratory}
    if len(labs) > 1:
        warnings.append("LABORATORY_CONTEXT_DIFFERS - comparability not assumed")
    methods = {r.method for r in resolutions if r.method}
    if len(methods) > 1:
        warnings.append("METHOD_CONTEXT_DIFFERS - comparability not assumed")
    span = span_days([r.effective_at for r in resolutions if r.effective_at])
    if span > 1:
        warnings.append(f"INPUTS_SPAN_{round(span)}_DAYS")
    return warnings
