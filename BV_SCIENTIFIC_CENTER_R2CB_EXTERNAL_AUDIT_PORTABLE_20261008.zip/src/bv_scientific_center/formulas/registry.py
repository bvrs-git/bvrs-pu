"""Formula registry with publication-time validation."""

from __future__ import annotations

from ..core.enums import TemporalRequirement
from ..core.expression import compile_expression
from ..core.registry import DefinitionRegistry
from ..core.units import is_known
from ..errors import ExpressionError, UnknownUnitError
from .definition import ClinicalFormulaDefinition


def validate_formula(formula: ClinicalFormulaDefinition) -> None:
    if not formula.definition_id:
        raise ExpressionError("Formula requires a definition_id")
    if not formula.expression:
        raise ExpressionError(f"Formula {formula.definition_id} has no expression")

    compiled = compile_expression(formula.expression)
    declared = set(formula.input_names())
    undeclared = compiled.names - declared
    if undeclared:
        raise ExpressionError(
            f"Formula {formula.definition_id} expression references undeclared "
            f"inputs: {sorted(undeclared)}"
        )

    names = [i.name for i in formula.inputs]
    if len(names) != len(set(names)):
        raise ExpressionError(f"Formula {formula.definition_id} has duplicate input names")

    for requirement in formula.inputs:
        if not is_known(requirement.required_unit):
            raise UnknownUnitError(
                f"Formula {formula.definition_id} input {requirement.name!r} "
                f"uses unknown unit {requirement.required_unit!r}"
            )
    if not is_known(formula.output_unit):
        raise UnknownUnitError(
            f"Formula {formula.definition_id} output unit {formula.output_unit!r} is unknown"
        )

    if formula.temporal_requirement is TemporalRequirement.WITHIN_N_DAYS and (
        not formula.temporal_window_days or formula.temporal_window_days <= 0
    ):
        raise ExpressionError(
            f"Formula {formula.definition_id} requires a positive temporal_window_days"
        )

    for constraint in formula.validity_constraints:
        compile_expression(constraint)


class FormulaRegistry(DefinitionRegistry[ClinicalFormulaDefinition]):
    def __init__(self) -> None:
        super().__init__("formula", validate_formula)
