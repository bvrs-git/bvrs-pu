"""Temporal alignment of cross-domain inputs.

Never silently mix distant observations. The formula declares an acceptable
temporal relationship; this module selects one aligned observation per input or
reports that no aligned set exists (``TEMPORALLY_INCOMPATIBLE``).
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from datetime import datetime

from ..core.enums import TemporalRequirement
from ..core.timeutil import parse_dt, same_calendar_day, span_days
from ..observations.refs import ScientificObservationRef

_MAX_CANDIDATES_PER_INPUT = 6


@dataclass
class AlignmentResult:
    ok: bool
    mapping: dict[str, ScientificObservationRef] = field(default_factory=dict)
    effective_at: datetime | None = None
    reason: str = ""


def _timestamps(mapping: dict[str, ScientificObservationRef]) -> list[datetime]:
    return [parse_dt(r.effective_at) for r in mapping.values()]


def _predicate(
    mapping: dict[str, ScientificObservationRef],
    requirement: TemporalRequirement,
    window_days: int | None,
) -> bool:
    values = _timestamps(mapping)
    if requirement is TemporalRequirement.LATEST_AVAILABLE:
        return True
    if requirement is TemporalRequirement.SAME_COLLECTION:
        first = next(iter(mapping.values()))
        same_time = all(v == values[0] for v in values)
        same_source = all(
            (r.source_entity_id, r.source_module) == (first.source_entity_id, first.source_module)
            for r in mapping.values()
        )
        return same_time and same_source
    if requirement is TemporalRequirement.SAME_DAY:
        return all(same_calendar_day(values[0], v) for v in values)
    if requirement is TemporalRequirement.WITHIN_N_DAYS:
        return window_days is not None and span_days(values) <= window_days
    if requirement is TemporalRequirement.OTHER_EXPLICIT_RULE:
        # Explicit custom rule: only enforce a window if one is declared.
        return window_days is None or span_days(values) <= window_days
    return False


def align_inputs(
    candidates_by_name: dict[str, list[ScientificObservationRef]],
    requirement: TemporalRequirement,
    window_days: int | None = None,
) -> AlignmentResult:
    if not candidates_by_name:
        return AlignmentResult(ok=False, reason="no inputs to align")

    # Most-recent first, bounded to keep the search small and deterministic.
    ordered: dict[str, list[ScientificObservationRef]] = {}
    for name, refs in candidates_by_name.items():
        ordered[name] = sorted(refs, key=lambda r: parse_dt(r.effective_at), reverse=True)[
            :_MAX_CANDIDATES_PER_INPUT
        ]
        if not ordered[name]:
            return AlignmentResult(ok=False, reason=f"no candidates for input {name!r}")

    if requirement is TemporalRequirement.LATEST_AVAILABLE:
        mapping = {name: refs[0] for name, refs in ordered.items()}
        return AlignmentResult(ok=True, mapping=mapping, effective_at=max(_timestamps(mapping)))

    names = list(ordered)
    best: dict[str, ScientificObservationRef] | None = None
    best_key: tuple | None = None
    for combo in itertools.product(*(ordered[n] for n in names)):
        mapping = dict(zip(names, combo))
        if not _predicate(mapping, requirement, window_days):
            continue
        values = _timestamps(mapping)
        key = (max(values), -span_days(values))
        if best_key is None or key > best_key:
            best_key = key
            best = mapping

    if best is None:
        return AlignmentResult(
            ok=False,
            reason=(
                f"no set of observations satisfies {requirement.value}"
                + (f" within {window_days} days" if window_days else "")
            ),
        )
    return AlignmentResult(ok=True, mapping=best, effective_at=max(_timestamps(best)))
