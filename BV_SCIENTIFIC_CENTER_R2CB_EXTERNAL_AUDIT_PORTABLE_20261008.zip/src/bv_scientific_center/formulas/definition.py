"""Clinical formula definitions.

A formula declares:

* the exact inputs it needs (concept + required unit + whether a confirmed
  source is mandatory);
* the temporal relationship its inputs must satisfy;
* a constrained arithmetic expression over those inputs (see
  :mod:`bv_scientific_center.core.expression`);
* optional validity constraints, context population requirements and warnings;
* evidence references.

It never contains code and never mutates measured data.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.definition import VersionedDefinition
from ..core.enums import DefinitionStatus, TemporalRequirement


@dataclass(frozen=True)
class FormulaInputRequirement:
    name: str                       # variable name used inside the expression
    concept: str                    # canonical concept code
    required_unit: str              # unit the expression expects
    required: bool = True
    requires_confirmed_source: bool = True
    label: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "FormulaInputRequirement":
        return cls(
            name=data["name"],
            concept=data["concept"],
            required_unit=data.get("required_unit", "1"),
            required=bool(data.get("required", True)),
            requires_confirmed_source=bool(data.get("requires_confirmed_source", True)),
            label=data.get("label"),
        )


@dataclass(frozen=True)
class ClinicalFormulaDefinition(VersionedDefinition):
    """A single, versioned derived-metric formula."""

    inputs: tuple[FormulaInputRequirement, ...] = ()
    output_unit: str = "1"
    expression: str = ""
    temporal_requirement: TemporalRequirement = TemporalRequirement.LATEST_AVAILABLE
    temporal_window_days: int | None = None
    validity_constraints: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    domain: str | None = None
    # e.g. {"sex": ["MALE"], "population": ["ADULT"]}
    population_constraints: dict[str, list[str]] = field(default_factory=dict)
    output_label: str | None = None

    def input_names(self) -> tuple[str, ...]:
        return tuple(i.name for i in self.inputs)

    def required_input_names(self) -> tuple[str, ...]:
        return tuple(i.name for i in self.inputs if i.required)

    @classmethod
    def from_dict(cls, data: dict) -> "ClinicalFormulaDefinition":
        from ..core.definition import coerce_enum

        return cls(
            definition_id=data["definition_id"],
            name=data.get("name", data["definition_id"]),
            version=int(data.get("version", 1)),
            description=data.get("description", ""),
            status=coerce_enum(DefinitionStatus, data.get("status", "DRAFT")),
            evidence_refs=tuple(data.get("evidence_refs", ())),
            metadata=dict(data.get("metadata", {})),
            inputs=tuple(
                FormulaInputRequirement.from_dict(i) for i in data.get("inputs", ())
            ),
            output_unit=data.get("output_unit", "1"),
            expression=data.get("expression", ""),
            temporal_requirement=coerce_enum(
                TemporalRequirement, data.get("temporal_requirement", "LATEST_AVAILABLE")
            ),
            temporal_window_days=data.get("temporal_window_days"),
            validity_constraints=tuple(data.get("validity_constraints", ())),
            warnings=tuple(data.get("warnings", ())),
            domain=data.get("domain"),
            population_constraints=dict(data.get("population_constraints", {})),
            output_label=data.get("output_label"),
        )
