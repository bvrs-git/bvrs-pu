"""A minimal in-process event bus.

Only meaningful domain events are published (spec §83). Map rendering is a pure
projection and is deliberately NOT published as an event. Consumers such as the
Prontuario (future) subscribe to reviewed/important signals - not to every
internal calculation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable

from ..core import ids
from ..core.timeutil import now_utc

EVENT_TYPES = (
    "DerivedMetricComputed",
    "ClinicalSignalGenerated",
    "ClinicalSignalReviewed",
    "KnowledgePackageActivated",
    "SynthesisRunCompleted",
)

Handler = Callable[["Event"], None]


@dataclass
class Event:
    event_type: str
    payload: dict[str, Any] = field(default_factory=dict)
    patient_id: str | None = None
    run_id: str | None = None
    event_id: str = field(default_factory=ids.event_id)
    created_at: datetime = field(default_factory=now_utc)

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type,
            "patient_id": self.patient_id,
            "run_id": self.run_id,
            "payload": self.payload,
            "created_at": self.created_at,
        }


class EventBus:
    def __init__(self, *, recorder: Callable[[Event], None] | None = None) -> None:
        self._handlers: dict[str, list[Handler]] = {}
        self._recorder = recorder
        self.events: list[Event] = []

    def subscribe(self, event_type: str, handler: Handler) -> None:
        if event_type not in EVENT_TYPES:
            raise ValueError(f"Unknown event type: {event_type!r}")
        self._handlers.setdefault(event_type, []).append(handler)

    def publish(self, event: Event) -> Event:
        if event.event_type not in EVENT_TYPES:
            raise ValueError(f"Unknown event type: {event.event_type!r}")
        self.events.append(event)
        if self._recorder is not None:
            self._recorder(event)
        for handler in self._handlers.get(event.event_type, []):
            handler(event)
        return event

    def emit(
        self,
        event_type: str,
        *,
        payload: dict[str, Any] | None = None,
        patient_id: str | None = None,
        run_id: str | None = None,
    ) -> Event:
        return self.publish(
            Event(
                event_type=event_type,
                payload=payload or {},
                patient_id=patient_id,
                run_id=run_id,
            )
        )
