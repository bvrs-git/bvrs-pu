"""Command-line entry point for the BV Scientific Center.

    python -m bv_scientific_center demo      # in-memory synthetic demo
    python -m bv_scientific_center report    # print critical-gate report
    python -m bv_scientific_center serve     # start the minimal UI (read-only)
    python -m bv_scientific_center backup    # safe, verified SQLite backup
    python -m bv_scientific_center curate    # local administrative curation
"""

from __future__ import annotations

import argparse
import json
import sys

from .app import ScientificCenterApp


def _build_app(args: argparse.Namespace) -> ScientificCenterApp:
    if args.command == "demo":
        return ScientificCenterApp(memory=True)
    return ScientificCenterApp(args.data_dir)


def _demo(app: ScientificCenterApp) -> int:
    summary = app.bootstrap_synthetic()
    print("BV Scientific Center - synthetic demo")
    for key, value in summary.items():
        print(f"  {key}: {value}")
    scientific = app.bootstrap_scientific()
    print("  scientific curation seed:")
    for key, value in scientific.items():
        print(f"    {key}: {value}")
    projection = app.build_map(app.reproduce_run(summary["patient_id"]))
    print(f"  map nodes: {len(projection.nodes)}  map edges: {len(projection.edges)}")
    return 0


def _report(app: ScientificCenterApp) -> int:
    summary = app.bootstrap_synthetic()
    patient_id = summary["patient_id"]
    overview = app.patient_overview(patient_id)
    print("BV_SCIENTIFIC_CENTER_R1 = STANDALONE")
    print(f"SYNTHETIC_PATIENT = {patient_id}")
    print(f"RUN = {summary['run_id']}")
    print(f"DERIVED_METRICS = {summary['metrics']} (valid {summary['valid_metrics']})")
    print(f"SCORES = {summary['scores']}")
    print(f"SIGNALS = {summary['signals']}")
    print(f"OBSERVATIONS = {overview['counts']['observations']}")
    return 0


def _serve(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    if not app.list_patients():
        print("No data found - seeding synthetic fixtures ...")
        app.bootstrap_synthetic()
    if not app.references.list():
        app.bootstrap_scientific()
    from .ui.server import serve

    print(f"BV Scientific Center UI on http://{args.host}:{args.port} (read-only)")
    serve(app, args.host, args.port)
    return 0


def _backup(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    from .storage.backup import safe_backup

    sources = args.source or [
        args.data_dir + "/knowledge.db",
        args.data_dir + "/derived.db",
    ]
    reports = []
    for source in sources:
        report = safe_backup(source, args.dest, label=args.label)
        print(f"BACKUP OK {report['destination']}")
        print(f"  sha256={report['sha256']}")
        print(f"  integrity_check={report['integrity_check']} fk_violations={report['foreign_key_violations']}")
        reports.append(report)
    print(f"BACKUPS = {len(reports)}")
    return 0


def _curate(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    from .knowledge.curation import CurationService  # noqa: F401
    from .knowledge.scientific import CurationStatus, CurationSubjectType

    subject = {
        "reference": CurationSubjectType.REFERENCE,
        "evidence": CurationSubjectType.EVIDENCE,
        "claim": CurationSubjectType.CLAIM,
    }[args.subject]

    if args.action == "approve":
        outcome = app.curation.approve(
            subject, args.id, reviewer=args.actor, justification=args.justification
        )
    elif args.action == "retract":
        outcome = app.curation.retract(subject, args.id, actor=args.actor, reason=args.reason)
    else:
        target = {
            "screen": CurationStatus.SCREENED,
            "curate": CurationStatus.CURATED,
            "reject": CurationStatus.REJECTED,
            "supersede": CurationStatus.SUPERSEDED,
        }[args.action]
        outcome = app.curation.transition(
            subject, args.id, target, actor=args.actor, justification=args.justification
        )
    print(json.dumps(outcome.to_dict(), indent=2, ensure_ascii=False))
    return 0


def _acquire(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    result = app.acquire_by_doi(args.doi)
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


def _corpus(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    from .bibliography.corpus import acquire_corpus, import_corpus

    if args.acquire:
        result = acquire_corpus(app.crossref, args.path)
    else:
        result = import_corpus(app, args.path)
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


def _review_export(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    payload = app.export_review_queue(args.format)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(payload)
        print(f"WROTE {args.out} ({len(payload)} bytes)")
    else:
        print(payload)
    return 0


def _content_review(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    reference = app.set_content_review(args.id, args.status, reviewer=args.reviewer)
    print(
        f"{reference.reference_id} content_review_status={reference.content_review_status.value}"
    )
    return 0


def _candidates(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    print(json.dumps(app.formula_candidates_list(), indent=2, ensure_ascii=False, default=str))
    return 0


def _dossier(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    payload = app.export_candidate_dossier(args.id, args.format)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(payload)
        print(f"WROTE {args.out} ({len(payload)} bytes)")
    else:
        print(payload)
    return 0


def _human_review(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    print(json.dumps(app.human_review_queue(), indent=2, ensure_ascii=False, default=str))
    return 0


def _medical_dossier(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    payload = app.export_dossier(args.id, args.format)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(payload)
        print(f"WROTE {args.out} ({len(payload)} bytes)")
    else:
        print(payload)
    return 0


def _dossier_index(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    print(json.dumps(app.dossier_index(), indent=2, ensure_ascii=False, default=str))
    return 0


def _review_decision(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    if not (args.id and args.decision and args.actor and args.justification):
        print(
            "review-decision requires --id, --decision, --actor and --justification",
            file=sys.stderr,
        )
        return 2
    decision_id = app.record_review_decision(
        args.id, args.decision, actor=args.actor, justification=args.justification
    )
    print(f"RECORDED {decision_id} (recorded, not executed)")
    return 0


def _reconcile(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    print(json.dumps(app.reconciliation(), indent=2, ensure_ascii=False, default=str))
    return 0


def _extract(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    if args.acquire:
        result = app.bootstrap_r2cb()
    else:
        result = app.bootstrap_r2cb_offline()
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


def _formula_evidence(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    print(json.dumps(app.formula_evidence_matrix(), indent=2, ensure_ascii=False, default=str))
    return 0


def _applicability(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    print(json.dumps(app.applicability_matrix(), indent=2, ensure_ascii=False, default=str))
    return 0


def _freeze_content(app: ScientificCenterApp, args: argparse.Namespace) -> int:
    from .bibliography.snapshot import DEFAULT_CONTENT_SNAPSHOT, freeze_europepmc_corpus
    from .seed.r2ca_seed import SELECTED_DOIS

    result = freeze_europepmc_corpus(
        app.europepmc, SELECTED_DOIS, args.path or DEFAULT_CONTENT_SNAPSHOT
    )
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="bv-scientific-center", description=__doc__)
    parser.add_argument(
        "command",
        nargs="?",
        default="serve",
        choices=[
            "serve",
            "demo",
            "report",
            "backup",
            "curate",
            "acquire",
            "corpus",
            "review-export",
            "content-review",
            "candidates",
            "dossier",
            "human-review",
            "medical-dossier",
            "dossier-index",
            "review-decision",
            "reconcile",
            "extract",
            "formula-evidence",
            "applicability",
            "freeze-content",
        ],
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--data-dir", default="data/runtime", help="Directory with knowledge.db/derived.db")

    backup = parser.add_argument_group("backup")
    backup.add_argument("--source", action="append", help="Database file to back up (repeatable)")
    backup.add_argument("--dest", default="data/runtime/backup", help="Backup destination directory")
    backup.add_argument("--label", default=None)

    curate = parser.add_argument_group("curate")
    curate.add_argument("--subject", choices=["reference", "evidence", "claim"])
    curate.add_argument("--id", dest="id")
    curate.add_argument(
        "--action",
        choices=["screen", "curate", "approve", "reject", "supersede", "retract"],
    )
    curate.add_argument("--actor", default=None, help="Reviewer/actor identity (required to approve)")
    curate.add_argument("--justification", default=None)
    curate.add_argument("--reason", default=None, help="Retraction reason")
    curate.add_argument(
        "--decision",
        default=None,
        help="Medical review decision (ACCEPT_FOR_CONSIDERATION|REQUEST_REVISION|REJECT|KEEP_PENDING)",
    )

    bib = parser.add_argument_group("bibliography")
    bib.add_argument("--doi", default=None, help="DOI for acquisition")
    bib.add_argument("--path", default="data/seed/corpus_bibliography.json")
    bib.add_argument("--acquire", action="store_true", help="Acquire corpus online (else import offline)")
    bib.add_argument("--format", choices=["json", "csv", "md"], default="json")
    bib.add_argument("--out", default=None, help="Output file for review-export")
    bib.add_argument("--status", default=None, help="Content review status")
    bib.add_argument("--reviewer", default=None)

    args = parser.parse_args(argv)

    if args.command == "curate" and not (args.subject and args.id and args.action):
        parser.error("curate requires --subject, --id and --action")

    app = _build_app(args)
    try:
        if args.command == "demo":
            return _demo(app)
        if args.command == "report":
            return _report(app)
        if args.command == "backup":
            return _backup(app, args)
        if args.command == "curate":
            return _curate(app, args)
        if args.command == "acquire":
            if not args.doi:
                parser.error("acquire requires --doi")
            return _acquire(app, args)
        if args.command == "corpus":
            return _corpus(app, args)
        if args.command == "review-export":
            return _review_export(app, args)
        if args.command == "content-review":
            if not (args.id and args.status):
                parser.error("content-review requires --id and --status")
            return _content_review(app, args)
        if args.command == "candidates":
            return _candidates(app, args)
        if args.command == "dossier":
            if not args.id:
                parser.error("dossier requires --id")
            return _dossier(app, args)
        if args.command == "human-review":
            return _human_review(app, args)
        if args.command == "medical-dossier":
            if not args.id:
                parser.error("medical-dossier requires --id")
            return _medical_dossier(app, args)
        if args.command == "dossier-index":
            return _dossier_index(app, args)
        if args.command == "review-decision":
            return _review_decision(app, args)
        if args.command == "reconcile":
            return _reconcile(app, args)
        if args.command == "extract":
            return _extract(app, args)
        if args.command == "formula-evidence":
            return _formula_evidence(app, args)
        if args.command == "applicability":
            return _applicability(app, args)
        if args.command == "freeze-content":
            return _freeze_content(app, args)
        return _serve(app, args)
    finally:
        app.close()


if __name__ == "__main__":
    sys.exit(main())
