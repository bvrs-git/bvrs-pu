"""Inbound projections consumed by the Scientific Center.

These DTOs are the *only* way data enters the module from other BV modules.
Importing another module's repository or ORM entity is forbidden by design.

Each projection carries ``source_module``, ``source_entity_type``,
``source_entity_id`` and ``source_version`` so the Scientific Center can build
a :class:`~bv_scientific_center.observations.refs.ScientificObservationRef`
without cloning source tables.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.enums import (
    FastingStatus,
    ObservationAuthority,
    PopulationContext,
    SexContext,
)
from ..core.timeutil import parse_dt


def _authority(value: Any) -> ObservationAuthority:
    if isinstance(value, ObservationAuthority):
        return value
    return ObservationAuthority(str(value))


def _fasting(value: Any) -> FastingStatus:
    if isinstance(value, FastingStatus):
        return value
    try:
        return FastingStatus(str(value))
    except ValueError:
        return FastingStatus.UNKNOWN


def _sex(value: Any) -> SexContext:
    if isinstance(value, SexContext):
        return value
    try:
        return SexContext(str(value).upper())
    except (ValueError, AttributeError):
        return SexContext.UNKNOWN


def _population(value: Any) -> PopulationContext:
    if isinstance(value, PopulationContext):
        return value
    try:
        return PopulationContext(str(value).upper())
    except (ValueError, AttributeError):
        return PopulationContext.UNKNOWN


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------
@dataclass
class ProjectionBase:
    # Defaults keep dataclass field ordering valid for subclasses that override
    # source_module/source_entity_type. Required-ness is enforced by from_dict.
    patient_id: str = ""
    source_module: str = ""
    source_entity_type: str = ""
    source_entity_id: str = ""
    source_version: str = "1"

    def header(self) -> dict[str, str]:
        return {
            "patient_id": self.patient_id,
            "source_module": self.source_module,
            "source_entity_type": self.source_entity_type,
            "source_entity_id": self.source_entity_id,
            "source_version": self.source_version,
        }


# ---------------------------------------------------------------------------
# LAB
# ---------------------------------------------------------------------------
@dataclass
class LabObservationProjection(ProjectionBase):
    """A single laboratory observation owned by the LAB module.

    ``authority`` defaults to ``LAB_CONFIRMED``; document-extracted but
    unreviewed values must arrive as ``DOCUMENT_EXTRACTED_UNREVIEWED`` so a
    formula requiring a confirmed source refuses with ``SOURCE_UNCONFIRMED``.
    """

    source_module: str = "LAB"
    source_entity_type: str = "LabObservation"
    concept: str = ""
    value: float | None = None
    unit: str = ""
    effective_at: str | None = None
    authority: ObservationAuthority = ObservationAuthority.LAB_CONFIRMED
    method: str | None = None
    matrix: str | None = None
    laboratory: str | None = None
    collection_at: str | None = None
    fasting_status: FastingStatus = FastingStatus.UNKNOWN
    context: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LabObservationProjection":
        return cls(
            patient_id=data["patient_id"],
            source_entity_id=data["source_entity_id"],
            source_version=str(data.get("source_version", "1")),
            concept=data["concept"],
            value=None if data.get("value") is None else float(data["value"]),
            unit=data["unit"],
            effective_at=data.get("effective_at"),
            authority=_authority(data.get("authority", ObservationAuthority.LAB_CONFIRMED)),
            method=data.get("method"),
            matrix=data.get("matrix"),
            laboratory=data.get("laboratory"),
            collection_at=data.get("collection_at"),
            fasting_status=_fasting(data.get("fasting_status", "UNKNOWN")),
            context=dict(data.get("context") or {}),
        )

    def provenance(self) -> dict[str, Any]:
        return {
            "method": self.method,
            "matrix": self.matrix,
            "laboratory": self.laboratory,
            "collection_at": self.collection_at,
        }


# ---------------------------------------------------------------------------
# BIOIMPEDANCE
# ---------------------------------------------------------------------------
@dataclass
class BioimpedanceMeasurement:
    concept: str
    value: float | None
    unit: str


@dataclass
class BioimpedanceSummaryProjection(ProjectionBase):
    source_module: str = "BIOIMPEDANCE"
    source_entity_type: str = "BioimpedanceSummary"
    effective_at: str | None = None
    authority: ObservationAuthority = ObservationAuthority.LAB_CONFIRMED
    measurements: list[BioimpedanceMeasurement] = field(default_factory=list)
    device: str | None = None
    method: str | None = None

    def __post_init__(self) -> None:
        self.measurements = [
            m if isinstance(m, BioimpedanceMeasurement) else BioimpedanceMeasurement(**m)
            for m in self.measurements
        ]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BioimpedanceSummaryProjection":
        return cls(
            patient_id=data["patient_id"],
            source_entity_id=data["source_entity_id"],
            source_version=str(data.get("source_version", "1")),
            effective_at=data.get("effective_at"),
            authority=_authority(data.get("authority", ObservationAuthority.LAB_CONFIRMED)),
            measurements=[BioimpedanceMeasurement(**m) for m in data.get("measurements", [])],
            device=data.get("device"),
            method=data.get("method"),
        )

    def provenance(self) -> dict[str, Any]:
        return {"device": self.device, "method": self.method}


# ---------------------------------------------------------------------------
# NUTROLOGIA
# ---------------------------------------------------------------------------
@dataclass
class NutritionAssessmentProjection(ProjectionBase):
    source_module: str = "NUTROLOGIA"
    source_entity_type: str = "NutritionAssessment"
    effective_at: str | None = None
    authority: ObservationAuthority = ObservationAuthority.CLINICIAN_CONFIRMED
    energy_target_kcal: float | None = None
    protein_target_g: float | None = None
    notes: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "NutritionAssessmentProjection":
        return cls(
            patient_id=data["patient_id"],
            source_entity_id=data["source_entity_id"],
            source_version=str(data.get("source_version", "1")),
            effective_at=data.get("effective_at"),
            authority=_authority(data.get("authority", ObservationAuthority.CLINICIAN_CONFIRMED)),
            energy_target_kcal=data.get("energy_target_kcal"),
            protein_target_g=data.get("protein_target_g"),
            notes=data.get("notes"),
        )


# ---------------------------------------------------------------------------
# INTEGRATIVA
# ---------------------------------------------------------------------------
@dataclass
class IntegrativeResponse:
    question_code: str
    domain: str
    value: float | None
    unit: str = "1"


@dataclass
class IntegrativeIntakeSummary(ProjectionBase):
    source_module: str = "INTEGRATIVA"
    source_entity_type: str = "IntegrativeIntake"
    effective_at: str | None = None
    authority: ObservationAuthority = ObservationAuthority.PATIENT_REPORTED
    responses: list[IntegrativeResponse] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.responses = [
            r if isinstance(r, IntegrativeResponse) else IntegrativeResponse(**r)
            for r in self.responses
        ]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "IntegrativeIntakeSummary":
        return cls(
            patient_id=data["patient_id"],
            source_entity_id=data["source_entity_id"],
            source_version=str(data.get("source_version", "1")),
            effective_at=data.get("effective_at"),
            authority=_authority(data.get("authority", ObservationAuthority.PATIENT_REPORTED)),
            responses=[IntegrativeResponse(**r) for r in data.get("responses", [])],
        )


# ---------------------------------------------------------------------------
# Patient-reported fact
# ---------------------------------------------------------------------------
@dataclass
class PatientReportedFact(ProjectionBase):
    source_module: str = "PATIENT_AREA"
    source_entity_type: str = "PatientReportedFact"
    concept: str = ""
    value: float | None = None
    unit: str = "1"
    effective_at: str | None = None
    authority: ObservationAuthority = ObservationAuthority.PATIENT_REPORTED

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PatientReportedFact":
        return cls(
            patient_id=data["patient_id"],
            source_entity_id=data["source_entity_id"],
            source_version=str(data.get("source_version", "1")),
            concept=data["concept"],
            value=None if data.get("value") is None else float(data["value"]),
            unit=data.get("unit", "1"),
            effective_at=data.get("effective_at"),
            authority=_authority(data.get("authority", ObservationAuthority.PATIENT_REPORTED)),
        )


# ---------------------------------------------------------------------------
# PRONTUARIO (read-only consumption)
# ---------------------------------------------------------------------------
@dataclass
class DiagnosisSummaryProjection(ProjectionBase):
    source_module: str = "PRONTUARIO"
    source_entity_type: str = "Diagnosis"
    code: str = ""
    label: str = ""
    status: str = "ACTIVE"
    confirmed_at: str | None = None
    authority: ObservationAuthority = ObservationAuthority.CLINICIAN_CONFIRMED

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DiagnosisSummaryProjection":
        return cls(
            patient_id=data["patient_id"],
            source_entity_id=data["source_entity_id"],
            source_version=str(data.get("source_version", "1")),
            code=data.get("code", ""),
            label=data.get("label", ""),
            status=data.get("status", "ACTIVE"),
            confirmed_at=data.get("confirmed_at"),
        )


@dataclass
class MedicationSummaryProjection(ProjectionBase):
    source_module: str = "PRONTUARIO"
    source_entity_type: str = "Medication"
    name: str = ""
    dose: float | None = None
    unit: str | None = None
    frequency: str | None = None
    started_at: str | None = None
    stopped_at: str | None = None
    authority: ObservationAuthority = ObservationAuthority.CLINICIAN_CONFIRMED

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MedicationSummaryProjection":
        return cls(
            patient_id=data["patient_id"],
            source_entity_id=data["source_entity_id"],
            source_version=str(data.get("source_version", "1")),
            name=data.get("name", ""),
            dose=data.get("dose"),
            unit=data.get("unit"),
            frequency=data.get("frequency"),
            started_at=data.get("started_at"),
            stopped_at=data.get("stopped_at"),
        )


# ---------------------------------------------------------------------------
# Context (demographics, pregnancy, pediatric)
# ---------------------------------------------------------------------------
@dataclass
class PatientContextProjection:
    """Demographic / contextual information. Never inferred, only supplied."""

    patient_id: str
    source_module: str = "CONTEXT"
    source_entity_id: str = "context"
    source_version: str = "1"
    sex: SexContext = SexContext.UNKNOWN
    age_years: float | None = None
    population: PopulationContext = PopulationContext.UNKNOWN
    on_hormone_therapy: bool | None = None
    contraception: bool | None = None
    menopause: bool | None = None
    menstrual_phase: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PatientContextProjection":
        return cls(
            patient_id=data["patient_id"],
            source_version=str(data.get("source_version", "1")),
            sex=_sex(data.get("sex", "UNKNOWN")),
            age_years=data.get("age_years"),
            population=_population(data.get("population", "UNKNOWN")),
            on_hormone_therapy=data.get("on_hormone_therapy"),
            contraception=data.get("contraception"),
            menopause=data.get("menopause"),
            menstrual_phase=data.get("menstrual_phase"),
            extra=dict(data.get("extra") or {}),
        )


@dataclass
class PregnancyContextProjection:
    """Pregnancy state comes from the Gestantes module - never recreated here."""

    patient_id: str
    source_module: str = "GESTANTES"
    source_entity_id: str = "pregnancy"
    source_version: str = "1"
    is_pregnant: bool = False
    gestational_age_weeks: float | None = None
    authority: ObservationAuthority = ObservationAuthority.CLINICIAN_CONFIRMED

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PregnancyContextProjection":
        return cls(
            patient_id=data["patient_id"],
            source_version=str(data.get("source_version", "1")),
            is_pregnant=bool(data.get("is_pregnant", False)),
            gestational_age_weeks=data.get("gestational_age_weeks"),
        )


@dataclass
class PediatricContextProjection:
    """Pediatric age/context comes from the Pediatria module."""

    patient_id: str
    source_module: str = "PEDIATRIA"
    source_entity_id: str = "pediatric"
    source_version: str = "1"
    is_pediatric: bool = False
    age_years: float | None = None
    authority: ObservationAuthority = ObservationAuthority.CLINICIAN_CONFIRMED

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PediatricContextProjection":
        return cls(
            patient_id=data["patient_id"],
            source_version=str(data.get("source_version", "1")),
            is_pediatric=bool(data.get("is_pediatric", False)),
            age_years=data.get("age_years"),
        )


def parse_effective_at(value: str | None):
    return parse_dt(value)
