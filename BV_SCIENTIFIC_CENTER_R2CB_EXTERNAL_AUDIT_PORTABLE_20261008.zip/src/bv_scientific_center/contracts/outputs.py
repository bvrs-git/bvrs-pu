"""Outbound DTOs (projections) published by the Scientific Center.

The Clinical Center exposes *projections*, never persistence internals. The
clinical map contract is versioned so future BV Suite integration is explicit.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.enums import EdgeType, MapLayer, NodeType


@dataclass
class Provenance:
    """Traceability record for a node, edge, metric or signal.

    Every map node/edge must carry one of: a ``source_ref``, a ``formula_id``/
    ``rule_id`` (+version), or an explicit clinician ``annotation_id``. Orphan
    nodes are rejected by the map builder (TEST - MAP PROVENANCE).
    """

    source_ref: str | None = None
    source_module: str | None = None
    source_entity_id: str | None = None
    formula_id: str | None = None
    formula_version: int | None = None
    score_id: str | None = None
    score_version: int | None = None
    rule_id: str | None = None
    rule_version: int | None = None
    annotation_id: str | None = None
    evidence_refs: list[str] = field(default_factory=list)
    note: str | None = None

    def is_traceable(self) -> bool:
        return any(
            [
                self.source_ref,
                self.formula_id,
                self.score_id,
                self.rule_id,
                self.annotation_id,
            ]
        )

    def describe(self) -> str:
        parts: list[str] = []
        if self.source_ref:
            parts.append(f"source={self.source_ref}")
        if self.formula_id:
            parts.append(f"formula={self.formula_id}@{self.formula_version}")
        if self.score_id:
            parts.append(f"score={self.score_id}@{self.score_version}")
        if self.rule_id:
            parts.append(f"rule={self.rule_id}@{self.rule_version}")
        if self.annotation_id:
            parts.append(f"annotation={self.annotation_id}")
        return "; ".join(parts) or "UNTRACEABLE"


@dataclass
class MapNodeProjection:
    node_id: str
    node_type: NodeType
    layer: MapLayer
    label: str
    authority: str
    domain: str | None = None
    value: float | None = None
    unit: str | None = None
    effective_at: str | None = None
    provenance: Provenance = field(default_factory=Provenance)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class MapEdgeProjection:
    edge_id: str
    source_node_id: str
    target_node_id: str
    relation: EdgeType
    layer: MapLayer
    provenance: Provenance = field(default_factory=Provenance)
    metadata: dict[str, Any] = field(default_factory=dict)

    def why_connected(self) -> dict[str, Any]:
        """Answer "WHY ARE THESE CONNECTED?" without any opaque edge."""
        return {
            "relation": self.relation.value,
            "causal": self.relation is EdgeType.CAUSAL_MODEL_SUPPORTED,
            "rule_id": self.provenance.rule_id,
            "rule_version": self.provenance.rule_version,
            "evidence_refs": list(self.provenance.evidence_refs),
            "explanation": self.provenance.note or self.provenance.describe(),
        }


@dataclass
class ClinicalMapMetadata:
    patient_id: str
    generation_time: str
    rule_versions: dict[str, int] = field(default_factory=dict)
    formula_versions: dict[str, int] = field(default_factory=dict)
    score_versions: dict[str, int] = field(default_factory=dict)
    knowledge_package_version: str | None = None
    run_id: str | None = None
    window_start: str | None = None
    window_end: str | None = None
    temporal_mode: str = "TODAY"
    layers_enabled: list[str] = field(default_factory=list)


@dataclass
class ClinicalMapProjectionV1:
    """Versioned clinical map contract (R1)."""

    contract_version: str
    metadata: ClinicalMapMetadata
    nodes: list[MapNodeProjection] = field(default_factory=list)
    edges: list[MapEdgeProjection] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        from ..core.serialization import dump

        return dump(self)
