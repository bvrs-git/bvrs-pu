"""Versioned contracts (projections) crossing the module boundary.

Input directions consume projections from other BV modules. Output direction
publishes :class:`ClinicalMapProjectionV1` and friends. Persistence internals
are never exposed.
"""
