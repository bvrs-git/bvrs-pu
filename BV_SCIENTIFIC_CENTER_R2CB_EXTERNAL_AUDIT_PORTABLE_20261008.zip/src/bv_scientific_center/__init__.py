"""BV Centro Cientifico & Mapa Clinico - R0/R1.

Standalone scientific synthesis and clinical map layer of the BV ecosystem.

This package is a *standalone module*. It consumes versioned projections from
other BV modules (Prontuario, Laboratorio, Bioimpedancia, Nutrologia,
Integrativa, Pediatria, Gestantes) and never imports their repositories or ORM
entities. It never writes back into BV Clinical.

Core invariants enforced by this package:

    MEASURED_DATA          != DERIVED_METRIC
    DERIVED_METRIC         != CLINICAL_SIGNAL
    CLINICAL_SIGNAL        != DIAGNOSTIC_HYPOTHESIS
    DIAGNOSTIC_HYPOTHESIS  != CONFIRMED_DIAGNOSIS
    MISSING                != ZERO

Runtime dependencies: Python standard library only.
"""

from __future__ import annotations

__all__ = ["__version__", "PRODUCT_ROLE"]

__version__ = "0.1.0"

PRODUCT_ROLE = "BV_SCIENTIFIC_CENTER_R1"
