"""Scientific Center application facade (composition root).

Wires the storage, registries, engines and services together and exposes the
read models used by the UI and tests. It is deliberately free of framework code:
the UI is a thin adapter over this object.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from .ai.drafts import AIDraft, placeholder_summary
from .annotations.service import ClinicalReviewService
from .clinical_map.builder import ClinicalMapBuilder, validate_projection
from .contracts.outputs import ClinicalMapProjectionV1
from .core.context import EvaluationContext
from .core.enums import MapLayer, ReviewDecision, SignalStatus
from .core.timeutil import now_utc, parse_dt, to_iso
from .events.bus import Event, EventBus
from .formulas.definition import ClinicalFormulaDefinition
from .formulas.registry import FormulaRegistry
from .knowledge.packages import KnowledgePackage
from .knowledge.repository import KnowledgeRepository, PackageRepository
from .knowledge.curation import CurationService
from .knowledge.evidence_links import EvidenceLinkService
from .knowledge.scientific import CurationStatus, CurationSubjectType, LinkTargetType
from .knowledge.scientific_repository import (
    ClinicalClaimRepository,
    CurationEventRepository,
    EvidenceLinkRepository,
    ScientificEvidenceRepository,
    ScientificReferenceRepository,
    ScientificSearch,
)
from .knowledge.bibliographic_repository import (
    AcquisitionRepository,
    AppraisalRepository,
    EditorialAlertRepository,
)
from .knowledge.formula_candidates import ScientificFormulaCandidateRegistryV1
from .knowledge.formula_candidate_repository import FormulaCandidateRepository
from .knowledge.content_repository import (
    AcquiredContentRepository,
    ContentExtractionRepository,
    EditorialCheckRepository,
    ReviewDecisionRepository,
)
from .bibliography.europepmc import EuropePmcAdapter
from .bibliography.cache import BibliographyCache
from .bibliography.crossref import CrossrefAdapter
from .bibliography.pubmed import PubMedAdapter
from .bibliography.service import BibliographyService
from .bibliography.transport import UrllibTransport
from .observations.refs import ScientificObservationRef
from .rules.definition import ScientificClinicalRule
from .rules.registry import RuleRegistry
from .scores.definition import ClinicalScoreDefinition
from .scores.registry import ScoreRegistry
from .storage.database import Database
from .storage.repositories import (
    AnnotationRepository,
    DerivedMetricRepository,
    EventRepository,
    ObservationRepository,
    PinRepository,
    ScoreResultRepository,
    SignalRepository,
    SynthesisRunRepository,
)
from .synthesis.run import SynthesisRunResult, SynthesisRunner

DEFAULT_BASE_DIR = Path("data") / "runtime"


class ScientificCenterApp:
    def __init__(
        self,
        base_dir: str | Path | None = None,
        *,
        memory: bool = False,
        knowledge_package_version: str | None = None,
    ) -> None:
        self.database = Database(base_dir or DEFAULT_BASE_DIR, memory=memory).initialize()

        self.formulas = FormulaRegistry()
        self.scores = ScoreRegistry()
        self.rules = RuleRegistry()

        self.observations = ObservationRepository(self.database)
        self.metrics = DerivedMetricRepository(self.database)
        self.score_results = ScoreResultRepository(self.database)
        self.signals = SignalRepository(self.database)
        self.runs = SynthesisRunRepository(self.database)
        self.annotations = AnnotationRepository(self.database)
        self.pins = PinRepository(self.database)
        self.events = EventRepository(self.database)

        self.knowledge = KnowledgeRepository(self.database)
        self.packages = PackageRepository(self.database)

        # -- R2A scientific curation --------------------------------------
        self.references = ScientificReferenceRepository(self.database)
        self.evidence_records = ScientificEvidenceRepository(self.database)
        self.claims = ClinicalClaimRepository(self.database)
        self.evidence_links = EvidenceLinkRepository(self.database)
        self.curation_events = CurationEventRepository(self.database)
        self.scientific_search = ScientificSearch(self.database)
        self.curation = CurationService(
            references=self.references,
            evidence=self.evidence_records,
            claims=self.claims,
            events=self.curation_events,
        )
        self.linking = EvidenceLinkService(
            links=self.evidence_links,
            references=self.references,
            evidence=self.evidence_records,
        )

        # -- R2B bibliographic acquisition --------------------------------
        self.bibliography_cache = BibliographyCache(self.database)
        self.acquisitions = AcquisitionRepository(self.database)
        self.editorial_alerts = EditorialAlertRepository(self.database)
        self.appraisals = AppraisalRepository(self.database)
        transport = UrllibTransport()
        self.crossref = CrossrefAdapter(transport, cache=self.bibliography_cache)
        self.pubmed = PubMedAdapter(transport, cache=self.bibliography_cache)
        self.europepmc = EuropePmcAdapter(transport, cache=self.bibliography_cache)
        self.content = AcquiredContentRepository(self.database)
        self.extractions = ContentExtractionRepository(self.database)
        self.editorial_checks = EditorialCheckRepository(self.database)
        self.review_decisions = ReviewDecisionRepository(self.database)
        self.bibliography = BibliographyService(
            references=self.references,
            acquisitions=self.acquisitions,
            alerts=self.editorial_alerts,
            appraisals=self.appraisals,
            crossref=self.crossref,
            pubmed=self.pubmed,
            europepmc=self.europepmc,
            content=self.content,
        )
        self.bibliography.bind_evidence_repository(self.evidence_records)

        # -- R2C-A formula candidates (non-operational) -------------------
        self.formula_candidates = ScientificFormulaCandidateRegistryV1()
        self.formula_candidate_repo = FormulaCandidateRepository(self.database)

        self.event_bus = EventBus(recorder=self._record_event)
        self.review = ClinicalReviewService(
            signals=self.signals,
            annotations=self.annotations,
            pins=self.pins,
            event_bus=self.event_bus,
        )
        self.runner = SynthesisRunner(
            formulas=self.formulas,
            scores=self.scores,
            rules=self.rules,
            observations=self.observations,
            metrics=self.metrics,
            score_results=self.score_results,
            signals=self.signals,
            runs=self.runs,
            event_bus=self.event_bus,
            database=self.database,
            knowledge_package_version=knowledge_package_version,
        )

    # -- events ------------------------------------------------------------
    def _record_event(self, event: Event) -> None:
        self.events.append(
            {
                "event_id": event.event_id,
                "event_type": event.event_type,
                "patient_id": event.patient_id,
                "run_id": event.run_id,
                "payload": event.payload,
                "created_at": to_iso(event.created_at),
            }
        )

    # -- knowledge / packages ---------------------------------------------
    def activate_package(self, package_id: str, version: str) -> dict[str, Any]:
        record = self.packages.get(package_id, version)
        if record is None:
            raise KeyError(f"Unknown package {package_id!r} v{version}")
        package = KnowledgePackage.from_dict(record["payload"])
        package.validate()

        for formula_dict in package.formulas:
            self.formulas.publish(ClinicalFormulaDefinition.from_dict(formula_dict))
        for score_dict in package.scores:
            self.scores.publish(ClinicalScoreDefinition.from_dict(score_dict))
        for rule_dict in package.rules:
            self.rules.publish(ScientificClinicalRule.from_dict(rule_dict))
        for item in package.items:
            item.package_id = package.package_id
            item.package_version = package.version
            self.knowledge.save_item(item, require_citation=False)
        for reference in package.references:
            self.knowledge.save_reference(reference)

        activated = self.packages.activate(package_id, version)
        self.runner.knowledge_package_version = f"{package_id}@{version}"
        self.event_bus.emit(
            "KnowledgePackageActivated",
            payload={"package_id": package_id, "version": version},
        )
        return activated

    def import_package(self, package: KnowledgePackage, *, activate: bool = False) -> dict[str, Any]:
        self.packages.save(package)
        if activate:
            return self.activate_package(package.package_id, package.version)
        return self.packages.get(package.package_id, package.version)  # type: ignore[return-value]

    def knowledge_search(self, query: str, limit: int = 25) -> dict[str, Any]:
        """Search results never replace references with AI prose (spec §29)."""
        items = self.knowledge.search(query, limit=limit)
        related_formulas = [
            f.to_dict()
            for f in self.formulas.all_latest()
            if query.lower() in f.name.lower() or query.lower() in (f.description or "").lower()
        ]
        related_scores = [
            s.to_dict()
            for s in self.scores.all_latest()
            if query.lower() in s.name.lower()
        ]
        related_rules = [
            r.to_dict()
            for r in self.rules.all_latest()
            if query.lower() in r.name.lower() or query.lower() in (r.category or "").lower()
        ]
        return {
            "query": query,
            "items": items,
            "related_formulas": related_formulas,
            "related_scores": related_scores,
            "related_rules": related_rules,
        }

    # -- synthesis ---------------------------------------------------------
    def run_synthesis(
        self,
        patient_id: str,
        projections: Iterable[Any] = (),
        *,
        observation_refs: Iterable[ScientificObservationRef] | None = None,
        context: EvaluationContext | None = None,
    ) -> SynthesisRunResult:
        return self.runner.run(
            patient_id,
            projections,
            observation_refs=observation_refs,
            context=context or EvaluationContext(),
        )

    def build_map(
        self,
        run: SynthesisRunResult,
        *,
        layers: Iterable[MapLayer] | None = None,
        as_of: datetime | None = None,
        temporal_mode: str = "TODAY",
    ) -> ClinicalMapProjectionV1:
        annotations = self.annotations.list_for_patient(run.patient_id)
        projection = ClinicalMapBuilder(annotations=annotations).build(
            run, layers=layers, as_of=as_of, temporal_mode=temporal_mode
        )
        validate_projection(projection)
        return projection

    # -- read models -------------------------------------------------------
    def patient_overview(self, patient_id: str) -> dict[str, Any]:
        refs = self.observations.list_for_patient(patient_id)
        metrics = self.metrics.list_for_patient(patient_id)
        signals = self.signals.list_for_patient(patient_id)
        scores = self.score_results.list_for_patient(patient_id)
        runs = self.runs.list_for_patient(patient_id)
        return {
            "patient_id": patient_id,
            "observations": refs,
            "metrics": metrics,
            "scores": scores,
            "signals": signals,
            "runs": runs,
            "counts": {
                "observations": len(refs),
                "metrics": len(metrics),
                "valid_metrics": len([m for m in metrics if m.is_valid]),
                "scores": len(scores),
                "signals": len(signals),
                "open_signals": len(
                    [s for s in signals if s["status"] == SignalStatus.NEW.value]
                ),
            },
        }

    def latest_run(self, patient_id: str) -> dict[str, Any] | None:
        runs = self.runs.list_for_patient(patient_id)
        return runs[0] if runs else None

    def list_patients(self) -> list[str]:
        return self.observations.list_patients()

    def reproduce_run(
        self, patient_id: str, *, context: EvaluationContext | None = None
    ) -> SynthesisRunResult:
        """Rebuild a run by recomputation (does not persist).

        Recomputation yields identical values but *new* metric ids. For a
        deterministic map of a stored run, use :meth:`rebuild_run`.
        """
        refs = self.observations.list_for_patient(patient_id)
        return self.runner.run(
            patient_id,
            observation_refs=refs,
            context=context or EvaluationContext(),
            persist=False,
        )

    def rebuild_run(self, patient_id: str, run_id: str) -> SynthesisRunResult:
        """Deterministically rebuild a stored run from persisted state.

        Uses the preserved input snapshot and stored metric/score/signal ids, so
        the resulting clinical map is reproducible for a given stored run.
        """
        record = self.runs.get(run_id)
        if record is None or record.get("patient_id") != patient_id:
            raise KeyError(f"Unknown run {run_id!r} for patient {patient_id!r}")
        snapshot_ids = [
            entry["observation_ref_id"] for entry in record.get("input_snapshot", [])
        ]
        refs = [
            ref
            for ref in (self.observations.get(ref_id) for ref_id in snapshot_ids)
            if ref is not None
        ]
        return SynthesisRunner.reconstruct_run(
            record,
            refs=refs,
            metrics=self.metrics.list_for_run(patient_id, run_id),
            score_rows=self.score_results.list_for_run(patient_id, run_id),
            signal_rows=self.signals.list_for_run(patient_id, run_id),
        )

    def knowledge_by_origin(self) -> dict[str, int]:
        """Governance view: knowledge item counts grouped by origin."""
        counts: dict[str, int] = {}
        for item in self.knowledge.list_items():
            counts[item.origin.value] = counts.get(item.origin.value, 0) + 1
        return counts

    def domain_dashboard(self, patient_id: str) -> dict[str, list[dict[str, Any]]]:
        from .clinical_map.builder import _concept_domain

        domains: dict[str, list[dict[str, Any]]] = {}

        def add(domain: str | None, entry: dict[str, Any]) -> None:
            domains.setdefault(domain or "OTHER", []).append(entry)

        for ref in self.observations.list_for_patient(patient_id):
            add(
                _concept_domain(ref.concept),
                {
                    "kind": "OBSERVATION",
                    "label": ref.label(),
                    "value": ref.value,
                    "unit": ref.unit,
                    "effective_at": to_iso(ref.effective_at),
                    "authority": ref.authority.value,
                },
            )
        for metric in self.metrics.list_for_patient(patient_id):
            if not metric.is_valid:
                continue
            add(
                metric.domain,
                {
                    "kind": "DERIVED_METRIC",
                    "label": metric.metric_definition_id,
                    "value": metric.value,
                    "unit": metric.unit,
                    "effective_at": to_iso(metric.effective_at),
                    "authority": metric.authority.value,
                },
            )
        for signal in self.signals.list_for_patient(patient_id):
            add(
                signal.get("domain"),
                {
                    "kind": "SIGNAL",
                    "label": signal["title"],
                    "severity": signal["severity"],
                    "status": signal["status"],
                    "signal_id": signal["signal_id"],
                },
            )
        return domains

    def timeline(self, patient_id: str) -> list[dict[str, Any]]:
        entries: list[dict[str, Any]] = []
        for ref in self.observations.list_for_patient(patient_id):
            entries.append(
                {
                    "effective_at": to_iso(ref.effective_at),
                    "kind": "OBSERVATION",
                    "layer": ref.layer.value,
                    "label": f"{ref.label()} = {ref.value} {ref.unit}".strip(),
                    "source": ref.source_module,
                }
            )
        for metric in self.metrics.list_for_patient(patient_id):
            if not metric.is_valid:
                continue
            entries.append(
                {
                    "effective_at": to_iso(metric.effective_at),
                    "kind": "DERIVED_METRIC",
                    "layer": MapLayer.DERIVED.value,
                    "label": f"{metric.metric_definition_id} = {metric.value:g} {metric.unit}",
                    "source": "SCIENTIFIC_CENTER",
                }
            )
        for signal in self.signals.list_for_patient(patient_id):
            entries.append(
                {
                    "effective_at": signal.get("generated_at"),
                    "kind": "SIGNAL",
                    "layer": MapLayer.SIGNALS.value,
                    "label": signal["title"],
                    "source": "SCIENTIFIC_CENTER",
                }
            )
        entries.sort(key=lambda e: e["effective_at"] or "")
        return entries

    def compare(
        self, patient_id: str, t0: str | datetime, t1: str | datetime
    ) -> dict[str, Any]:
        """Mathematical change between two dates. No efficacy is inferred."""
        start = parse_dt(t0)
        end = parse_dt(t1)
        assert start is not None and end is not None

        def window(dt: datetime) -> list[ScientificObservationRef]:
            return [
                r
                for r in self.observations.list_for_patient(patient_id)
                if r.effective_at is not None and r.effective_at.date() == dt.date()
            ]

        before = {r.concept: r for r in window(start)}
        after = {r.concept: r for r in window(end)}
        changes: list[dict[str, Any]] = []
        for concept in sorted(set(before) | set(after)):
            b = before.get(concept)
            a = after.get(concept)
            if b is None or a is None or b.value is None or a.value is None:
                continue
            if b.unit != a.unit:
                changes.append(
                    {
                        "concept": concept,
                        "comparable": False,
                        "reason": f"unit changed {b.unit} -> {a.unit}",
                    }
                )
                continue
            changes.append(
                {
                    "concept": concept,
                    "comparable": True,
                    "t0": b.value,
                    "t1": a.value,
                    "unit": a.unit,
                    "absolute_change": round(a.value - b.value, 4),
                    "percent_change": round((a.value - b.value) / b.value * 100, 2)
                    if b.value
                    else None,
                }
            )
        return {
            "patient_id": patient_id,
            "t0": to_iso(start),
            "t1": to_iso(end),
            "changes": changes,
            "disclaimer": (
                "Mathematical change only. No treatment efficacy is claimed."
            ),
        }

    def correlation_series(self, patient_id: str, concept_a: str, concept_b: str) -> dict[str, Any]:
        """Co-variation exploration - explicitly NOT causal (spec §39, §40)."""
        refs = [
            r
            for r in self.observations.list_for_patient(patient_id)
            if r.concept in {concept_a, concept_b} and r.value is not None
        ]
        series_a = [
            {"at": to_iso(r.effective_at), "value": r.value, "unit": r.unit}
            for r in refs
            if r.concept == concept_a
        ]
        series_b = [
            {"at": to_iso(r.effective_at), "value": r.value, "unit": r.unit}
            for r in refs
            if r.concept == concept_b
        ]
        return {
            "patient_id": patient_id,
            "a": {"concept": concept_a, "points": series_a},
            "b": {"concept": concept_b, "points": series_b},
            "mode": "CO_VARIATION_EXPLORATION",
            "causality_claimed": False,
            "statistical_claim": None,
            "note": (
                "Visual co-trend only. No inferential statistics are computed on "
                "N-of-1 series without an explicit statistical design."
            ),
        }

    def ai_placeholder_summary(self, patient_id: str) -> AIDraft:
        items = self.knowledge.list_items()
        return placeholder_summary([i.title for i in items[:3]])

    # -- R2A scientific curation ------------------------------------------
    def ingest_reference(self, reference):
        return self.references.ingest(reference)

    def register_evidence(self, evidence):
        return self.evidence_records.save(evidence)

    def register_claim(self, claim):
        return self.claims.save(claim)

    def link_evidence(self, **kwargs):
        return self.linking.link(**kwargs)

    def curation_dashboard(self) -> dict[str, Any]:
        return {
            "references": self.references.count_by_status(),
            "evidence": _count_by(self.evidence_records.list(), "curation_status"),
            "claims": _count_by(self.claims.list(), "curation_status"),
        }

    def scientific_search_references(self, query: str = "", **filters) -> list[dict[str, Any]]:
        return self.scientific_search.search_references(query, **filters)

    def reference_view(self, reference_id: str) -> dict[str, Any]:
        reference = self.references.get(reference_id)
        if reference is None:
            raise KeyError(reference_id)
        evidence = [
            e.to_dict()
            for e in self.evidence_records.list()
            if reference_id in e.reference_ids
        ]
        links = self.evidence_links.for_subject(
            CurationSubjectType.REFERENCE, reference_id
        )
        return {
            "reference": reference.to_dict(),
            "evidence": evidence,
            "links": [l.to_dict() for l in links],
            "history": self.curation.history(CurationSubjectType.REFERENCE, reference_id),
            "clinically_usable": self.curation.is_clinically_usable(
                CurationSubjectType.REFERENCE, reference_id
            ),
            "editorial_alerts": self.editorial_alerts.for_reference(reference_id),
            "acquisitions": self.acquisitions.for_reference(reference_id),
            "appraisals": self.appraisals.for_reference(reference_id),
            "has_retraction": self.editorial_alerts.has_retraction(reference_id),
        }

    def methodology_taxonomy(self) -> dict[str, Any]:
        from .knowledge.methodology import taxonomy

        return taxonomy()

    def retraction_impacts(self, evidence_id: str) -> list[dict[str, Any]]:
        return self.curation.claims_impacted_by_retraction(evidence_id)

    # -- R2B bibliographic acquisition & review ---------------------------
    def acquire_by_doi(self, doi: str) -> dict[str, Any]:
        return self.bibliography.acquire_by_doi(doi)

    def set_content_review(self, reference_id: str, status: str, *, reviewer: str | None = None):
        from .core.enums import ContentReviewStatus

        reference = self.references.get(reference_id)
        if reference is None:
            raise KeyError(reference_id)
        reference.content_review_status = ContentReviewStatus(status)
        reference.last_checked_at = now_utc()
        return self.references.save(reference)

    def record_appraisal(self, appraisal: dict[str, Any]) -> str:
        return self.bibliography.record_appraisal(appraisal)

    def check_editorial(self, reference_id: str) -> list[dict[str, Any]]:
        return self.bibliography.check_editorial(reference_id)

    def references_for_claim(self, claim_id: str) -> dict[str, Any]:
        claim = self.claims.get(claim_id)
        if claim is None:
            raise KeyError(claim_id)

        def refs_for(evidence_ids):
            out = []
            for evidence_id in evidence_ids:
                evidence = self.evidence_records.get(evidence_id)
                if evidence is None:
                    continue
                for rid in evidence.reference_ids:
                    reference = self.references.get(rid)
                    if reference is not None:
                        out.append(reference.to_dict())
            return out

        return {
            "claim_id": claim_id,
            "text": claim.text,
            "favorable": refs_for(claim.favorable_evidence_ids),
            "contrary": refs_for(claim.contrary_evidence_ids),
            "inconclusive": refs_for(claim.inconclusive_evidence_ids),
        }

    def review_queue(self) -> list[dict[str, Any]]:
        alerts_by_ref = {
            rid: self.editorial_alerts.for_reference(rid)
            for rid in self.editorial_alerts.references_with_alerts()
        }
        evidence_by_ref: dict[str, list[str]] = {}
        for evidence in self.evidence_records.list():
            for rid in evidence.reference_ids:
                evidence_by_ref.setdefault(rid, []).append(evidence.evidence_id)

        queue: list[dict[str, Any]] = []
        for reference in self.references.list():
            alerts = alerts_by_ref.get(reference.reference_id, [])
            if reference.curation_status is CurationStatus.APPROVED and not alerts:
                continue  # approved and clean -> nothing pending
            links = self.evidence_links.for_subject(
                CurationSubjectType.REFERENCE, reference.reference_id
            )
            queue.append(
                {
                    "reference_id": reference.reference_id,
                    "title": reference.title,
                    "doi": reference.doi,
                    "pmid": reference.pmid,
                    "bibliographic_status": reference.bibliographic_status.value,
                    "content_review_status": reference.content_review_status.value,
                    "verification_status": reference.verification_status.value,
                    "curation_status": reference.curation_status.value,
                    "origin": reference.origin.value,
                    "editorial_alerts": alerts,
                    "evidence": evidence_by_ref.get(reference.reference_id, []),
                    "links": [l.to_dict() for l in links],
                    "appraisals": self.appraisals.for_reference(reference.reference_id),
                    "clinically_usable": self.bibliography.is_clinically_usable(reference.reference_id),
                }
            )
        return queue

    def export_review_queue(self, fmt: str = "json") -> str:
        import csv
        import io
        import json as _json

        queue = self.review_queue()
        if fmt == "json":
            return _json.dumps(queue, indent=2, ensure_ascii=False, default=str)
        if fmt == "csv":
            buffer = io.StringIO()
            writer = csv.writer(buffer)
            writer.writerow(
                [
                    "reference_id",
                    "title",
                    "doi",
                    "bibliographic_status",
                    "content_review_status",
                    "curation_status",
                    "editorial_alerts",
                    "clinically_usable",
                ]
            )
            for row in queue:
                writer.writerow(
                    [
                        row["reference_id"],
                        row["title"],
                        row["doi"],
                        row["bibliographic_status"],
                        row["content_review_status"],
                        row["curation_status"],
                        len(row["editorial_alerts"]),
                        row["clinically_usable"],
                    ]
                )
            return buffer.getvalue()
        raise ValueError(f"Unknown export format: {fmt!r}")

    # -- R2C-A formula candidates & human review --------------------------
    def bootstrap_r2ca(self) -> dict[str, Any]:
        from .seed.r2ca_seed import seed_r2ca

        return seed_r2ca(self)

    def formula_candidates_list(self) -> list[dict[str, Any]]:
        return [c.to_dict() for c in self.formula_candidates.all_latest()]

    def candidate_view(self, candidate_id: str, version: int | None = None) -> dict[str, Any]:
        candidate = self.formula_candidates.get(candidate_id, version)
        links = self.evidence_links.for_target(
            LinkTargetType.FORMULA_CANDIDATE, candidate_id, target_version=candidate.version
        )
        references = [
            self.references.get(rid).to_dict()
            for rid in candidate.reference_ids
            if self.references.get(rid) is not None
        ]
        alerts = []
        for reference in references:
            for alert in self.editorial_alerts.for_reference(reference["reference_id"]):
                alerts.append(alert)
        return {
            "candidate": candidate.to_dict(),
            "evidence_links": [l.to_dict() for l in links],
            "references": references,
            "editorial_alerts": alerts,
        }

    def human_review_queue(self) -> dict[str, list[dict[str, Any]]]:
        references_pending = []
        for reference in self.references.list():
            alerts = self.editorial_alerts.for_reference(reference.reference_id)
            if reference.curation_status is CurationStatus.APPROVED and not alerts:
                continue
            references_pending.append(
                {
                    "reference_id": reference.reference_id,
                    "title": reference.title,
                    "bibliographic_status": reference.bibliographic_status.value,
                    "content_review_status": reference.content_review_status.value,
                    "curation_status": reference.curation_status.value,
                    "editorial_alerts": len(alerts),
                }
            )
        claims_pending = [
            {
                "claim_id": claim.claim_id,
                "text": claim.text,
                "curation_status": claim.curation_status.value,
                "certainty_level": claim.certainty_level.value,
            }
            for claim in self.claims.list()
            if claim.curation_status is not CurationStatus.APPROVED
        ]
        candidates_pending = [
            {
                "candidate_id": candidate.candidate_id,
                "version": candidate.version,
                "display_name": candidate.display_name,
                "candidate_type": candidate.candidate_type.value,
                "review_status": candidate.review_status.value,
                "operational": candidate.operational,
                "references": len(candidate.reference_ids),
                "validation_evidence": len(candidate.validation_evidence_ids),
            }
            for candidate in self.formula_candidates.all_latest()
        ]
        return {
            "references_pending": references_pending,
            "claims_pending": claims_pending,
            "formula_candidates_pending": candidates_pending,
        }

    # -- R2C-B content acquisition & medical dossiers ---------------------
    def bootstrap_r2cb(self, *, dois: tuple[str, ...] | None = None) -> dict[str, Any]:
        """Acquire real content for the selected references and extract fields.

        Identification precedes association: content is only linked when the
        returned DOI matches the requested DOI. Offline replay uses the same
        code path via a snapshot adapter (see ``bootstrap_r2cb_offline``).
        """
        from .seed.r2ca_seed import SELECTED_DOIS

        targets = dois or SELECTED_DOIS
        acquired = 0
        abstracts = 0
        extractions = 0
        for doi in targets:
            reference = self.references.find_by_identifier("doi", doi)
            if reference is None:
                continue
            snapshots = self.bibliography.acquire_content(reference.reference_id, doi=doi)
            acquired += len(snapshots)
            if any(s.content_type.value == "ABSTRACT" and s.text for s in snapshots):
                abstracts += 1
            if self.extract_reference(reference.reference_id) is not None:
                extractions += 1
        return {
            "references_targeted": len(targets),
            "content_snapshots": acquired,
            "abstracts_acquired": abstracts,
            "extractions": extractions,
            "availability": self.content.count_by_availability(),
        }

    def bootstrap_r2cb_offline(
        self, *, snapshot_path: str | None = None, dois: tuple[str, ...] | None = None
    ) -> dict[str, Any]:
        """Replay a frozen Europe PMC snapshot through the real code path."""
        from .bibliography.snapshot import (
            DEFAULT_CONTENT_SNAPSHOT,
            EuropePmcSnapshotAdapter,
            load_content_snapshot,
        )

        path = snapshot_path or DEFAULT_CONTENT_SNAPSHOT
        snapshot = load_content_snapshot(path)
        self.bibliography.europepmc = EuropePmcSnapshotAdapter(snapshot, path=path)
        return self.bootstrap_r2cb(dois=dois)

    def acquire_content_for(self, reference_id: str) -> list[dict[str, Any]]:
        reference = self.references.get(reference_id)
        if reference is None:
            raise KeyError(reference_id)
        self.bibliography.acquire_content(reference_id, doi=reference.doi)
        self.extract_reference(reference_id)
        return self.content.for_reference(reference_id)

    def content_for(self, reference_id: str) -> list[dict[str, Any]]:
        return self.content.for_reference(reference_id)

    def extract_reference(self, reference_id: str) -> dict[str, Any] | None:
        """Extract appraisal fields from the stored abstract (if any).

        Only fields grounded in a verbatim span are populated. Re-running is
        idempotent (same source + version → same extraction id).
        """
        from .knowledge.extraction import extract_from_abstract

        content = self.content.for_reference(reference_id)
        abstract = next(
            (c for c in content if c["content_type"] == "ABSTRACT" and c.get("text")), None
        )
        if abstract is None:
            return None
        extraction = extract_from_abstract(
            reference_id,
            abstract["text"],
            content_id=abstract["content_id"],
            source_sha256=abstract["sha256"],
        )
        self.extractions.save(extraction)
        return self.extractions.latest(reference_id)

    def extraction_for(self, reference_id: str) -> dict[str, Any] | None:
        return self.extractions.latest(reference_id)

    def reconciliation(self) -> dict[str, Any]:
        """Bibliographic reconciliation matrix (R2C-B GATE 0).

        Explains why the same module reports different reference counts across
        phases without changing any stored value: R2B counted import operations
        (pilot + corpus), while the store de-duplicates by DOI-derived id.
        """
        rows: list[dict[str, Any]] = []
        for reference in self.references.list():
            data = reference.to_dict()
            rows.append(
                {
                    "reference_id": reference.reference_id,
                    "doi": data.get("doi"),
                    "pmid": data.get("pmid"),
                    "origin": data.get("origin"),
                    "title": reference.title,
                    "publication_type": data.get("publication_type"),
                    "metadata_source": data.get("metadata_source"),
                    "bibliographic_status": data.get("bibliographic_status"),
                    "curation_status": data.get("curation_status"),
                    "content_review_status": data.get("content_review_status"),
                    "content_available": self.content.has_abstract(reference.reference_id),
                }
            )
        real = [r for r in rows if r["origin"] != "SYNTHETIC_TEST"]
        synthetic = [r for r in rows if r["origin"] == "SYNTHETIC_TEST"]
        dois = [r["doi"] for r in real if r["doi"]]
        duplicates = sorted({d for d in dois if dois.count(d) > 1})
        return {
            "total": len(rows),
            "real": len(real),
            "synthetic": len(synthetic),
            "duplicate_dois": duplicates,
            "rows": rows,
            "note": (
                "R2B reported 19 imports = 4 pilot + 15 corpus operations; one DOI "
                "(10.15857/ksep.2009.18.2.256) is shared, so the store holds 18 "
                "distinct real references. No record was altered to reconcile counts."
            ),
        }

    def _dossier_dict(self, reference_id: str) -> dict[str, Any]:
        reference = self.references.get(reference_id)
        if reference is None:
            raise KeyError(reference_id)
        content = self.content.for_reference(reference_id)
        abstract = next(
            (c for c in content if c["content_type"] == "ABSTRACT" and c.get("text")), None
        )
        full_text = next(
            (c for c in content if c["content_type"] == "FULL_TEXT_XML" and c.get("text")), None
        )
        appraisals = self.appraisals.for_reference(reference_id)
        linked_candidates = [
            link.to_dict()
            for link in self.evidence_links.for_subject(
                CurationSubjectType.REFERENCE, reference_id
            )
        ]
        alerts = self.editorial_alerts.for_reference(reference_id)
        extraction = self.extractions.latest(reference_id)
        currency = self.editorial_checks.latest(reference_id)
        return {
            "reference": reference.to_dict(),
            "editorial": {
                "curation_status": reference.curation_status.value,
                "bibliographic_status": reference.bibliographic_status.value,
                "content_review_status": reference.content_review_status.value,
                "last_checked_at": reference.to_dict().get("last_checked_at"),
                "alerts": alerts,
            },
            "currency": currency,
            "content_accessed": [
                {
                    "content_id": c["content_id"],
                    "content_type": c["content_type"],
                    "source": c["source"],
                    "availability": c["availability"],
                    "license": c["license"],
                    "sha256": c["sha256"],
                    "queried_at": c["queried_at"],
                    "storage_permitted": c["storage_permitted"],
                    "locator": c["locator"],
                    "excerpt": (c["text"][:1200] if c.get("text") else None),
                }
                for c in content
            ],
            "abstract_available": abstract is not None,
            "full_text_available": full_text is not None,
            "structured_extraction": extraction,
            "methodology": self.body_composition_sheet(reference_id),
            "appraisals": appraisals,
            "linked_formula_candidates": linked_candidates,
            "unverified_fields": (
                extraction.get("pending_fields", []) if extraction else (
                    appraisals[0].get("pending_fields", []) if appraisals else []
                )
            ),
            "medical_questions": [
                "Accept this evidence for consideration?",
                "Request further revision/information?",
                "Reject?",
                "Keep pending?",
            ],
            "review_decisions": self.review_decisions.for_reference(reference_id),
            "decision_form": {
                "allowed_decisions": [d.value for d in ReviewDecision],
                "requires": ["actor", "justification"],
                "executed": False,
                "note": (
                    "Prepared locally. The system records a decision but never executes it. "
                    "Accepting for consideration does NOT approve any formula for clinical use."
                ),
            },
        }

    def export_dossier(self, reference_id: str, fmt: str = "json") -> str:
        import json as _json

        data = self._dossier_dict(reference_id)
        if fmt == "json":
            return _json.dumps(data, indent=2, ensure_ascii=False, default=str)
        if fmt == "md":
            r = data["reference"]
            lines = [
                f"# Medical review dossier — {r['title']}",
                "",
                f"- reference_id: {r['reference_id']}",
                f"- DOI: {r.get('doi')}  PMID: {r.get('pmid')}",
                f"- Journal: {r.get('venue')} ({r.get('publication_year')})",
                f"- Curation: {data['editorial']['curation_status']} | Bibliographic: {data['editorial']['bibliographic_status']} | Content: {data['editorial']['content_review_status']}",
                f"- Abstract available: {data['abstract_available']} | Full text stored: {data['full_text_available']}",
                "",
                "## Content accessed",
            ]
            for c in data["content_accessed"]:
                lines.append(
                    f"- {c['content_type']} via {c['source']} [{c['availability']}] license={c['license']} "
                    f"sha256={str(c['sha256'])[:16]} locator={c['locator']}"
                )
            lines += ["", "## Structured extraction (citation-grounded, not human-reviewed)"]
            extraction = data.get("structured_extraction")
            if extraction:
                lines.append(
                    f"- source: {extraction['source_kind']} sha256={str(extraction['source_sha256'])[:16]} "
                    f"version={extraction['extraction_version']}"
                )
                for name, f in extraction["fields"].items():
                    if f.get("value"):
                        lines.append(
                            f"  - **{name}**: {f['value']} "
                            f"_[{f['provenance']} · {f['locator']} · verbatim: {str(f.get('verbatim'))[:60]}]_"
                        )
                    else:
                        lines.append(f"  - **{name}**: pending — {f.get('note')}")
            else:
                lines.append("- No abstract available; no fields extracted (insufficient information).")
            for a in data["appraisals"]:
                lines.append(f"- appraisal pending: {', '.join(a.get('pending_fields', []))}")
            lines += ["", "## Editorial currency"]
            currency = data.get("currency")
            if currency:
                lines.append(
                    f"- last check: {currency['checked_at']} via {currency['provider']} "
                    f"outcome={currency['outcome']} currency_known={currency['currency_known']}"
                )
            else:
                lines.append("- currency not verified (no provider check recorded).")
            for alert in data["editorial"]["alerts"]:
                lines.append(f"- alert: {alert['alert_type']} — {alert['details']}")
            lines += ["", "## Related formula candidates"]
            for link in data["linked_formula_candidates"]:
                lines.append(f"- {link['target_id']} ({link['relation']})")
            lines += ["", "## Medical decision (prepared, not executed)"]
            for q in data["medical_questions"]:
                lines.append(f"- [ ] {q}")
            lines += [
                "",
                "> Prepared for human review. No decision is recorded automatically. "
                "Accepting for consideration does NOT approve any formula for clinical use.",
            ]
            return "\n".join(lines)
        raise ValueError(f"Unknown dossier format: {fmt!r}")

    def dossier_index(self) -> list[dict[str, Any]]:
        from .seed.r2ca_seed import SELECTED_DOIS

        index = []
        for doi in SELECTED_DOIS:
            reference = self.references.find_by_identifier("doi", doi)
            if reference is None:
                continue
            content = self.content.for_reference(reference.reference_id)
            abstract = any(c["content_type"] == "ABSTRACT" and c.get("text") for c in content)
            extraction = self.extractions.latest(reference.reference_id)
            appraisals = self.appraisals.for_reference(reference.reference_id)
            if extraction is not None:
                pending = extraction.get("pending_fields", [])
            elif appraisals:
                pending = appraisals[0].get("pending_fields", [])
            else:
                pending = []
            index.append(
                {
                    "reference_id": reference.reference_id,
                    "title": reference.title,
                    "doi": doi,
                    "abstract_available": abstract,
                    "extraction_available": extraction is not None,
                    "availability": [c["availability"] for c in content],
                    "pending_fields": pending,
                }
            )
        return index

    def record_review_decision(
        self,
        reference_id: str,
        decision: str,
        *,
        actor: str,
        justification: str,
    ) -> str:
        from .core.enums import ReviewDecision

        value = ReviewDecision(decision) if not isinstance(decision, ReviewDecision) else decision
        reference = self.references.get(reference_id)
        if reference is None:
            raise KeyError(reference_id)
        return self.review_decisions.record(
            reference_id=reference_id,
            decision=value.value,
            actor=actor,
            justification=justification,
            reference_version=reference.version,
            content_hash=reference.content_hash_value,
        )

    # -- R2C-B GATE 4/5/6: methodology, evidence and applicability ---------
    _METHOD_SHEET_FIELDS = (
        ("reference_method", "reference_method"),
        ("sample_size", "sample_size"),
        ("population", "population"),
    )

    _METHOD_UNKNOWN_FIELDS = (
        "device_brand",
        "device_model",
        "technology",
        "equation_used",
        "development_population",
        "validation_population",
        "hydration_conditions",
        "measurement_conditions",
        "cross_validation",
        "external_validation",
        "estimation_error",
        "systematic_bias",
        "agreement",
        "limits_of_agreement",
        "precision",
        "subgroup_performance",
        "generalisation",
    )

    def body_composition_sheet(self, reference_id: str) -> dict[str, Any]:
        """Body-composition / BIA methodology sheet (GATE 4).

        Fields not literally supported by the consulted content are recorded as
        INSUFFICIENT_INFORMATION; nothing is inferred. Reporting checklists are
        not risk-of-bias tools, and BIA is not a PROM instrument.
        """
        extraction = self.extractions.latest(reference_id)
        extracted = (extraction or {}).get("fields", {})
        from .knowledge.methodology import suggested_rob_instrument
        from .knowledge.scientific import StudyDesign

        design_value = (extracted.get("study_design") or {}).get("value")
        try:
            design = StudyDesign(design_value) if design_value else None
        except ValueError:
            design = None
        rob = suggested_rob_instrument(design) if design else {
            "design": None,
            "suggested_tool": None,
            "auto_applied": False,
            "status": "UNASSESSED",
            "reason": "Study design not established from the consulted content.",
        }
        fields: dict[str, Any] = {}
        for field_name, _source in self._METHOD_SHEET_FIELDS:
            entry = extracted.get(field_name)
            if entry and entry.get("value"):
                fields[field_name] = {
                    "value": entry["value"],
                    "provenance": entry["provenance"],
                    "locator": entry.get("locator"),
                }
            else:
                fields[field_name] = {"value": None, "provenance": "INSUFFICIENT_INFORMATION"}
        for name in self._METHOD_UNKNOWN_FIELDS:
            fields[name] = {"value": None, "provenance": "INSUFFICIENT_INFORMATION"}
        return {
            "reference_id": reference_id,
            "fields": fields,
            "sample_size": fields["sample_size"]["value"],
            "population": fields["population"]["value"],
            "reference_method": fields["reference_method"]["value"],
            "risk_of_bias": {
                "assigned_tool": None,
                "suggested_tool": rob["suggested_tool"],
                "status": rob["status"],
                "reason": (
                    "No human critical appraisal; instruments are never auto-applied. "
                    + rob["reason"]
                ),
            },
            "policy": {
                "reporting_checklists": [
                    "STROBE",
                    "TRIPOD",
                    "GRRAS",
                ],
                "note": (
                    "STROBE/TRIPOD/GRRAS are reporting checklists, not risk-of-bias tools; "
                    "PROM instruments are not applicable to BIA devices."
                ),
                "correlation_not_agreement": (
                    "High correlation is not treated as evidence of agreement; agreement, "
                    "bias and limits of agreement must be reported explicitly."
                ),
            },
        }

    def formula_evidence_matrix(self) -> list[dict[str, Any]]:
        """Formula candidate ↔ evidence matrix (GATE 5).

        Links are read, never created automatically from title/abstract keyword
        matches. Evidence gaps and contradictory evidence are surfaced.
        """
        matrix: list[dict[str, Any]] = []
        for candidate in self.formula_candidates.all_latest():
            links = self.evidence_links.for_target(
                LinkTargetType.FORMULA_CANDIDATE,
                candidate.candidate_id,
                target_version=candidate.version,
            )
            entries = []
            for link in links:
                data = link.to_dict()
                reference = self.references.get(data["subject_id"])
                if reference is None:
                    continue
                entries.append(
                    {
                        "reference_id": reference.reference_id,
                        "relation": data["relation"],
                        "justification": data.get("justification"),
                        "bibliographic_status": reference.bibliographic_status.value,
                        "content_review_status": reference.content_review_status.value,
                        "curation_status": reference.curation_status.value,
                        "content_available": self.content.has_abstract(reference.reference_id),
                        "retracted": self.editorial_alerts.has_retraction(reference.reference_id),
                    }
                )
            relations = {e["relation"] for e in entries}
            matrix.append(
                {
                    "candidate_id": candidate.candidate_id,
                    "version": candidate.version,
                    "display_name": candidate.display_name,
                    "candidate_type": candidate.candidate_type.value,
                    "expression": candidate.expression,
                    "operational": candidate.operational,
                    "links": entries,
                    "has_contradictory_evidence": "CONTRADICTORY_EVIDENCE" in relations,
                    "has_validation_evidence": bool(
                        {"INTERNAL_VALIDATION", "EXTERNAL_VALIDATION"} & relations
                    ),
                    "gaps": [
                        gap
                        for gap, present in (
                            ("no_methodological_foundation", not relations),
                            ("no_validation_evidence", not ({"INTERNAL_VALIDATION", "EXTERNAL_VALIDATION"} & relations)),
                        )
                        if present
                    ],
                }
            )
        return matrix

    def applicability_matrix(self) -> list[dict[str, Any]]:
        """Formula candidate applicability matrix (GATE 6).

        The mere presence of a subgroup in a study never marks a population as
        validated. Declared-applicable contexts remain VALIDATION_PENDING until a
        human review declares otherwise.
        """
        from .knowledge.applicability import POPULATIONS

        matrix: list[dict[str, Any]] = []
        for candidate in self.formula_candidates.all_latest():
            profile = candidate.applicability
            contexts = []
            for code, label in POPULATIONS.items():
                if code in profile.contraindications:
                    status = "NOT_APPLICABLE_BY_DEFINITION"
                elif code in profile.not_validated_populations:
                    status = "NOT_VALIDATED_FOR_CONTEXT"
                elif code in profile.applicable_populations:
                    status = "VALIDATION_PENDING"
                else:
                    status = "EVIDENCE_INSUFFICIENT"
                contexts.append({"context": code, "label": label, "status": status})
            matrix.append(
                {
                    "candidate_id": candidate.candidate_id,
                    "version": candidate.version,
                    "display_name": candidate.display_name,
                    "contexts": contexts,
                    "device_requirements": list(profile.device_requirements),
                }
            )
        return matrix

    def check_currency(self, reference_id: str, *, provider: str | None = None) -> dict[str, Any]:
        """Editorial currency check (GATE 8).

        A confirmed retraction blocks current use without erasing history. When
        no provider is available, currency is recorded as unknown (never
        fabricated).
        """
        reference = self.references.get(reference_id)
        if reference is None:
            raise KeyError(reference_id)
        used_provider = provider or ("CROSSREF" if reference.doi else "LOCAL")
        # Explicit editorial re-check (records alerts; never deletes history).
        try:
            self.bibliography.check_editorial(reference_id)
        except Exception:  # pragma: no cover - provider failure is non-fatal
            pass
        usable = False
        try:
            usable = bool(self.bibliography.is_clinically_usable(reference_id))
        except Exception:  # pragma: no cover - defensive
            usable = False
        alerts = self.editorial_alerts.for_reference(reference_id)
        retracted = self.editorial_alerts.has_retraction(reference_id)
        if retracted:
            outcome = "RETRACTED"
            details = "Confirmed retraction; publication not usable as current evidence."
        elif alerts:
            outcome = "ALERTS_PRESENT"
            details = "; ".join(a["details"] for a in alerts)
        else:
            outcome = "NO_ALERTS"
            details = "No editorial alert recorded at last check."
        currency_known = (not alerts) or any(a["source"] != "LOCAL" for a in alerts)
        if not currency_known:
            details += " Currency could not be verified (provider unavailable)."
        check_id = self.editorial_checks.record(
            reference_id=reference_id,
            provider=used_provider,
            outcome=outcome,
            details=details,
            currency_known=currency_known,
        )
        return {
            "check_id": check_id,
            "reference_id": reference_id,
            "provider": used_provider,
            "outcome": outcome,
            "currency_known": currency_known,
            "retracted": retracted,
            "clinically_usable": usable and not retracted,
        }

    def currency_for(self, reference_id: str) -> dict[str, Any] | None:
        return self.editorial_checks.latest(reference_id)

    def export_candidate_dossier(self, candidate_id: str, fmt: str = "json") -> str:
        import json as _json

        view = self.candidate_view(candidate_id)
        if fmt == "json":
            return _json.dumps(view, indent=2, ensure_ascii=False, default=str)
        if fmt == "md":
            c = view["candidate"]
            lines = [
                f"# Formula candidate dossier — {c['display_name']} ({c['candidate_id']} v{c['version']})",
                "",
                f"- Scientific name: {c['name']}",
                f"- Type: {c['candidate_type']}",
                f"- Review status: {c['review_status']}",
                f"- Operational: {c['operational']} (non-operational in R2C-A)",
                f"- Expression: `{c['expression']}`",
                f"- Output unit: {c['output_unit']}",
                "",
                "## Variables",
            ]
            for v in c["variables"]:
                lines.append(
                    f"- {v['name']} [{v['unit']}] allowed={v['allowed_semantics']} — {v['description']}"
                )
            lines += ["", "## Applicability", f"- {c['applicability']}"]
            lines += ["", "## Limitations"] + [f"- {x}" for x in c["limitations"]]
            lines += ["", "## References"]
            for r in view["references"]:
                lines.append(f"- {r.get('reference_id')} — {r.get('title')} ({r.get('doi')})")
            lines += ["", "## Evidence links"]
            for link in view["evidence_links"]:
                lines.append(f"- {link['relation']} <- {link['subject_id']}")
            lines += [
                "",
                "> Non-operational. No clinical approval. No cutoff imported.",
            ]
            return "\n".join(lines)
        raise ValueError(f"Unknown dossier format: {fmt!r}")

    def bootstrap_scientific(self, *, include_pilot: bool = True, include_corpus: bool = True) -> dict[str, Any]:
        from .seed.scientific_seed import seed_scientific

        summary = seed_scientific(self, include_pilot=include_pilot)
        if include_corpus:
            from .bibliography.corpus import DEFAULT_CORPUS_PATH, import_corpus
            from pathlib import Path as _Path

            if _Path(DEFAULT_CORPUS_PATH).exists():
                summary["corpus"] = import_corpus(self, DEFAULT_CORPUS_PATH)
            else:
                summary["corpus"] = {"imported": 0, "note": "corpus snapshot not present (offline)"}
        return summary

    # -- demo bootstrap ----------------------------------------------------
    def bootstrap_synthetic(self) -> dict[str, Any]:
        from .seed.knowledge_seed import build_synthetic_package, seed_knowledge
        from .seed.synthetic import (
            SYNTHETIC_PATIENT_ID,
            register_synthetic_formulas,
            register_synthetic_rules,
            register_synthetic_scores,
            synthetic_patient_context,
            synthetic_projections,
        )

        register_synthetic_formulas(self.formulas)
        register_synthetic_scores(self.scores)
        register_synthetic_rules(self.rules)
        seed_knowledge(self.knowledge)
        self.import_package(build_synthetic_package(), activate=True)

        context = EvaluationContext.from_patient_context(synthetic_patient_context())
        run = self.run_synthesis(
            SYNTHETIC_PATIENT_ID, synthetic_projections(), context=context
        )
        return {
            "patient_id": SYNTHETIC_PATIENT_ID,
            "run_id": run.run_id,
            "metrics": len(run.metrics),
            "valid_metrics": len(run.valid_metrics),
            "signals": len(run.signals),
            "scores": len(run.scores),
        }

    def close(self) -> None:
        self.database.commit()
        self.database.close()


def _count_by(records: list[Any], attribute: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for record in records:
        key = getattr(record, attribute)
        key = key.value if hasattr(key, "value") else str(key)
        counts[key] = counts.get(key, 0) + 1
    return counts
