# R2C-B GATE 5 — Formula ↔ evidence matrix

`app.formula_evidence_matrix()` reports, for each candidate, the linked
references with their verification/curation status, whether content is
available, whether the reference is retracted, and the evidence gaps. **No link
is created automatically from a title or abstract keyword match.**

## Relations allowed

`DERIVATION_ORIGINAL`, `METHODOLOGICAL_FOUNDATION`, `INTERNAL_VALIDATION`,
`EXTERNAL_VALIDATION`, `CLINICAL_APPLICATION`, `LIMITATION`,
`CONTRADICTORY_EVIDENCE` (legacy `FOUNDATIONAL` / `VALIDATION` / `DISCUSSION`
relations are preserved for compatibility).

## Current links (12) — all `IMPORTED_UNVERIFIED`, none retracted

| Candidate | Type | Linked references | Relation | Content available |
| --- | --- | --- | --- | --- |
| SCI-CAND-BMI | ALGEBRAIC_INDEX | 10.3928/21650799-20140514-04, 10.3390/ijerph16111920 | METHODOLOGICAL_FOUNDATION | 0 of 2 (both unavailable/restricted) |
| SCI-CAND-FMI | ALGEBRAIC_INDEX | 10.1016/j.clnu.2018.10.010, 10.20960/nh.03161 | METHODOLOGICAL_FOUNDATION | 2 abstracts |
| SCI-CAND-FFMI | ALGEBRAIC_INDEX | 10.1016/j.clnu.2018.10.010, 10.20960/nh.03161 | METHODOLOGICAL_FOUNDATION | 2 abstracts |
| SCI-CAND-WHTR | ALGEBRAIC_INDEX | 10.1253/circj.cj-10-0583, 10.3390/ijerph16111920 | METHODOLOGICAL_FOUNDATION | 1 abstract |
| SCI-CAND-BODY-FAT-PCT | ALGEBRAIC_INDEX | 10.1097/01823246-199001010-00008, 10.1016/s0899-9007(97)85179-9 | METHODOLOGICAL_FOUNDATION | 0 of 2 (unavailable) |
| SCI-CAND-BC-LONGITUDINAL | ALGEBRAIC_INDEX | 10.1016/s0261-5614(03)80008-0 | METHODOLOGICAL_FOUNDATION | 0 (unavailable) |
| SCI-CAND-WHTR-CUTOFF-PLACEHOLDER | INTERPRETIVE_CRITERION | 10.1253/circj.cj-10-0583 | DERIVATION_ORIGINAL | 0 (restricted) |

## Gaps (all candidates)

- `no_validation_evidence`: **no** `INTERNAL_VALIDATION` / `EXTERNAL_VALIDATION`
  link exists for any candidate.
- `no_methodological_foundation`: none (every candidate has at least one link).
- `has_contradictory_evidence`: **false** for all (none recorded yet — which is a
  gap in the evidence base, not proof of consistency).

## Interpretive criteria vs algebraic indices

The placeholder `RCE — critério interpretativo` is an `INTERPRETIVE_CRITERION`
with **no cutoff imported**; the algebraic indices are dimensionless/`kg/m²`
expressions. No cut-off is imported as a diagnostic criterion.

## Retraction propagation

If a linked reference is retracted, `formula_evidence_matrix` flags
`retracted=True` for that link. Historical syntheses are never rewritten; the
impact is surfaced for human review. `app.check_currency` records the editorial
state per reference.

## No clinical activation

Every candidate remains `operational = False`. Recording a medical review
decision (`ACCEPT_FOR_CONSIDERATION`) does **not** activate any candidate
(regression-tested).
