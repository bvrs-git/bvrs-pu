# R1 — Clinical Map

The clinical map is a **clinician-facing**, versioned projection built by
`ClinicalMapBuilder` (`src/bv_scientific_center/clinical_map/builder.py`) from a
`SynthesisRunResult`. It is not a patient portal. Nodes are derived from
observation refs, valid derived metrics, valid scores and signals; edges are
typed relationships. Every node and edge is traceable to a source reference, a
formula, a rule/score definition or a clinician annotation — there are **no
orphan nodes or opaque edges**.

The map is a *view* over source + derived state, not a second source of truth.
`ScientificCenterApp.build_map()` rebuilds the run from stored observations
(`reproduce_run`, `persist=False`) and then projects the graph, so layout and
rendering carry no authority.

## Node types

`NodeType` (in `core/enums.py`) enumerates every kind of node the graph can
express. The builder maps inputs to node types as follows:

| Node type | Produced from |
| --- | --- |
| `QUESTIONNAIRE_DOMAIN` | observation refs on the `PATIENT_REPORTED` layer |
| `DIAGNOSIS` | observation refs on the `CLINICIAN_CONFIRMED` layer |
| `MEDICATION` | `CLINICIAN_CONFIRMED` ref whose `concept == "MEDICATION"` |
| `BODY_COMPOSITION` | observation refs whose `source_module == "BIOIMPEDANCE"` |
| `NUTRITION` | observation refs whose `source_module == "NUTROLOGIA"` |
| `LAB_MARKER` | any other (objective) observation ref |
| `DERIVED_METRIC` | valid derived metrics and valid scores |
| `CLINICAL_SIGNAL` | signal candidates produced by rules |

`SYMPTOM` and `LIFESTYLE_FACTOR` are part of the taxonomy but are not emitted by
the R1 builder.

### Node id schemes

| Node | id | Source |
| --- | --- | --- |
| Observation | `obs:<observation_ref_id>` | `ScientificObservationRef` |
| Derived metric | `metric:<metric_id>` | valid `DerivedMetricResult` |
| Score | `score:<score_result_id>` | valid score result |
| Signal | `signal:<signal_id>` | rule-generated signal |

A `MapNodeProjection` carries `node_id`, `node_type`, `layer`, `label`,
`authority`, `domain`, `value`, `unit`, `effective_at`, `provenance` and a free
`metadata` dict (for derived metrics: status/warnings/input refs; for signals:
severity, signal type, status, explanation).

## Edge types and the non-causal default

`EdgeType` defines the allowed relationships. The default labelling is
deliberately **non-causal**:

```
MEASURED_WITH, DERIVED_FROM, ASSOCIATED_WITH, SUPPORTS_SIGNAL,
CONTRADICTS, TEMPORALLY_FOLLOWS, REPORTED_WITH, MEDICATED_BY, RELATED_TO
```

`CAUSAL_MODEL_SUPPORTED` is the only causal type. `NON_CAUSAL_EDGE_TYPES`
contains every other member, so *association is not causation* is enforced by the
enum, not by convention.

The R1 builder emits two edge kinds:

| Relation | Direction | Provenance |
| --- | --- | --- |
| `DERIVED_FROM` | input observation → derived metric | `formula_id` / `formula_version`, note `computed from <concept>` |
| `SUPPORTS_SIGNAL` | supporting input (observation or metric) → signal | `rule_id` / `rule_version`, `evidence_refs` from the rule explanation |

Edge ids are deterministic, e.g. `edge:<source>-><target>:DERIVED_FROM` and
`edge:<source>-><signal>:SUPPORTS_SIGNAL`.

```mermaid
graph LR
    OBS["obs:observation_ref_id"]
    METRIC["metric:metric_id"]
    SCORE["score:score_result_id"]
    SIGNAL["signal:signal_id"]
    OBS -->|DERIVED_FROM| METRIC
    OBS -->|SUPPORTS_SIGNAL| SIGNAL
    METRIC -->|SUPPORTS_SIGNAL| SIGNAL
```

## Map layers

`MapLayer` keeps categories visually and structurally distinct:

| Layer | Meaning |
| --- | --- |
| `OBJECTIVE` | measured data |
| `PATIENT_REPORTED` | questionnaires / reported facts |
| `DERIVED` | derived metrics, scores and nutrology-derived values |
| `CLINICIAN_CONFIRMED` | confirmed facts (diagnoses, medications) |
| `SIGNALS` | clinical signal candidates |

`ClinicalMapBuilder.build(..., layers=[...])` filters nodes to the requested
layers. Edges whose endpoint was filtered out are pruned, and
`ClinicalMapMetadata.layers_enabled` records the active layer set (sorted); when
no filter is given, all layers are enabled.

## Provenance and traceability

`Provenance` is the traceability record carried by every node and edge. It
supports a `source_ref`, `formula_id`/`formula_version`, `score_id`/
`score_version`, `rule_id`/`rule_version`, an `annotation_id`, plus
`evidence_refs` and a human-readable `note`.

- `is_traceable()` returns `True` when at least one of `source_ref`,
  `formula_id`, `score_id`, `rule_id` or `annotation_id` is set.
- `describe()` renders a compact locator such as
  `formula=HOMA_IR@2; source=...`, or `UNTRACEABLE`.

`validate_projection(projection)` enforces the rules and raises
`ProvenanceError` when:

- a node's provenance is not traceable (orphan node), or
- an edge references a missing endpoint, or
- an edge's provenance is not traceable.

`ScientificCenterApp.build_map()` calls `validate_projection` before returning,
so an untraceable graph can never leave the module.

## "WHY ARE THESE CONNECTED?"

`MapEdgeProjection.why_connected()` answers the question without any opaque
edge. It returns a dict:

| Key | Value |
| --- | --- |
| `relation` | the `EdgeType` value |
| `causal` | `True` only for `CAUSAL_MODEL_SUPPORTED` |
| `rule_id` / `rule_version` | the rule that produced the relation (when present) |
| `evidence_refs` | evidence references from provenance |
| `explanation` | the provenance note, or `describe()` as a fallback |

The UI renders this for every edge, so a clinician can always inspect why two
nodes are shown together.

## Temporal mode and `as_of` filtering

The projection records a `temporal_mode` label in `ClinicalMapMetadata`
(default `"TODAY"`). This is a requested-mode descriptor for the caller/UI
(e.g. today, last consultation, or a specific date); it is echoed in metadata
and rendered on the map page.

The actual temporal cutoff is applied by `as_of` (a `datetime`). Every node is
included only when its effective timestamp is `<= as_of`:

- observation refs use `effective_at` (`_node_in_window`),
- derived metrics and scores use `effective_at` (`_within_as_of`),
- signals use `generated_at`.

When `as_of` is `None`, no temporal filtering is applied. Passing an `as_of`
earlier than the data yields an empty node set (verified by
`tests/test_clinical_map.py::test_temporal_as_of_filter`).

## The `ClinicalMapProjectionV1` contract

`ClinicalMapProjectionV1` (`src/bv_scientific_center/contracts/outputs.py`) is
the versioned outward DTO. `contract_version` is the literal
`"ClinicalMapProjectionV1"`.

| Field | Type |
| --- | --- |
| `contract_version` | `str` |
| `metadata` | `ClinicalMapMetadata` |
| `nodes` | `list[MapNodeProjection]` |
| `edges` | `list[MapEdgeProjection]` |

`ClinicalMapMetadata` carries `patient_id`, `generation_time`, `rule_versions`,
`formula_versions`, `score_versions`, `knowledge_package_version`, `run_id`,
`window_start`, `window_end`, `temporal_mode` and `layers_enabled`. The window
bounds are the min/max `effective_at` across the run's observation refs.

`to_dict()` serialises the projection for the UI and for future BV Suite
integration; the module exposes projections, never persistence internals.

## Color safety

The UI styles each layer badge with a distinct border color (defined in
`ui/render.py`), keyed by layer name:

| Layer | Badge class |
| --- | --- |
| `OBJECTIVE` | `layer-OBJECTIVE` |
| `PATIENT_REPORTED` | `layer-PATIENT_REPORTED` |
| `DERIVED` | `layer-DERIVED` |
| `CLINICIAN_CONFIRMED` | `layer-CLINICIAN_CONFIRMED` |
| `SIGNALS` | `layer-SIGNALS` |

Color encodes the **source layer / review category only**. It never encodes an
automatic diagnosis. Derived metrics and signals are always `SYSTEM_DERIVED`;
measured nodes stay `MEASURED` or `CLINICIAN_CONFIRMED`. The map page carries an
explicit disclaimer that edges are non-causal unless they are an explicit
validated causal model, and that association is not causation.

## Layout is presentation only

The builder's only responsibility is the graph; **layout is presentation only**.
The projection is not persisted as a layout, and the map is rebuilt from source
plus derived state on each request. Re-rendering or re-arranging the graph cannot
change clinical meaning, because meaning lives in node provenance, edge
provenance and the versioned metadata, not in positions on screen.
