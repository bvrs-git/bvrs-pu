# R1 — Knowledge Repository

The knowledge repository is the citation-backed scientific corpus of the BV
Scientific Center. It supports integrative medicine, nutrology, body
composition, laboratory interpretation and related topics, and it is **extensible
by design**: new content arrives through versioned knowledge packages rather than
application code changes.

Its purpose is to hold *reference knowledge* (guidelines, reviews, meta-analyses,
RCTs, observational studies, books, consensus statements) that a clinician can
search and cite. It is **not** a clinical record and it is the explicit
counterpart of the clinical database.

## Scope and separation

- The knowledge database holds **no patient data**. `KnowledgeRepository` opens
  the `knowledge` connection only and never reads the clinical database
  (`derived.db`).
- `tests/test_knowledge.py::test_repository_has_no_patient_data` asserts that a
  `ScientificKnowledgeItem` has no `patient_id` attribute.
- Patient data lives only in the clinical database; the two are separate SQLite
  files managed by `storage/database.py`.

## `ScientificKnowledgeItem`

A `ScientificKnowledgeItem` (`knowledge/models.py`) is one curated source entry.

| Field | Notes |
| --- | --- |
| `knowledge_id` | primary key |
| `title` | required |
| `topic`, `subtopic` | grouping |
| `summary` | free text |
| `key_points` | tuple of strings |
| `source_type` | `KnowledgeSourceType` (`GUIDELINE`, `REVIEW`, `META_ANALYSIS`, `RCT`, `OBSERVATIONAL`, `BOOK`, `CONSENSUS`, `OTHER`) |
| `publication_year` | integer |
| `authors` | tuple of strings |
| `journal`, `doi`, `url` | locators |
| `citation` | human-readable citation string |
| `evidence_level`, `evidence_framework`, `evidence_grade`, `certainty` | evidence metadata |
| `reviewer`, `reviewed_at` | review bookkeeping |
| `target_type` | `TargetType` — a lab range is never conflated with a clinical target |
| `tags` | tuple of strings |
| `status` | `KnowledgeStatus` (`DRAFT`, `IN_REVIEW`, `APPROVED`, `RETIRED`) |
| `package_id`, `package_version` | provenance back to the originating package |
| `created_at`, `reviewed_at` | timestamps |

`TargetType` distinguishes `LAB_REFERENCE`, `GUIDELINE_TARGET`, `OPTIMAL_RANGE`
and `CLINICIAN_TARGET` so that a target is never mistaken for a reference range.

## `ScientificClaim`

A `ScientificClaim` is an individual, reviewable statement extracted from or
associated with a knowledge item:

| Field | Notes |
| --- | --- |
| `claim_id` | primary key |
| `text` | the claim |
| `knowledge_item_id` | parent item |
| `supporting_reference_ids` | the references that back the claim |
| `review_status` | `ClaimReviewStatus` (`UNREVIEWED`, `IN_REVIEW`, `SUPPORTED`, `UNSUPPORTED`) |
| `created_at` | timestamp |

Claims are stored in `knowledge_claims` and retrieved with
`KnowledgeRepository.claims_for_item(knowledge_id)`. Claim-level status makes it
possible to track support separately from the item's own approval state.

## `KnowledgeReference` and citation rules

A `KnowledgeReference` is a bibliographic record: `reference_id`, `citation`,
`title`, `source` (journal / publisher / institution), `year`, `doi`, `url`,
`item_id`, `created_at`.

`has_minimum_citation()` returns `True` only when **all** of these hold:

- `citation` is non-empty after stripping, and
- `year` is not `None`, and
- at least one locator is present: `doi` or `url` or `source`.

`references` are persisted in `knowledge_references` via
`save_reference()` / `get_reference()`.

## The citation gate

A knowledge item can never reach `APPROVED` without usable citation metadata:

- `ScientificKnowledgeItem.has_minimum_citation()` requires a non-empty
  `citation`, a non-null `publication_year`, and one of `doi`, `url` or
  `journal`.
- `can_approve(require_citation=True)` combines that with the approval request.
- `KnowledgeRepository.save_item()` raises `CitationRequiredError` when an item
  is saved with `status == APPROVED` and fails the gate.
- `KnowledgeRepository.set_status()` applies the same gate before promoting to
  `APPROVED`.

By default `require_citation=True`. Synthetic fixtures seed items with
`require_citation=False` because they are deliberately unverifiable placeholders
(see `seed/knowledge_seed.py`), not production references.

## Storage: `knowledge.db`, no patient data

`storage/schema.py` defines the knowledge schema:

| Table | Contents |
| --- | --- |
| `knowledge_items` | curated source entries |
| `knowledge_claims` | per-claim text, status and supporting references |
| `knowledge_references` | bibliographic records |
| `knowledge_packages` | importable, versioned content bundles |
| `knowledge_fts` | full-text index (FTS5 virtual table) |

No table carries a patient identifier. `KnowledgeRepository` is constructed from
`Database.knowledge` (`knowledge.db`), while clinical state lives in
`Database.clinical` (`derived.db`).

## Full-text search design

Search is implemented in `knowledge/search.py` and is entirely **local and
offline** — SQLite FTS5, no cloud vector database.

- `index_item(conn, item)` maintains the `knowledge_fts` virtual table over
  `title`, `summary`, `key_points`, `topic` and `tags` (with `knowledge_id`
  `UNINDEXED`); it is called on every `save_item`.
- `search_knowledge_ids(conn, query, limit)` tokenises the query, builds an
  `AND` expression of prefix terms (`"term"*`), runs `MATCH ... ORDER BY rank`
  and returns ranked ids.
- If FTS5 raises `OperationalError` (or returns no ids), it **falls back to a
  `LIKE` scan** over `title`, `summary`, `key_points` and `topic`. Search
  therefore keeps working even where FTS5 is unavailable.
- `search_items(...)` hydrates the matched ids back into full
  `knowledge_items` rows, preserving relevance order.

Embeddings, if ever added, are **an index only**: the citation database remains
the source of truth and stays usable without them.

## Search result shape

`KnowledgeRepository.search(query, limit=25)` returns a list of dicts, one per
matching item, exposing the item columns (including `knowledge_id`, `title`,
`topic`, `summary`, `key_points`, `citation`, `status`).

`ScientificCenterApp.knowledge_search(query, limit=25)` wraps that into the read
model used by the UI:

| Key | Value |
| --- | --- |
| `items` | matching knowledge items (with their citations) |
| `related_formulas` | formulas whose name/description matches the query |
| `related_scores` | scores whose name matches the query |
| `related_rules` | rules whose name/category matches the query |

Related definitions come from the in-memory registries (`all_latest()`), not from
the repository tables.

**References are never replaced by AI prose.** Search results always surface the
underlying item and its citation; generated text is a separate, clearly labelled
`AI_DRAFT` / `AI_SUGGESTION` artifact (`ai/drafts.py`) and is never presented as
the reference.
