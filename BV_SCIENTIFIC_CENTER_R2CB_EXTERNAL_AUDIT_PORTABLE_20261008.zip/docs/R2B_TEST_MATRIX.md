# R2B — Test Matrix

## Totals

| Snapshot | Passed | Skipped | Failed |
| --- | --- | --- | --- |
| R2A baseline | 204 | 0 | 0 |
| R2B | **258** | **2** | **0** |

Measured with `python -m pytest` (config in `pyproject.toml`, `addopts = "-q"`,
`pythonpath = ["src"]`). The two skipped tests are the online integration tests,
gated by the environment variable `BV_RUN_ONLINE=1`. R2B adds **54** offline
tests across eight files (plus two opt-in online tests). The R2A baseline is
preserved unchanged.

## New R2B test files

| Tests | File | Gate |
| --- | --- | --- |
| 3 | `test_rr7_content_hash.py` | 0 |
| 9 | `test_bibliography_adapters.py` | 1 |
| 6 | `test_bibliography_provenance.py` | 2 |
| 4 | `test_content_states.py` | 3 |
| 5 | `test_corpus_r2b.py` | 4 |
| 4 | `test_editorial_alerts.py` | 6 |
| 6 | `test_review_workflow.py` | 7 |
| 17 | `test_bibliography_adversarial.py` | 9 |
| 2 (skipped) | `test_online_integration.py` | online |

Helpers: `tests/_biblio_helpers.py` (`FakeTransport`, `json_transport`,
`routed_transport`, `load_fixture`) and the `biblio_app` / `scientific_app`
fixtures in `tests/conftest.py`.

## Gate coverage

| Gate | Focus | Evidence |
| --- | --- | --- |
| 0 | RR-7: `content_hash()` never shadowed | `test_rr7_content_hash.py` |
| 1 | Crossref / PubMed adapters, transport | `test_bibliography_adapters.py` |
| 2 | Provenance, offline cache, reconciliation | `test_bibliography_provenance.py` |
| 3 | Bibliographic verification vs content review | `test_content_states.py` |
| 4 | Initial controlled corpus | `test_corpus_r2b.py` |
| 5 | Structured appraisal | `test_bibliography_adversarial.py` (appraisal scenario) |
| 6 | Editorial alerts / retraction | `test_editorial_alerts.py` |
| 7 | Human review queue + export | `test_review_workflow.py` |
| 9 | Adversarial bibliographic suite | `test_bibliography_adversarial.py` |
| — | Online integration (opt-in) | `test_online_integration.py` |
| 1–4 (R2A) | Methodological taxonomy / no auto-GRADE | `test_methodology.py` |

## GATE 9 checklist

The adversarial suite labels its scenarios inline. Scenarios 12 and 16 are not
labelled in `test_bibliography_adversarial.py`; they are covered by sibling R2B
suites and are included here to complete the 20-item checklist.

| # | Scenario | Test(s) |
| --- | --- | --- |
| 1 | Crossref unavailable | `test_crossref_unavailable_returns_unavailable` |
| 2 | PubMed unavailable, Crossref works | `test_pubmed_unavailable_still_acquires_from_crossref` |
| 3 | HTTP 429 rate limited | `test_rate_limited_acquire_is_graceful`, `test_retry_policy_backoff_and_retry_after`, `test_rate_limited_propagates` |
| 4 | Malformed provider response | `test_malformed_response_is_graceful`, `test_malformed_response_returns_none`, `test_crossref_missing_message_returns_none` |
| 5 | Duplicate DOI import is idempotent | `test_duplicate_doi_import_is_idempotent` |
| 6 | PMID and DOI resolve to one reference | `test_pmid_and_doi_resolve_to_one_reference` |
| 7 | Divergent providers flag conflict | `test_divergent_providers_flag_conflict`, `test_reconciliation_detects_divergence` |
| 8 | Preprint and article keep separate identities | `test_preprint_and_article_keep_separate_identities`, `test_preprint_keeps_its_own_identity` |
| 9 | Later conflicting metadata refused | `test_later_conflicting_metadata_is_refused` |
| 10 | Retracted reference blocked | `test_retracted_reference_is_blocked`, `test_retraction_detected_from_crossref` |
| 11 | Erratum is not a full retraction | `test_erratum_is_not_treated_as_full_retraction` |
| 12 | Offline re-check preserves state, flags currency | `test_offline_check_preserves_state_and_flags_currency` |
| 13 | Appraisal with a missing field records pending | `test_appraisal_with_missing_fields_records_pending` |
| 14 | Synthetic / automated approval refused | `test_synthetic_cannot_be_approved`, `test_approval_still_requires_human_actor` |
| 15 | Tampered package rejected | `test_tampered_package_rejected` |
| 16 | Acquisition parameters sanitized | `test_provenance_params_are_sanitized` |
| 17 | Concurrent import is safe | `test_concurrent_import_is_safe` |
| 18 | Patient-like data excluded from scientific tables | `test_patient_like_data_is_not_stored_in_scientific_tables` |
| 19 | Historical synthesis fingerprint preserved | `test_acquisition_does_not_change_historical_synthesis` |
| 20 | Offline consultation after acquisition | `test_offline_after_acquisition` |

## Online integration (opt-in)

`test_online_integration.py` hits real providers and is excluded from the default
run. Enable it explicitly and disable the default addopts:

```
BV_RUN_ONLINE=1 python -m pytest -o addopts="" -q tests/test_online_integration.py
```

It verifies a real Crossref lookup by a known DOI (rate-limited to 1 req/s) and
that the frozen corpus snapshot loads with `provider == "CROSSREF"`. The offline
suite never depends on provider availability.
