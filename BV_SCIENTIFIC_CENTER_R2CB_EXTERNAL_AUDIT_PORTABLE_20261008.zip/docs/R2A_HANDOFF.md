# R2A — Handoff

## Status

`BV_SCIENTIFIC_CENTER_R2A_STATUS = PASS`

The scientific curation and evidence-governance infrastructure is in place. The
R1.2 baseline (137 tests) is preserved; 204 tests pass. No clinical recommendation
was introduced; no automatic approval exists.

## What R2A delivers

* **Scientific model** — `ScientificReference`, `ScientificEvidence`,
  `ClinicalClaim`, `EvidenceLink`, `CurationEvent`, and a configurable
  study-design taxonomy with non-automatic methodological suggestions.
* **Curation workflow** — seven explicit states, a validated transition map, an
  audit event per transition, and retraction with claim-impact surfacing.
* **Human approval guard** — reviewer + justification + version required;
  synthetic and unverified content can never be APPROVED.
* **Evidence linking** — FOUNDATIONAL / VALIDATION / DISCUSSION links to formulas,
  scores and rules, without touching historical calculations.
* **Package governance** — author/reviewer, dependencies, provenance, content
  hash, revision history, idempotent import, conflict detection.
* **Search + read-only UI** — filters (title/author/DOI/PMID/type/year/status) over
  FTS5 with safe fallback; approvals only via a local administrative CLI.
* **Verified pilot** — 4 real anthropometric/body-composition references with
  Crossref-verified metadata, imported as `IMPORTED_UNVERIFIED`, never approved.
* **Safe backup** — official `Connection.backup()` with integrity/FK verification
  and SHA-256; explicit failure on invalid artifacts.

## How to run

```sh
python -m pytest                                  # 204 passed
python -m compileall src                          # OK
python -m bv_scientific_center demo               # synthetic + scientific seed
python -m bv_scientific_center backup             # verified backup (sha256)
python -m bv_scientific_center curate --subject reference --id REF-... \
    --action approve --actor reviewer-1 --justification "..."
python run_ui.py --port 8787                      # read-only UI
```

## Documents

`docs/R2A_ARCHITECTURE.md`, `R2A_SCIENTIFIC_CONTRACTS.md`, `R2A_CURATION_MODEL.md`,
`R2A_APPROVAL_RULES.md`, `R2A_TEST_MATRIX.md`, `R2A_BACKUP_PROCEDURE.md`,
`R2A_COMPATIBILITY.md`, `R2A_RESIDUAL_RISKS.md`, `R2A_HANDOFF.md`.
R1 / R1.1 / R1.2 documents are preserved unchanged.

## Handoff to R2B (proposal only — do not start without a new directive)

1. **Progressive real-knowledge ingestion** through the curation pipeline: import
   verified references (Crossref/PubMed) as `IMPORTED_UNVERIFIED`, screen, curate
   and approve with human review; attach evidence to formulas/scores/rules.
2. **Evidence-strength population** when source packages provide it (framework,
   grade, certainty), still human-applied.
3. **Supersede/revision flow** for metadata updates and new versions of a source,
   with claim re-curation.
4. **Semantic search as an index only**, keeping the citation database authoritative.
5. **Reviewer identity** hardening and optional authentication before any
   non-loopback exposure.
6. **Package dependencies resolution** and integrity verification on import.

Do not integrate with the BV Suite Clinical Bot without a new directive.
`GIT_CHANGED = NO`.
