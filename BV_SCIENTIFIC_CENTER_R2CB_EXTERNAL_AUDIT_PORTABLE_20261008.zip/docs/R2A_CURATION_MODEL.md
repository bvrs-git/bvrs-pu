# R2A — Curation Model

States and transitions are enforced in `knowledge/scientific.py`
(`CURATION_TRANSITIONS`) and applied by `knowledge/curation.py`
(`CurationService`). Every transition writes a `CurationEvent`.

## States (GATE 2)

`IMPORTED_UNVERIFIED`, `SCREENED`, `CURATED`, `APPROVED`, `REJECTED`,
`SUPERSEDED`, `RETRACTED`.

## Allowed transitions

| From | To |
| --- | --- |
| IMPORTED_UNVERIFIED | SCREENED, REJECTED, RETRACTED |
| SCREENED | CURATED, REJECTED, SUPERSEDED, RETRACTED |
| CURATED | APPROVED, REJECTED, SUPERSEDED, RETRACTED |
| APPROVED | SUPERSEDED, RETRACTED, REJECTED |
| REJECTED | SUPERSEDED, RETRACTED |
| SUPERSEDED | *(terminal)* |
| RETRACTED | *(terminal)* |

No-op transitions (same status) are refused. Illegal transitions raise
`CurationTransitionError` and leave the record unchanged.

```mermaid
stateDiagram-v2
    [*] --> IMPORTED_UNVERIFIED
    IMPORTED_UNVERIFIED --> SCREENED
    IMPORTED_UNVERIFIED --> REJECTED
    SCREENED --> CURATED
    SCREENED --> REJECTED
    SCREENED --> SUPERSEDED
    CURATED --> APPROVED
    CURATED --> REJECTED
    CURATED --> SUPERSEDED
    APPROVED --> SUPERSEDED
    APPROVED --> RETRACTED
    APPROVED --> REJECTED
    REJECTED --> SUPERSEDED
    SUPERSEDED --> [*]
    RETRACTED --> [*]
```

## Audit

Each transition records `subject_type`, `subject_id`, `from_status`, `to_status`,
`actor`, `justification`, `version` and `created_at`. History is exposed read-only
in the UI and via `CurationService.history(...)`.

## Usage of approved evidence

`is_clinically_usable(status)` is true only for `APPROVED`. A retracted, rejected or
superseded record can no longer be presented as current evidence for clinical
grounding. `CurationService.active_references()` returns only approved references.

## Retraction semantics

* Retraction requires a reason (else `CurationApprovalError`).
* Sets `retraction_reason` on references; `editorial_status = RETRACTED` and
  `retraction_notes` on evidence.
* `claims_impacted_by_retraction(evidence_id)` lists claims that reference the
  broken evidence, with an explicit "not current" warning. Claims are **not**
  modified automatically — a human must re-curate them.

## Methodological suggestion (GATE 3)

`methodology.suggest_assessment(evidence, references_present=...)` returns a
structured **suggestion** with `auto_certainty=False`, `suggested_certainty=None`
and a notice. The taxonomy maps clinical question types to informative designs and
is advisory, not a rigid hierarchy. `MethodologicalAssessment.validate()` refuses
a certainty value without a named human assessor.
