# R2C-A — Evidence Links

`knowledge/evidence_links.py` and the `EvidenceLink` model in
`knowledge/scientific.py` connect a bibliographic subject (a reference, or an
evidence record) to a target such as a `FORMULA_CANDIDATE`. Linking evidence never
mutates a clinical calculation; historical syntheses keep the versions they used.

## Relation types

`EvidenceRelation` combines the legacy R2A values with new, finer-grained R2C-A
relations. Both sets are available.

| Relation | Origin | Meaning |
| --- | --- | --- |
| `FOUNDATIONAL` | legacy | Grounds the definition. |
| `VALIDATION` | legacy | Evaluates performance. |
| `DISCUSSION` | legacy | Discusses use / context. |
| `DERIVATION_ORIGINAL` | R2C-A | The source from which the candidate derives. |
| `METHODOLOGICAL_FOUNDATION` | R2C-A | Methodological basis for the candidate. |
| `INTERNAL_VALIDATION` | R2C-A | Internal validation. |
| `EXTERNAL_VALIDATION` | R2C-A | External validation. |
| `CLINICAL_APPLICATION` | R2C-A | Clinical application context. |
| `LIMITATION` | R2C-A | A limitation of the candidate. |
| `CONTRADICTORY_EVIDENCE` | R2C-A | Evidence that disagrees. |

`LinkTargetType` includes `FORMULA`, `SCORE`, `RULE`, `REFERENCE_RANGE`,
`INCLUSION_CRITERION` and the R2C-A addition `FORMULA_CANDIDATE`.

In the seed, an `ALGEBRAIC_INDEX` candidate is linked with
`METHODOLOGICAL_FOUNDATION`; a non-index candidate (the interpretive placeholder)
is linked with `DERIVATION_ORIGINAL`.

## Justification, verification and version

Every R2C-A link carries, in addition to its relation:

- `justification` — a human-readable rationale.
- `verification_status` — defaults to `"UNVERIFIED"`.
- `link_version` — starts at `1`.

`EvidenceLinkService.link(...)` requires the *subject* to exist (a known reference
or evidence record) and records the actor, target version, applicability,
justification and verification status. `links_for_target(...)` and
`formula_provenance(...)` read them back by target and version.

## No title-based auto-linking

Links are always **explicit**. There is no code path that creates a link by
matching titles. Cross-provider reconciliation (`bibliography/reconcile.py`) groups
records by persistent identity — DOI preferred, then PMID — and states plainly:

> Records are never merged by title similarity.

A preprint (posted-content) and its published article keep their own identities.
This applies equally to evidence links: a candidate is linked to specific
reference ids supplied by a human/seed, never inferred from text.

## Retraction propagation without rewriting history

Editorial alerts are stored separately (`EditorialAlertRepository`). Adding a
retraction alert for a reference attached to a candidate surfaces an alert in the
candidate view, **without** changing the recorded links:

```python
view_before = app.candidate_view("SCI-CAND-FMI")
links_before = len(view_before["evidence_links"])

app.editorial_alerts.add(reference_id=..., alert_type="RETRACTION",
                         source="TEST", details="retracted", is_retraction=True)

view_after = app.candidate_view("SCI-CAND-FMI")
assert len(view_after["evidence_links"]) == links_before  # history preserved
assert view_after["editorial_alerts"]                     # impact surfaced
```

```mermaid
flowchart LR
    REF[Reference] -->|link, versioned| CAND[Formula candidate]
    RET[Retraction alert] -->|adds a warning| VIEW[Candidate view]
    RET -. does not edit .-> CAND
    RET -. does not delete .-> LINK[Stored evidence link]
```

`retraction_impacts(evidence_id)` (through
`CurationService.claims_impacted_by_retraction`) lists claims whose referenced
evidence is now retracted/rejected/superseded, marking them
`"referenced evidence is retracted/rejected; claim is not current"`.

## Separation from operational formulas

Candidate links target `FORMULA_CANDIDATE` ids, which are distinct from the
operational formula registry. A test asserts that no candidate id appears in
`FormulaRegistry().all_latest()`.

See also: `R2C_A_SCIENTIFIC_REVIEW.md`, `R2C_A_HUMAN_REVIEW_HANDOFF.md`.
