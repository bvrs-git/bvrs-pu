# R2C-B — Residual risks

| ID | Risk | Severity | Mitigation / status |
| --- | --- | --- | --- |
| RR-CB-1 | Four of eight selected references have no accessible content in Europe PMC | Medium | Recorded as `SOURCE_UNAVAILABLE` with provenance; no content invented. Pending alternative source in R2C-C. |
| RR-CB-2 | Only abstracts available for 3 references; abstracts cannot validate methodology | Medium | Fields dependent on full text are `INSUFFICIENT_INFORMATION`; `FULL_TEXT_REVIEWED` never inferred. |
| RR-CB-3 | Automated extraction could mis-map a span to a field | Medium | Each field stores the verbatim span + source SHA-256; guard rejects spans absent from the source; provenance is `EXTRACTED_UNVERIFIED`, never `HUMAN_REVIEWED`; tests re-check verbatim membership. |
| RR-CB-4 | Publisher license terms can change after acquisition | Low | License recorded per snapshot; historical snapshots preserved; no automatic re-licensing. |
| RR-CB-5 | Europe PMC availability may change over time | Low | Currency recorded via `check_currency`; expired/offline → "currency unknown"; last known state preserved. |
| RR-CB-6 | A retraction discovered after ingestion | Medium | Retraction alert blocks current use; history preserved; linked formulas flagged. Tested. |
| RR-CB-7 | One `cc by` full text stored; redistribution terms must be respected downstream | Low | Only stored because the license permits; redistribution flag is separate from storage. |
| RR-CB-8 | `-shm`/`-wal` sidecars left next to backup artifacts by verification reads | Very low | Benign; main artifact verified. |
| RR-CB-9 | No human critical review has occurred | High (clinical) | All dossiers pending; 0 approvals; formulas non-operational. This is a clinical, not technical, residual risk. |
| RR-CB-10 | Abstract for one DOI exists with a different DOI/title pair | Low | Identifiers, not titles, govern association; nothing linked by title. |

No residual risk permits clinical activation. Technical PASS does not imply
clinical approval.
