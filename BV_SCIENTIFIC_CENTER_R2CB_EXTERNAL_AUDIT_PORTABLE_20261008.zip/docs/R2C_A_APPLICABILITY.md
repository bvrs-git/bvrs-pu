# R2C-A — Applicability

`knowledge/applicability.py` records, per candidate, in which contexts it has been
validated. Its central rule: **absence of evidence is never presented as evidence
of absence.**

## ApplicabilityProfile

```python
@dataclass
class ApplicabilityProfile:
    applicable_populations: tuple[str, ...] = ()
    not_validated_populations: tuple[str, ...] = ()
    contraindications: tuple[str, ...] = ()
    device_requirements: tuple[str, ...] = ()
    notes: str | None = None
    evidence_refs: tuple[str, ...] = ()
```

`has_constraints()` returns `True` only when at least one of the four constraint
tuples is non-empty. When there are no constraints, the prototype evaluator
**skips applicability evaluation entirely** and proceeds.

## Statuses

| Constant | Meaning |
| --- | --- |
| `APPLICABLE` | The context is validated for this candidate. |
| `NOT_APPLICABLE` | A contraindication or an unsatisfied device requirement. |
| `APPLICABILITY_NOT_ESTABLISHED` | No validation is recorded for the context. |

`evaluate(population=..., device=...)` returns `{"status": ..., "reason": ...}` in
this precedence order:

```mermaid
flowchart TD
    A[population provided?] -->|in contraindications| NA[NOT_APPLICABLE]
    A -->|else check device| B{device_requirements?}
    B -->|device unknown or not in set| NA
    B -->|ok / none| C{population in applicable_populations?}
    C -->|yes| AP[APPLICABLE]
    C -->|no, or population absent| NE[APPLICABILITY_NOT_ESTABLISHED]
```

## APPLICABILITY_NOT_ESTABLISHED semantics

`APPLICABILITY_NOT_ESTABLISHED` is an **explicit marker**, not a rejection and not
a silent pass. It means: *this context has not been validated*. It applies when a
population is neither applicable nor a contraindication, and when no population
context is provided at all (treated as `UNKNOWN`).

- A `PEDIATRIC` context with no validation recorded yields
  `APPLICABILITY_NOT_ESTABLISHED` — never a claim that the candidate is simply
  inapplicable.
- In the prototype evaluator, `APPLICABILITY_NOT_ESTABLISHED` blocks evaluation
  and returns `value=None`, exactly like `NOT_APPLICABLE`.

## Population / condition codes

Canonical codes are held in `POPULATIONS`:

| Code | Label |
| --- | --- |
| `ADULT` | Adults |
| `PEDIATRIC` | Pediatric |
| `PREGNANT` | Pregnancy |
| `ELDERLY` | Older adults |
| `ATHLETE` | Athletes |
| `SEVERE_OBESITY` | Severe obesity |
| `HYDRATION_CHANGE` | Significant hydration change |
| `EDEMA_ASCITES` | Edema / ascites |
| `ACUTE_CONDITION` | Acute conditions |
| `DEVICE_SPECIFIC` | Specific devices/methods |

## Device requirements

`device_requirements` constrains the device/method that may produce an input:

- If requirements are declared and the device is `None`, the status is
  `NOT_APPLICABLE` ("device requirement not satisfied (device unknown)").
- If the device is supplied but not in the required set, the status is
  `NOT_APPLICABLE`.
- If the device matches (or no requirements are declared), evaluation continues to
  the population check.

```python
profile.evaluate(population="ADULT")                       # NOT_APPLICABLE (device unknown)
profile.evaluate(population="ADULT", device="OTHER")       # NOT_APPLICABLE
profile.evaluate(population="ADULT", device="BIA_X")       # APPLICABLE
```

## Round-tripping

`to_dict()` / `from_dict()` preserve all four constraint tuples, `notes` and
`evidence_refs`, so a profile survives candidate serialization unchanged.

See also: `R2C_A_FORMULA_CANDIDATES.md`, `R2C_A_INPUT_SEMANTICS.md`.
