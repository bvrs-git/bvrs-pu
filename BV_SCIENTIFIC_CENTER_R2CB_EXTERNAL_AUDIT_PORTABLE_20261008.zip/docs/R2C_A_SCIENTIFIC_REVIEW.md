# R2C-A — Scientific Review

R2C-A produces a **review sheet (appraisal) per selected reference** with
field-level provenance. Because the frozen corpus carries only bibliographic
metadata — no abstract or full text — the appraisals record what was genuinely
verified and mark everything else as insufficient. Nothing is invented.

## Appraisal sheets

An appraisal is persisted through `AppraisalRepository` (`review_appraisals`
table). Each row carries:

- `reference_id`, `reviewer`, `created_at`, `content_review_status`
- descriptive fields: `scientific_question`, `study_design`, `population`,
  `sample_size`, `inclusion_criteria`, `exclusion_criteria`, `reference_method`,
  `intervention`, `comparator`, `outcomes`, `quantitative_results`,
  `confidence_intervals`, `limitations`, `risk_of_bias`, `clinical_applicability`,
  `author_conclusions`, `reviewer_interpretation`
- provenance machinery: `pending_fields`, `field_provenance`,
  `field_provenance_note`, `validation_metrics`

## Field-level provenance states

`AppraisalFieldProvenance` (`core/enums.py`) distinguishes four states:

| State | Meaning |
| --- | --- |
| `EXTRACTED_UNVERIFIED` | Taken from a machine extraction, not yet checked |
| `SOURCE_VERIFIED` | Confirmed against the consulted source's metadata |
| `HUMAN_REVIEWED` | Explicitly read and judged by a human |
| `INSUFFICIENT_INFORMATION` | Not derivable from what was consulted |

A single appraisal mixes states freely: metadata fields and scientific fields have
different provenance.

## What was verified vs insufficient

For the eight selected DOIs (`SELECTED_DOIS` in `seed/r2ca_seed.py`), the seed
records:

- `SOURCE_VERIFIED` — `doi`, `title`, `publication_year`, `journal`
- `INSUFFICIENT_INFORMATION` — `scientific_question`, `study_design`,
  `population`, `sample_size`, `reference_method`, `outcomes`,
  `quantitative_results`, `limitations`, `clinical_applicability`

The `_APPRAISAL_PENDING` tuple lists exactly the scientific fields that remain
pending; the same fields appear in `pending_fields`. The appraisal note states the
reason explicitly:

> Only bibliographic metadata is available (no abstract/full text consulted);
> scientific fields are not invented.

The appraisal therefore has `content_review_status = "INSUFFICIENT_INFORMATION"`
and `reviewer = None` — **no human review was performed**.

```mermaid
flowchart LR
    R[Selected DOI] --> M[Metadata fields]
    R --> S[Scientific fields]
    M -->|verified against source| V[SOURCE_VERIFIED]
    S -->|no full text available| I[INSUFFICIENT_INFORMATION]
    I --> P[pending_fields]
```

## No invention

- `quantitative_results` stays an empty object `{}` — no numbers were invented.
- `reviewer` is `None` when no human performed the review.
- The seed never fabricates an abstract, a sample size, an effect estimate or a
  confidence interval that the corpus does not contain.

## Validation metrics policy

`ValidationMetrics` (`knowledge/methodology.py`) holds optional strings such as
`correlation`, `agreement`, `mean_bias`, `limits_of_agreement`,
`estimation_error`, `calibration`, `external_validation` and
`subgroup_performance`, plus the flag `reported_by_source`.

Its `validate()` refuses any recorded metric unless it was reported by the
consulted source:

```python
def validate(self) -> None:
    if self.populated_fields() and not self.reported_by_source:
        raise ValueError(
            "Validation metrics cannot be recorded unless reported by the consulted source"
        )
```

Empty metrics are always acceptable. A metric backed by attribution
(`reported_by_source=True`) is acceptable. A metric that appears from nowhere is
refused.

## Methodological assessment is never automatic

`MethodologicalAssessment.validate()` refuses a certainty level other than
`NOT_ASSESSED` unless a human assessor is named:

```python
if self.certainty is not CertaintyLevel.NOT_ASSESSED:
    if not self.human_applied or not self.assessed_by:
        raise ValueError(
            "Certainty cannot be set without a human assessor (GRADE is never automatic)"
        )
```

`suggest_assessment(evidence, references_present=...)` produces a **structured
suggestion only**: it returns `suggested_certainty=None`, `auto_certainty=False`
and an advisory `notice`. It must not be persisted as an assessment without human
editing and an assessor identity. The question-type taxonomy
(`QUESTION_TYPE_TAXONOMY`) suggests which designs *may be informative*; it is
advisory and never implies a design is automatically higher quality.

See also: `R2C_A_EVIDENCE_LINKS.md`, `R2C_A_HUMAN_REVIEW_HANDOFF.md`.
