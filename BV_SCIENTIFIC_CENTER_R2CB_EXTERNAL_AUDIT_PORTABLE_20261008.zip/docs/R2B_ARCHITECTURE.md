# R2B — Bibliographic Architecture

## Purpose

R2B turns the scientific library from a frozen seed into a library that can be
*acquired* from real bibliographic providers, *verified*, *critically appraised*
and finally *approved for clinical use* — while keeping those four operations
strictly independent. The module uses only the Python standard library and
SQLite (including FTS5). No third-party runtime dependency is introduced.

Central principle (carried over from R2A):

> imported evidence is not validated evidence;
> validated evidence is not automatically a clinical recommendation.

Nothing in this layer stores patient data. All R2B tables live in
`knowledge.db`.

## Components

| Module | Responsibility |
| --- | --- |
| `bibliography/models.py` | `BibliographicRecord`, `normalize_doi`, `normalize_pmid`, `content_sha256`; `PROCESSING_VERSION = "r2b-1"`. |
| `bibliography/transport.py` | `HttpTransport` protocol, `UrllibTransport`, `RateLimiter`, `RetryPolicy`, `HttpResponse`, `HttpStatusError`, `RateLimited`. |
| `bibliography/cache.py` | `BibliographyCache` (`cache_key`, `get`, `put`, `count`, `entries`) backed by `bibliography_cache`. |
| `bibliography/crossref.py` | `CrossrefAdapter` (`fetch_by_doi`, `search`), `parse_work`. |
| `bibliography/pubmed.py` | `PubMedAdapter` (`esearch`, `esummary`, `fetch_by_pmid`, `fetch_by_doi`, `search`), `parse_summary`. |
| `bibliography/reconcile.py` | `reconcile`, `ReconciliationResult`. |
| `bibliography/service.py` | `BibliographyService`, `reference_id_for`, `record_to_reference`, `map_publication_type`. |
| `bibliography/corpus.py` | `CORPUS_QUERIES`, `acquire_corpus`, `load_corpus`, `import_corpus`. |
| `knowledge/bibliographic_repository.py` | `AcquisitionRepository`, `EditorialAlertRepository`, `AppraisalRepository`. |
| `app.py` | Facade methods (`acquire_by_doi`, `set_content_review`, `review_queue`, `export_review_queue`, `check_editorial`, `references_for_claim`, `bootstrap_scientific`, …). |

## Layering

```mermaid
flowchart TD
    UI["Read-only UI (ui/server.py)"] --> APP["ScientificCenterApp facade"]
    APP --> SVC["BibliographyService"]
    SVC --> CR["CrossrefAdapter"]
    SVC --> PM["PubMedAdapter"]
    CR --> TR["HttpTransport / UrllibTransport"]
    PM --> TR
    CR --> CACHE["BibliographyCache"]
    PM --> CACHE
    CACHE --> DB["knowledge.db"]
    SVC --> REPO["Acquisition / EditorialAlert / Appraisal repositories"]
    SVC --> REF["ScientificReferenceRepository"]
    REPO --> DB
    REF --> DB
```

## Adapters and transport

Both adapters normalize *exactly* what the provider returns; they never fabricate
metadata. Each accepts an injected transport and an optional `BibliographyCache`.

* `UrllibTransport` sends an identifiable `User-Agent`:
  `BVScientificCenter/0.1 (mailto:contact@example.invalid)`. No personal email or
  credential is hardcoded; a `mailto` (Crossref) or `api_key` (PubMed) is supplied
  by configuration only.
* `RateLimiter` enforces a minimum interval, default **3 requests/second**.
* `RetryPolicy` applies exponential backoff (`0.5s`, `1s`, `2s`, … capped at `8s`).
* An HTTP **429** is retried honoring `Retry-After`; when retries are exhausted a
  `RateLimited` exception is raised. `5xx` responses are retried; other errors
  raise `HttpStatusError`.
* A malformed provider response is handled and surfaced as `None`, never as a
  value (see `tests/test_bibliography_adapters.py`).

## Offline-first

* The transport is injectable, so the automated suite uses frozen fixtures and
  never depends on Crossref/PubMed availability.
* After a successful acquisition, `BibliographyCache` serves the same request
  again with no network access (`tests/test_bibliography_provenance.py`).
* The initial corpus is a frozen JSON snapshot consumed offline
  (`bibliography/corpus.py`, `data/seed/corpus_bibliography.json`).

## Four independent operations

```mermaid
flowchart LR
    A["1. Identify a publication"] --> B["2. Verify its metadata"]
    B --> C["3. Critically appraise content"]
    C --> D["4. Approve clinical use (local CLI)"]
    A -.-> C
    A -.-> D
    B -.-> D
```

None of the operations implies another. The state is carried on
`ScientificReference` through three distinct dimensions:

* **Bibliographic verification** — `BibliographicVerification`
  `{PENDING, VERIFIED, CONFLICT, UNAVAILABLE}`, set during acquisition and
  reconciliation.
* **Content review** — `ContentReviewStatus`
  `{NOT_REVIEWED, ABSTRACT_REVIEWED, FULL_TEXT_REVIEWED, CRITICALLY_APPRAISED, INSUFFICIENT_INFORMATION}`,
  set by a reviewer via `set_content_review`.
* **Editorial curation** — `CurationStatus` (R2A state machine), changed only
  through `CurationService`, whose `APPROVED` transition requires a human actor
  and a justification.

`BibliographicVerification`, `ContentReviewStatus` and `EditorialAlertType` live
in `core/enums.py`; `VerificationStatus` and `CurationStatus` live in
`knowledge/scientific.py`.

## Persistence

R2B adds four tables and four columns (see `R2B_PROVENANCE_SCHEMA.md`):

| Table | Role |
| --- | --- |
| `bibliography_cache` | Offline response cache. |
| `acquisition_records` | Per-acquisition provenance. |
| `editorial_alerts` | Retraction / correction / erratum / concern notices. |
| `review_appraisals` | Structured critical appraisals. |

`scientific_references` gains `bibliographic_status`, `content_review_status`,
`issn` and `last_checked_at`; the migration is additive and non-destructive
(`storage/schema.py`, `_migrate` in `storage/database.py`).

## Boundaries

* The HTTP UI is **read-only**; there is no approval route.
* Approval is a local administrative action (`python -m bv_scientific_center curate`).
* No formula, score or rule is imported or changed by acquisition; historical
  synthesis reconstructions keep their logical fingerprint.
