# R1 — Clinical Synthesis Run

A **run** is the reproducible unit of computation. It records the input
snapshot, the formula/score/rule versions used, the knowledge package version
and the timestamps. Historical results are never rewritten: a knowledge update
creates a **new run**.

Module layout:

| Path | Responsibility |
| --- | --- |
| `synthesis/run.py` | `SynthesisRunResult`, `SynthesisRunner` |
| `observations/refs.py` | `ScientificObservationRef`, `ProjectionIngestor` |
| `events/bus.py` | `EventBus` and the published domain events |
| `app.py` | `run_synthesis`, `reproduce_run`, `latest_run` wrappers |

---

## 1. Run record

`SynthesisRunResult` carries:

| Field | Meaning |
| --- | --- |
| `run_id` | Generated run identifier |
| `patient_id` | Patient identifier |
| `status` | `SynthesisRunStatus` (`STARTED`, `COMPLETED`, `FAILED`, `PARTIAL`) |
| `started_at`, `completed_at` | UTC timestamps |
| `knowledge_package_version` | Version of the active knowledge package (or `None`) |
| `observation_refs` | The ingested observation references (the input snapshot) |
| `metrics` | Computed `DerivedClinicalMetric` results |
| `scores` | Computed `ClinicalScoreResult` results |
| `signals` | Emitted `ClinicalSignalCandidate` results |
| `rule_evaluations` | One `RuleEvaluation` per rule |
| `formula_versions` | `{definition_id: version}` for every formula used |
| `score_versions` | `{definition_id: version}` for every score used |
| `rule_versions` | `{definition_id: version}` for every rule used |

Convenience properties: `valid_metrics` and `valid_scores` (only
`is_valid` results), and `to_dict()`.

The persisted run record (`SynthesisRunner._run_record`) stores exactly:
`run_id`, `patient_id`, `knowledge_package_version`, `input_snapshot`
(`[ref.snapshot() for ref in observation_refs]`), `formula_versions`,
`score_versions`, `rule_versions`, `started_at`, `completed_at`, `status`, and
`meta` containing the metric ids and signal ids.

---

## 2. `SynthesisRunner.run` flow

```python
SynthesisRunner(
    *, formulas, scores, rules,
    observations=None, metrics=None, score_results=None, signals=None, runs=None,
    event_bus=None, knowledge_package_version=None,
)

runner.run(
    patient_id, projections=(), *,
    observation_refs=None, context=None, persist=True,
) -> SynthesisRunResult
```

```mermaid
sequenceDiagram
    participant Caller
    participant Runner as SynthesisRunner
    participant Ingest as ProjectionIngestor
    participant Formula as compute_metric
    participant Score as compute_score
    participant Rule as evaluate_rule
    participant Store as Repositories
    participant Bus as EventBus

    Caller->>Runner: run(patient_id, projections, context)
    Runner->>Runner: run_id + started_at (now_utc)
    Runner->>Ingest: ingest_many(projections)
    Ingest-->>Runner: ScientificObservationRef[]
    Runner->>Store: save_many(refs)  (persist=True)
    Runner->>Runner: group refs by concept
    loop every usable formula (latest)
        Runner->>Formula: compute_metric(formula, refs_by_concept)
        Formula-->>Runner: DerivedClinicalMetric
        Runner->>Store: save(metric, run_id)
        Runner->>Bus: emit DerivedMetricComputed (if valid)
    end
    loop every usable score (latest)
        Runner->>Score: compute_score(score, refs_by_concept)
        Score-->>Runner: ClinicalScoreResult
        Runner->>Store: save(score_result, run_id)
    end
    Runner->>Runner: group metrics by definition
    loop every usable rule (latest)
        Runner->>Rule: evaluate_rule(rule, observations, metrics)
        Rule-->>Runner: RuleEvaluation
        Runner->>Store: save(signal, run_id)
        Runner->>Bus: emit ClinicalSignalGenerated (if signal)
    end
    Runner->>Runner: completed_at + status=COMPLETED
    Runner->>Store: save(run record)
    Runner->>Bus: emit SynthesisRunCompleted
    Runner-->>Caller: SynthesisRunResult
```

Notes:

- Only definitions whose status is `VALIDATED_FOR_USE` (`is_usable`) are
  executed; `all_latest()` selects the newest version of each definition.
- `metrics` are grouped by definition id (`_group_metrics`) and passed to rules,
  which is how `DERIVED_METRIC` inputs are resolved.
- Refusals are values, so a refused metric/score does not abort the run; it is
  persisted with its `calculation_status` and simply produces no event.
- Rules are evaluated with `generated_at=started_at` and the run's `run_id`, so
  every signal is linked back to its run.

---

## 3. Input snapshot design

Ingestion produces immutable `ScientificObservationRef` objects. Each
`snapshot()` returns a **minimal** value snapshot — enough to reproduce the
computation without needless duplication:

```python
{
  "observation_ref_id", "concept", "value", "unit", "effective_at",
  "source_module", "source_entity_type", "source_entity_id",
  "source_version", "authority", "fasting_status",
}
```

The Scientific Center **references** source observations; it never clones source
tables. The snapshot records the essential value plus the pointer (entity id and
version) so a run remains auditable even if the source row later changes. MISSING
semantics are preserved: an absent value keeps `value is None` and is never
coerced to `0`.

---

## 4. Events published

`EventBus` only publishes recognised domain events (`EVENT_TYPES`). Map rendering
is a pure projection and is deliberately **not** published. During a run:

| Event | When | Key payload |
| --- | --- | --- |
| `DerivedMetricComputed` | A valid metric is produced | `metric_id`, `definition`, `version`, `value`, `unit` |
| `ClinicalSignalGenerated` | A rule matches and emits a signal | `signal_id`, `rule`, `rule_version`, `severity` |
| `SynthesisRunCompleted` | End of run | `run_id`, `metrics`, `scores`, `signals` counts |

Every event carries `patient_id` and `run_id` for correlation.

---

## 5. Reproducibility

A run is reproducible because it records:

- **which inputs** — the immutable input snapshot with value, unit and source
  reference/version;
- **which versions** — `formula_versions`, `score_versions`, `rule_versions`;
- **which formula/score/rule** — by `definition_id`;
- **which package** — `knowledge_package_version`;
- **when computed** — `started_at` and `completed_at`;
- **what was produced** — metric ids and signal ids in `meta`.

`ScientificCenterApp.reproduce_run(patient_id, context=...)` rebuilds a run from
stored observations with `persist=False`, so results can be recomputed and
compared against stored values without creating history. Definitions are
immutable: a changed definition must be published as a new version
(`DuplicateDefinitionError` otherwise), and each result stays pinned to the
version and content hash it used.

---

## 6. New run, never rewrite history

- Every call to `run(...)` generates a fresh `run_id` and a new
  `SynthesisRunResult`; prior runs are retained.
- A knowledge or definition update is applied by running again — it never edits
  or deletes historical results.
- Because refusals are recorded as values and versions are pinned, an old run can
  always be explained and reproduced.
