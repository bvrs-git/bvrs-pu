# R2C-A — Residual Risks

Known, accepted limitations of the R2C-A phase. Each is a deliberate trade-off, not
an undetected defect.

## 1. No full text consulted — scientific fields are insufficient

The frozen corpus carries only bibliographic metadata. Every scientific field in an
appraisal is `INSUFFICIENT_INFORMATION` and listed in `pending_fields`; no sample
size, effect estimate or confidence interval was invented. **Impact:** the
appraisals ground nothing scientific on their own; a human must consult the full
texts before any content review. **Mitigation:** the honest provenance model prevents
insufficient fields from being mistaken for reviewed ones, and `ValidationMetrics`
refuses unreported numbers.

## 2. Reviewer identity is a local string

A reviewer is a caller-supplied label, not an authenticated principal. The UI states
this explicitly ("declared, not authenticated"). **Impact:** the audit trail records
*who claims* to have acted; it does not prove identity. **Mitigation:** approval still
requires an actor and a justification (`require_approval_actor`), and the phase
performs no approvals.

## 3. No UI authentication / no HTTP approval

The candidate and human-review routes are read-only and unauthenticated; there is no
HTTP approval action (approval paths return `404`). **Impact:** the UI cannot be used
to change review state, but it also cannot be relied on for access control.
**Mitigation:** state changes are confined to the local CLI (`curate`) and the
library API.

## 4. Prototype evaluator is test-only

`evaluate_candidate_prototype` exists to check candidate definitions in tests. It is
never wired into clinical synthesis. **Impact:** the "math is validated" claim is
scoped to the prototype and its independently computed fixtures; it is not an
operational execution path. **Mitigation:** candidates are non-operational by
construction and cannot be resolved by the operational `FormulaRegistry`.

## 5. Small corpus

The candidate set (7) and the selected DOIs (8) are a pilot. **Impact:** coverage is
narrow; many contexts are `APPLICABILITY_NOT_ESTABLISHED`. **Mitigation:** the
explicit `APPLICABILITY_NOT_ESTABLISHED` marker avoids turning missing evidence into
a false claim of inapplicability.

## 6. Cross-database non-atomicity

Runtime state spans `knowledge.db` and `derived.db`. A candidate write and a
synthesis write cannot be committed as a single cross-file transaction. **Impact:** a
crash between writes could leave the two files at different logical points.
**Mitigation:** candidate seeding is idempotent (duplicate import is a no-op) and
does not touch synthesis, so it cannot alter a historical run fingerprint; verified
backups are available (`backup` command).

## 7. Cutoffs not imported

No cutoff or predictive equation is imported as a diagnostic criterion. The WHtR
placeholder carries `metadata = {"cutoff_defined": False}` and the interpretive
criterion type exists without any threshold. **Impact:** candidates produce raw
indices only — no interpretation. **Mitigation:** this is the intended state;
importing a cutoff requires a future, explicitly reviewed step.

## Summary

| # | Risk | Severity | Status |
| --- | --- | --- | --- |
| 1 | No full text consulted | High | Accepted; pending_fields + metrics policy |
| 2 | Reviewer identity is a local string | Medium | Accepted; no approvals performed |
| 3 | No UI auth / no HTTP approval | Medium | Accepted; CLI/library only |
| 4 | Prototype evaluator test-only | Low | By design |
| 5 | Small corpus | Medium | Accepted; explicit NOT_ESTABLISHED |
| 6 | Cross-database non-atomicity | Medium | Accepted; idempotent, fingerprint-safe |
| 7 | Cutoffs not imported | Low | By design |

See also: `R2C_A_HUMAN_REVIEW_HANDOFF.md`, `R2C_A_TEST_MATRIX.md`.
