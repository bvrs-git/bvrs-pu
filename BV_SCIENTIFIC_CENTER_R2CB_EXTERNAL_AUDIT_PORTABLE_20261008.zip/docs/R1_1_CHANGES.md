# R1.1 — Changes (Controlled Corrections)

Six demonstrated defects were fixed. For each: original failure → regression test →
minimal change → specific test run → full regression → decision. No unrelated
edits; no R2 features.

Full regression after every change: `python -m pytest` = **108 passed**;
`python -m compileall src` = OK.

---

## F1 — Record ingestion date (GATE 2A)

* **Failure:** derived-metric inputs exposed only the clinical date; registration
  date was missing, allowing clinical vs ingestion time to be conflated.
* **Regression test:** `tests/test_provenance.py`.
* **Change:**
  * `observations/refs.py` — added `ingested_at` field + included it in
    `snapshot()`.
  * `storage/schema.py` — `observations.ingested_at TEXT`.
  * `storage/database.py` — additive migration for legacy DBs.
  * `storage/repositories.py` — persist/read `ingested_at` (legacy fallback to
    `created_at`).

## F2 — Idempotent ingestion (GATE 2C / 3)

* **Failure:** re-ingesting identical projections duplicated observation rows
  (23 → 46).
* **Regression test:** `tests/test_idempotency.py`.
* **Change:**
  * `core/ids.py` — added `stable_id(prefix, *parts)`.
  * `observations/refs.py` — `_stable_ref_id(...)` used by every ingestor
    (`INSERT OR REPLACE` semantics in the repository make persistence idempotent).

## F3 — Patient isolation (GATE 3)

* **Failure:** a run could compute metrics for patient B from patient A
  references.
* **Regression test:** `tests/test_patient_isolation.py`.
* **Change:**
  * `synthesis/run.py` — `_ingest` validates every reference against the run's
    `patient_id` and raises `ContractViolation` (fail-closed) before computing.

## F4 — Deterministic reconstruction (GATE 5)

* **Failure:** rebuilding a stored run produced different map node ids
  (symmetric difference 22).
* **Regression test:** `tests/test_determinism.py`.
* **Change:**
  * `synthesis/run.py` — `SynthesisRunner.reconstruct_run(...)`;
    `_run_record` now records `meta.observation_ref_ids`.
  * `storage/repositories.py` — `list_for_run` on metrics, scores and signals.
  * `app.py` — `ScientificCenterApp.rebuild_run(patient_id, run_id)`.
  * `ui/server.py` — map route prefers `rebuild_run` for a completed stored run.

## F5 — Fail-closed persistence (GATE 3)

* **Failure:** a raising run wrote no audit record and could leave partial writes.
* **Regression test:** `tests/test_fail_closed.py`.
* **Change:**
  * `synthesis/run.py` — compute-before-persist; `try/except` records a `FAILED`
    run (`meta.error_type`/`meta.error`) and re-raises; no partial derived data.

## F6 — Knowledge governance (GATE 4)

* **Failure:** no formal separation of synthetic / imported / approved knowledge;
  approval depended only on citation metadata.
* **Regression test:** `tests/test_governance.py`.
* **Change:**
  * `core/enums.py` — `KnowledgeOrigin` (`SYNTHETIC_TEST`, `IMPORTED`, `CURATED`).
  * `knowledge/models.py` — `origin` field; `can_approve` blocks synthetic
    content.
  * `knowledge/repository.py` — `save_item`/`set_status` raise
    `KnowledgeGovernanceError` for synthetic approval; `origin` persisted/read.
  * `errors.py` — `KnowledgeGovernanceError`.
  * `storage/schema.py` + `storage/database.py` — `knowledge_items.origin` +
    additive migration.
  * `seed/knowledge_seed.py` — synthetic fixtures marked
    `origin=SYNTHETIC_TEST`.

---

## Verified, not changed (no defect)

* Division by zero returns `ERROR` with `value=None` (never a value).
* Expression sandbox rejects arbitrary execution.
* FTS/SQL injection is safe (parameterized + token-quoted).
* UI binds loopback by default; unknown routes 404.
* Publishing an identical definition is idempotent.
* Map nodes/edges remain traceable (no orphans).

## Files changed

```
src/bv_scientific_center/core/enums.py
src/bv_scientific_center/core/ids.py
src/bv_scientific_center/errors.py
src/bv_scientific_center/observations/refs.py
src/bv_scientific_center/storage/schema.py
src/bv_scientific_center/storage/database.py
src/bv_scientific_center/storage/repositories.py
src/bv_scientific_center/synthesis/run.py
src/bv_scientific_center/knowledge/models.py
src/bv_scientific_center/knowledge/repository.py
src/bv_scientific_center/seed/knowledge_seed.py
src/bv_scientific_center/app.py
src/bv_scientific_center/ui/server.py
tests/  (9 new test files; +40 tests)
docs/R1_1_*.md  (new)
```

## Reconciliation (R1.2)

The R1.1 devolutiva reported “8 new test files”; the correct count is **9**
(`test_provenance`, `test_idempotency`, `test_patient_isolation`,
`test_determinism`, `test_fail_closed`, `test_governance`,
`test_calculation_safety`, `test_ui_security`, `test_migration`). The
`R1_1_TEST_MATRIX.md` already listed nine; only this line was off by one and is
corrected here.

## Compatibility

Changes are additive: no public contract was removed, no route renamed, no
destructive migration. Existing R1 behavior and the 12 R1 gates remain green.
