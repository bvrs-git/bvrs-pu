# R1.2 — Transaction Strategy

## Principle

All rows that belong to one synthesis run in the **same database** are persisted
as a single transactional unit. `knowledge.db` and `derived.db` are separate
files; the module never assumes cross-database atomicity.

## Connection configuration

`storage/database.py`:

* `isolation_level = None` — the module controls transactions explicitly (no
  implicit partial commits).
* `PRAGMA busy_timeout = 5000` — tolerate short lock contention.
* `PRAGMA journal_mode = WAL` for file databases — concurrent readers with a
  writer.
* `PRAGMA foreign_keys = ON`.
* a per-database `threading.RLock` (`Database.write_lock`) serializes writes on
  the shared connection (the UI server is threaded).

## Explicit transaction

```python
@contextmanager
def transaction(self, namespace="clinical"):
    conn = self.clinical if namespace == "clinical" else self.knowledge
    with self._write_lock:
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except BaseException:
            conn.rollback()
            raise
        else:
            conn.commit()
```

Not re-entrant by design; do not nest transactions on the same database.

## Synthesis cycle

```
run():
    ingest (in memory; validates patient isolation)
    compute (in memory; no writes)
    _persist(result):
        with database.transaction("clinical"):
            observations   (commit=False)
            derived_metrics(commit=False)
            score_results  (commit=False)
            signals        (commit=False)
            synthesis_run  (commit=False)   # status = COMPLETED
        # single COMMIT here
    _emit(events)          # after commit, outside the transaction
except:
    _record_failure()      # separate, controlled transaction: status = FAILED
    raise
```

Repository `save*` methods gained a `commit: bool = True` parameter so the runner
can defer commits to the enclosing transaction. Calls outside the runner keep the
previous behavior (`commit=True`).

## Failure semantics

* On failure mid-persist the transaction **rolls back**, leaving the previous
  state intact.
* No partial run appears as `COMPLETED`.
* A single `FAILED` run is recorded in a **separate** transaction (metadata:
  `error_type`, `error`); no duplicate finalization.
* `_emit` runs only after a successful commit, so events never describe a run
  that was rolled back.

## Tests

`tests/test_transactions.py`: rollback on injected mid-persist failure; no partial
`COMPLETED`; correlated rows present after success; single `FAILED` per attempt.
`tests/test_concurrency.py`: concurrent re-ingestion, concurrent runs for distinct
patients, read-while-writing, index/constraint integrity.

## Residual

Persistence through a single shared connection serialized by a lock is sufficient
for the prototype (loopback UI). Scaling would move to per-operation connections
plus WAL; see `R1_2_RESIDUAL_RISKS.md`.
