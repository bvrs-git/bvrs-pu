# R2B — Handoff

## Status

| Dimension | Status |
| --- | --- |
| Technical implementation | **PASS** |
| Test suite | **PASS** — 258 passed, 2 skipped (online, opt-in) |
| R2A baseline preserved | **PASS** — 204 |
| Clinical approval of the corpus | **PENDING** — no human approval performed |

R2B delivers the real bibliographic layer: acquisition from Crossref and PubMed,
offline-first operation, per-acquisition provenance, cross-provider reconciliation
by persistent identity, two independent review dimensions, editorial-alert
handling, a human review queue, and a frozen initial corpus.

## What was delivered

* Adapters and transport: `CrossrefAdapter`, `PubMedAdapter`, `UrllibTransport`,
  `RateLimiter`, `RetryPolicy`, `RateLimited`.
* Offline cache backed by `bibliography_cache`.
* Reconciliation by persistent identity (never by title).
* `BibliographyService` with acquisition, provenance, editorial alerts and
  appraisals; facade methods on `ScientificCenterApp`.
* New tables (`bibliography_cache`, `acquisition_records`, `editorial_alerts`,
  `review_appraisals`) and additive columns on `scientific_references`.
* CLI commands: `acquire`, `corpus`, `review-export`, `content-review`, `curate`,
  `backup`.
* Read-only UI routes: `/knowledge/references`, `/knowledge/reference/<id>`,
  `/knowledge/curation`, `/knowledge/review-queue`.
* Frozen corpus `data/seed/corpus_bibliography.json` (15 records) plus 4 pilot
  references = 19 real references, all unapproved.

## Explicit non-claims

* **No clinical approval was performed.** Every reference remains
  `IMPORTED_UNVERIFIED`; `curation.active_references()` is empty.
* **No cutoff value or equation was imported** for clinical execution.
* **No formula, score or rule was changed.** Historical synthesis reconstructions
  keep their logical fingerprint after acquisition
  (`test_acquisition_does_not_change_historical_synthesis`).
* **No patient data** is stored in any scientific table.
* Approval remains a local administrative action; the HTTP surface has no
  approval route.

## Technical evidence

* `python -m pytest` → 258 passed, 2 skipped.
* RR-7 resolved: `content_hash()` is never shadowed; the stored hash lives in the
  dedicated `content_hash_value` field.
* Offline suite never depends on provider availability; online tests are gated by
  `BV_RUN_ONLINE=1`.

## Proposed next phase (R2C) — proposal only

The following are suggestions, not commitments, and require their own review and
approval before implementation:

1. **Progressive ingestion** — scheduled/background acquisition with explicit
   currency re-checks, so references are refreshed without manual runs.
2. **Appraisal workflow** — a guided capture flow for `review_appraisals`
   (including `provenance_locations` and `pending_fields`) with reviewer
   assignment and completion tracking.
3. **Semantic search as an index** — an embedding-based index over references and
   evidence, used only for retrieval; it must never substitute for verification or
   approval.
4. **Reviewer identity hardening** — replace the declared reviewer string with an
   authenticated identity (or a signed local identity), so approval provenance
   cannot be self-asserted.

Each proposal should preserve the existing separations: identification,
verification, content appraisal and clinical approval stay independent; no
automation may produce an approval.
