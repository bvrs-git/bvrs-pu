# R2B — Provenance Schema

## Acquisition records

Every provider response that is imported produces one `acquisition_records` row
(`knowledge/bibliographic_repository.py`, `AcquisitionRepository.append`). Columns:

| Column | Meaning |
| --- | --- |
| `acquisition_id` | Generated id (`ids.new_id("acq")`). |
| `reference_id` | The library reference the acquisition belongs to. |
| `provider` | `CROSSREF` or `PUBMED`. |
| `endpoint` | Full request URL (e.g. `https://api.crossref.org/works/<doi>`). |
| `params_json` | Request parameters, **sanitized** (see below). |
| `queried_at` | UTC timestamp of the query (`to_iso(now_utc())`). |
| `record_identity` | The provider record id (DOI for Crossref, PMID for PubMed). |
| `identifiers_json` | Original and normalized identifiers (see below). |
| `payload_sha256` | SHA-256 of the provider payload. |
| `processing_version` | Normalization version, `"r2b-1"`. |
| `verification_status` | Reconciliation outcome value (`VERIFIED` / `CONFLICT` / …). |
| `divergences_json` | Field divergences for the primary provider record. |
| `created_at` | Row insertion timestamp. |

A non-unique index `idx_acquisition_reference` covers `reference_id`.

## Sanitized parameters

`BibliographicRecord.sanitized_params()` replaces the value of any key whose
lowercased name contains `key`, `token`, `secret`, `mail`, `email` or `password`
with the literal `"<redacted>"`. All other values pass through unchanged. This
means a configured Crossref `mailto` or PubMed `api_key` is never persisted in
clear text (`test_provenance_params_are_sanitized`).

## Payload hash

`payload_sha256` is produced by `content_sha256` in `bibliography/models.py`:
SHA-256 over `json.dumps(payload, sort_keys=True, default=str)` encoded as UTF-8.
It is computed from the record's `raw` payload, or from a minimal
`{"id": provider_record_id}` stanza when no raw payload exists, so every record
carries a 64-hex-character digest (`test_import_records_provenance`).

The cache stores a second digest: `bibliography_cache.response_sha256` is the
SHA-256 of the raw response body, distinct from the record payload digest.

## Identifiers

`identifiers_json` records both normalized and original forms, e.g.:

```json
{
  "doi": "10.1234/abc.2019",
  "pmid": null,
  "issn": ["1111-2222", "3333-4444"],
  "original_doi": "10.1234/Abc.2019"
}
```

`doi`, `pmid` and `issn` are the normalized values carried on the record;
`original_doi` is read from the provider payload (`raw["DOI"]`) so the exact
source value is recoverable.

## Cache table (`bibliography_cache`)

| Column | Meaning |
| --- | --- |
| `cache_key` | SHA-256 of `{provider, endpoint, params}` (`cache_key`). |
| `provider` | Provider name. |
| `request_json` | `{endpoint, params}` used for the request. |
| `response_json` | Raw response body (decoded). |
| `response_sha256` | SHA-256 of the response body. |
| `status_code` | HTTP status of the cached response. |
| `created_at` | UTC timestamp. |

`get` reconstructs an `HttpResponse` from the row, so a cached lookup succeeds
with no transport at all (`test_offline_cache_serves_without_transport`).

## Related tables

* `editorial_alerts` — `alert_id`, `reference_id`, `alert_type`, `source`,
  `detected_at`, `details`, `is_retraction`, `created_at` (see
  `R2B_RETRACTION_HANDLING.md`).
* `review_appraisals` — see `R2B_HUMAN_REVIEW_POLICY.md`.

## New columns on `scientific_references`

Added additively by `_migrate` (never drops or rewrites data):
`bibliographic_status`, `content_review_status`, `issn`, `last_checked_at`
(alongside the existing `isbn`, `content_hash`, `origin`).
