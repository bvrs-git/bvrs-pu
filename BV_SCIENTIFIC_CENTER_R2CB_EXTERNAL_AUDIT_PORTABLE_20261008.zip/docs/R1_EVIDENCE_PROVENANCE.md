# R1 — Evidence, Provenance and Target Ranges

Every derived node, edge, metric, signal and scientific claim must be
**traceable**. Provenance is explicit and typed; evidence-strength fields are
kept optional and are populated **only when a source actually supports them**.
Grades are never invented.

Module layout:

| Path | Responsibility |
| --- | --- |
| `contracts/outputs.py` | `Provenance`, map projections, `ClinicalMapMetadata` |
| `knowledge/models.py` | `KnowledgeReference`, `ScientificKnowledgeItem`, `ScientificClaim`, `TargetRange` |
| `core/enums.py` | `TargetType`, review-status enums |
| `seed/knowledge_seed.py` | Synthetic (clearly-labelled) knowledge fixtures |

---

## 1. The `Provenance` model

`contracts/outputs.py` defines `Provenance`, attached to every map node and edge:

| Field | Meaning |
| --- | --- |
| `source_ref` | Pointer to a source observation |
| `source_module`, `source_entity_id` | Source module and entity |
| `formula_id`, `formula_version` | Deriving formula (if any) |
| `score_id`, `score_version` | Deriving score (if any) |
| `rule_id`, `rule_version` | Deriving rule (if any) |
| `annotation_id` | Clinician annotation (if any) |
| `evidence_refs` | Knowledge reference ids backing the item |
| `note` | Free-text note |

### Traceability requirement

`Provenance.is_traceable()` is true when **at least one** anchor is present:
`source_ref`, `formula_id`, `score_id`, `rule_id` or `annotation_id`.
`describe()` renders a human-readable trace (e.g.
`formula=T/E@1; rule=RULE_X@2`) or `"UNTRACEABLE"` when nothing anchors it.

The map builder rejects **orphan** nodes: a map node/edge must carry a
`source_ref`, a `formula_id`/`rule_id` (+version), or an explicit clinician
`annotation_id`. `MapEdgeProjection.why_connected()` answers
"WHY ARE THESE CONNECTED?" with the relation, whether it is
causal (`CAUSAL_MODEL_SUPPORTED`), the rule id/version, evidence refs and an
explanation — no opaque edges.

```mermaid
flowchart TD
    P[Provenance] --> S[source_ref]
    P --> F[formula_id + version]
    P --> SC[score_id + version]
    P --> R[rule_id + version]
    P --> A[annotation_id]
    S --> T{is_traceable?}
    F --> T
    SC --> T
    R --> T
    A --> T
    T -- yes --> OK[traceable map node/edge]
    T -- no --> ORPH[rejected as orphan]
```

---

## 2. Claim-level provenance

`ScientificClaim` records the provenance of a single statement:

| Field | Meaning |
| --- | --- |
| `claim_id` | Claim identifier |
| `text` | The claim text |
| `knowledge_item_id` | Owning knowledge item (or `None`) |
| `supporting_reference_ids` | References that support the claim |
| `review_status` | `ClaimReviewStatus` |
| `created_at` | Creation timestamp |

`ClaimReviewStatus` lifecycle: `UNREVIEWED`, `IN_REVIEW`, `SUPPORTED`,
`UNSUPPORTED`. A claim is traceable to its supporting references and carries its
own review state; claims are displayed with that state so a reviewer can see at a
glance whether a statement is supported.

---

## 3. Evidence strength is optional — never invented

`ScientificKnowledgeItem` carries optional evidence fields:

| Field | Meaning |
| --- | --- |
| `evidence_level` | Source-specific level text |
| `evidence_framework` | The framework the level belongs to (e.g. a named grading scheme) |
| `evidence_grade` | Grade within that framework |
| `certainty` | Certainty qualifier |
| `reviewer` | Person who reviewed the item |

These are all `str | None`. They stay `None` unless the source provides them, and
the module never synthesises, upgrades or infers a grade. Reviewers are recorded
only when a real review occurred.

Citation completeness is enforced before approval:

- `KnowledgeReference.has_minimum_citation()` requires a non-empty `citation`,
  a `year`, and at least one locator (`doi`, `url` or `source`).
- `ScientificKnowledgeItem.has_minimum_citation()` requires a non-empty
  `citation`, a `publication_year`, and at least one locator (`doi`, `url` or
  `journal`).
- `ScientificKnowledgeItem.can_approve(require_citation=True)` returns `False`
  when the minimum citation is missing.

Fixtures in `seed/knowledge_seed.py` are explicitly labelled **SYNTHETIC
FIXTURE**: placeholder citations, `source_type=CONSENSUS`, seeded with
`require_citation=False`, kept at `IN_REVIEW` — deliberately **not APPROVED**.
Production content is imported through reviewed knowledge packages carrying real
citation metadata.

---

## 4. Citation display expectations

Citations are surfaced from the reference metadata, not invented:

- display the `citation` string together with `title`, `source`/`journal`,
  `year` and, when present, a `doi`/`url` link;
- show the evidence context as `evidence_framework` / `evidence_grade`
  (rendering `-` when absent, never a fabricated value);
- list the item's claims with their `review_status` so support status is visible;
- show the `target_type` when a knowledge item concerns a target rather than a
  lab reference.

---

## 5. Target types and the "optimal range" safety rule

`TargetType` distinguishes clinical targets from laboratory ranges:

| Value | Meaning |
| --- | --- |
| `LAB_REFERENCE` | A laboratory's reference interval |
| `GUIDELINE_TARGET` | A target from a clinical guideline |
| `OPTIMAL_RANGE` | A range presented as "optimal" |
| `CLINICIAN_TARGET` | A target set by the treating clinician |

`TargetRange` carries `target_type`, `population`, `source`, `version`,
`evidence_refs`, optional `low`/`high`/`unit` and a `note`. Its `attribution()`
returns `target_type`, `population`, `source`, `version` and `evidence_refs` so
every target states where it came from.

**Safety rule: a laboratory reference range is not a clinical target, and a
target is never conflated with a lab reference range.** An `OPTIMAL_RANGE` (or
any other target type) must:

- be typed with its own `TargetType`, never silently presented as a
  `LAB_REFERENCE`;
- carry its `source`, `version` and `evidence_refs`;
- be attributed to a `population` where relevant;
- be shown with its provenance, so a clinician can judge the basis of the
  "optimal" claim rather than reading it as a universal reference interval.

Because targets are first-class, typed and attributed, the map and reports can
display them without ever degrading a target into a reference range (or the
reverse).
