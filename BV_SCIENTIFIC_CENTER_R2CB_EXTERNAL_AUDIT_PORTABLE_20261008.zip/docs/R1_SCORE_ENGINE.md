# R1 — Clinical Score Engine

A **score** is a formula with **interpretation bands**. It reuses the entire
derived-metric safety machinery (presence, source authority, unit compatibility,
temporal alignment, context/validity gates) and adds a descriptive strata
assignment. A score result — and any band label — is **never a diagnosis**.

Module layout:

| Path | Responsibility |
| --- | --- |
| `scores/definition.py` | `ScoreInput`, `ScoreBand`, `ClinicalScoreDefinition`, `ClinicalScoreResult` |
| `scores/registry.py` | `validate_score`, `ScoreRegistry` |
| `scores/engine.py` | `score_as_formula`, `compute_score` |

---

## 1. Definition model

### `ScoreInput`

| Field | Type | Default | Meaning |
| --- | --- | --- | --- |
| `name` | `str` | — | Expression variable name |
| `concept` | `str` | `name` | Canonical concept code |
| `required_unit` | `str` | `"1"` | Unit the expression expects |
| `required` | `bool` | `True` | Missing input refuses only when required |
| `requires_confirmed_source` | `bool` | `False` | Reported/questionnaire inputs default to unconfirmed |
| `label` | `str \| None` | `None` | Human-readable label |
| `question_code` | `str \| None` | `None` | Questionnaire question identifier |

Unlike `FormulaInputRequirement`, `requires_confirmed_source` defaults to
`False`: score inputs are frequently patient-reported questionnaire responses,
which are not confirmed-instrument sources.

### `ScoreBand`

| Field | Type | Default | Meaning |
| --- | --- | --- | --- |
| `label` | `str` | — | Band name shown to the clinician |
| `lower` | `float \| None` | `None` | **Inclusive** lower bound (absent = −∞) |
| `upper` | `float \| None` | `None` | **Exclusive** upper bound (absent = +∞) |
| `interpretation` | `str` | `""` | Free-text description of the stratum |

`ScoreBand.contains(value)` returns `False` when `value < lower` or
`value >= upper`, otherwise `True`. Bands are therefore half-open intervals:
lower inclusive, upper exclusive, so adjacent bands (`[a, b)` then `[b, c)`) do
not overlap.

### `ClinicalScoreDefinition`

Extends `VersionedDefinition` (shares `definition_id`, `name`, `version`,
`description`, `status`, `evidence_refs`, `metadata`). Additional fields mirror
the formula definition and add bands:

| Field | Type | Default |
| --- | --- | --- |
| `inputs` | `tuple[ScoreInput, ...]` | `()` |
| `output_unit` | `str` | `"1"` |
| `expression` | `str` | `""` |
| `bands` | `tuple[ScoreBand, ...]` | `()` |
| `band_direction` | `ScoreBandDirection` | `NON_DIRECTIONAL` |
| `temporal_requirement` | `TemporalRequirement` | `LATEST_AVAILABLE` |
| `temporal_window_days` | `int \| None` | `None` |
| `validity_constraints` | `tuple[str, ...]` | `()` |
| `warnings` | `tuple[str, ...]` | `()` |
| `domain` | `str \| None` | `None` |
| `population_constraints` | `dict[str, list[str]]` | `{}` |
| `output_label` | `str \| None` | `None` |

`band_direction` (`ScoreBandDirection`) records how the value should be read —
`HIGHER_IS_HIGHER`, `LOWER_IS_HIGHER` or `NON_DIRECTIONAL` — without turning a
band into a diagnosis. `band_for(value)` returns the first matching band or
`None`.

---

## 2. Band assignment

`band_for` iterates `bands` in declaration order and returns the first band whose
`contains(value)` is true. Because the lower bound is inclusive and the upper
bound is exclusive, a value exactly on a shared boundary always falls into the
band that declares it as its `lower` bound:

```
lower = None, upper = 2.0   -> [ -∞, 2.0 )
lower = 2.0,  upper = 4.0   -> [ 2.0, 4.0 )
lower = 4.0,  upper = None  -> [ 4.0, +∞ )
```

A band is assigned **only when the underlying metric is valid**. On any refusal
(missing input, unconfirmed source, incompatible unit, temporal mismatch,
outside domain, error) `value` is `None` and `band` is `None`.

---

## 3. `ClinicalScoreResult`

| Field | Meaning |
| --- | --- |
| `score_result_id` | Derived from the metric id (`metric_` prefix replaced by `score_`) |
| `patient_id` | Patient identifier |
| `score_id`, `score_version` | Definition id and version used |
| `value`, `unit` | Computed value and output unit |
| `band`, `band_interpretation` | Matched band label and its description (or `None`) |
| `computed_at`, `effective_at` | Timestamps |
| `calculation_status` | Same `CalculationStatus` as the formula engine |
| `authority` | `SYSTEM_DERIVED` |
| `inputs` | Per-input resolution summary (original/normalized value and unit) |
| `warnings`, `refusal_reason`, `domain` | Propagation from the metric |
| `derived_from_metric_id` | Id of the underlying `DerivedClinicalMetric` |

`is_valid` mirrors `calculation_status.is_valid`.

---

## 4. Reuse of the formula engine

There is a **single computation code path** for safety:

1. `score_as_formula(score)` adapts a `ClinicalScoreDefinition` into a
   `ClinicalFormulaDefinition`, mapping each `ScoreInput` to a
   `FormulaInputRequirement` and stamping `metadata={"kind": "score", ...}`.
2. `compute_score(...)` calls `formulas.engine.compute_metric` on that adapted
   formula, then wraps the result.

```mermaid
flowchart LR
    S[ClinicalScoreDefinition] --> A[score_as_formula]
    A --> F[ClinicalFormulaDefinition]
    F --> M[compute_metric]
    M --> D[DerivedClinicalMetric]
    D --> W[_wrap]
    S --> W
    W --> R[ClinicalScoreResult]
```

Because the score reuses the formula engine, it inherits every refusal gate and
its precedence (`INSUFFICIENT_INPUT → SOURCE_UNCONFIRMED → UNIT_INCOMPATIBLE →
TEMPORALLY_INCOMPATIBLE → OUTSIDE_DEFINED_DOMAIN → ERROR`). Band assignment is
purely additive on top of a valid metric.

---

## 5. Registry validation — `validate_score`

`validate_score` enforces the same structural rules as `validate_formula`:

- non-empty `definition_id` and `expression`;
- the expression compiles and references only declared input names;
- `output_unit` and every input `required_unit` must be known;
- `WITHIN_N_DAYS` requires a positive `temporal_window_days`;
- every `validity_constraints` string compiles.

`ScoreRegistry` wraps `DefinitionRegistry`, so publishing the same
`definition_id` + `version` with different content raises
`DuplicateDefinitionError`. For example, publishing with `output_unit="wagons"`
raises `UnknownUnitError`.

---

## 6. A score and its bands are not a diagnosis

- `ClinicalScoreResult.authority` is `SYSTEM_DERIVED`; the value is a computed
  number, not a clinical conclusion.
- A band is a **descriptive stratum** with a free-text interpretation; it
  carries no diagnostic authority and must be reviewed by a clinician.
- The engine never writes to BV Clinical and never creates a diagnosis.
- Missing or refused inputs produce no band, rather than a defaulted one.
