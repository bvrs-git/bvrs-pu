# R2B — Human Review Policy

## Review queue

`ScientificCenterApp.review_queue()` returns the items a human still needs to
act on. A reference is skipped only when it is `APPROVED` **and** has no
editorial alert; everything else stays in the queue.

Each queue entry contains: `reference_id`, `title`, `doi`, `pmid`,
`bibliographic_status`, `content_review_status`, `verification_status`,
`curation_status`, `origin`, `editorial_alerts`, `evidence`, `links`,
`appraisals` and `clinically_usable`.

`export_review_queue("json" | "csv")` serializes the queue. CSV columns are
`reference_id`, `title`, `doi`, `bibliographic_status`, `content_review_status`,
`curation_status`, `editorial_alerts` (count), `clinically_usable`. An unknown
format raises `ValueError`. CLI:

```
python -m bv_scientific_center review-export --format json|csv [--out FILE]
```

## Structured appraisals

Critical appraisals are stored in `review_appraisals` via
`AppraisalRepository.save` (facade `record_appraisal`). Fields:

| Field | Meaning |
| --- | --- |
| `appraisal_id` | Generated id (`ids.new_id("appr")`) or supplied. |
| `reference_id` | Appraised reference. |
| `reviewer` | Declared reviewer identity (free text). |
| `created_at` | UTC timestamp. |
| `content_review_status` | `ContentReviewStatus` recorded with the appraisal. |
| `scientific_question` | The question the study addresses. |
| `study_design` | Design label. |
| `population` | Population context. |
| `sample_size` | Reported sample size. |
| `inclusion_criteria` / `exclusion_criteria` | Study eligibility. |
| `reference_method` | Reference standard / method. |
| `intervention` / `comparator` | Compared arms. |
| `outcomes` | List of outcomes. |
| `quantitative_results` | Structured results. |
| `confidence_intervals` | Reported intervals. |
| `limitations` | List of limitations. |
| `risk_of_bias` | Reviewer's risk-of-bias note. |
| `clinical_applicability` | Applicability note. |
| `author_conclusions` | Authors' stated conclusions. |
| `reviewer_interpretation` | Reviewer's own interpretation. |
| `provenance_locations` | Where each extracted value came from (e.g. section/page). |
| `pending_fields` | Fields the reviewer could not fill. |

`provenance_locations` and `pending_fields` make incompleteness explicit rather
than silent: an appraisal with a missing field records it in `pending_fields`
(`test_appraisal_with_missing_fields_records_pending`).

## Reviewer identity

A reviewer is a **declared local string** (`reviewer`, `actor`), stored with the
appraisal and with every curation event. It is **not authentication**: nothing
verifies that the string corresponds to an authenticated human. Approval requires
a non-empty actor and a justification (`require_approval_actor`), which is a
governance guardrail, not a credential check
(`test_reviewer_string_is_not_authentication`).

## Approval is local and administrative

Approval is possible only through the local CLI, which goes through
`CurationService`:

```
python -m bv_scientific_center curate \
  --subject reference|evidence|claim --id <id> --action approve \
  --actor <reviewer> --justification <text>
```

`CurationService.transition` validates the state machine and, for `APPROVED`,
rejects synthetic content, requires actor + justification, and checks
`can_approve()` (verified metadata plus a stable identifier, or supporting
evidence for claims).

The HTTP surface is **read-only** for this flow. Relevant routes in
`ui/server.py`:

| Route | Renderer |
| --- | --- |
| `/knowledge/references` | `scientific_references` (search + list) |
| `/knowledge/reference/<id>` | `scientific_reference_detail` |
| `/knowledge/curation` | `curation_dashboard` |
| `/knowledge/review-queue` | `review_queue_page` |

There is no approval route. The review-queue and reference pages state that
approval requires an explicit local administrative action and is never available
over HTTP. The queue itself never marks anything approved automatically — every
pending entry reports `clinically_usable = false`.
