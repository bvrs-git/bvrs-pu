# R2C-B GATE 0 — Backup procedure and audit

## Tooling

`storage/backup.py::safe_backup` uses the official
`sqlite3.Connection.backup()` API (transactionally consistent, includes
committed WAL content), verifies `PRAGMA integrity_check` and
`PRAGMA foreign_key_check`, records a SHA-256, refuses to overwrite an existing
artifact, and deletes a failed artifact while raising explicitly. `restore_to`
performs an isolated restore drill.

## Audit of the R1.2 backup (`data/runtime/backup_20261007_234344/`)

| Artifact | integrity_check | FK violations | journal_mode | SHA-256 (prefix) |
| --- | --- | --- | --- | --- |
| knowledge.db | ok | 0 | delete | e10fd3fedaf12e2c |
| derived.db | ok | 0 | delete | b4233e28b97fa3bd |

**Finding.** The artifacts validate (integrity ok, 0 FK violations) but their
journal mode is `delete`, and their provenance is a filesystem copy. A copy of a
WAL-mode database made without the backup API (e.g. `shutil.copy2`) can miss
committed transactions still in the `-wal` file. There is no way to retroactively
prove the R1.2 copy captured a consistent WAL snapshot, so R1.2's artifact is
accepted as **valid but not provenance-guaranteed**. Historical backups are
**not** deleted. From R2C-B onward every backup uses the verified API.

## R2C-B backups (verified, `Connection.backup()`)

Destination: `data/runtime/backup_r2cb/`.

| Artifact | integrity | FK | SHA-256 (prefix) |
| --- | --- | --- | --- |
| knowledge_r2cb_pre_20261008T035828Z.db | ok | 0 | da7f70f9c2ccb2f5 |
| derived_r2cb_pre_20261008T035828Z.db | ok | 0 | 19b513d023005b53 |
| knowledge_r2cb_post_20261008T040439Z.db | ok | 0 | d4e026d2912d8873 |
| derived_r2cb_post_20261008T040439Z.db | ok | 0 | 19b513d023005b53 |
| knowledge_r2cb_final_20261008T041927Z.db | ok | 0 | af7084bc1d95ed00 |
| derived_r2cb_final_20261008T041929Z.db | ok | 0 | c696cc08e34c1c67 |

Restore drill executed into an isolated temp directory for both pre-backups
(`restore_to` → both `ok`). The original databases were not modified by backup or
restore. `derived.db` only changed when a synthesis run was executed (synthetic
demo/report); that is expected and is why a **final** backup is taken after all
R2C-B operations.

Note: `verify_database` opens the artifact read-write; on a WAL-mode artifact
this may leave transient `-shm`/`-wal` sidecar files. They do not affect the
verified main artifact.

## Procedure (repeatable)

```
python -m bv_scientific_center backup --dest data/runtime/backup_<label> --label <label>
```

or programmatically `safe_backup(source, dest, label=...)` for each of
`knowledge.db` and `derived.db`. A backup that fails verification is rejected and
removed; the command fails explicitly.
