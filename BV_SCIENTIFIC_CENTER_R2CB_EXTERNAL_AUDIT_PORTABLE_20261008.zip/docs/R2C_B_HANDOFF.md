# R2C-B — Handoff to R2C-C

## What R2C-B delivered

- Real content acquisition pipeline with identifier verification, licensing and
  availability classification, frozen into a reproducible snapshot.
- 3 abstracts acquired; 1 `cc by` full text legally retrieved and stored.
- Citation-grounded structured extraction (version `r2cb-2`) with per-field
  verbatim provenance and source hashes; no field is human-reviewed.
- Medical dossiers (JSON + Markdown), a navigable index, and a prepared
  (non-executed) decision form with a read-only HTTP surface.
- Body-composition methodology sheet; formula↔evidence matrix; applicability
  matrix; editorial currency checks.
- 62 new offline tests + 1 online opt-in test; 392 passed, 0 failed.
- One real defect fixed (`cc by-nc` redistribution) with a regression test.

## Open items for R2C-C

1. **Obtain content for the 4 unavailable references** through lawful channels
   (publisher open access, author manuscripts, institutional repositories).
   Never circumvent paywalls; keep `SOURCE_UNAVAILABLE` if unavailable.
2. **Human critical appraisal** of the 3 abstracted references (and any newly
   acquired full text): assign a risk-of-bias tool per design, record agreement /
   bias / limits of agreement, and mark fields `HUMAN_REVIEWED` only then.
3. **Evidence-link enrichment**: add `INTERNAL_VALIDATION` /
   `EXTERNAL_VALIDATION` / `LIMITATION` / `CONTRADICTORY_EVIDENCE` links with
   justification; the current matrix shows these are all missing.
4. **Decide on formula candidates**: no candidate may be activated in R2C-C
   without explicit human validation and a versioned operational definition.
5. **Dossier export to the reviewer** (JSON/Markdown) and structured reviewer
   feedback capture.

## Constraints carried forward

- Runtime deps: stdlib only (tests use pytest).
- No Git operations; no BV Clinical/Bot changes; no real patient data.
- Additive migrations only; historical syntheses and documents preserved.
- No automatic approval, no automatic GRADE, no cutoffs imported, no formula
  activation without a new directive.

## Entry points

- CLI: `extract`, `reconcile`, `medical-dossier`, `dossier-index`,
  `review-decision`, `formula-evidence`, `applicability`, `freeze-content`.
- UI (read-only): `/knowledge/dossiers`, `/knowledge/dossier/<id>`.
- Python: `ScientificCenterApp.bootstrap_r2cb`, `bootstrap_r2cb_offline`,
  `extract_reference`, `dossier_index`, `export_dossier`,
  `body_composition_sheet`, `formula_evidence_matrix`, `applicability_matrix`,
  `check_currency`, `reconciliation`, `record_review_decision`.
