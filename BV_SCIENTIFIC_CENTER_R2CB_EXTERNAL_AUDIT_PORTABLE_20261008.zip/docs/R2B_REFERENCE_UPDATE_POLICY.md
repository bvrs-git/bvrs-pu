# R2B — Reference Update Policy

## Snapshots are immutable

The corpus is captured once into a frozen JSON snapshot
(`data/seed/corpus_bibliography.json`) and is the artifact that tests and
offline use consume. Importing the snapshot is idempotent and **never approves**
anything (`import_corpus`). Re-running `bootstrap_scientific` does not change the
number of stored references (`test_corpus_import_is_idempotent`).

## Later source changes never silently overwrite

`ScientificReferenceRepository.ingest` is the only import path used by
acquisition. For a reference with a stable identifier it:

1. looks the existing row up with `find_by_identifier(kind, value)`;
2. if absent, saves it;
3. if present and the *stored content hash equals* the incoming hash, returns the
   existing row unchanged (exact duplicate → idempotent);
4. otherwise raises `MetadataConflictError`.

`save` stores the hash in the dedicated `content_hash_value` field, written to
the `content_hash` column. `_stored_hash` prefers that field and only recomputes
when it is empty. This is the RR-7 fix: the `content_hash()` method is never
shadowed by an attribute of the same name.

The consequence is explicit: same DOI with a different title (or any other
hashed field) is a refused import, never an in-place rewrite
(`test_later_conflicting_metadata_is_refused`).

## Supersede / new-version path

When a source genuinely changes, the change is represented explicitly through the
curation state machine rather than by overwriting metadata:

* `CurationStatus.SUPERSEDED` is terminal; `superseded_by` records the
  replacement reference id (`CurationService.supersede`).
* Every transition bumps `version` and appends an audit `CurationEvent`.
* Allowed transitions are defined by `CURATION_TRANSITIONS` in
  `knowledge/scientific.py`; illegal transitions raise `CurationTransitionError`.

## Offline last-known-state preservation

`BibliographyService.check_editorial` re-queries the provider to look for new
editorial notices. When no provider is reachable it does **not** alter the stored
reference. It records a local alert and leaves the last known state intact:

```mermaid
flowchart TD
    Q["check_editorial(reference_id)"] --> T{"Provider reachable?"}
    T -->|yes| D["Detect alerts; append new ones"]
    T -->|no| L["Append LOCAL alert: currency could not be verified"]
    D --> R["Return existing alerts"]
    L --> R
    R --> P["Stored metadata untouched"]
```

The offline branch adds an `EXPRESSION_OF_CONCERN` alert with `source = "LOCAL"`
and the detail `"Provider unavailable: currency could not be verified."`.
`test_offline_check_preserves_state_and_flags_currency` asserts the reference's
DOI is unchanged afterwards.
