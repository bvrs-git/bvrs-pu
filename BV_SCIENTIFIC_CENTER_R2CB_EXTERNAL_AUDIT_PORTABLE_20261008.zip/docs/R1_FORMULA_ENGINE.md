# R1 — Derived Metric (Formula) Engine

The formula engine computes a **derived clinical metric** from declared inputs.
It is deterministic, explainable and refuses to compute when any safety gate
fails. Refusals are **values**, never exceptions and never silent substitutions.

Module layout:

| Path | Responsibility |
| --- | --- |
| `core/enums.py` | `CalculationStatus`, `TemporalRequirement`, `DefinitionStatus`, `REFUSAL_PRECEDENCE` |
| `core/expression.py` | Constrained AST expression sandbox |
| `core/units.py` | Unit registry and explicit, validated conversion |
| `core/timeutil.py` | Timezone-aware UTC ISO 8601 helpers |
| `core/context.py` | `EvaluationContext` (population, sex, age, fasting, pregnancy) |
| `core/definition.py` | `VersionedDefinition` (immutable versioning primitives) |
| `core/registry.py` | Generic immutable definition registry |
| `formulas/definition.py` | `FormulaInputRequirement`, `ClinicalFormulaDefinition` |
| `formulas/registry.py` | `validate_formula`, `FormulaRegistry` |
| `formulas/alignment.py` | Temporal input alignment |
| `formulas/engine.py` | `compute_metric`, `InputResolution`, `DerivedClinicalMetric` |

---

## 1. Formula definition model

### `FormulaInputRequirement`

Declares exactly one input the expression needs.

| Field | Type | Default | Meaning |
| --- | --- | --- | --- |
| `name` | `str` | — | Variable name used inside the expression |
| `concept` | `str` | — | Canonical concept code (from `core/concepts.py`) |
| `required_unit` | `str` | `"1"` | Unit the expression expects this input in |
| `required` | `bool` | `True` | If `False`, a missing input does not refuse |
| `requires_confirmed_source` | `bool` | `True` | Input must come from a confirmed authority |
| `label` | `str \| None` | `None` | Human-readable label |

`FormulaInputRequirement.from_dict(data)` builds one from a mapping.

### `ClinicalFormulaDefinition`

Extends `VersionedDefinition`, so it also carries `definition_id`, `name`,
`version`, `description`, `status`, `evidence_refs` and `metadata`.

| Field | Type | Default |
| --- | --- | --- |
| `inputs` | `tuple[FormulaInputRequirement, ...]` | `()` |
| `output_unit` | `str` | `"1"` |
| `expression` | `str` | `""` |
| `temporal_requirement` | `TemporalRequirement` | `LATEST_AVAILABLE` |
| `temporal_window_days` | `int \| None` | `None` |
| `validity_constraints` | `tuple[str, ...]` | `()` |
| `warnings` | `tuple[str, ...]` | `()` |
| `domain` | `str \| None` | `None` |
| `population_constraints` | `dict[str, list[str]]` | `{}` |
| `output_label` | `str \| None` | `None` |

Helper methods: `input_names()`, `required_input_names()`, `from_dict(data)`.

### Versioning primitives

`VersionedDefinition` (from `core/definition.py`) exposes `key`
(`(definition_id, version)`), `is_usable` (`status` is `VALIDATED_FOR_USE`),
`to_dict()` and `hash()` (a SHA-256 content hash). `DefinitionStatus` lifecycle:
`DRAFT`, `VALIDATED_FOR_USE`, `RETIRED`.

---

## 2. Publication validation — `formulas/registry.validate_formula`

A formula is validated at publish time and stored immutably:

- `definition_id` must be non-empty;
- `expression` must be non-empty and must compile in the sandbox;
- the expression may only reference **declared** input names;
- input names must be unique;
- every input `required_unit` and the `output_unit` must be **known** to the unit
  registry (`UnknownUnitError` otherwise);
- `WITHIN_N_DAYS` requires a strictly positive `temporal_window_days`;
- every `validity_constraints` string must compile.

`FormulaRegistry` wraps `DefinitionRegistry.publish`. Publishing the identical
`definition_id` + `version` is idempotent; publishing the **same version with
different content** raises `DuplicateDefinitionError` (bump the version instead).
Historical results stay pinned to the version and content hash they used.

---

## 3. Unit safety

Every unit symbol maps to exactly one **dimension** and one affine transform to
that dimension's canonical unit:

```
canonical = value * factor + offset
```

Symbols are normalised before lookup (micro sign → `u`, superscripts → `^n`), so
`µg/dL` and `ug/dL` are the same unit. `convert(value, from_unit, to_unit)` is
explicit and validated:

- unknown symbol → `UnknownUnitError`;
- different dimensions → `UnitConversionError`.

Cross-unit ratios are computable **only** because the formula declares the
required unit for each input and the conversion factor is applied
deterministically. Example: `ng/dL` and `pg/mL` share the mass-concentration
dimension, so a T/E ratio is representable; a dimension mismatch such as
`IU` vs `ug` surfaces as `UNIT_INCOMPATIBLE` and the engine refuses.

---

## 4. Explicit conversion and `InputResolution`

For every aligned input, the engine calls `core.units.convert` and records the
operation in an `InputResolution`:

| Field | Meaning |
| --- | --- |
| `name` | Expression variable name |
| `concept` | Canonical concept code |
| `observation_ref_id` | Source observation reference id |
| `original_value`, `original_unit` | Value as received |
| `normalized_value`, `normalized_unit` | Value after conversion |
| `conversion_applied` | `True` when a conversion actually happened |
| `conversion_ref` | e.g. `"mg/L->mg/dL"`, else `None` |
| `effective_at` | Input collection time |
| `source_module`, `laboratory`, `method` | Provenance context |

The normalized values are the ones bound to expression variables, so the raw
numbers are never combined as if their units were silently interchangeable.

---

## 5. Temporal alignment — `formulas/alignment.align_inputs`

Inputs are never silently mixed when they are distant. The formula declares an
acceptable relationship via `TemporalRequirement`:

| Value | Meaning |
| --- | --- |
| `SAME_COLLECTION` | Same timestamp **and** same source entity/module |
| `SAME_DAY` | Same calendar day |
| `WITHIN_N_DAYS` | Span between inputs ≤ `temporal_window_days` |
| `LATEST_AVAILABLE` | Take the most recent candidate per input (no span check) |
| `OTHER_EXPLICIT_RULE` | Enforce a window only if one is declared |

The aligner sorts candidates most-recent-first, bounded to
`_MAX_CANDIDATES_PER_INPUT = 6`, then searches combinations for a set satisfying
the predicate. The best set maximises `(max timestamp, -span_days)`. If none
qualifies it returns `ok=False` with a `reason`, and the engine refuses with
`TEMPORALLY_INCOMPATIBLE`.

---

## 6. Context and population constraints

`EvaluationContext` (in `core/context.py`) carries `sex`, `age_years`,
`population`, `fasting_status`, `pregnant`, `on_hormone_therapy`,
`contraception` and `menopause`. Context is **supplied by authoritative
projections**, never inferred. `EvaluationContext.from_patient_context(...)`
builds one from a patient-context projection.

`population_constraints` is a `dict[str, list[str]]` interpreted by the engine:

| Key | Effect |
| --- | --- |
| `sex` | Context sex must be in the allowed list |
| `population` | Context population must be in the allowed list |
| `allow_pregnancy` | Default `False` — pregnancy is excluded unless allowed |
| `allow_pediatric` | Default `False` — pediatric is excluded unless allowed |
| `min_age` / `max_age` | Bound `age_years`; a required but unknown age refuses |

By default a formula is **adult / non-pregnant**; applying it in an incompatible
context yields `OUTSIDE_DEFINED_DOMAIN`.

---

## 7. Validity constraints

Each string in `validity_constraints` is a sandbox boolean over the normalized
input variables (e.g. `"estradiol > 0"`, `"height_m > 0"`). A constraint that
does not hold produces `OUTSIDE_DEFINED_DOMAIN`; a constraint that fails to
compile raises `ExpressionError` at evaluation and produces `ERROR`.

---

## 8. Calculation statuses and precedence

`CalculationStatus` values: `VALID`, `INSUFFICIENT_INPUT`, `UNIT_INCOMPATIBLE`,
`TEMPORALLY_INCOMPATIBLE`, `SOURCE_UNCONFIRMED`, `OUTSIDE_DEFINED_DOMAIN`,
`ERROR`. `is_valid` is true only for `VALID`; `is_refusal` is the complement.

The deterministic refusal precedence is `REFUSAL_PRECEDENCE`, which is exactly
the gate order in `compute_metric`:

```
INSUFFICIENT_INPUT
  → SOURCE_UNCONFIRMED
  → UNIT_INCOMPATIBLE
  → TEMPORALLY_INCOMPATIBLE
  → OUTSIDE_DEFINED_DOMAIN
  → ERROR
```

```mermaid
flowchart TD
    A[compute_metric] --> B{numeric input present?}
    B -- no --> R1[INSUFFICIENT_INPUT]
    B -- yes --> C{confirmed source if required?}
    C -- no --> R2[SOURCE_UNCONFIRMED]
    C -- yes --> D{unit convertible?}
    D -- no --> R3[UNIT_INCOMPATIBLE]
    D -- yes --> E{aligned set exists?}
    E -- no --> R4[TEMPORALLY_INCOMPATIBLE]
    E -- yes --> F{context allowed?}
    F -- no --> R5[OUTSIDE_DEFINED_DOMAIN]
    F -- yes --> G{validity constraints hold?}
    G -- no --> R5
    G -- yes --> H{expression evaluates?}
    H -- no --> R6[ERROR]
    H -- yes --> V[VALID + value]
```

---

## 9. Constrained expression sandbox — `core/expression.py`

Scientific content may arrive from imported knowledge packages and must never
execute arbitrary code. Expressions are parsed with `ast.parse(mode="eval")` and
interpreted by an explicit AST walker. **`eval` and `exec` are never used.**

Allowed constructs:

- literals: `int`, `float`, `bool`, `str`, `None`;
- names resolved from the supplied variable mapping;
- arithmetic: `+ - * / // % **` (`**` is bounded);
- comparison: `== != < <= > >= in not in`;
- boolean: `and or not`;
- conditional: `a if cond else b`;
- list/tuple literals;
- whitelisted functions: `abs`, `min`, `max`, `round`, `floor`, `ceil`, `sqrt`,
  `log`, `ln`, `exp`, `clamp`.

Forbidden: attribute access, subscripting, lambdas, comprehensions, assignment,
imports, `await`/`yield`, starred args, keyword args, and any name starting with
`_`. The exponent of `**` must be a numeric literal with magnitude ≤ 12. Only
direct calls to whitelisted functions are permitted. Referencing an undefined
variable raises `ExpressionError` at evaluation. `compile_expression(source)`
returns a reusable `CompiledExpression` with a `names` set of referenced
identifiers used for publication validation.

---

## 10. `compute_metric` API

```python
compute_metric(
    formula, refs_by_concept, *, patient_id, context=None, computed_at=None
) -> DerivedClinicalMetric
```

- `formula` — a `ClinicalFormulaDefinition`.
- `refs_by_concept` — `dict[str, list[ScientificObservationRef]]` keyed by
  concept.
- `context` — an `EvaluationContext` (defaults to an empty one).
- `computed_at` — UTC datetime (defaults to `now_utc()`).

A `DerivedClinicalMetric` carries: `metric_id`, `patient_id`,
`metric_definition_id`, `metric_definition_version`, `value`, `unit`,
`computed_at`, `effective_at`, `calculation_status`, `input_refs`,
`input_resolutions`, `formula_snapshot`, `authority` (`SYSTEM_DERIVED`),
`warnings`, `missing_inputs`, `refusal_reason` and `domain`. `is_valid` mirrors
`calculation_status.is_valid`. On refusal, `value` is `None` and
`refusal_reason` explains why. Contextual warnings are appended when a
conversion was applied, when laboratories/methods differ across inputs, or when
inputs span more than one day.

MEASURED_DATA ≠ DERIVED_METRIC: the engine only reads observation references and
never mutates measured data.

---

## 11. Worked example (synthetic fixtures)

From `seed/synthetic.py` (architecture-validation fixtures; no real patient
data):

```python
# Testosterone / Estradiol ratio
ClinicalFormulaDefinition(
    definition_id="TESTOSTERONE_ESTRADIOL_RATIO",
    name="Testosterone / Estradiol ratio (TEST)",
    version=1,
    status=DefinitionStatus.VALIDATED_FOR_USE,
    inputs=(
        FormulaInputRequirement("testosterone", "TESTOSTERONE_TOTAL", "ng/dL"),
        FormulaInputRequirement("estradiol", "ESTRADIOL", "pg/mL"),
    ),
    output_unit="1",
    expression="testosterone / estradiol",
    temporal_requirement=TemporalRequirement.SAME_DAY,
    validity_constraints=("estradiol > 0",),
    domain="GONADAL",
    population_constraints={"allow_pregnancy": [False]},
)

# Triglyceride / HDL ratio
ClinicalFormulaDefinition(
    definition_id="TRIGLYCERIDE_HDL_RATIO",
    inputs=(
        FormulaInputRequirement("triglycerides", "TRIGLYCERIDES", "mg/dL"),
        FormulaInputRequirement("hdl", "HDL_CHOLESTEROL", "mg/dL"),
    ),
    output_unit="1",
    expression="triglycerides / hdl",
    temporal_requirement=TemporalRequirement.SAME_DAY,
    validity_constraints=("hdl > 0",),
    domain="LIPID",
)
```

With the synthetic observations on the same collection day:

| Input | Value | Unit |
| --- | --- | --- |
| `TESTOSTERONE_TOTAL` | 480.0 | `ng/dL` |
| `ESTRADIOL` | 28.0 | `pg/mL` |
| `TRIGLYCERIDES` | 190.0 | `mg/dL` |
| `HDL_CHOLESTEROL` | 38.0 | `mg/dL` |

Both metrics compute `VALID` because the formula declares the units each input
must be expressed in and the conversion is applied deterministically:

- T/E ratio = `480 / 28 ≈ 17.143` (dimensionless);
- TG/HDL ratio = `190 / 38 = 5.0`.

`calculation_status` remains a refusal value (e.g. `SOURCE_UNCONFIRMED` when the
estradiol observation is `DOCUMENT_EXTRACTED_UNREVIEWED`, or
`TEMPORALLY_INCOMPATIBLE` when the two samples fall on different days).
