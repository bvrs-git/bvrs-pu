# R2C-A — Test Matrix

## Totals

| Snapshot | Passed | Skipped | Failed |
| --- | --- | --- | --- |
| R2A/R2B baseline | 258 | 0 | 0 |
| R2C-A | **330** | **2** | **0** |

Measured with `python -m pytest` (config in `pyproject.toml`, `addopts = "-q"`,
`pythonpath = ["src"]`). The two skipped tests are the R2B online integration tests,
gated by `BV_RUN_ONLINE=1`. `python -m pytest --collect-only` reports **332** tests.
The R2A/R2B baseline (258) is preserved unchanged; no clinical activation occurred
and historical synthesis fingerprints are unchanged.

## New R2C-A test files

| Tests | File | Gate |
| --- | --- | --- |
| 9 | `test_formula_candidates.py` | 3 — candidate registry |
| 13 | `test_candidate_math.py` | 5 — prototype math |
| 6 | `test_input_semantics.py` | 4 — input semantics |
| 6 | `test_applicability.py` | 6 — applicability |
| 5 | `test_evidence_links_r2ca.py` | 7 — evidence links |
| 5 | `test_scientific_review.py` | 1/2 — appraisal & metrics |
| 6 | `test_human_review_r2ca.py` | 8 — human review & dossiers |
| 19 | `test_r2ca_adversarial.py` | 9 — adversarial |
| 3 | `test_ui_r2ca.py` | UI — read-only candidates |
| **72** | **total** | |

Fixtures: the `r2ca_app` fixture in `tests/conftest.py` seeds the candidate registry
offline (`bootstrap_scientific()` + `bootstrap_r2ca()`, network adapters disabled);
`seeded_app` and `scientific_app` back the cross-phase adversarial scenarios.

## Gate coverage

| Gate | Focus | Evidence |
| --- | --- | --- |
| 1 | Scientific review model / appraisal honesty | `test_scientific_review.py` |
| 2 | Appraisal provenance + metrics policy | `test_scientific_review.py` |
| 3 | Candidate registry (types, versions) | `test_formula_candidates.py` |
| 4 | Input semantics / anti-upgrade | `test_input_semantics.py` |
| 5 | Prototype math (units, domain, temporal) | `test_candidate_math.py` |
| 6 | Applicability profiles | `test_applicability.py` |
| 7 | Differentiated evidence links | `test_evidence_links_r2ca.py` |
| 8 | Human review queue + dossiers | `test_human_review_r2ca.py` |
| 9 | Adversarial suite | `test_r2ca_adversarial.py` |
| UI | Read-only candidate routes | `test_ui_r2ca.py` |

## GATE 9 checklist

The 20 scenarios are labelled inline in `tests/test_r2ca_adversarial.py`. Scenarios
7 and 8 share one test in that file.

| # | Scenario | Test(s) |
| --- | --- | --- |
| 1 | Dimensionally invalid input | `test_dimensional_mismatch_refused` |
| 2 | Unsafe expression rejected | `test_unsafe_expression_rejected` |
| 3 | Incompatible / unknown unit | `test_unknown_unit_refused` |
| 4 | Division by zero | `test_division_by_zero` |
| 5 | Missing input | `test_missing_input` |
| 6 | Device estimate treated as measured | `test_device_estimate_cannot_be_measured` |
| 7 / 8 | Applicability unknown / unvalidated population | `test_applicability_not_established` |
| 9 | Distinct patients in one run | `test_mixing_patients_is_refused` |
| 10 | Incompatible clinical dates | `test_incompatible_clinical_dates` |
| 11 | Formula without reference must stay DRAFT | `test_formula_without_reference_must_be_draft` |
| 12 | Candidate linked to a retracted reference flagged | `test_candidate_linked_to_retracted_reference_is_flagged` |
| 13 | Contradictory evidence is representable | `test_contradictory_evidence_link` |
| 14 | Version change without traceability refused | `test_version_change_requires_new_version` |
| 15 | Attempted automatic clinical activation | `test_candidate_is_not_in_operational_registry` |
| 16 | Automatic assessment ≠ human review | `test_suggestion_is_not_human_review` |
| 17 | Recompute preserves historical synthesis | `test_recomputation_preserves_history` |
| 18 | Duplicate candidate import is idempotent | `test_duplicate_candidate_import_is_idempotent` |
| 19 | Failed transition leaves state unchanged | `test_failed_transition_leaves_state_unchanged` |
| 20 | Offline candidate reconstruction | `test_offline_candidate_reconstruction` |

## UI read-only checks

`test_ui_r2ca.py` asserts that `/knowledge/candidates`,
`/knowledge/candidate/SCI-CAND-FMI` and `/knowledge/human-review` all return `200`,
that the candidate page marks `operational: no`, and that approval paths
(`/knowledge/candidate/.../approve`, `/knowledge/human-review/approve`) return
`404`.
