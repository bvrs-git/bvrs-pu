# R1.2 — Temporality Policy

## Invariants

```
CLINICAL_DATE (effective_at)  !=  INGESTION_DATE (ingested_at)
```

* `effective_at` — when the measurement/sample was taken (clinical time).
* `ingested_at` — when the observation was registered into the Scientific Center.
* The ingestion moment **never** substitutes the original measurement date.
* When a clinical date is unknown, ingestion is refused (`ContractViolation`) —
  the module never fabricates a measurement timestamp.
* When a legacy `ingested_at` is unknown, it stays **UNKNOWN/NULL** — it is never
  back-filled from `created_at` or from the clinical date.

## Fields and their meaning

| Field | Meaning | Source |
| --- | --- | --- |
| `effective_at` | clinical / collection time | source projection |
| `ingested_at` | registration time | set at ingestion (`now_utc`) |
| `computed_at` | moment a derived metric/score was computed | engine |
| `generated_at` | moment a signal candidate was generated | rule engine |
| `started_at` / `completed_at` | synthesis run window | runner |
| `as_of` | point-in-time view for the map | UI/builder |
| `created_at` | row insertion time (storage) | repository |

## Timezone policy

* **Canonical storage** is timezone-aware UTC, formatted `%Y-%m-%dT%H:%M:%S.%f%z`.
* **Clinical boundary is strict**: `core/timeutil.parse_clinical_dt` raises
  `NaiveTimestampError` for timestamps without an offset. Source modules must send
  offsets; the module does not guess a local zone.
* `parse_dt` remains permissive **only** for internal storage round-trips (values
  are always written with offsets).
* Equivalent offsets normalize to the same instant
  (`08:00+00:00 == 05:00-03:00`).

## Refusal behavior

A naive clinical timestamp fails the run **before** any write: the run is recorded
`FAILED` and no observation is persisted (`test_naive_timestamp_run_is_failed_not_fabricated`).

## `as_of` and future dates

The clinical map builder excludes any node whose `effective_at` (or
`generated_at`/`computed_at`) is after `as_of`. Future-dated observations are
therefore excluded from a past view and never leak into it.

## Repeated measurements and ordering

`list_for_patient` orders by `effective_at`; multiple measurements of the same
concept are candidates for formula/rule alignment, which is governed by the
declared `TemporalRequirement` (`SAME_COLLECTION`, `SAME_DAY`, `WITHIN_N_DAYS`,
`LATEST_AVAILABLE`, `OTHER_EXPLICIT_RULE`). Distant inputs are refused
(`TEMPORALLY_INCOMPATIBLE`).

## Tests

`tests/test_temporal_policy.py` (8), plus `tests/test_provenance.py`,
`tests/test_migration.py` (legacy NULL preserved) and
`tests/test_calculation_safety.py` (`as_of`).
