# R2C-B GATE 2 — Access and licensing policy

## Separated states

Availability of access and permission to store/redistribute are distinct:

- `ABSTRACT_AVAILABLE`
- `FULL_TEXT_AVAILABLE`
- `FULL_TEXT_ACCESS_RESTRICTED`
- `FULL_TEXT_LICENSE_UNKNOWN`
- `FULL_TEXT_REUSE_PERMITTED`
- `SOURCE_UNAVAILABLE`

## Rules

| Situation | Storage decision |
| --- | --- |
| Abstract available | Stored for internal annotation; `storage_permitted=True`; redistribution restricted |
| Full text, permissive license (`cc by`, `cc0`, public domain) | Versioned snapshot stored; license recorded |
| Full text, `cc by-nc` / `cc by-nd` | Stored internally; redistribution explicitly **not** permitted |
| Full text, unknown/non-permissive license | **Not stored**; only metadata, locators and minimal permitted excerpts |
| Source unavailable | Metadata of the attempt only; no text |

`AcquiredContentRepository.save` never persists `text` when
`storage_permitted=False` — the guard is enforced at the repository boundary,
not just by convention.

## Defect found and fixed during R2C-B

`classify_license("cc by-nc")` originally returned `redistribution_permitted =
True` because `"cc by"` is a prefix of `"cc by-nc"`. A regression test
(`tests/test_r2cb_content.py::test_license_classification`) proved the bug; the
classification now inspects `-nc` / `-nd` / `noncommercial` suffixes so
non-commercial / no-derivatives licenses are correctly non-redistributable
(while still permitting internal storage).

## Copyright

No protected full text is copied into the repository except the single `cc by`
article, whose license permits storage; the license is recorded with the
snapshot. Restricted articles keep only metadata and locators.
