# R1 — Knowledge Packages

A **knowledge package** is an importable, versioned, validated bundle of
scientific content. Its purpose is to let scientific content evolve
**independently from application code**: literature, formulas, scores and rules
ship as data, not as a software release.

`KnowledgePackage` (`knowledge/packages.py`) bundles knowledge items with the
formula/score/rule definitions they rely on, plus references and a source
manifest.

## The `KnowledgePackage` model

| Field | Notes |
| --- | --- |
| `package_id` | stable identity |
| `name` | display name |
| `version` | explicit version string |
| `domain` | content domain label |
| `items` | tuple of `ScientificKnowledgeItem` |
| `formulas` | tuple of declarative formula dicts |
| `scores` | tuple of declarative score dicts |
| `rules` | tuple of declarative rule dicts |
| `references` | tuple of `KnowledgeReference` |
| `source_manifest` | provenance of the source documents |
| `review_status` | `PackageReviewStatus` |
| `created_at` | timestamp |
| `metadata` | free dict |

Identity is the `(package_id, version)` pair (`key`). `hash()` is a content hash
over the serialised package (`dump_package`), used to detect changed content
under an existing version.

## Lifecycle

Import → validate → review → activate → (rollback).

```mermaid
graph LR
    IMPORT["import_package"] --> SAVE["PackageRepository.save"]
    SAVE --> VALIDATE["validate: structure + security"]
    VALIDATE --> REVIEW["review_status"]
    REVIEW --> ACTIVATE["activate_package"]
    ACTIVATE --> REG["Registries + repository"]
    ACTIVATE --> EVENT["KnowledgePackageActivated"]
    ACTIVATE --> ROLLBACK["rollback: activate other / deactivate"]
    ROLLBACK --> ACTIVATE
```

1. **Import** — `ScientificCenterApp.import_package(package, activate=False)`
   calls `PackageRepository.save()`, which validates the package then persists it
   into `knowledge_packages`.
2. **Validate** — `KnowledgePackage.validate()` performs structural checks and a
   security scan (see below).
3. **Review** — `review_status` advances from `DRAFT` to `IN_REVIEW` to
   `APPROVED` as humans review the content.
4. **Activate** — `ScientificCenterApp.activate_package(package_id, version)`
   re-validates the package, then:
   - publishes each formula into the `FormulaRegistry`,
   - publishes each score into the `ScoreRegistry`,
   - publishes each rule into the `RuleRegistry`,
   - saves each item (stamped with `package_id` / `package_version`) and each
     reference into the knowledge repository,
   - marks the package active via `PackageRepository.activate()`, sets the
     runner's `knowledge_package_version` to `"{package_id}@{version}"`, and
     emits the `KnowledgePackageActivated` event.
5. **Rollback** — activation deactivates all other packages
   (`UPDATE knowledge_packages SET is_active = 0`). Rolling back means activating
   a different version, or calling `PackageRepository.deactivate(package_id,
   version)`, after which `active_package()` returns `None`. Historical run
   snapshots keep their own provenanced `knowledge_package_version`.

## Security posture: untrusted until validated

An imported package is **untrusted** until validated. `KnowledgePackage.validate()`
runs `_scan()` over the entire serialised payload and raises
`PackageSecurityError` when it finds:

- forbidden substrings anywhere in the payload (for example `<script`,
  `</script`, `javascript:`, `onerror=`, `onload=`, `<iframe`, `eval(`, `exec(`,
  `__import__`, `subprocess`, `os.system`, `require(`, `import os`); and
- forbidden filesystem-path keys (`path`, `file_path`, `filepath`, `filename`,
  `local_path`, `uri`), which would otherwise let a package reference arbitrary
  paths.

There are **no scripts and no executable HTML** in a package. Formulas, scores
and rules remain **declarative JSON** and are evaluated only by the constrained
interpreter; the package is never executed as code.

Structural validation raises `PackageValidationError` when:

- `package_id` or `version` is missing,
- a knowledge item is missing `knowledge_id` or `title`, or
- a formula/score/rule definition lacks a `definition_id` or an explicit
  `version`.

## Immutability of published versions

`PackageRepository.save()` treats a published `(package_id, version)` as
immutable:

- If the same `(package_id, version)` already exists with the **same** content
  hash, the call is idempotent.
- If it exists with a **different** hash, the repository raises
  `ImmutablePublishError` and instructs the author to publish a new version.

New literature therefore always requires a new version; existing version numbers
are never silently rewritten (verified by
`tests/test_knowledge.py::test_package_version_is_immutable`).

## The GPT Work ingestion pipeline

Scientific content is authored outside the application and flows through a
human-reviewed pipeline:

```mermaid
graph TD
    DOCS["Reference documents"] --> EXTRACT["Structured extraction / draft"]
    EXTRACT --> PKG["Knowledge package"]
    PKG --> HUMAN["Human review"]
    HUMAN --> APPROVE["Approved import"]
```

1. **Reference documents** — real source material is collected.
2. **Structured extraction / draft** — content is turned into structured items,
   claims, definitions and a `source_manifest` (the synthetic fixture tags its
   manifest origin as `GPT_WORK_PLACEHOLDER`).
3. **Knowledge package** — the extraction is bundled as a versioned package.
4. **Human review** — reviewers validate structure, security and content, and
   advance `review_status`.
5. **Approved import** — only reviewed packages are activated.

**AI output is never auto-treated as verified source.** Any machine-generated
text is labelled `AI_DRAFT` or `AI_SUGGESTION` by `ai/drafts.py` and can never
become `CLINICIAN_CONFIRMED` on its own. `AIDraft.__post_init__` rejects any
other label, and `AIDraft.is_clinician_confirmed` is always `False`.

## Claim-level provenance

Provenance is captured at every level so a claim can be traced back to its
source:

- Each `ScientificClaim` carries `supporting_reference_ids` and its own
  `ClaimReviewStatus` (`UNREVIEWED`, `IN_REVIEW`, `SUPPORTED`, `UNSUPPORTED`).
- Each `ScientificKnowledgeItem` records the originating `package_id` and
  `package_version` when it is imported.
- Each activated package retains its `source_manifest` and content hash, and its
  version is stamped onto synthesis runs via `knowledge_package_version`.

The result is that any statement surfaced in the UI can be traced to the package
version, the knowledge item, the claim, and the references that back it.
