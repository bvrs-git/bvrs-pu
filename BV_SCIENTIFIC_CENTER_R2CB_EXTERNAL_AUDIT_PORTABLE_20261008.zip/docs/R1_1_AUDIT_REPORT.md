# R1.1 — Audit Report

**Module:** BV Centro Científico & Mapa Clínico (standalone R0/R1)
**Workspace:** `F:\Codex Projetos\Científico e Mapa - Módulo Separado`
**Audit scope:** R1.1 — audit, hardening and baseline certification (gates 1–7).
**Result:** `BV_SCIENTIFIC_CENTER_R1_1_STATUS = PASS`

Restrictions honored: no changes to BV Clinical / BV Bot; no Git init/commits;
no real patient data; no new runtime dependencies; no destructive migrations; no
automatic diagnosis; synthetic content kept non-approved.

## Environment

| Item | Value |
| --- | --- |
| Python | 3.14.6 |
| Platform | Windows 10.0.19045 |
| Runtime deps | Python standard library only |
| Test runner | pytest 9.1.1 |
| Databases | `knowledge.db`, `derived.db` (SQLite 3.50.4, FTS5) |

## GATE 1 — Baseline certification

| Check | Result |
| --- | --- |
| R0/R1 components | Present (formula registry, metric/score/rule engines, synthesis run, knowledge repository + packages + FTS, clinical map + projection, synthetic fixtures, minimal UI) |
| SQLite state and schemas | `knowledge.db` (items/claims/references/packages/fts) and `derived.db` (observations/derived_metrics/score_results/signals/signal_reviews/synthesis_runs/annotations/pins/events) |
| HTTP routes | 15 routes over loopback, smoke-tested (see `R1_1_TEST_MATRIX.md`) |
| Input/output contracts | Intact (see `R1_1_CONTRACTS_INVENTORY.md`) |
| Registry versions | Formulas/scores/rules versioned and immutable |
| Measured/derived/interpretive separation | Enforced structurally |
| Documentation | 15 `docs/R1_*.md` present |

Commands re-run on the audited tree (evidence captured during this execution):

```
python -m pytest            -> 108 passed
python -m compileall src    -> COMPILE_OK
python -m bv_scientific_center report -> 7 valid metrics, 1 score, 3 signals
UI smoke (15 routes, loopback) -> all HTTP 200
```

The previously reported "68 tests" was **not** taken as evidence; the suite was
re-run and re-counted. `tests/test_critical_gates.py` still prints all 12 R1 gates
as `PASS`.

## Summary of findings

| # | Gate | Finding | Severity | Status |
| --- | --- | --- | --- | --- |
| F1 | 2A | Derived-metric inputs did not record the **ingestion date**, so clinical date and registration date could be conflated | Medium | **Fixed** |
| F2 | 2C / 3 | Re-ingesting identical projections **duplicated** observation rows (23 → 46) | Medium | **Fixed** |
| F3 | 3 | Cross-**patient contamination**: a run could compute metrics for patient B using patient A references | High | **Fixed** |
| F4 | 5 | Rebuilding a stored run produced **different map node ids** (non-deterministic) | Medium | **Fixed** |
| F5 | 3 | A failed run wrote **no audit record** and could leave partial writes | Medium | **Fixed** |
| F6 | 4 | No formal **governance separation** of synthetic vs imported vs approved knowledge | High | **Fixed** |
| F7 | 2B/3 | Division by zero, precedence, determinism, FTS injection, loopback binding | — | **Verified (no defect)** |

Each fix: failure recorded → regression test added → minimal change → specific
test → full regression → documented (`R1_1_CHANGES.md`). No R2 functionality was
added.

## GATE 2 — Scientific and temporal audit

* **Provenance (2A):** fixed by F1. Every derived metric now exposes, per input:
  observation reference id, concept, value + unit (original and normalized),
  source module/entity/version, authority, **clinical date** (`effective_at`) and
  **ingestion date** (`ingested_at`), plus the metric's own `computed_at`. Refusals
  carry a `calculation_status` and `refusal_reason`.
* **Calculation safety (2B):** division by zero → `ERROR` (never a value);
  unit/authority/temporal/domain refusals return `None`; refusal precedence is
  deterministic. See `tests/test_calculation_safety.py`.
* **Temporal alignment (2C):** cross-domain inputs must satisfy the declared
  `TemporalRequirement`; `as_of` excludes future-dated observations; duplicate
  ingestion eliminated by F2.
* **Source authority (2D):** selection is deterministic and rule-based —
  authority filter → unit filter → temporal alignment (latest or aligned set);
  unknown context never grants authority.

## GATE 3 — Security and isolation

* Expression engine: whitelisted AST interpreter, no `eval`/`exec`
  (`tests/test_expression.py`).
* FTS5/SQL: parameterized; adversarial queries return safely and leave the schema
  intact (`tests/test_ui_security.py`).
* UI: binds `127.0.0.1` by default; unknown routes return 404; invalid input is
  handled (fail-closed) rather than crashing the process.
* Patient isolation: fail-closed (F3).
* Idempotency: deterministic reference ids (F2).
* Persistence integrity: compute-before-persist + `FAILED` audit record (F5).

## GATE 4 — Knowledge governance

Knowledge items now carry an explicit `origin` (`SYNTHETIC_TEST`, `IMPORTED`,
`CURATED`). `SYNTHETIC_TEST` content can **never** be `APPROVED`, even with
citation metadata. Approval requires citation metadata **and** non-synthetic
origin. Automated tests never grant clinical approval (F6).

## GATE 5 — Clinical map and synthesis

Map node id schemes: `obs:<ref>`, `metric:<id>`, `score:<id>`, `signal:<id>`.
Layers keep measured/reported/derived/signals distinct; every node/edge is
traceable; `validate_projection` rejects orphans. Stored syntheses are now
rebuildable deterministically (F4) via `ScientificCenterApp.rebuild_run`, and the
map route prefers that reconstruction.

## GATE 6 — Controlled corrections

Six minimal corrections (F1–F6), each with a regression test; no unrelated edits.
Full suite re-run after each: **108 passed**, `compileall` OK.

## GATE 7 — Evidence

This report set:

* `R1_1_AUDIT_REPORT.md` (this file)
* `R1_1_TEST_MATRIX.md`
* `R1_1_CONTRACTS_INVENTORY.md`
* `R1_1_SECURITY_FINDINGS.md`
* `R1_1_PROVENANCE_FINDINGS.md`
* `R1_1_CHANGES.md`
* `R1_1_RESIDUAL_RISKS.md`
* `R1_1_R2_PLAN.md`

Historical R1 documentation (`docs/R1_*.md`) was **not** overwritten.

## Verdict

`BV_SCIENTIFIC_CENTER_R1_1_STATUS = PASS` — baseline certified, six demonstrated
defects fixed with regression coverage, no unresolved critical failures. No R2
work was started.
