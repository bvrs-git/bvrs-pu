# R1 — Test Matrix

## How to run

```
python -m pytest
```

`pyproject.toml` sets `pythonpath = ["src"]`, `testpaths = ["tests"]` and
`addopts = "-q"`, so the command works from the project root without installing
the package. Per-file counts are available with
`python -m pytest --collect-only -q`.

**Current result: `68 passed`** across the test files below.

## Gates proven per test file

| Test file | Tests | Critical gate(s) proven |
| --- | --- | --- |
| `tests/test_critical_gates.py` | 1 | All gates in one aggregated assertion: `MEASURED_DERIVED_SEPARATION`, `MISSING_IS_NOT_ZERO`, `UNIT_VALIDATION`, `TEMPORAL_VALIDATION`, `SOURCE_AUTHORITY_CHECK`, `FORMULA_VERSIONING`, `RULE_VERSIONING`, `KNOWLEDGE_CITATIONS`, `SIGNAL_NOT_DIAGNOSIS`, `REPRODUCIBILITY`, `MAP_PROVENANCE`, `NO_AUTO_DIAGNOSIS` |
| `tests/test_formula_engine.py` | 12 | `MISSING_IS_NOT_ZERO`, `UNIT_VALIDATION`, `TEMPORAL_VALIDATION`, `SOURCE_AUTHORITY_CHECK`, `MEASURED_DERIVED_SEPARATION`, `FORMULA_VERSIONING` |
| `tests/test_units.py` | 6 | `UNIT_VALIDATION` (normalisation, same-dimension conversion, affine temperature, incompatible-dimension and unknown-unit refusals) |
| `tests/test_expression.py` | 13 | Expression sandbox safety (no `eval`/`exec`, forbidden constructs rejected, bounded exponent) — supports `FORMULA_VERSIONING` / `RULE_VERSIONING` validity |
| `tests/test_rule_engine.py` | 6 | `SIGNAL_NOT_DIAGNOSIS`, `RULE_VERSIONING`, `MISSING_IS_NOT_ZERO` |
| `tests/test_score_engine.py` | 3 | `MISSING_IS_NOT_ZERO`, `UNIT_VALIDATION` (band assignment, refusal has no band, unknown output unit rejected) |
| `tests/test_synthesis_run.py` | 5 | `REPRODUCIBILITY`, `FORMULA_VERSIONING`, `RULE_VERSIONING` (run record keeps versions, re-run is a new run) |
| `tests/test_clinical_map.py` | 8 | `MAP_PROVENANCE` (traceable nodes/edges, orphan rejection, layer filtering, non-opaque "why connected?") |
| `tests/test_knowledge.py` | 10 | `KNOWLEDGE_CITATIONS` (citation-required approval), package security/versioning/rollback, no patient data in repository |
| `tests/test_review.py` | 4 | `NO_AUTO_DIAGNOSIS`, `SIGNAL_NOT_DIAGNOSIS` (acceptance does not create a diagnosis; annotations do not mutate source) |
| `tests/conftest.py` | — | Fixtures only: `make_ref`, `app` (in-memory), `seeded_app` |

## Gate reference

| Gate | Meaning | Representative evidence |
| --- | --- | --- |
| `MEASURED_DERIVED_SEPARATION` | Measured observations keep `MEASURED` authority; derived outputs are `SYSTEM_DERIVED` | `test_critical_gates.py`, `test_formula_engine.py` (`test_valid_computation`), `test_clinical_map.py` (`test_measured_nodes_are_not_derived`) |
| `SIGNAL_NOT_DIAGNOSIS` | Every signal explanation carries the "not a diagnosis" disclaimer | `test_rule_engine.py`, `test_critical_gates.py` |
| `FORMULA_VERSIONING` | New version preserves history; results stay pinned to the version used | `test_formula_engine.py` (`test_formula_versioning_preserves_history`, `test_registry_immutability`) |
| `RULE_VERSIONING` | Same registry machinery applies to rules | `test_critical_gates.py`, `test_rule_engine.py` (`test_rule_registry_rejects_undeclared_condition_input`) |
| `MISSING_IS_NOT_ZERO` | Absent inputs refuse and yield `None`, never `0` | `test_formula_engine.py`, `test_score_engine.py`, `test_rule_engine.py` |
| `UNIT_VALIDATION` | Unknown units and incompatible dimensions refuse (`UNIT_INCOMPATIBLE`) | `test_units.py`, `test_formula_engine.py` |
| `TEMPORAL_VALIDATION` | Distant inputs refuse (`TEMPORALLY_INCOMPATIBLE`) | `test_formula_engine.py` (`test_temporally_incompatible_refuses`), `test_critical_gates.py` |
| `SOURCE_AUTHORITY_CHECK` | Unconfirmed sources refuse (`SOURCE_UNCONFIRMED`) | `test_formula_engine.py` (`test_unconfirmed_source_refuses`), `test_critical_gates.py` |
| `REPRODUCIBILITY` | A stored run records its input snapshot and reproduces identical values | `test_synthesis_run.py`, `test_critical_gates.py` |
| `MAP_PROVENANCE` | No orphan node, no untraceable/opaque edge | `test_clinical_map.py`, `test_critical_gates.py` |
| `KNOWLEDGE_CITATIONS` | An item cannot reach `APPROVED` without citation metadata | `test_knowledge.py`, `test_critical_gates.py` |
| `NO_AUTO_DIAGNOSIS` | Reviewing/accepting a signal or promotion draft never creates a diagnosis | `test_review.py`, `test_critical_gates.py` |
