# R1.2 — Handoff

## Status

`BV_SCIENTIFIC_CENTER_R1_2_STATUS = PASS`

Hardening of persistence integrity, observation identity and provenance is
complete. Baseline R1.1 (108 tests) preserved; 137 tests pass in total. No R2
scientific functionality was started.

## What R1.2 guarantees

* **Observation identity** is the source natural key; re-ingestion is idempotent;
  divergent content is refused (or explicitly revised) and never overwrites.
* **Synthesis persistence** is a single transaction per run; a failure rolls back
  and records exactly one `FAILED` run; no partial run appears complete.
* **Clinical time ≠ ingestion time**; naive timestamps are refused; legacy unknowns
  stay UNKNOWN.
* **Concurrency** is configured (WAL, `busy_timeout`, write lock) and tested.
* **Historical reconstruction** is deterministic from preserved state, with
  execution identity separated from logical (content) identity.

## Contracts and compatibility

* No public contract removed or renamed; no route changed.
* No schema change in R1.2; no destructive migration.
* Additive parameters only: repository `save*` gained `commit: bool = True`
  (default preserves prior behavior).

## How to run

```
python -m pytest                       # 137 passed
python -m compileall src               # OK
python -m bv_scientific_center report  # synthetic gate summary
python -m bv_scientific_center demo    # in-memory demo
python run_ui.py --port 8787           # clinician UI (loopback)
```

Backup of the synthetic databases used during this phase:
`data/runtime/backup_20261007_234344/{knowledge.db,derived.db}` (procedure in
`R1_2_DIAGNOSTIC.md`).

## Documents

`docs/R1_2_DIAGNOSTIC.md`, `R1_2_TEST_MATRIX.md`, `R1_2_CORRECTIONS.md`,
`R1_2_TRANSACTION_STRATEGY.md`, `R1_2_IDENTITY_POLICY.md`,
`R1_2_TEMPORALITY_POLICY.md`, `R1_2_RECONSTRUCTION_POLICY.md`,
`R1_2_RESIDUAL_RISKS.md`, `R1_2_HANDOFF.md`.
R1/R1.1 documents are preserved unchanged (except the reconciled test-file count in
`R1_1_CHANGES.md`).

## Handoff to R2

The R2 proposal in `R1_1_R2_PLAN.md` stands. R1.2 adds two items for R2:

1. **Scale concurrency** — if the UI is ever exposed beyond a single operator, move
   from the shared connection to per-operation connections and add authentication
   (residual R-2/R-3).
2. **Source-version discipline** — formalize the contract that a clinical value
   correction always arrives with a bumped `source_version`; expose the explicit
   revision path (`on_conflict="REVISE"`) and its provenance in the UI.

Do not start R2 without a new directive. `GIT_CHANGED = NO`.
