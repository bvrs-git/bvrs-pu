# R2C-B GATE 3/4 — Structured appraisal sheets

Extraction version: **`r2cb-2`**. Every populated field is `EXTRACTED_UNVERIFIED`
and carries the verbatim source span plus the SHA-256 of the consulted abstract.
Fields not grounded in the abstract are `INSUFFICIENT_INFORMATION` with a reason.
**No field is ever marked `HUMAN_REVIEWED`; automated extraction is not human
critical review.**

## Extracted fields (3 abstracts)

### 10.3390/ijerph16111920 — Percentile curves (Croatian adolescents)

| Field | Value | Locator |
| --- | --- | --- |
| scientific_question | "The main purpose of the present study was to establish percentile curves for … WHtR(exp) in adolescents." | abstract:Purpose |
| study_design | CROSS_SECTIONAL | abstract |
| sample_size | 1036 | abstract |
| population | secondary-school students | abstract |
| reference_method | standardized measuring protocol | abstract |
| author_conclusions | "This is the first study in Croatia to establish combined …" | abstract:Conclusion |
| outcomes / quantitative_results / confidence_intervals / limitations / clinical_applicability | INSUFFICIENT_INFORMATION | — |

### 10.1016/j.clnu.2018.10.010 — FMI/FFMI reference values (Chinese adults)

Abstract quote withheld for external redistribution (restricted license).
Fields extracted internally: study_design=CROSS_SECTIONAL, sample_size, population, reference_method=bioelectrical impedance analysis. Values remain recorded in the internal audit; they are not reproduced here.

### 10.20960/nh.03161 — FMI/FFMI reference values (Spanish adolescents)

Abstract quote withheld for external redistribution (restricted license).
Fields extracted internally: study_design=CROSS_SECTIONAL, sample_size, population, reference_method=skinfold thickness. Values remain recorded in the internal audit; they are not reproduced here.

### Other references

The remaining five references have no abstract in Europe PMC; no field is
extracted. They remain explicitly `INSUFFICIENT_INFORMATION`.

## Body-composition / BIA methodology sheet (GATE 4)

`app.body_composition_sheet(reference_id)` produces, per reference:

- **Grounded when the abstract states it:** `reference_method`, `sample_size`,
  `population`.
- **`INSUFFICIENT_INFORMATION` (never inferred):** device brand, device model,
  technology, equation used, development population, validation population,
  hydration conditions, measurement conditions, cross/external validation,
  estimation error, systematic bias, agreement, limits of agreement, precision,
  subgroup performance, generalisation.

Policy encoded in the sheet:

- `STROBE` / `TRIPOD` / `GRRAS` are **reporting checklists**, not risk-of-bias
  tools; they are never used as RoB instruments.
- BIA is a measurement device, not a PROM instrument.
- **Correlation is not agreement.** Agreement, bias and limits of agreement must
  be reported explicitly; a high r is not treated as concordance.
- Risk of bias stays **`UNASSESSED`** without human review; no tool is
  auto-applied. A design-appropriate instrument is only **suggested**
  (`suggested_rob_instrument`): RCT → RoB 2, cross-sectional → JBI checklist,
  diagnostic accuracy → QUADAS-2, instrument validation → COSMIN, reviews →
  AMSTAR-2/ROBIS. Reporting checklists (STROBE/TRIPOD/GRRAS) are never returned
  as risk-of-bias tools.

## Limitation

Abstracts are not sufficient to validate methodological results (device
equations, bias, agreement, external validation). Only the one `cc by` article
has full text available; even then, no validation metric is asserted because no
human review has been performed. `FULL_TEXT_REVIEWED` is never inferred from an
abstract.
