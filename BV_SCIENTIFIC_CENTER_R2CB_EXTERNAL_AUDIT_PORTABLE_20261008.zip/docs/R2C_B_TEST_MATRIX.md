# R2C-B GATE 9/10 — Test matrix

## Environment

- Python 3.14.6, SQLite 3.50.4 (FTS5), stdlib-only runtime.

## Suite totals

| Metric | Value |
| --- | --- |
| Baseline (R2C-A) | 330 passed, 2 skipped |
| R2C-B total | **392 passed, 3 skipped, 0 failed** |
| New R2C-B offline tests | **62** |
| New online (opt-in) tests | 1 |

The 3 skipped tests are the online integration tests, gated by `BV_RUN_ONLINE=1`
(they pass live: `3 passed`).

## New offline test files

| File | Tests | Area |
| --- | --- | --- |
| `tests/test_r2cb_content.py` | 10 | acquisition, availability, licensing, identifier safety |
| `tests/test_r2cb_extraction.py` | 9 | citation-grounded extraction, provenance, idempotency |
| `tests/test_r2cb_dossiers.py` | 8 | dossiers (JSON/MD), index, decision form and guards |
| `tests/test_r2cb_reconciliation.py` | 6 | R2B 19 vs R2C-A 18 reconciliation |
| `tests/test_r2cb_matrices.py` | 7 | evidence links, applicability, methodology, RoB mapping |
| `tests/test_r2cb_currency.py` | 4 | editorial currency, retraction handling |
| `tests/test_r2cb_adversarial.py` | 14 | injection, malformed input, history, isolation |
| `tests/test_r2cb_ui.py` | 4 | read-only dossiers, no decision route |

## GATE 9 adversarial coverage map

| Scenario | Test |
| --- | --- |
| Crossref/PubMed unavailable | `test_r2cb_currency.py::test_offline_currency_is_unknown_not_fabricated` |
| HTTP 429 / backoff | `test_bibliography_adapters.py::test_retry_policy_backoff_and_retry_after`, `test_rate_limited_propagates` |
| Malformed response | `test_r2cb_adversarial.py::test_malformed_provider_response_fails_closed` |
| Transport failure | `test_r2cb_adversarial.py::test_transport_failure_fails_closed` |
| DOI duplicated / conflicting metadata | `test_r2cb_adversarial.py::test_duplicate_doi_import_is_idempotent`, `test_conflicting_doi_metadata_is_refused` |
| Metadata changed later | `test_r2cb_adversarial.py::test_changed_source_preserves_history` |
| Retracted reference | `test_r2cb_currency.py::test_confirmed_retraction_blocks_current_use` |
| Errata ≠ retraction | `test_r2cb_adversarial.py::test_errata_is_not_a_retraction` |
| Full text not accessible | `test_r2cb_content.py::test_restricted_access_is_recorded_not_ignored` |
| Extraction with missing field | `test_r2cb_extraction.py::test_ungrounded_fields_are_insufficient` |
| Automatic approval attempt | `test_r2cb_dossiers.py::test_review_decision_is_recorded_not_executed` |
| Formula activation attempt | `test_r2cb_adversarial.py::test_review_decision_cannot_activate_formula` |
| Automatic human review | `test_r2cb_adversarial.py::test_extraction_never_marks_human_reviewed` |
| Source unavailable offline | `test_r2cb_content.py::test_unavailable_source_is_explicit` |
| SQL injection via DOI | `test_r2cb_adversarial.py::test_malicious_doi_does_not_reach_sql` |
| Abstract mistaken for full text | `test_r2cb_content.py::test_abstracts_acquired_with_provenance` (locator `abstract`) |
| Correlation ≠ agreement | `test_r2cb_matrices.py::test_methodology_policy_distinguishes_checklists_from_rob` |
| Unvalidated population | `test_r2cb_matrices.py::test_applicability_matrix_never_auto_validates` |
| Patient data in library | `test_r2cb_adversarial.py::test_no_patient_data_in_knowledge_library` |
| Historical synthesis preserved | `test_r2cb_adversarial.py::test_content_acquisition_does_not_touch_synthesis` |
| Idempotent re-ingestion | `test_r2cb_content.py::test_acquisition_is_idempotent`, `test_r2cb_adversarial.py::test_exact_reingest_is_idempotent` |
| Offline reconstruction | `test_r2cb_adversarial.py::test_offline_replay_after_acquisition` |

## Correction with a regression test

| Defect | Test | Fix |
| --- | --- | --- |
| `cc by-nc` treated as redistributable | `test_r2cb_content.py::test_license_classification` | `classify_license` now honours `-nc`/`-nd` suffixes |

## Baseline preserved

All 330 pre-existing tests still pass; no prior document was overwritten.
