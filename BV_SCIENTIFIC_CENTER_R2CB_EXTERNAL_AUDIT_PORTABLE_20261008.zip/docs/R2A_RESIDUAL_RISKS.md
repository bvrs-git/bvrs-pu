# R2A — Residual Risks

Risks remaining after R2A. None blocks certification.

| # | Risk | Impact | Status |
| --- | --- | --- | --- |
| RR-1 | The R1.2 backup was made with `shutil.copy2` (consistent only because no WAL/writer was active) | Historical artifact is sound but the method is unsafe | Audited in `R2A_BACKUP_PROCEDURE.md`; official-API procedure adopted going forward; historical backups preserved |
| RR-2 | Curation UI has no authentication | If bound beyond loopback it exposes scientific metadata | UI is read-only and has no approval endpoint; server binds `127.0.0.1`; localhost is not treated as auth |
| RR-3 | Approval is performed by a local CLI actor string | No cryptographic identity of the reviewer | Reviewer + justification + version are recorded in `curation_events`; stronger identity is an R2B concern |
| RR-4 | Pilot references are limited (4, anthropometric/body-composition) | Small evidence base | Only Crossref-verified metadata used; never auto-approved; R2B expands coverage |
| RR-5 | Crossref metadata can change or a work can be retracted after import | Stale metadata | `accessed_at` and `metadata_source` recorded; retraction flow available; re-verification is manual |
| RR-6 | No automatic GRADE/risk-of-bias engines | Assessment depends on human judgment | By design; suggestions only; certainty requires a named assessor |
| RR-7 | `content_hash` is a method on models but a stored string on read rows | Subtle API asymmetry | Handled by `_content_hash` helper; documented in the contracts doc |
| RR-8 | Metadata change for an existing DOI requires explicit conflict resolution | A legitimate update is blocked until resolved | By design (never silent overwrite); a supersede/new-version flow is the intended path |
| RR-9 | Knowledge search is lexical (FTS5) with LIKE fallback | Recall depends on wording | Raw citation DB remains source of truth; embeddings as index only (R2B) |
| RR-10 | `derived.db` and `knowledge.db` are not atomic together | No cross-database transaction | Documented; the module never assumes cross-database atomicity |

## Out of scope (unchanged)

No real patient data; no BV Clinical / BV Bot changes; no automatic diagnosis; no
automatic GPT Work connection; no Patient Area publication; no third-party runtime
dependencies; no destructive migrations.
