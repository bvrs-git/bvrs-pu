# R1 — Data Ownership

The Scientific Center is a **consumer and synthesizer**, not a system of record
for clinical measurements. Every measurement, questionnaire answer, diagnosis and
medication belongs to the module that captured it. The Scientific Center owns only
what it computes or curates.

## Ownership matrix

| Data | Owner module | Enters as |
| --- | --- | --- |
| Laboratory observations | `LAB` | `LabObservationProjection` |
| Body composition / bioimpedance | `BIOIMPEDANCE` | `BioimpedanceSummaryProjection` |
| Nutrition assessment / targets | `NUTROLOGIA` | `NutritionAssessmentProjection` |
| Questionnaires / integrative intake | `INTEGRATIVA` | `IntegrativeIntakeSummary` |
| Patient-reported facts | `PATIENT_AREA` | `PatientReportedFact` |
| Clinician record / diagnoses | `PRONTUÁRIO` | `DiagnosisSummaryProjection` |
| Medications | `PRONTUÁRIO` | `MedicationSummaryProjection` |
| Demographic / contextual data | `CONTEXT` | `PatientContextProjection` |
| Pregnancy state | `GESTANTES` | `PregnancyContextProjection` |
| Pediatric state | `PEDIATRIA` | `PediatricContextProjection` |

### Owned by the Scientific Center

| Data | Where |
| --- | --- |
| Derived formulas, scores and rule definitions | `formulas/`, `scores/`, `rules/`, `core/registry.py` |
| Computed metrics and score results | `derived_metrics`, `score_results` (in `derived.db`) |
| Cross-domain synthesis runs | `synthesis/run.py`, `synthesis_runs` |
| Signal candidates and reviews | `signals`, `signal_reviews` |
| Knowledge graph (items, claims, references, packages) | `knowledge.db` |
| Evidence metadata (citations, evidence levels, target ranges) | `knowledge/models.py` |
| Clinical map projections | `clinical_map/builder.py`, `contracts/outputs.py` |
| Clinician annotations and pins | `annotations`, `pins` |

## The ownership rule

1. **Reference, never clone.** A consumer references a source observation through
   a `ScientificObservationRef`; it never copies source tables.
2. **Never SQL into another module.** The Scientific Center has no connection to
   any other BV database. Its only inputs are projection DTOs.
3. **Reference by `(source_module, source_entity_type, source_entity_id,
   source_version)`.** Each `ScientificObservationRef` is an immutable,
   provenance-rich pointer that names where the value came from.

This keeps BV Clinical as the single source of truth and lets the Scientific
Center be deployed, tested and versioned independently.

## `ScientificObservationRef`

Defined in `observations/refs.py`. It is a frozen dataclass — a pointer plus the
minimal immutable value snapshot needed to reproduce a computation:

| Field | Meaning |
| --- | --- |
| `observation_ref_id` | Prefixed opaque id (`obsref_...`), the reference itself |
| `patient_id` | Patient the observation belongs to |
| `concept` | Canonical concept code (`core/concepts.py`) |
| `value` | Numeric value, or `None` when missing (never `0`) |
| `unit` | Unit symbol as received |
| `effective_at` | Timezone-aware UTC `datetime` of the observation |
| `source_module` | Owning module (`LAB`, `BIOIMPEDANCE`, `PRONTUARIO`, ...) |
| `source_entity_type` | Source entity kind (e.g. `LabObservation`) |
| `source_entity_id` | Source row/entity id |
| `source_version` | Version of the source record |
| `authority` | `ObservationAuthority` confirmation state |
| `layer` | `MapLayer` used for map grouping |
| `provenance` | Free dict (method, matrix, laboratory, device, ...) |
| `fasting_status` | `FastingStatus` |
| `context` | Free dict (e.g. questionnaire domain, medication details) |
| `labels` | Display labels |

Helpers: `display_authority` (maps `ObservationAuthority` to `Authority`),
`snapshot()` (minimal immutable value snapshot stored in `input_refs` /
`synthesis_runs.input_snapshot`), `label()`.

`ObservationAuthority` distinguishes confirmed sources from unconfirmed ones.
`CONFIRMED_OBSERVATION_AUTHORITIES` = `LAB_CONFIRMED`, `CLINICIAN_CONFIRMED`,
`DOCUMENT_EXTRACTED_REVIEWED`. A formula input with
`requires_confirmed_source=True` refuses with `SOURCE_UNCONFIRMED` when the only
candidate is, for example, `DOCUMENT_EXTRACTED_UNREVIEWED`.

## How `ProjectionIngestor` maps projections to refs

`ProjectionIngestor.ingest(projection)` dispatches on the projection type and
returns one or more refs. `ingest_many(projections)` flattens a list. An
unsupported type raises `ContractViolation`.

| Projection | Method | Emitted concept(s) | `layer` | Default authority |
| --- | --- | --- | --- | --- |
| `LabObservationProjection` | `lab_to_ref` | `projection.concept` | `OBJECTIVE` | `LAB_CONFIRMED` |
| `BioimpedanceSummaryProjection` | `bioimpedance_to_refs` | one per `measurement.concept` | `OBJECTIVE` | `LAB_CONFIRMED` |
| `NutritionAssessmentProjection` | `nutrition_to_refs` | `ENERGY_TARGET`, `PROTEIN_TARGET` | `DERIVED` | `CLINICIAN_CONFIRMED` |
| `IntegrativeIntakeSummary` | `integrative_to_refs` | one per `response.question_code` | `PATIENT_REPORTED` | `PATIENT_REPORTED` |
| `PatientReportedFact` | `patient_reported_to_ref` | `projection.concept` | `PATIENT_REPORTED` | `PATIENT_REPORTED` |
| `MedicationSummaryProjection` | `medication_to_ref` | `"MEDICATION"` | `CLINICIAN_CONFIRMED` | `CLINICIAN_CONFIRMED` |
| `DiagnosisSummaryProjection` | `diagnosis_to_ref` | `code or label` | `CLINICIAN_CONFIRMED` | `CLINICIAN_CONFIRMED` |

The ingestor requires an `effective_at` (for lab values either `effective_at` or
`collection_at`); a missing timestamp raises `ContractViolation`. Every ref
carries the source header (`source_module`, `source_entity_type`,
`source_entity_id`, `source_version`) straight from the projection so provenance
survives into the derived database and into map projections.

## `MISSING != ZERO`

There is no default-substitution anywhere in the pipeline:

* A projection may carry `value=None`. The ref keeps `value=None`.
* `compute_metric` only collects candidates where `r.value is not None`. A
  required input with no numeric observation is reported in `missing_inputs`, and
  the metric is created with `calculation_status = INSUFFICIENT_INPUT`,
  `value = None` and a `refusal_reason` — **never** a computed `0`.
* `evaluate_rule` similarly drops non-numeric candidates; a required input with
  none makes the rule *not evaluated*, and still `signal is None`.
* `scores` inherit the same behaviour: a refused score returns `value = None` and
  `band = None`.

Tests that pin this invariant: `tests/test_formula_engine.py`
(`test_missing_input_is_not_zero`, `test_missing_value_is_not_zero`),
`tests/test_score_engine.py` (`test_score_missing_input_has_no_band`),
`tests/test_rule_engine.py` (`test_missing_input_skips_rule_without_raising`) and
the aggregated `MISSING_IS_NOT_ZERO` gate in `tests/test_critical_gates.py`.
