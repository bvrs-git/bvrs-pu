# R1 — Architecture

**BV Centro Científico & Mapa Clínico** is the standalone scientific synthesis and
clinical map layer of the BV Suite. It consumes **versioned projections** from
other BV modules and produces derived metrics, scores and explainable clinical
signal candidates. It is a *separate module*: it never imports another module's
repositories or ORM entities, never SQLs into their tables, and never writes back
into BV Clinical.

The package is `src/bv_scientific_center/`. Runtime dependencies are the **Python
standard library only**; tests use `pytest`.

## Core invariants

Enforced structurally throughout the code (`core/enums.py`, engine refusals,
storage separation):

```
MEASURED_DATA         != DERIVED_METRIC
DERIVED_METRIC        != CLINICAL_SIGNAL
CLINICAL_SIGNAL       != DIAGNOSTIC_HYPOTHESIS
DIAGNOSTIC_HYPOTHESIS != CONFIRMED_DIAGNOSIS
MISSING               != ZERO
```

## Responsibilities

| Responsibility | Where it lives |
| --- | --- |
| Versioned definitions (formulas, scores, rules) | `core/definition.py`, `core/registry.py`, `formulas/`, `scores/`, `rules/` |
| Derived metrics from declared inputs | `formulas/engine.py` (`compute_metric`, `DerivedClinicalMetric`) |
| Interpretation scores with bands | `scores/engine.py` (`compute_score`, `ClinicalScoreResult`) |
| Rule-based signal candidates | `rules/engine.py` (`evaluate_rule`, `ClinicalSignalCandidate`) |
| Longitudinal synthesis run | `synthesis/run.py` (`SynthesisRunner`, `SynthesisRunResult`) |
| Constrained expression sandbox | `core/expression.py` |
| Unit registry + explicit conversion | `core/units.py` |
| Time alignment | `core/timeutil.py`, `formulas/alignment.py` |
| Observation references + projection ingestor | `observations/refs.py` |
| Scientific knowledge repository + packages + search | `knowledge/` |
| Clinical map model + projection | `clinical_map/builder.py`, `contracts/outputs.py` |
| Review, annotations, pins, promotion drafts | `annotations/service.py` |
| AI labelling boundary (no production reasoning) | `ai/drafts.py` |
| Domain events | `events/bus.py` |
| Synthetic fixtures | `seed/synthetic.py`, `seed/knowledge_seed.py` |
| Minimal clinician UI | `ui/` |

## Boundaries

* **Inbound** — data enters only through projection DTOs in `contracts/inputs.py`.
  `ProjectionIngestor` normalizes them into `ScientificObservationRef` pointers.
* **Outbound** — the module publishes projections (DTOs), never persistence
  internals. The map contract is `ClinicalMapProjectionV1` in
  `contracts/outputs.py`.
* **No writes to BV Clinical.** There is no code path that mutates a source
  module. Accepting a signal or adding an annotation never creates a diagnosis.
* **No patient data in the knowledge store.** `knowledge.db` holds references and
  scientific content only.

## Layered package map

Arrows point from a module to the module it imports (dependency direction). The
foundation is `errors.py`; the UI is the outermost adapter.

```mermaid
flowchart TD
    UI[ui / __main__] --> App[app]
    App --> Synthesis[synthesis.run]
    App --> ClinicalMap[clinical_map.builder]
    App --> Annotations[annotations.service]
    App --> Knowledge[knowledge.repository]
    App --> Seed[seed]

    Synthesis --> Formulas[formulas]
    Synthesis --> Scores[scores]
    Synthesis --> Rules[rules]
    Synthesis --> Storage[storage.repositories]
    Synthesis --> Events[events.bus]

    Scores --> Formulas
    Rules --> Formulas
    Scores --> Core[core]
    Rules --> Core

    Storage --> Formulas
    Storage --> Rules
    Storage --> Scores
    Storage --> Observations[observations.refs]
    Storage --> Core

    ClinicalMap --> Synthesis
    ClinicalMap --> Contracts[contracts.outputs]
    ClinicalMap --> Observations

    Observations --> Contracts
    Contracts --> Core

    Formulas --> Core
    Knowledge --> StorageDb[storage.database]
    Events --> Core
    AI[ai.drafts] --> Core
    Core --> Errors[errors]
```

## Composition root — `ScientificCenterApp`

`app.py` defines `ScientificCenterApp`, the composition root and the only object
the UI and tests talk to. It is deliberately free of framework code. Its
constructor:

1. builds the two-database `Database` (`initialize()`);
2. instantiates the three registries — `FormulaRegistry`, `ScoreRegistry`,
   `RuleRegistry`;
3. wires the repositories (`ObservationRepository`, `DerivedMetricRepository`,
   `ScoreResultRepository`, `SignalRepository`, `SynthesisRunRepository`,
   `AnnotationRepository`, `PinRepository`, `EventRepository`);
4. wires the knowledge repositories (`KnowledgeRepository`, `PackageRepository`);
5. creates the `EventBus` (recording every event through `_record_event` into the
   events table), the `ClinicalReviewService`, and the `SynthesisRunner`.

Public surface (selected):

| Method | Purpose |
| --- | --- |
| `run_synthesis(patient_id, projections=..., observation_refs=..., context=...)` | Execute a run and persist results |
| `reproduce_run(patient_id, ...)` | Rebuild a run from stored observations (`persist=False`) |
| `build_map(run, layers=..., as_of=..., temporal_mode=...)` | Build and validate a `ClinicalMapProjectionV1` |
| `patient_overview`, `latest_run`, `list_patients`, `timeline`, `compare`, `correlation_series`, `domain_dashboard` | Read models for the UI |
| `knowledge_search`, `import_package`, `activate_package` | Knowledge repository and package lifecycle |
| `bootstrap_synthetic()` | Register synthetic fixtures, seed knowledge, import + activate the synthetic package, and run synthesis |
| `ai_placeholder_summary(patient_id)` | Deterministic AI-labelling placeholder (`AI_DRAFT`) |
| `close()` | Commit and close both connections |

The `ClinicalReviewService` exposes `review_signal`, `annotate`, `pin` and
`build_prontuario_promotion_draft` (a reviewable draft that never auto-inserts a
diagnosis).

## Two-database split

`storage/database.py` owns two SQLite connections with foreign keys enabled and
`row_factory = sqlite3.Row`:

| Database | Schema | Contents |
| --- | --- | --- |
| `knowledge.db` | `KNOWLEDGE_SCHEMA` | `knowledge_items`, `knowledge_claims`, `knowledge_references`, `knowledge_packages`, `knowledge_fts` (FTS5). **No patient data.** |
| `derived.db` | `CLINICAL_SCHEMA` | `observations`, `derived_metrics`, `score_results`, `signals`, `signal_reviews`, `synthesis_runs`, `annotations`, `pins`, `events` |

The split is a hard boundary: `KnowledgeRepository`/`PackageRepository` use only
`database.knowledge`; the clinical repositories use only `database.clinical`.
`memory=True` opens both as `:memory:` (used by tests).

## Runtime dependency policy

* Implementation imports only the standard library (`sqlite3`, `ast`, `math`,
  `json`, `hashlib`, `uuid`, `datetime`, `http.server`, `dataclasses`, `enum`,
  `re`, `itertools`, `operator`, `pathlib`, `typing`, `urllib`).
* `pyproject.toml` declares `dependencies = []` and `requires-python = ">=3.11"`;
  the package is found under `src/`. The only optional dependency is
  `dev = ["pytest>=7"]`.
* Expressions are never executed with `eval`/`exec`; they are parsed with `ast`
  and interpreted by an explicit whitelisted AST walker (`core/expression.py`).
* Imported knowledge packages are untrusted until validated
  (`knowledge/packages.py` rejects scripts, JavaScript URIs and filesystem
  paths).
