# R2B — Initial Corpus

## Scope

The initial controlled corpus covers the domain
`ANTHROPOMETRY_BODY_COMPOSITION_NUTRITION`. It is defined by explicit subdomain
queries and inclusion/exclusion criteria in `bibliography/corpus.py`
(`CORPUS_QUERIES`, `INCLUSION_CRITERIA`, `EXCLUSION_CRITERIA`,
`POPULATION_NOTE`). Records are acquired from Crossref (rate-limited) and frozen
into `data/seed/corpus_bibliography.json` with provenance; the snapshot is what
tests and offline use consume.

## Subdomains

Six subdomains, each a topical Crossref bibliographic query (chosen for
relevance, not popularity):

| Subdomain | Query |
| --- | --- |
| `BMI_DEFINITION_USE` | body mass index definition classification limitations |
| `WAIST_ANTHROPOMETRY` | waist circumference waist-to-height ratio anthropometric measurement |
| `FAT_MASS_INDEX` | fat mass index reference values |
| `FAT_FREE_MASS_INDEX` | fat-free mass index reference values |
| `BIOIMPEDANCE_PRINCIPLES` | bioelectrical impedance analysis body composition validity limitations |
| `LONGITUDINAL_BODY_COMPOSITION` | longitudinal change body composition follow-up |

## Inclusion criteria

* Relevant to anthropometry, body composition or nutritional assessment.
* Journal article, review meta-analysis/guideline or instrument validation.
* Provides methodological, definitional or reference-value content.

## Exclusion criteria

* Not selected by popularity or citation count.
* Cannot be imported automatically as a clinical cutoff or equation.
* Preprints kept with their own identity; not merged with the published article.

## Population note

Population contexts (adult, pediatric, pregnant, athletes, clinical conditions)
are recorded as metadata only and never imported as cutoff values.

## Contents

* **15** Crossref records in the frozen snapshot (`provider = "CROSSREF"`,
  domain recorded, `inclusion_criteria` / `exclusion_criteria` / `population_note`
  embedded in the snapshot).
* **4** R2A pilot references carried over by `seed_scientific`
  (`pilot_references()`). One of them, `REF-PILOT-WHTR-MULTIMORBIDITY`, is a
  preprint (`10.21203/rs.3.rs-137388/v1`).

Total: **19 real references**, all unapproved.

## Guarantees

* Every corpus record carries a DOI, a title and a year; the snapshot size is
  asserted to be within 12–20 records (`test_corpus_snapshot_is_controlled_and_verifiable`).
* Imports are unapproved and clinically unusable:
  `curation.active_references() == []` after bootstrap
  (`test_corpus_is_imported_but_never_approved`,
  `test_pilot_references_are_part_of_the_corpus_and_unapproved`).
* **No cutoff value or equation is imported** for clinical execution, and no
  patient data is stored in any scientific table
  (`test_patient_like_data_is_not_stored_in_scientific_tables`).
* Snapshot import is idempotent (`test_corpus_import_is_idempotent`).
