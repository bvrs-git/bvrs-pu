# R2C-B GATE 6 — Clinical applicability matrix

`app.applicability_matrix()` emits, for each of the 7 candidates, a status per
population/context:

- `VALIDATED_FOR_CONTEXT`
- `NOT_VALIDATED_FOR_CONTEXT`
- `EVIDENCE_INSUFFICIENT`
- `NOT_APPLICABLE_BY_DEFINITION`
- `VALIDATION_PENDING`

## Rules applied

1. A context is **never** marked `VALIDATED_FOR_CONTEXT` automatically. Contexts
   the candidate declares applicable are `VALIDATION_PENDING` until a human
   review declares otherwise.
2. Contexts the profile declares **not** validated → `NOT_VALIDATED_FOR_CONTEXT`.
3. Declared contraindications → `NOT_APPLICABLE_BY_DEFINITION`.
4. Everything else → `EVIDENCE_INSUFFICIENT`.

**The mere presence of a subgroup in a study never marks a population as
validated.** For example, the Chinese-adults study is in adults only; it does not
validate pediatric use.

## Representative rows

| Candidate | ADULT | PEDIATRIC | PREGNANT | ELDERLY | ATHLETE |
| --- | --- | --- | --- | --- | --- |
| SCI-CAND-BMI | VALIDATION_PENDING | NOT_VALIDATED_FOR_CONTEXT | NOT_VALIDATED_FOR_CONTEXT | EVIDENCE_INSUFFICIENT | NOT_VALIDATED_FOR_CONTEXT |
| SCI-CAND-FMI | VALIDATION_PENDING | NOT_VALIDATED_FOR_CONTEXT | NOT_VALIDATED_FOR_CONTEXT | EVIDENCE_INSUFFICIENT | EVIDENCE_INSUFFICIENT |
| SCI-CAND-FFMI | VALIDATION_PENDING | NOT_VALIDATED_FOR_CONTEXT | NOT_VALIDATED_FOR_CONTEXT | EVIDENCE_INSUFFICIENT | EVIDENCE_INSUFFICIENT |
| SCI-CAND-WHTR | VALIDATION_PENDING | NOT_VALIDATED_FOR_CONTEXT | NOT_VALIDATED_FOR_CONTEXT | EVIDENCE_INSUFFICIENT | EVIDENCE_INSUFFICIENT |
| SCI-CAND-BODY-FAT-PCT | VALIDATION_PENDING | EVIDENCE_INSUFFICIENT | NOT_VALIDATED_FOR_CONTEXT | EVIDENCE_INSUFFICIENT | EVIDENCE_INSUFFICIENT |
| SCI-CAND-BC-LONGITUDINAL | VALIDATION_PENDING | EVIDENCE_INSUFFICIENT | NOT_VALIDATED_FOR_CONTEXT | EVIDENCE_INSUFFICIENT | EVIDENCE_INSUFFICIENT |
| SCI-CAND-WHTR-CUTOFF-PLACEHOLDER | NOT_VALIDATED_FOR_CONTEXT | NOT_VALIDATED_FOR_CONTEXT | EVIDENCE_INSUFFICIENT | EVIDENCE_INSUFFICIENT | EVIDENCE_INSUFFICIENT |

`DEVICE_SPECIFIC`, `SEVERE_OBESITY`, `HYDRATION_CHANGE`, `EDEMA_ASCITES`,
`ACUTE_CONDITION` are `EVIDENCE_INSUFFICIENT` or `NOT_VALIDATED_FOR_CONTEXT`
depending on the profile; none is validated.

## Absence of evidence

The registry uses `APPLICABILITY_NOT_ESTABLISHED` /
`EVIDENCE_INSUFFICIENT`; absence of evidence is never presented as proof of
absence of effect. No generic exclusion rule is added without a basis.
