# R1.2 — Historical Reconstruction Policy

## Goal

A synthesized result must be reproducible from preserved state, without depending
on the current, mutable state of the observation store.

## Execution identity vs logical identity

* **Execution identity** — `run_id` (random). Two executions of the same synthesis
  have different `run_id`.
* **Logical (content) identity** — `SynthesisRunResult.logical_fingerprint()`,
  a content hash over: patient, formula/score/rule versions, and the sorted metric
  values/units/statuses, score values/bands and signal identities.

Two runs over the same inputs and versions share the logical fingerprint even
though their `run_id` differs (`test_execution_identity_differs_but_logical_identity_matches`).

## Reconstruction paths

| Method | Behavior | Determinism |
| --- | --- | --- |
| `SynthesisRunner.reconstruct_run(...)` | rebuilds from persisted state | deterministic (stable ids) |
| `ScientificCenterApp.rebuild_run(patient_id, run_id)` | loads the stored run record, its input snapshot ids, and the stored metrics/scores/signals | deterministic |
| `ScientificCenterApp.reproduce_run(patient_id)` | recomputes from current observations | values deterministic; **new** metric ids |

The UI map route prefers `rebuild_run` for a completed stored run, so the map of a
stored run is reproducible.

## Invariants verified

* Rebuilding the same stored run twice yields identical node/edge id sets.
* `rebuild_run` and `reproduce_run` share the same logical fingerprint.
* Recomputing or running again does not modify the historical run record
  (`completed_at`, `status`, `input_snapshot` unchanged).
* Because observations are immutable after insert (controlled ingestion), a
  divergent re-send is refused and cannot change a reconstruction
  (`test_reconstruction_is_independent_of_mutable_state`).
* Reconstruction preserves provenance links (metric version, input reference ids).

## Refusal

When evidence is missing (e.g. unknown `run_id`, or a patient mismatch), the
rebuild refuses with `KeyError` — it never fabricates a result
(`test_reconstruction_refuses_without_evidence`,
`tests/test_determinism.py::test_rebuild_isolates_by_patient`).

## Input snapshot

Each run stores `input_snapshot` (per-observation value snapshot including both
`effective_at` and `ingested_at`) plus `meta.observation_ref_ids`, `metric_ids` and
`signal_ids`. This is the immutable reference set used for reconstruction; it
avoids duplicating entire source tables while remaining sufficient to rebuild.

## Tests

`tests/test_historical_reconstruction.py` (6), `tests/test_determinism.py` (5),
`tests/test_synthesis_run.py` (5).
