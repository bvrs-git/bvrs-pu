# R2C-B GATE 0 — Bibliographic reconciliation (R2B 19 vs R2C-A 18)

## Question

R2B reported **19 real references**; R2C-A reported **18 real + 3 synthetic = 21
rows**. R2C-B must explain the difference without altering any stored value.

## Answer (demonstrable, not cosmetic)

The store de-duplicates references by DOI-derived stable id
(`ids.stable_id("REF-DOI", doi)`). R2B's "19" counted **import operations**, not
distinct entities:

- R2A pilot: **4** imports
- R2B corpus: **15** imports
- shared DOI between pilot and corpus: **1** → `10.15857/ksep.2009.18.2.256`
  ("Reference norms of fat mass index and fat-free mass index for girls", the
  R2A pilot `REF-PILOT-FMI-FFMI-GIRLS-NORMS`)

Thus 4 + 15 − 1 = **18 distinct real references**. The R2A pilot import already
created the reference under that DOI; the corpus import of the same DOI resolved
to the same entity and did not duplicate it.

Machine-readable matrix: `app.reconciliation()` (also `python -m
bv_scientific_center reconcile`).

## Matrix summary

| Bucket | Count |
| --- | --- |
| Total references in store | 21 |
| Real (`origin != SYNTHETIC_TEST`) | 18 |
| Synthetic fixtures (`origin = SYNTHETIC_TEST`) | 3 |
| Duplicate DOI identities | 0 |

Distinct real references (18), by DOI:

```
10.3928/21650799-20140514-04     10.1177/216507991406200608
10.1080/080352500750027745       10.21275/sr23722204501
10.1253/circj.cj-10-0583         10.3390/ijerph16111920
10.20960/nh.03161                10.1016/j.clnu.2018.10.010
10.15857/ksep.2009.18.2.256      10.1097/01823246-199001010-00008
10.1016/s0899-9007(97)85179-9    10.33948/1798-003-001-009
10.1016/s0261-5614(03)80008-0    10.3389/fphys.2023.1104018
10.4103/jpgm.jpgm_887_20         10.1080/01635581.2025.2581336
10.15857/ksep.2013.22.4.301      10.21203/rs.3.rs-137388/v1
```

## Note on a second "same title, different DOI" pair

`10.3928/21650799-20140514-04` and `10.1177/216507991406200608` share the title
"Limitations of Body Mass Index to Assess Body Fat" but are distinct DOIs. They
are kept as **separate identities** and never merged by title. Europe PMC does
not index the former under its DOI; content is therefore not associated with it
(see `SOURCE_UNAVAILABLE` in the source inventory).

## Conclusion

No information was lost or altered to reconcile the counts. The seven candidate
formulas remain non-operational.
