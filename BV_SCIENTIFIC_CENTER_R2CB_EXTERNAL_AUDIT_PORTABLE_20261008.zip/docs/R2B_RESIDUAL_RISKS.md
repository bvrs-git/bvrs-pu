# R2B — Residual Risks

Known limitations and residual risks of the R2B layer. None is a regression
(historical syntheses keep their logical fingerprint), and each is bounded by the
design; they are listed so that R2C can address them deliberately.

| Risk | Description | Current mitigation |
| --- | --- | --- |
| Reviewer identity is a local string | `reviewer` / `actor` is declared free text. It is **not authentication** and cannot prove who approved. | Approval requires a non-empty actor + justification and is recorded in the audit trail; approval is CLI-only. |
| Metadata can change or be retracted after import | Providers may update, correct or retract a record after acquisition. The stored snapshot is only as current as `last_checked_at`. | `check_editorial` appends alerts; offline re-check preserves the last known state and flags currency as unverifiable. |
| Lexical search only | Search is SQLite FTS5 over titles/authors/venue/identifiers; it is keyword-based, not semantic. | Search is explicitly a retrieval tool; it never implies verification or approval. |
| Cross-database non-atomicity | `knowledge.db` and `derived.db` are separate files; atomicity is per database. A write touching both is not a single transaction. | Acquisition writes only to `knowledge.db`; the module never assumes cross-database atomicity. |
| Small corpus | The initial corpus is 19 real references (15 Crossref + 4 pilot). It is not a comprehensive evidence base. | Corpus is versioned and frozen; size bounds are asserted by tests. |
| No authentication on the UI | The HTTP UI binds `127.0.0.1` by default and has no login. | The UI is read-only; it exposes no approval or mutation route. |
| Provider vocabulary differences | Provider `publication_type` values use different vocabularies. | `publication_type` is deliberately **not** compared during reconciliation, to avoid false conflicts. |
| Cache staleness | Cached responses are served indefinitely; the cache has no TTL. | The cache enables offline consultation and does not overwrite stored references; a fresh `check_editorial` is an explicit action. |
| Erratum vs retraction heuristics | Alert classification is keyword-based on provider notes. | `is_retraction` is stored explicitly; errata never set it; history is append-only. |
| No patient data by construction | Scientific tables contain no `patient_id`. | Asserted by `test_patient_like_data_is_not_stored_in_scientific_tables`. |

## Notes

* No formula, score or rule is imported by R2B; acquisition cannot alter clinical
  computation.
* Approval remains a local administrative action; the residual risk of a
  mis-declared reviewer is a governance matter, not a technical one.
