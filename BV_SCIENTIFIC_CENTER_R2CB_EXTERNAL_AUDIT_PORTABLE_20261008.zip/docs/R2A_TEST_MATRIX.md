# R2A — Test Matrix

## Totals

| Snapshot | Tests | Pass | Fail |
| --- | --- | --- | --- |
| R1.2 baseline (re-measured) | 137 | 137 | 0 |
| R2A | **204** | **204** | **0** |

New in R2A: **10 files, 67 tests**.

## Tests per file (R2A marked)

| Tests | File |
| --- | --- |
| 13 | `test_expression.py` |
| 12 | `test_formula_engine.py` |
| 10 | `test_knowledge.py` |
| 10 | `test_curation_workflow.py` **[R2A]** |
| 10 | `test_adversarial_r2a.py` **[R2A]** |
| 8 | `test_clinical_map.py` |
| 8 | `test_ui_security.py` |
| 8 | `test_temporal_policy.py` |
| 8 | `test_backup_safety.py` **[R2A]** |
| 7 | `test_identity_conflicts.py` |
| 7 | `test_scientific_models.py` **[R2A]** |
| 7 | `test_scientific_search.py` **[R2A]** |
| 6 | `test_units.py`, `test_rule_engine.py`, `test_packages_r2a.py` **[R2A]**, `test_historical_reconstruction.py`, `test_curation_ui_security.py` **[R2A]** |
| 5 | `test_synthesis_run.py`, `test_determinism.py`, `test_governance.py`, `test_calculation_safety.py`, `test_pilot_references.py` **[R2A]** |
| 4 | `test_provenance.py`, `test_idempotency.py`, `test_patient_isolation.py`, `test_review.py`, `test_concurrency.py`, `test_transactions.py`, `test_evidence_links.py` **[R2A]**, `test_methodology.py` **[R2A]** |
| 3 | `test_score_engine.py`, `test_fail_closed.py` |
| 2 | `test_migration.py` |
| 1 | `test_critical_gates.py` |

## Gate coverage

| Gate | Focus | Evidence |
| --- | --- | --- |
| 0 | Safe backup / integrity | `test_backup_safety.py` |
| 1 | Scientific model | `test_scientific_models.py` |
| 2 | Curation workflow / audit | `test_curation_workflow.py` |
| 3 | Methodological taxonomy / no auto-GRADE | `test_methodology.py` |
| 4 | Evidence ↔ formula links | `test_evidence_links.py` |
| 5 | Package governance / versioning | `test_packages_r2a.py` |
| 6 | Search filters / read-only UI | `test_scientific_search.py`, `test_curation_ui_security.py` |
| 7 | Real-reference pilot | `test_pilot_references.py` |
| 8 | Adversarial | `test_adversarial_r2a.py` |
| 1–6 | Regression (R1/R1.1/R1.2 preserved) | all prior test files + `test_critical_gates.py` |

## GATE 8 checklist (adversarial)

| Scenario | Test |
| --- | --- |
| Duplicate DOI (identical) | `test_duplicate_doi_identical_is_idempotent` |
| DOI with conflicting metadata | `test_conflicting_doi_metadata_is_refused` |
| Claim without reference | `test_claim_without_reference_cannot_be_approved` |
| Retracted reference | `test_retracted_reference_cannot_be_approved_and_is_not_usable` |
| Unauthorized status change | `test_unauthorised_status_change_is_rejected` |
| Reviewing an approved item | `test_reapproval_same_status_is_rejected` (workflow) |
| Tampered / partial package | `test_tampered_and_partial_packages_are_rejected` |
| Transactional failure | `test_failed_transition_does_not_change_status` |
| Concurrency on import | `test_concurrent_reference_import_is_safe` |
| SQL/FTS injection | `test_search_injection_is_safe` |
| Synthetic reference to APPROVED | `test_synthetic_references_are_not_approvable`, `test_synthetic_reference_can_never_be_approved` |
| Synthetic patient linked to knowledge | `test_knowledge_tables_contain_no_patient_data` |
| Historical reconstruction after review | `test_historical_reconstruction_after_scientific_review` |

## Acceptance evidence

* **Approval is human-only** — approval without actor/justification raises; synthetic
  never approvable; unverified never approvable.
* **Idempotency** — identical DOI import is a no-op; conflicting metadata refused.
* **Isolation** — scientific tables have no `patient_id`; patient id not usable as a
  reference identifier.
* **Historical preservation** — clinical reconstruction fingerprint identical after
  evidence retraction.
