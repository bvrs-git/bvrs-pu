# R2C-A — Input Semantics

`knowledge/input_semantics.py` makes the *nature* of an input value explicit and
prevents a device estimate or a derived value from ever being presented as a
measurement.

## The semantics chain

`InputSemantics` (`core/enums.py`) has six values. `InputValue` carries one, plus
its unit, value and any device provenance.

| Semantics | Meaning |
| --- | --- |
| `MEASURED` | Directly measured. |
| `CLINICIAN_ASSESSED` | Judged by a clinician. |
| `PATIENT_REPORTED` | Reported by or about the patient. |
| `DEVICE_ESTIMATED` | Produced by a device/model/algorithm. |
| `FORMULA_DERIVED` | Computed by a formula from other inputs. |
| `UNKNOWN` | Not established. |

A **directness order** (`_DIRECTNESS`) underlies the rules, from most direct to
least:

```mermaid
flowchart LR
    M[MEASURED<br/>0] --> C[CLINICIAN_ASSESSED<br/>1] --> P[PATIENT_REPORTED<br/>2] --> D[DEVICE_ESTIMATED<br/>3] --> F[FORMULA_DERIVED<br/>4] --> U[UNKNOWN<br/>5]
```

Lower index = more directly established. A derived or estimated value must never
move *up* this chain.

## Constructors

| Helper | Produces |
| --- | --- |
| `measurement(name, value, unit)` | `MEASURED` |
| `device_estimate(name, value, unit, device=, model=, algorithm=, method=)` | `DEVICE_ESTIMATED` |
| `clinician_assessed(...)` | `CLINICIAN_ASSESSED` |
| `patient_reported(...)` | `PATIENT_REPORTED` |
| `derived(name, value, unit, parents=(...))` | `FORMULA_DERIVED` |

## Device provenance

`InputValue` carries `device`, `model`, `algorithm`, `method`, `conditions`,
`source_ref` and `effective_at`. `provenance()` returns them as a structured
dictionary so that the estimation context travels with the number.

```python
fat_mass = device_estimate("fat_mass", 20.0, "kg",
                           device="BIA-X", model="M1", algorithm="vendor-v3")
fat_mass.device    # "BIA-X"
fat_mass.algorithm # "vendor-v3"
```

## The anti-upgrade rule

`derived(...)` calls `assert_no_semantics_upgrade(parents, FORMULA_DERIVED)`
before building the child. The rule is: **a derived value must not be more
"direct" than any of its inputs.**

```python
def assert_no_semantics_upgrade(parents, child_semantics) -> None:
    child_rank = _DIRECTNESS[child_semantics]
    for parent in parents:
        if child_rank < _DIRECTNESS[parent.semantics]:
            raise EvidenceGovernanceError(...)
```

Consequences:

- A value derived from a `DEVICE_ESTIMATED` input cannot be labelled `MEASURED`
  (this raises `EvidenceGovernanceError`).
- The proper derived value stays `FORMULA_DERIVED` and records its `derived_from`
  parents, preserving traceability to the original estimate.
- `semantics_allows(candidate, declared)` returns `True` only when the candidate is
  at least as direct as the declared requirement — the check the prototype
  evaluator uses for `SEMANTICS_MISMATCH`.

## Missing stays UNKNOWN / None

- `InputValue.is_missing()` is `True` when `value is None`.
- Missing values are never coerced to `0`; the prototype evaluator returns
  `INSUFFICIENT_INPUT`.
- Unknown context resolves to `UNKNOWN` (or `None`), never to an assumed default.

## What the evaluator enforces

For every declared variable, `evaluate_candidate_prototype` checks that the input's
`semantics` is in the variable's `allowed_semantics`. A device estimate supplied to
a variable that only allows `MEASURED` produces `SEMANTICS_MISMATCH`, not a silent
conversion.

See also: `R2C_A_FORMULA_CANDIDATES.md`, `R2C_A_APPLICABILITY.md`.
