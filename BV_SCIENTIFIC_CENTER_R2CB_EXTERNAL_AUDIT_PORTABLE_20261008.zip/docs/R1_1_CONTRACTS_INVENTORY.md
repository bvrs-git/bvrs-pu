# R1.1 — Contracts Inventory

All boundary types live in `src/bv_scientific_center/contracts/`. Inbound types are
consumed; outbound types are published. Persistence internals are never exposed.

## Inbound projections (`contracts/inputs.py`)

| Projection | `source_module` | Notables fields |
| --- | --- | --- |
| `LabObservationProjection` | `LAB` | concept, value (nullable), unit, effective_at, authority, method/matrix/laboratory, collection_at, fasting_status, context |
| `BioimpedanceSummaryProjection` | `BIOIMPEDANCE` | effective_at, measurements[{concept,value,unit}], device, method |
| `NutritionAssessmentProjection` | `NUTROLOGIA` | energy_target_kcal, protein_target_g, notes |
| `IntegrativeIntakeSummary` | `INTEGRATIVA` | responses[{question_code,domain,value,unit}] |
| `PatientReportedFact` | `PATIENT_AREA` | concept, value, unit |
| `DiagnosisSummaryProjection` | `PRONTUARIO` | code, label, status, confirmed_at *(read-only)* |
| `MedicationSummaryProjection` | `PRONTUARIO` | name, dose, unit, frequency, started_at, stopped_at |
| `PatientContextProjection` | `CONTEXT` | sex, age_years, population, hormone therapy / contraception / menopause flags |
| `PregnancyContextProjection` | `GESTANTES` | is_pregnant, gestational_age_weeks |
| `PediatricContextProjection` | `PEDIATRIA` | is_pediatric, age_years |

Common header on every projection: `patient_id`, `source_module`,
`source_entity_type`, `source_entity_id`, `source_version`. Each exposes
`from_dict` for validation at the boundary. `ProjectionIngestor` normalizes any of
them into `ScientificObservationRef`.

### Source authority values (`ObservationAuthority`)

`LAB_CONFIRMED`, `CLINICIAN_CONFIRMED`, `DOCUMENT_EXTRACTED_REVIEWED` are
*confirmed*; `DOCUMENT_EXTRACTED_UNREVIEWED`, `PATIENT_REPORTED`,
`IMPORTED_UNVERIFIED`, `UNKNOWN` are not. Formulas/rules that require a confirmed
source refuse with `SOURCE_UNCONFIRMED` otherwise.

## Observation reference (`observations/refs.py`)

`ScientificObservationRef` — immutable pointer: `observation_ref_id` (deterministic
natural-key hash), `patient_id`, `concept`, `value` (nullable), `unit`,
`effective_at` (clinical), `ingested_at` (registration), `source_module`,
`source_entity_type`, `source_entity_id`, `source_version`, `authority`, `layer`,
`provenance`, `fasting_status`, `context`, `labels`. `snapshot()` produces the
immutable value snapshot persisted for reproducibility.

## Outbound contracts (`contracts/outputs.py`)

| Type | Purpose |
| --- | --- |
| `ClinicalMapProjectionV1` | versioned clinical map contract (`contract_version`, `metadata`, `nodes`, `edges`) |
| `ClinicalMapMetadata` | patient, generation_time, formula/score/rule versions, knowledge package version, run_id, window, temporal mode, layers |
| `MapNodeProjection` | node_id, node_type, layer, label, authority, domain, value, unit, effective_at, provenance |
| `MapEdgeProjection` | edge_id, endpoints, relation, layer, provenance, `why_connected()` |
| `Provenance` | source_ref / source module / formula | score | rule (+version) / annotation / evidence_refs / note; `is_traceable()` |

## Domain events (`events/bus.py`)

`EVENT_TYPES = (DerivedMetricComputed, ClinicalSignalGenerated,
ClinicalSignalReviewed, KnowledgePackageActivated, SynthesisRunCompleted)`.
Map rendering is a pure projection and is deliberately **not** an event.

## Storage contracts

**`derived.db`** — `observations`, `derived_metrics`, `score_results`, `signals`,
`signal_reviews`, `synthesis_runs`, `annotations`, `pins`, `events`.

**`knowledge.db`** — `knowledge_items`, `knowledge_claims`, `knowledge_references`,
`knowledge_packages`, `knowledge_fts` (FTS5). **No patient data.**

`synthesis_runs` records reproducibility: `input_snapshot`, `formula_versions`,
`score_versions`, `rule_versions`, `knowledge_package_version`, timestamps,
status, and `meta` with `observation_ref_ids`/`metric_ids`/`signal_ids`.

## Enumerations (`core/enums.py`)

`Authority`, `ObservationAuthority` (+ confirmed set), `MapLayer`,
`CalculationStatus`, `TemporalRequirement`, `DefinitionStatus`, `Severity`,
`SignalStatus`, `ScoreBandDirection`, `FastingStatus`, `SexContext`,
`PopulationContext`, `TargetType`, `ClinicalDomain`, `NodeType`, `EdgeType`
(+ non-causal set), `KnowledgeSourceType`, `KnowledgeStatus`, `KnowledgeOrigin`,
`ReviewStatus`, `PackageReviewStatus`, `ClaimReviewStatus`,
`SynthesisRunStatus`, `SignalType`, `REFUSAL_PRECEDENCE`.

## Versioning and immutability

* Formula/score/rule definitions: `DefinitionRegistry` keyed by
  `(definition_id, version)` with content hashing; re-publishing the same content
  is idempotent, different content for the same version raises
  `DuplicateDefinitionError`.
* Knowledge packages: `PackageRepository` rejects a different payload for an
  existing `(package_id, version)` (`ImmutablePublishError`).
* Historical results keep `metric_definition_version` and `formula_snapshot`.

## Changes since R1

* `ScientificObservationRef` gained `ingested_at` (clinical vs ingestion date).
* `Observations` table gained `ingested_at`; `knowledge_items` gained `origin`.
* `KnowledgeOrigin` enum added; governance enforced on approval.
* Both schema changes are applied by an **additive** migration
  (`storage/database._migrate`); no drops, no rewrites.
