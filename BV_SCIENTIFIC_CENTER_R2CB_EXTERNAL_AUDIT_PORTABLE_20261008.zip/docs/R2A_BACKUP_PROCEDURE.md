# R2A — Backup Procedure (GATE 0)

## Audit of the R1.2 backup

Artifact: `data/runtime/backup_20261007_234344/{knowledge.db,derived.db}`
(created with `shutil.copy2`).

| Check | Result |
| --- | --- |
| `PRAGMA integrity_check` | `ok` |
| `PRAGMA foreign_key_check` | 0 violations |
| `PRAGMA journal_mode` (artifact) | `delete` |
| `-wal` / `-shm` present in backup dir | none |

Findings:

* At the time of that copy the module was still using the **rollback journal**
  (WAL was adopted later in R1.2), and no writer process was active. Under those
  conditions the artifact is a consistent snapshot — verified above.
* `shutil.copy2` copies only the main database file and is **not safe** under WAL
  or concurrent writes: a non-empty `-wal` can hold committed transactions that
  the copy would miss. The R1.2 copy is therefore *consistent by circumstance*, not
  by method.
* Historical backups are neither replaced nor deleted.

## Safe procedure (adopted)

`storage/backup.py` uses the official `sqlite3.Connection.backup()` API, which
copies a transactionally consistent snapshot (including WAL content), then verifies:

1. open the source read-only (`file:...?mode=ro`, so no `-wal`/`-shm` is created);
2. `src.backup(dst)`;
3. `PRAGMA integrity_check` and `PRAGMA foreign_key_check` on the artifact;
4. SHA-256 of the artifact;
5. if verification fails, **delete** the artifact and raise
   `BackupVerificationError` (explicit failure, no unusable file left behind).

Backups are written to a timestamped filename; an existing filename is never
overwritten.

## Commands

```sh
# CLI (both databases by default)
python -m bv_scientific_center backup

# explicit sources / destination
python -m bv_scientific_center backup \
  --source data/runtime/knowledge.db \
  --source data/runtime/derived.db \
  --dest data/runtime/backup --label manual
```

Output includes `sha256`, `integrity_check` and `fk_violations` per artifact.

## Restore drill

`storage.backup.restore_to(backup, target)` restores a verified backup into a new
target (the backup itself is never modified) and verifies the restored database.
This is exercised by `tests/test_backup_safety.py::test_restore_drill`.

## Tests

`tests/test_backup_safety.py` (8): verified backup + hash; WAL-active snapshot
includes committed rows; original preserved; restore drill; invalid source fails
and leaves no artifact; missing source fails; no overwrite; invalid verify report.
