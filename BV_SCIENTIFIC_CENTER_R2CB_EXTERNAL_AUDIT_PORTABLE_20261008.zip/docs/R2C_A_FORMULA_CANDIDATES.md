# R2C-A — Formula Candidates

R2C-A introduces a catalog of **scientific formula candidates**. A candidate is a
versioned *definition* with an expression, declared variables, an applicability
profile and a review state. It is never an executable clinical formula.

## Registry

`ScientificFormulaCandidateRegistryV1` (`knowledge/formula_candidates.py`) is a
versioned, **separate** store keyed by `(candidate_id, version)`.

| Operation | Behaviour |
| --- | --- |
| `publish(candidate)` | Validates, then stores. Identical re-publish is idempotent; divergent content on the same version is refused (bump the version). |
| `get(id, version=None)` | Latest version by default. |
| `versions(id)` | Sorted version list. |
| `all_latest()` / `all()` | Latest per id / every stored version. |

Persistence is via `FormulaCandidateRepository` (`formula_candidates` table),
which stores the serialized payload plus a `content_hash`. `load_all_into(registry)`
rebuilds the registry offline.

## Non-operational guarantee

`FormulaCandidate.operational` is always `False`; `validate()` refuses a candidate
that would be operational. The candidate id can never be resolved by the
operational `FormulaRegistry`:

```python
with pytest.raises(KeyError):
    FormulaRegistry().get("SCI-CAND-BMI")
```

`validate()` also enforces: a non-empty id/name; expression validity restricted to
the declared variables; known units for every variable and the output; compilable
refusal conditions; and that a candidate **without any reference or validation
evidence must remain `DRAFT`**.

## Candidate types

`FormulaCandidateType` distinguishes three things that are frequently conflated:

| Type | Meaning |
| --- | --- |
| `ALGEBRAIC_INDEX` | A pure arithmetic index (e.g. BMI). Correctness is arithmetic, not clinical. |
| `PREDICTIVE_EQUATION` | A model that predicts a quantity. |
| `INTERPRETIVE_CRITERION` | A rule that interprets a value (typically via cutoffs). |

A mathematically correct index does **not** imply clinically validated cutoffs.

## Statuses

`FormulaCandidateStatus` (deliberately with **no** "approved for clinical use"):

| Status | Meaning |
| --- | --- |
| `DRAFT` | Definition exists; insufficient grounding. |
| `TECHNICALLY_VALIDATED` | Definition validated technically (math/units), not clinically. |
| `UNDER_SCIENTIFIC_REVIEW` | In the human scientific review queue. |
| `RETIRED` | Withdrawn. |

There is no terminal "clinically approved" state in R2C-A.

```mermaid
stateDiagram-v2
    [*] --> DRAFT
    DRAFT --> TECHNICALLY_VALIDATED
    DRAFT --> UNDER_SCIENTIFIC_REVIEW
    TECHNICALLY_VALIDATED --> UNDER_SCIENTIFIC_REVIEW
    UNDER_SCIENTIFIC_REVIEW --> RETIRED
    DRAFT --> RETIRED
```

## Seeded candidates

The seed (`seed/r2ca_seed.py`) publishes **7** candidates. `measured` denotes
`allowed_semantics = (MEASURED, CLINICIAN_ASSESSED)`; `measured_or_device` adds
`DEVICE_ESTIMATED`.

| ID | Type | Expression | Output | Variables (semantics) | Status |
| --- | --- | --- | --- | --- | --- |
| `SCI-CAND-BMI` | ALGEBRAIC_INDEX | `weight_kg / (height_m * height_m)` | `kg/m^2` | `weight_kg [kg]` (measured), `height_m [m]` (measured) | UNDER_SCIENTIFIC_REVIEW |
| `SCI-CAND-FMI` | ALGEBRAIC_INDEX | `fat_mass_kg / (height_m * height_m)` | `kg/m^2` | `fat_mass_kg [kg]` (measured_or_device), `height_m [m]` (measured) | UNDER_SCIENTIFIC_REVIEW |
| `SCI-CAND-FFMI` | ALGEBRAIC_INDEX | `fat_free_mass_kg / (height_m * height_m)` | `kg/m^2` | `fat_free_mass_kg [kg]` (measured_or_device), `height_m [m]` (measured) | UNDER_SCIENTIFIC_REVIEW |
| `SCI-CAND-WHTR` | ALGEBRAIC_INDEX | `waist_cm / height_cm` | `1` | `waist_cm [cm]` (measured), `height_cm [cm]` (measured) | UNDER_SCIENTIFIC_REVIEW |
| `SCI-CAND-BODY-FAT-PCT` | ALGEBRAIC_INDEX | `100 * fat_mass_kg / weight_kg` | `%` | `fat_mass_kg [kg]` (measured_or_device), `weight_kg [kg]` (measured) | UNDER_SCIENTIFIC_REVIEW |
| `SCI-CAND-BC-LONGITUDINAL` | ALGEBRAIC_INDEX | `followup_value - baseline_value` | `kg` | `baseline_value [kg]`, `followup_value [kg]` (measured) | UNDER_SCIENTIFIC_REVIEW |
| `SCI-CAND-WHTR-CUTOFF-PLACEHOLDER` | INTERPRETIVE_CRITERION | `whtr` | `1` | `whtr [1]` (measured) | DRAFT |

All candidates carry `refusal_conditions` guarding the defined domain (e.g.
`height_m <= 0`, `weight_kg <= 0`), and `output_domain` strings such as
`height_m > 0`. `SCI-CAND-BC-LONGITUDINAL` uses
`temporal_requirement = OTHER_EXPLICIT_RULE`.

### Applicability notes

- `SCI-CAND-BMI`: applicable `ADULT`; not validated `PEDIATRIC`, `PREGNANT`,
  `ATHLETE`, `SEVERE_OBESITY`.
- `SCI-CAND-FMI`: not validated `PEDIATRIC`, `PREGNANT`, `EDEMA_ASCITES`.
- `SCI-CAND-FFMI`: not validated `PEDIATRIC`, `PREGNANT`.
- `SCI-CAND-WHTR`: not validated `PEDIATRIC`, `PREGNANT`.
- `SCI-CAND-BODY-FAT-PCT`: not validated `PREGNANT`, `EDEMA_ASCITES`,
  `HYDRATION_CHANGE`.
- `SCI-CAND-BC-LONGITUDINAL`: not validated `PREGNANT`, `EDEMA_ASCITES`,
  `ACUTE_CONDITION`.
- `SCI-CAND-WHTR-CUTOFF-PLACEHOLDER`: no applicable population; not validated
  `ADULT`, `PEDIATRIC`.

### Limitations (verbatim intent)

- BMI: does not distinguish fat from lean mass; no validated cutoff imported.
- FMI / FFMI: depend on the fat-mass / fat-free-mass estimation method;
  population-specific reference values not imported.
- WHtR: measurement-site variability; no validated cutoff imported.
- Body-fat %: device-estimated inputs propagate uncertainty.
- Longitudinal: change is arithmetic, no efficacy inference.
- Placeholder: **cutoffs are NOT imported as diagnostic criteria**
  (`metadata = {"cutoff_defined": False}`).

## Prototype math is test-only

`knowledge/candidate_math.evaluate_candidate_prototype` exists solely to validate
candidate definitions in tests. It is never wired into clinical synthesis. Its
statuses are values, never silent substitutions: `VALID`, `INSUFFICIENT_INPUT`,
`SEMANTICS_MISMATCH`, `UNIT_INCOMPATIBLE`, `NOT_FINITE`, `DIVISION_BY_ZERO`,
`OUTSIDE_DEFINED_DOMAIN`, `TEMPORALLY_INCOMPATIBLE`,
`APPLICABILITY_NOT_ESTABLISHED`, `NOT_APPLICABLE`. Reference fixtures are
independently computed (BMI `70/1.75^2`, FMI `20/1.75^2`, FFMI `55/1.75^2`,
WHtR `90/175`, BF% `100*20/70`, longitudinal `55-60`).

See also: `R2C_A_INPUT_SEMANTICS.md`, `R2C_A_APPLICABILITY.md`,
`R2C_A_EVIDENCE_LINKS.md`.
