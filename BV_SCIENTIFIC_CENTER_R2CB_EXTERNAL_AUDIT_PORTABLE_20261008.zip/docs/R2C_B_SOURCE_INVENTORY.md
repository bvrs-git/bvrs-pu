# R2C-B GATE 1/2 — Source inventory and content acquisition

Provider: **Europe PMC** (`https://www.ebi.ac.uk/europepmc/webservices/rest`).
Frozen snapshot: `data/seed/europepmc_corpus.json` (generated against the live
provider; replayed offline through the unmodified adapter).

## Acquisition result (the 8 selected references)

| DOI | In Europe PMC | Abstract | Availability | Full text stored |
| --- | --- | --- | --- | --- |
| 10.3928/21650799-20140514-04 | no | — | `SOURCE_UNAVAILABLE` | no |
| 10.3390/ijerph16111920 | yes (PMID 31151245, PMC6603580) | yes | `FULL_TEXT_REUSE_PERMITTED` (cc by) | **yes** |
| 10.1253/circj.cj-10-0583 | yes (PMID 20827026) | no | `FULL_TEXT_ACCESS_RESTRICTED` | no |
| 10.1016/j.clnu.2018.10.010 | yes (PMID 30389251) | yes | `FULL_TEXT_ACCESS_RESTRICTED` | no |
| 10.20960/nh.03161 | yes (PMID 32960624) | yes | `FULL_TEXT_ACCESS_RESTRICTED` | no |
| 10.1097/01823246-199001010-00008 | no | — | `SOURCE_UNAVAILABLE` | no |
| 10.1016/s0899-9007(97)85179-9 | no | — | `SOURCE_UNAVAILABLE` | no |
| 10.1016/s0261-5614(03)80008-0 | no | — | `SOURCE_UNAVAILABLE` | no |

Totals: **3 abstracts acquired**, **1 legally retrieved full text**,
**4 restricted** entries, **4 sources unavailable**. Every reference has a
recorded attempt (availability + provenance), so "unavailable" is explicit and
traceable, never silently empty.

## Why four are unavailable

Europe PMC does not index these four DOIs at all (searched by `DOI:"…"` and by
bare DOI). Crossref has the metadata but no abstract. No content is invented and
no paywall is circumvented; each is recorded as `SOURCE_UNAVAILABLE` with
currency-appropriateness handled by GATE 8.

A title-similar publication (`10.1177/216507991406200608`) exists for the first
DOI, but titles are never used to associate content — the identifiers differ, so
nothing is linked.

## Provenance per acquisition (GATE 2)

Each stored snapshot records: provider, endpoint, query parameters, UTC query
time, requested/returned identifiers, content type, license, availability,
storage decision and note, a SHA-256 of the stored text, and a locator. The
snapshot file itself records the same plus the full-text artifact hash.

Identifier verification happens **before** association: if the returned DOI does
not match the requested DOI, the entry is stored as `SOURCE_UNAVAILABLE` with an
`identifier mismatch` note and no text is associated.
