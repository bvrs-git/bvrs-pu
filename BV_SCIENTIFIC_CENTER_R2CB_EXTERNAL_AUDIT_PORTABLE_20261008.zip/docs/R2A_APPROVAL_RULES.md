# R2A — Approval Rules

Approval is an explicit, human, audited action. It is never automatic, never
inferred from tests, and never available over HTTP.

## Requirements to APPROVE

| Requirement | Enforcement |
| --- | --- |
| Identified reviewer (`actor`) | `require_approval_actor` → `CurationApprovalError` |
| Non-empty justification | `require_approval_actor` → `CurationApprovalError` |
| Legal transition (must be `CURATED`) | `CurationTransitionError` |
| Not SYNTHETIC_TEST origin | `EvidenceGovernanceError` |
| Reference: verified metadata **and** stable identifier | `ScientificReference.can_approve()` |
| Evidence: has at least one reference, not retracted | `ScientificEvidence.validate()` |
| Claim: has at least one favorable evidence id | `ClinicalClaim.validate()` |
| Package APPROVED: author + reviewer present, not synthetic | `KnowledgePackage.validate()` |

## No automatic approval (GATE 2)

* Applying methodological criteria only produces a **suggestion**
  (`methodology.suggest_assessment`) with `auto_certainty=False`.
* GRADE is never assigned from the study type alone; certainty requires a named
  human assessor (`MethodologicalAssessment.validate`).
* Automated tests never grant approval; synthetic content can never be APPROVED.

## HTTP is read-only (GATE 6)

* The UI exposes references, evidence, links and curation history **read-only**.
* There is no approval route: `/knowledge/reference/<id>/approve` and
  `/knowledge/curation/approve` return 404; `POST` returns 501.
* Localhost is **not** treated as authentication (documented explicitly in the UI).
* Approval happens only through the explicit local administrative flow:

```
python -m bv_scientific_center curate \
  --subject reference --id REF-... --action approve \
  --actor reviewer-1 --justification "eligible after curation review"
```

Each administrative action prints the resulting `CurationOutcome` (status,
version, actor, justification, timestamp) and is persisted in `curation_events`.

## Retraction

`--action retract --reason "..."` — a reason is mandatory. Retracted records are not
clinically usable and their dependent claims are surfaced for re-curation.
