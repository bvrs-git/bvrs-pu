# R1.1 — Residual Risks

Risks that remain after R1.1. None blocks certification; each is bounded and has a
mitigation or an explicit R2 owner.

| # | Risk | Impact | Mitigation / status |
| --- | --- | --- | --- |
| R-1 | `reproduce_run` recomputes with new ids (by design); only `rebuild_run` is deterministic | A map built from recomputation differs in node ids | Documented; UI uses `rebuild_run` for completed stored runs; recompute is used only for ad-hoc analysis |
| R-2 | Prototype UI has **no authentication** | If bound to a non-loopback interface it would expose clinical data | Server defaults to `127.0.0.1`; operator must not change the host; R2 to add auth before any exposure |
| R-3 | Persistence is not a single atomic transaction across both DBs | A crash during write could leave observations without a matching run row | Computation happens before persistence; ingest/compute failures are recorded as `FAILED`; a crash *during* the write phase is not yet wrapped — R2 to wrap persistence in a transaction or add a run-in-progress marker |
| R-4 | Legacy rows from pre-R1.1 DBs have `ingested_at = NULL` | `ingested_at` falls back to `created_at` for those rows | Additive migration; new ingests always populate `ingested_at` |
| R-5 | Synthetic formulas/scores/rules and knowledge fixtures are architecture tests | Could be mistaken for clinical content | All marked `SYNTHETIC`/`TEST_RULE`/`origin=SYNTHETIC_TEST`; synthetic knowledge can never be `APPROVED`; no clinical validation is claimed |
| R-6 | Observation identity uses a natural key; if a source mutates a value for the same key, `INSERT OR REPLACE` replaces it | Prior value not retained in the observation row | `source_version` is preserved; R2 to add a source-revision audit table if required |
| R-7 | FTS search is lexical (FTS5) with a `LIKE` fallback; no semantics | Recall depends on wording | Raw citation DB remains source of truth; embeddings planned as an **index only** (R2) |
| R-8 | Naive datetimes are assumed UTC | Mis-tagged local times could shift alignment | Documented convention; source modules must send offsets |
| R-9 | SQLite single connection shared by the threaded HTTP server (`check_same_thread=False`) | Concurrent writes could contend under load | Prototype/loopback usage; R2 to add WAL + per-request handling if the UI is scaled |
| R-10 | No inferential statistics on N-of-1 series | Risk of over-claiming from co-trends | `correlation_series` is explicitly `CO_VARIATION_EXPLORATION`, `causality_claimed=false`, no statistical claim |
| R-11 | No production AI reasoning | “Synthesis” is rule-based only | AI boundary labels output `AI_DRAFT`/`AI_SUGGESTION`; never auto-confirms |
| R-12 | Knowledge approval relies on human curation quality | Weak curation could admit weak evidence | Citation gate + origin separation; evidence-strength fields are optional and never auto-filled |

## Explicitly out of scope (unchanged)

No real patients; no BV Clinical modification; no automatic GPT Work connection; no
Patient Area publication; no automatic diagnosis; no third-party runtime
dependencies.
