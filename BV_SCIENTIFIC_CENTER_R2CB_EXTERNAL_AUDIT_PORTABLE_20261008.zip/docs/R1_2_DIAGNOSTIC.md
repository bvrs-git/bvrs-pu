# R1.2 — Initial Diagnostic

**Scope:** transactional integrity, observation identity and provenance.
**Nature:** hardening only. No R2 scientific features were started.
**Result:** `BV_SCIENTIFIC_CENTER_R1_2_STATUS = PASS`

## Environment

| Item | Value |
| --- | --- |
| Python | 3.14.6 |
| SQLite | 3.50.4 (stdlib `sqlite3`, FTS5 available) |
| Runtime deps | standard library only |
| Test runner | pytest 9.1.1 |

## GATE 1 — Baseline revalidation

* `python -m pytest` → **108 passed** at the start of R1.2 (no regression from R1.1).
* `python -m compileall src` → OK.
* Schemas present: `knowledge.db` (items/claims/references/packages/fts),
  `derived.db` (observations/derived_metrics/score_results/signals/signal_reviews/
  synthesis_runs/annotations/pins/events).
* Public contracts intact (see `R1_1_CONTRACTS_INVENTORY.md`).
* Documentation divergence reconciled: the R1.1 devolutiva stated “8 new test
  files”; the correct count is **9**. `R1_1_CHANGES.md` was corrected (the R1.1
  test matrix already listed nine).

## Findings audited in this phase

| # | Area | Finding | Severity | Resolution |
| --- | --- | --- | --- | --- |
| T1 | Identity | `observations` used `INSERT OR REPLACE`, so a divergent re-send silently overwrote value/provenance/`created_at` | High | Controlled UPSERT with semantic verification |
| T2 | Identity | `created_at` was reset on every `knowledge_items` update | Medium | Original timestamps preserved on update |
| T3 | Transactions | Synthesis writes were individually committed; a mid-cycle failure could leave partial rows | High | Single `BEGIN IMMEDIATE … COMMIT` per run |
| T4 | Temporal | Naive timestamps were silently assumed UTC at the clinical boundary | Medium | `parse_clinical_dt` rejects naive input (`NaiveTimestampError`) |
| T5 | Temporal | Legacy rows with unknown `ingested_at` were back-filled from `created_at` | Low | Kept `NULL`/UNKNOWN explicitly |
| T6 | Concurrency | No explicit `busy_timeout`/WAL; write methods not serialized on the shared connection | Medium | `busy_timeout`, WAL, per-database write lock |
| T7 | Reproducibility | Execution identity and logical (content) identity were not distinguished | Low | `SynthesisRunResult.logical_fingerprint()` |

## Pre-change safeguard (schema safety)

Before any schema-affecting work, an integral copy of the synthetic databases in
use was preserved. Procedure:

```
# 1. materialize the synthetic DBs (persistent, not memory)
PYTHONPATH=src python -m bv_scientific_center report
# 2. copy both databases to a timestamped backup directory
python -c "import shutil,datetime,pathlib; d=pathlib.Path('data/runtime'); \
b=d/('backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')); b.mkdir(parents=True,exist_ok=True); \
[shutil.copy2(d/n, b/n) for n in ('knowledge.db','derived.db')]"
```

Result: `data/runtime/backup_20261007_234344/{knowledge.db,derived.db}` (integral,
`shutil.copy2`). The backup is retained; it is outside version control
(`data/runtime/` is git-ignored).

## Constraints honored

No changes to BV Clinical / BV Bot; no real patient data; no Git init/commits/tags;
no runtime dependencies added; no destructive migrations (only additive
`ALTER TABLE ADD COLUMN`); no public contract broken; no assumed dates, units,
identities or clinical authorities.
