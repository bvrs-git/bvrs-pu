# R1.1 — Suggested Plan for R2

> Proposal only. No R2 work was started. Items are ordered by risk reduction first,
> then capability.

## A. Governance and scientific curation (highest priority)

1. **Knowledge package pipeline.** GPT Work → structured extraction draft →
   `KnowledgePackage` → human review → approved import → activation. Enforce that
   AI-produced content enters as `origin=IMPORTED` in `DRAFT`/`IN_REVIEW` and can
   only become `APPROVED`/`CURATED` through an explicit reviewer action.
2. **Review workflow for items and claims.** Reviewer identity, timestamps, and a
   status transition log per `ScientificClaim`; block approval without citation
   metadata (already enforced) and without a reviewer.
3. **Evidence-strength ingestion.** Populate `evidence_framework`/`evidence_grade`/
   `certainty` only when a source package supplies them; never infer grades.

## B. Formula and rule library

4. **Validated formula set** (each with exact definition, units, assumptions and
   test cases): extend beyond the synthetic set. Keep the draft → validation →
   version → activation workflow; formulas only become `VALIDATED_FOR_USE` after
   tests and review.
5. **Formula/rule diffing.** When a new version is published, produce an
   evaluation diff on synthetic + regression patients before activation.
6. **Signal recomputation runs** that never rewrite history: new `SynthesisRun`
   with `SUPERSEDED` handling for prior signals.

## C. Clinical map and synthesis UX

7. **Temporal map UI**: view the map at TODAY / LAST_CONSULTATION / a specific date
   (builder already supports `as_of`).
8. **Before/After comparison UI** over the existing `compare` service, labelled as
   mathematical change only.
9. **Correlation explorer UI** over the existing `correlation_series` service, with
   the “co-variation, not causation” framing.

## D. Interoperability

10. **Stable JSON contracts** for `ClinicalMapProjectionV1` and inbound projections
    (serialization already exists; add a versioned HTTP/JSON surface).
11. **Promotion-to-Prontuário workflow**: a clinician-reviewable draft
    (already modeled) exposed through a versioned contract; never an automatic
    diagnosis insert.
12. **Consumer of reviewed signals** for the future Clinical Bot, restricted to
    `ACCEPTED`/`REVIEWED` signals, not every internal calculation.

## E. Search and knowledge access

13. **Embeddings as an index only** (raw citation DB stays authoritative); semantic
    search augments, never replaces, FTS.
14. **Biomarker/condition/topic facets** and “related formulas/biomarkers/rules”
    enrichment.

## F. Platform hardening

15. **Transactional persistence** across the write phase; optional SQLite WAL.
16. **Authentication** before any non-loopback UI exposure.
17. **Audit log surfacing** (events table) in the UI and export.
18. **Concurrency review** for the threaded UI if usage grows.

## Non-goals for R2 (unless explicitly re-scoped)

No real patient data; no merge into BV Clinical; no automatic diagnosis; no
automatic AI clinical reasoning replacing clinician judgment; no copyrighted
bibliography auto-import.
