# R2C-B — Architecture (Real scientific content, extraction and medical dossiers)

## Scope

R2C-B moves the eight already-selected references from `METADATA_ONLY` to
documentally verifiable evidence: abstracts and (where the license permits)
full text are acquired, stored with per-field provenance, and prepared as
medical dossiers. It does **not** expand the formula catalogue, activate any
clinical calculation, create executable scores, or integrate with BV Clinical /
BV Bot.

## Principles

1. **Identify → verify metadata → appraise content → approve** are four
   independent operations; none implies another.
2. **Access ≠ storage permission.** A license that permits reading does not
   permit storing or redistributing the full text.
3. **Automated extraction is not human review.** Extracted fields are
   `EXTRACTED_UNVERIFIED` and each carries the verbatim source span and the
   SHA-256 of the consulted source.
4. **Missing is not zero.** Fields not grounded in the consulted text are
   `INSUFFICIENT_INFORMATION` with an explicit reason; nothing is invented.

## Modules

| Module | Responsibility |
| --- | --- |
| `bibliography/europepmc.py` | Europe PMC adapter (search/fetch/full text) |
| `bibliography/content.py` | Availability + license classification, `ContentSnapshot` |
| `bibliography/snapshot.py` | Frozen snapshot generation + offline replay transport |
| `bibliography/service.py` | `acquire_content`: identifier verification, licensing, persistence |
| `knowledge/content_repository.py` | `AcquiredContentRepository`, `ContentExtractionRepository`, `ReviewDecisionRepository`, `EditorialCheckRepository` |
| `knowledge/extraction.py` | Conservative, citation-grounded field extraction |
| `seed/r2ca_seed.py` | The 7 candidates and 8 selected DOIs |
| `app.py` | `bootstrap_r2cb`, `extract_reference`, `dossier_index`, `export_dossier`, `body_composition_sheet`, `formula_evidence_matrix`, `applicability_matrix`, `check_currency`, `reconciliation`, `record_review_decision` |
| `__main__.py` | CLI: `extract`, `reconcile`, `medical-dossier`, `dossier-index`, `review-decision`, `formula-evidence`, `applicability`, `freeze-content` |
| `ui/server.py`, `ui/render.py` | Read-only `/knowledge/dossiers`, `/knowledge/dossier/<id>` |

## Data flow

```mermaid
graph TD
    DOI[Selected DOI] --> EPMC[Europe PMC adapter]
    EPMC --> VERIFY{Identifier matches?}
    VERIFY -- no --> UNAV[SOURCE_UNAVAILABLE]
    VERIFY -- yes --> AVAIL[Availability + license decision]
    AVAIL --> ABS[Abstract snapshot]
    AVAIL -- permissive license --> FT[Full-text snapshot]
    ABS --> EXTR[Extraction r2cb-2]
    EXTR --> DOSSIER[Medical dossier]
    UNAVAIL --> DOSSIER
    DOSSIER --> REVIEW[Human review queue]
    REVIEW -.never automatic.-> DECISION[Recorded decision, not executed]
```

## Offline reproducibility

`data/seed/europepmc_corpus.json` freezes the raw Europe PMC `core` records and
the query provenance. The frozen full text (only for `cc by`) lives in
`data/seed/europepmc_fulltext/`. `EuropePmcSnapshotAdapter` replays the snapshot
through the **unmodified** adapter/service code, so offline tests exercise the
same identification, licensing and provenance logic as a live acquisition.
