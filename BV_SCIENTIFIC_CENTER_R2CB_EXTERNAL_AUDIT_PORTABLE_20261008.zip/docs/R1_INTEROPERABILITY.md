# R1 — Interoperability

The Scientific Center integrates with the rest of the BV Suite through **versioned
contracts**. Data enters as projection DTOs and leaves as projections; there is no
shared database and no shared ORM. This keeps the module independently
deployable and the integration surface explicit.

## Inbound projections — `contracts/inputs.py`

Every inbound DTO is a dataclass. `ProjectionBase` supplies the common header
`patient_id`, `source_module`, `source_entity_type`, `source_entity_id`,
`source_version` and `header()`; subclasses fix `source_module` /
`source_entity_type` defaults and add payload fields. `LabObservationProjection`
also exposes `provenance()`. All DTOs provide `from_dict(data)`.

| Projection | `source_module` | Key payload fields |
| --- | --- | --- |
| `LabObservationProjection` | `LAB` | `concept`, `value`, `unit`, `effective_at`, `authority` (default `LAB_CONFIRMED`), `method`, `matrix`, `laboratory`, `collection_at`, `fasting_status`, `context` |
| `BioimpedanceSummaryProjection` | `BIOIMPEDANCE` | `effective_at`, `authority`, `measurements` (`BioimpedanceMeasurement`: `concept`, `value`, `unit`), `device`, `method` |
| `NutritionAssessmentProjection` | `NUTROLOGIA` | `effective_at`, `authority` (default `CLINICIAN_CONFIRMED`), `energy_target_kcal`, `protein_target_g`, `notes` |
| `IntegrativeIntakeSummary` | `INTEGRATIVA` | `effective_at`, `authority` (default `PATIENT_REPORTED`), `responses` (`IntegrativeResponse`: `question_code`, `domain`, `value`, `unit`) |
| `PatientReportedFact` | `PATIENT_AREA` | `concept`, `value`, `unit` (default `"1"`), `effective_at`, `authority` (default `PATIENT_REPORTED`) |
| `DiagnosisSummaryProjection` | `PRONTUARIO` | `code`, `label`, `status` (default `ACTIVE`), `confirmed_at`, `authority` (default `CLINICIAN_CONFIRMED`) |
| `MedicationSummaryProjection` | `PRONTUARIO` | `name`, `dose`, `unit`, `frequency`, `started_at`, `stopped_at`, `authority` (default `CLINICIAN_CONFIRMED`) |
| `PatientContextProjection` | `CONTEXT` | `sex`, `age_years`, `population`, `on_hormone_therapy`, `contraception`, `menopause`, `menstrual_phase`, `extra` |
| `PregnancyContextProjection` | `GESTANTES` | `is_pregnant`, `gestational_age_weeks`, `authority` (default `CLINICIAN_CONFIRMED`) |
| `PediatricContextProjection` | `PEDIATRIA` | `is_pediatric`, `age_years`, `authority` (default `CLINICIAN_CONFIRMED`) |

The context projections (`PatientContext`, `PregnancyContext`, `PediatricContext`)
are **not** ingested as observations. They are mapped into an `EvaluationContext`
via `EvaluationContext.from_patient_context(...)`, `with_pregnancy(...)` and
`with_pediatric(...)`; context is always supplied, never inferred. Unrecognised
enum values degrade gracefully to `UNKNOWN`.

`ProjectionIngestor` (`observations/refs.py`) converts the observation-bearing
projections above into `ScientificObservationRef`s (see
`R1_DATA_OWNERSHIP.md` for the mapping table). An unsupported type raises
`ContractViolation`.

## Concept codes — `core/concepts.py`

Inputs and formulas are keyed by **concept**, not by any source module's column
names. This is what decouples the module from BV Clinical persistence and makes
the knowledge repository portable. Codes are grouped by area:

* Glycemic / metabolic: `GLUCOSE_FASTING`, `INSULIN_FASTING`, `HBA1C`, `HOMA_IR`
* Lipid: `TOTAL_CHOLESTEROL`, `HDL_CHOLESTEROL`, `LDL_CHOLESTEROL`,
  `TRIGLYCERIDES`, `NON_HDL_CHOLESTEROL`, `REMNANT_CHOLESTEROL`
* Inflammatory: `C_REACTIVE_PROTEIN`, `NEUTROPHILS_ABSOLUTE`,
  `LYMPHOCYTES_ABSOLUTE`, `PLATELETS`
* Thyroid: `TSH`, `FREE_T4`
* Adrenal / gonadal: `DHEAS`, `CORTISOL`, `TESTOSTERONE_TOTAL`, `ESTRADIOL`, `SHBG`
* Micronutrient: `VITAMIN_D_25OH`, `SELENIUM`, `VITAMIN_B12`, `FERRITIN`
* Body composition: `WEIGHT`, `HEIGHT`, `BMI`, `BODY_FAT_PERCENT`, `FAT_MASS`,
  `FAT_FREE_MASS`, `SKELETAL_MUSCLE_MASS`, `WAIST_CIRCUMFERENCE`, `FFMI`, `FMI`,
  `WAIST_HEIGHT_RATIO`
* Derived ratios: `TESTOSTERONE_ESTRADIOL_RATIO`, `TRIGLYCERIDE_HDL_RATIO`,
  `NEUTROPHIL_LYMPHOCYTE_RATIO`, `PLATELET_LYMPHOCYTE_RATIO`,
  `DHEA_CORTISOL_RATIO`
* Nutrition: `ENERGY_TARGET`, `PROTEIN_TARGET`, `PROTEIN_INTAKE`
* Reported / questionnaire domains: `SLEEP_QUALITY`, `ENERGY_LEVEL`,
  `GI_SYMPTOMS`, `STRESS_LEVEL`, `LIBIDO`
* Lifestyle: `PHYSICAL_ACTIVITY_MIN_WEEK`, `ALCOHOL_UNITS_WEEK`, `SMOKING_STATUS`

## Outbound projection — `contracts/outputs.py`

`ClinicalMapProjectionV1` is the versioned outbound contract
(`contract_version = "ClinicalMapProjectionV1"`). It is produced by
`ClinicalMapBuilder.build(...)` and validated by `validate_projection` before it
leaves the module. `to_dict()` serializes it via `core.serialization.dump`.

* `metadata: ClinicalMapMetadata` — `patient_id`, `generation_time`,
  `rule_versions`, `formula_versions`, `score_versions`,
  `knowledge_package_version`, `run_id`, `window_start`, `window_end`,
  `temporal_mode`, `layers_enabled`.
* `nodes: list[MapNodeProjection]` — `node_id`, `node_type` (`NodeType`), `layer`
  (`MapLayer`), `label`, `authority`, `domain`, `value`, `unit`, `effective_at`,
  `provenance`, `metadata`.
* `edges: list[MapEdgeProjection]` — `edge_id`, `source_node_id`,
  `target_node_id`, `relation` (`EdgeType`), `layer`, `provenance`, `metadata`.
  `why_connected()` returns a non-opaque explanation (relation, causality flag,
  rule id/version, evidence refs, explanation).

`Provenance` is the traceability record. `is_traceable()` is true when at least
one of `source_ref`, `formula_id`, `score_id`, `rule_id` or `annotation_id` is
set; `validate_projection` rejects any orphan node or edge whose endpoints are
missing. `CAUSAL_MODEL_SUPPORTED` is the only causal `EdgeType`; all others are in
`NON_CAUSAL_EDGE_TYPES`.

## Domain events — `events/bus.py`

`EventBus` is an in-process publish/subscribe bus. Only the events in
`EVENT_TYPES` may be published (an unknown type raises `ValueError`):

| Event | Emitted when |
| --- | --- |
| `DerivedMetricComputed` | A valid derived metric is produced during a run |
| `ClinicalSignalGenerated` | A rule matches and emits a signal candidate |
| `ClinicalSignalReviewed` | A clinician reviews/accepts/dismisses a signal |
| `KnowledgePackageActivated` | A knowledge package is activated |
| `SynthesisRunCompleted` | A synthesis run finishes |

`ScientificCenterApp` records every event into the `events` table via
`_record_event`. Map rendering is a pure projection and is deliberately **not**
published as an event.

## Future BV Suite integration

Integration stays behind the versioned contracts:

* Consumers publish the projection DTOs above; the module never reaches into their
  storage. New source fields are additive (extra metadata dicts), and enums
  degrade to `UNKNOWN`.
* The Clinical Center publishes `ClinicalMapProjectionV1` and the event types
  above. A future Prontuário integration consumes reviewed signals and the
  clinician-reviewable promotion draft (`build_prontuario_promotion_draft`), which
  is explicitly `creates_diagnosis_automatically: False` and
  `requires_clinician_review: True`.
* Knowledge content evolves through importable, versioned `KnowledgePackage`s,
  independent of application code.

R1 does **not** implement these consumer integrations; it defines the contracts
they will use.
