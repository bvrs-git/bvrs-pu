# R1.1 — Scientific and Temporal Provenance Findings

Answers the GATE 2 questions: can every derived result be traced to its inputs,
sources, versions, units, and time context — with clinical time clearly separated
from registration time?

## Provenance chain (after R1.1)

```
source module projection
   -> ScientificObservationRef
        effective_at   (clinical / collection time)
        ingested_at    (registration into Scientific Center)
        source_module / source_entity_type / source_entity_id / source_version
        authority      (confirmation state)
        unit + value (nullable; missing never becomes 0)
   -> compute_metric(formula, ...)
        input_refs          (per-input snapshot incl. both dates)
        input_resolutions   (original value+unit, normalized value+unit, conversion ref)
        metric_definition_id / _version / formula_snapshot
        effective_at (metric anchor) + computed_at (execution moment)
        calculation_status + refusal_reason (+ warnings)
```

## F1 — Ingestion date was not recorded (FIXED)

**Finding (probe A):** `ScientificObservationRef.snapshot()` exposed only the
clinical date; there was no ingestion/registration timestamp, so the derived
metric could not distinguish when a value was measured from when it entered the
system.

**Regression test:** `tests/test_provenance.py`
(`test_observation_ref_carries_both_dates`,
`test_derived_metric_records_clinical_and_ingestion_dates`).

**Fix:** `ingested_at` added to `ScientificObservationRef`, `snapshot()`, the
`observations` table (additive migration), and the repository read path (legacy
rows fall back to `created_at`). `metric.computed_at` remains the execution
moment.

## F2 — Duplicate observation ingestion (FIXED)

**Finding (probe B):** re-ingesting identical projections duplicated rows
(23 → 46 observations).

**Regression test:** `tests/test_idempotency.py`.

**Fix:** deterministic `observation_ref_id` from the source natural key
(`patient_id, source_module, source_entity_type, source_entity_id, source_version,
concept, effective_at`) plus `INSERT OR REPLACE`.

## F4 — Non-deterministic reconstruction (FIXED)

**Finding (probe D):** rebuilding a stored run recomputed metrics with new random
ids, so the rebuilt clinical map had different node ids (symmetric difference 22).

**Regression test:** `tests/test_determinism.py`.

**Fix:** `SynthesisRunner.reconstruct_run` rebuilds from persisted state
(`synthesis_runs.input_snapshot` ids + stored `derived_metrics`/`score_results`/
`signals`), and `ScientificCenterApp.rebuild_run(patient_id, run_id)` exposes it.
The UI map route now prefers `rebuild_run`, falling back to recomputation only when
no completed run exists. Node ids are therefore stable for a stored run.

## Temporal findings

* **Cross-domain alignment:** formulas declare a `TemporalRequirement`
  (`SAME_COLLECTION`, `SAME_DAY`, `WITHIN_N_DAYS`, `LATEST_AVAILABLE`,
  `OTHER_EXPLICIT_RULE`). Distant inputs are refused
  (`TEMPORALLY_INCOMPATIBLE`) — `tests/test_formula_engine.py`,
  `tests/test_calculation_safety.py`.
* **`as_of` / future dates:** the map builder excludes nodes beyond `as_of`;
  `tests/test_calculation_safety.py::test_future_dated_observation_excluded_by_as_of`.
* **Deterministic selection:** with multiple candidates, selection is authority
  filter → unit filter → alignment (latest or best-aligned set); repeated
  computations yield identical results
  (`test_latest_available_is_deterministic`,
  `test_confirmed_source_wins_over_unconfirmed`).
* **Re-execution:** each run is a new immutable record; history is never
  rewritten (`tests/test_synthesis_run.py::test_rerun_is_a_new_run_not_a_rewrite`).

## Authority

`ObservationAuthority` distinguishes confirmed sources from document-extracted
unreviewed / reported / unknown ones. Formulas and rules that declare
`requires_confirmed_source` refuse with `SOURCE_UNCONFIRMED` when only unconfirmed
sources exist; authority is never inferred. Evidence:
`tests/test_formula_engine.py::test_unconfirmed_source_refuses`,
`tests/test_calculation_safety.py::test_confirmed_source_wins_over_unconfirmed`.

## Provenance of the clinical map

Every node/edge is traceable to a source ref, a formula, a score, a rule or an
explicit annotation; `validate_projection` rejects orphans
(`tests/test_clinical_map.py`). Edges are typed and non-causal by default.

## Verdict

`SCIENTIFIC_PROVENANCE = PASS`
`TEMPORAL_PROVENANCE = PASS`
`SOURCE_AUTHORITY = PASS`
