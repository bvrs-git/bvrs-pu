# R2C-B GATE 7 — Medical dossier index

`app.dossier_index()` (CLI `python -m bv_scientific_center dossier-index`) and the
read-only UI at `/knowledge/dossiers`. Each publication also has a full dossier
in JSON (`medical-dossier --format json`) and Markdown (`--format md`).

| # | DOI | Abstract | Extraction | Availability | Pending fields |
| --- | --- | --- | --- | --- | --- |
| 1 | 10.3928/21650799-20140514-04 | no | no | SOURCE_UNAVAILABLE | all |
| 2 | 10.3390/ijerph16111920 | yes | yes | FULL_TEXT_REUSE_PERMITTED | 5 |
| 3 | 10.1253/circj.cj-10-0583 | no | no | FULL_TEXT_ACCESS_RESTRICTED | all |
| 4 | 10.1016/j.clnu.2018.10.010 | yes | yes | FULL_TEXT_ACCESS_RESTRICTED | 5 |
| 5 | 10.20960/nh.03161 | yes | yes | FULL_TEXT_ACCESS_RESTRICTED | 5 |
| 6 | 10.1097/01823246-199001010-00008 | no | no | SOURCE_UNAVAILABLE | all |
| 7 | 10.1016/s0899-9007(97)85179-9 | no | no | SOURCE_UNAVAILABLE | all |
| 8 | 10.1016/s0261-5614(03)80008-0 | no | no | SOURCE_UNAVAILABLE | all |

## Dossier contents

Each dossier has: reference and identifiers; editorial state; content effectively
accessed (type, source, availability, license, SHA-256, storage decision,
locator); structured extraction (value + provenance + locator + verbatim span);
body-composition methodology sheet; editorial alerts; linked formula candidates;
unverified/pending fields; the prepared (non-executed) medical decision form; and
the history of recorded decisions.

## Medical decision form (prepared, never executed)

Allowed decisions: `ACCEPT_FOR_CONSIDERATION`, `REQUEST_REVISION`, `REJECT`,
`KEEP_PENDING`. A decision requires a declared **actor** and a **justification**
(enforced in `ReviewDecisionRepository.record`). The system records the decision
and never executes it; accepting a reference for consideration does **not**
approve any formula for clinical use.

## Security

- HTTP is **read-only** for dossiers. There is no decision/approval route; such
  paths return 404 (regression-tested).
- A local reviewer string is a declaration, **not authentication**.
- Decisions are recorded only through the local CLI administrative action.

## Current state

**0 human critical reviews, 0 approvals.** All 8 dossiers are prepared and
pending human review. Technical readiness ≠ clinical approval.
