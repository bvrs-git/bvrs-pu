# R2A — Compatibility

## Baseline

* R1 (68), R1.1 (108) and R1.2 (137) tests all preserved.
* R2A total: **204 tests, all passing** (137 + 67 new).
* `python -m compileall src` = OK.
* Runtime dependencies: Python standard library only.

## Schema

* New tables are created **additively** (`CREATE TABLE IF NOT EXISTS` in
  `storage/schema.py`): `scientific_references`, `scientific_evidence`,
  `clinical_claims`, `evidence_links`, `curation_events`, `reference_fts`,
  `evidence_fts`.
* No column dropped, no table rewritten, no destructive migration. Existing
  databases open unchanged and gain the new tables.
* `derived.db` schema is unchanged in R2A.

## Public contracts

* No existing type, function, repository method, route or CLI command was removed
  or renamed.
* `KnowledgeReference`, `ScientificClaim`, `KnowledgeRepository`,
  `PackageRepository` remain available (existing tests unchanged).
* `KnowledgePackage` gained **optional** fields with defaults
  (`author`, `reviewer`, `provenance`, `dependencies`, `revision_history`,
  `origin`, `scientific_reference_ids`, `evidence_ids`, `claim_ids`); `from_dict`
  tolerates payloads without them.
* `SynthesisRunner` still accepts its previous arguments.

## Clinical behavior

* No clinical calculation was changed. Formula expressions, score bands and rule
  logic are untouched; evidence links never mutate a calculation.
* Historical syntheses reconstruct to the same logical fingerprint before and
  after scientific curation (`test_historical_reconstruction_after_scientific_review`).

## Isolation

* Scientific knowledge lives in `knowledge.db`; scientific tables contain no
  `patient_id` column and never store patient data.
* Patient-derived synthesis remains in `derived.db`.
* No cross-database atomicity is assumed.

## Additive API surface introduced

* `ScientificCenterApp`: `ingest_reference`, `register_evidence`, `register_claim`,
  `link_evidence`, `curation_dashboard`, `scientific_search_references`,
  `reference_view`, `methodology_taxonomy`, `retraction_impacts`,
  `bootstrap_scientific`.
* UI routes: `/knowledge/references`, `/knowledge/reference/<id>`,
  `/knowledge/curation` (read-only).
* CLI: `backup`, `curate` (local administrative flow).
