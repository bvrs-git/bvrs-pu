# R1 — Clinical Rule Engine and Signals

The rule engine turns **declarative** rules into explainable signal
**candidates**. A rule contains no executable code: its conditions are
constrained boolean expressions evaluated by the sandbox in
`core/expression.py`. A signal is a candidate for clinician attention — it is
**not** a diagnostic hypothesis and **never** a diagnosis.

Module layout:

| Path | Responsibility |
| --- | --- |
| `rules/definition.py` | `RuleInput`, `RuleSeverityEscalation`, `ScientificClinicalRule` |
| `rules/registry.py` | `validate_rule`, `RuleRegistry` |
| `rules/engine.py` | `evaluate_rule`, `RuleCandidate`, `RuleEvaluation` |
| `rules/signals.py` | `ClinicalSignalCandidate`, `SignalReview` |

---

## 1. Definition model

### `RuleInput`

| Field | Type | Default | Meaning |
| --- | --- | --- | --- |
| `name` | `str` | — | Condition variable name |
| `ref` | `str` | `name` | Concept code (observation) or metric definition id |
| `source` | `str` | `OBSERVATION` | `OBSERVATION` or `DERIVED_METRIC` |
| `required_unit` | `str` | `"1"` | Unit the condition expects |
| `required` | `bool` | `True` | Missing input skips the rule when required |
| `requires_confirmed_source` | `bool` | `False` | Restrict to confirmed authorities |
| `label` | `str \| None` | `None` | Human-readable label |

### `RuleSeverityEscalation`

| Field | Type | Meaning |
| --- | --- | --- |
| `expression` | `str` | Sandbox boolean over the resolved input variables |
| `severity` | `Severity` | Severity to apply when the expression is true |

### `ScientificClinicalRule`

Extends `VersionedDefinition`.

| Field | Type | Default |
| --- | --- | --- |
| `inputs` | `tuple[RuleInput, ...]` | `()` |
| `conditions` | `tuple[str, ...]` | `()` |
| `combine` | `str` | `"ALL"` (`ALL` \| `ANY`) |
| `signal_type` | `SignalType` | `OBSERVATION_FLAG` |
| `severity` | `Severity` | `INFO` |
| `severity_escalations` | `tuple[RuleSeverityEscalation, ...]` | `()` |
| `explanation_template` | `str` | `""` |
| `category` | `str` | `""` |
| `domain` | `str \| None` | `None` |
| `temporal_requirement` | `TemporalRequirement` | `LATEST_AVAILABLE` |
| `temporal_window_days` | `int \| None` | `None` |
| `population_constraints` | `dict[str, list[str]]` | `{}` |
| `interpretation_warning` | `str \| None` | `None` |
| `tags` | `tuple[str, ...]` | `()` |
| `test_rule` | `bool` | `False` |

`SignalType` values: `OBSERVATION_FLAG`, `TREND_FLAG`, `COMBINATION_FLAG`,
`CONTEXT_WARNING`, `SYNTHESIS_HINT`. `Severity` values: `INFO`, `LOW`,
`MODERATE`, `HIGH`. `test_rule=True` marks synthetic / architecture-validation
rules.

---

## 2. Declarative condition model and `combine` semantics

- Each string in `conditions` is compiled by the sandbox and evaluated to a
  boolean over the resolved, unit-normalized input variables.
- `combine="ALL"` matches when **all** conditions are true.
- `combine="ANY"` matches when **at least one** condition is true.

```mermaid
flowchart TD
    C1[condition 1] --> M{combine}
    C2[condition 2] --> M
    C3[condition N] --> M
    M -- ALL --> A[matched iff all true]
    M -- ANY --> B[matched iff any true]
```

---

## 3. Publication validation — `validate_rule`

- `definition_id` must be non-empty;
- `combine` must be `ALL` or `ANY`;
- at least one `condition` must be declared;
- every condition compiles and references only declared input names;
- every severity-escalation expression compiles;
- every input `source` must be `OBSERVATION` or `DERIVED_METRIC`;
- every input `required_unit` must be known;
- `WITHIN_N_DAYS` requires a positive `temporal_window_days`.

For example, a condition referencing an undeclared input such as
`"unknown_input > 1"` is rejected at publish time with `ExpressionError`.

---

## 4. Input resolution (including `DERIVED_METRIC` inputs)

`evaluate_rule(rule, *, patient_id, observations_by_concept=None,
metrics_by_definition=None, context=None, generated_at=None, run_id=None)`
resolves each `RuleInput`:

- **`OBSERVATION`** — reads `observations_by_concept[ref]`, keeping only
  observations whose `value is not None`.
- **`DERIVED_METRIC`** — reads `metrics_by_definition[ref]`, keeping only
  metrics that are `is_valid` with a non-`None` value. The metric is wrapped as
  a `RuleCandidate` whose `concept` is the metric definition id and whose
  `is_confirmed` is `False` — **a derived metric is never a confirmed source**,
  so such an input cannot satisfy `requires_confirmed_source`.

Every candidate then passes the same safety gates as the formula engine:

1. `requires_confirmed_source` filters out non-confirmed authorities;
2. unit compatibility (`same_dimension` against `required_unit`) filters out
   candidates that cannot be expressed in the declared unit;
3. a required input with no surviving candidate marks the rule unevaluated
   (`evaluated=False`, `matched=False`, `reason="missing required input(s): ..."`)
   without raising;
4. temporal alignment (`formulas.alignment.align_inputs`) selects one candidate
   per input, or the rule is skipped with the aligner's reason. `RuleCandidate`
   duck-types the `effective_at`, `source_entity_id` and `source_module` fields
   the aligner needs;
5. each chosen value is converted with `core.units.convert` to the declared unit
   (a conversion adds a `UNIT_CONVERSION_APPLIED` warning).

Only then are the conditions evaluated. Failure to resolve inputs **never
raises** — the rule is simply not evaluated and the reason is recorded in the
`RuleEvaluation`.

### `RuleEvaluation`

| Field | Meaning |
| --- | --- |
| `rule_id`, `rule_version` | Definition id and version |
| `evaluated` | Whether all inputs were resolved |
| `matched` | Whether the conditions were satisfied |
| `reason` | Why the rule did or did not produce a signal |
| `signal` | The `ClinicalSignalCandidate`, or `None` |
| `inputs` | Resolved input records used for explainability |

---

## 5. Severity escalations

Starting from `rule.severity`, escalations are evaluated in declaration order.
Each escalation whose expression is true sets the current severity. Later
matching escalations therefore override earlier ones (last match wins). An
escalation whose expression fails to evaluate is skipped
(`except ExpressionError: continue`) rather than aborting the rule.

---

## 6. `ClinicalSignalCandidate` and the `SignalStatus` lifecycle

| Field | Meaning |
| --- | --- |
| `signal_id` | Generated signal id |
| `patient_id` | Patient identifier |
| `rule_id`, `rule_version` | Rule that produced the signal |
| `title`, `category` | Display title and category/domain |
| `severity`, `signal_type` | Final severity and `SignalType` |
| `supporting_refs` | Resolved inputs plus one record per evidence reference |
| `generated_at` | Generation timestamp |
| `explanation` | Full explanation dict (see below) |
| `authority` | `SYSTEM_DERIVED` |
| `status` | `SignalStatus` (starts `NEW`) |
| `run_id`, `domain`, `interpretation_warning` | Run linkage and context |

`SignalStatus` lifecycle: `NEW → REVIEWED → ACCEPTED` or `DISMISSED`, with
`SUPERSEDED` when a later run replaces a signal. `SignalReview` records a
`status`, `note`, `reviewer`, `reviewed_at` and a `history`. Accepting a signal
does **not** create a diagnosis and writes nothing to BV Clinical.

---

## 7. Explainability — "WHY AM I SEEING THIS?"

`ClinicalSignalCandidate.why()` returns a copy of the `explanation` dict, so no
black-box edge or signal exists. The dict is built by `evaluate_rule` with:

| Key | Content |
| --- | --- |
| `rule` | Rule definition id |
| `rule_version` | Rule version used |
| `signal_type` | `SignalType` value |
| `category` | Rule category |
| `combine` | `ALL` or `ANY` |
| `conditions` | The declared condition strings |
| `inputs` | Resolved inputs with value, unit, original value/unit, effective_at, ref id/kind, source module, authority, laboratory |
| `evidence_refs` | The rule's declared evidence references |
| `severity` | Final severity value |
| `warnings` | Conversion warnings plus the interpretation warning |
| `rendered` | The explanation template rendered with input values |
| `is_test_rule` | Whether the rule is synthetic/test content |
| `authority` | `SYSTEM_DERIVED` |
| `disclaimer` | `"Signal candidate for clinician review. Not a diagnosis."` |

The `rendered` string substitutes `{name}`, `{name_unit}` and `{name_label}`
placeholders from the resolved inputs.

---

## 8. Signal ≠ diagnosis

- A signal is a **candidate for attention**, emitted under `SYSTEM_DERIVED`
  authority, with an explicit `disclaimer`.
- The engine produces no diagnostic hypothesis and no diagnosis; the typed
  taxonomy enforces `DERIVED_METRIC ≠ CLINICAL_SIGNAL ≠ DIAGNOSTIC_HYPOTHESIS ≠
  CONFIRMED_DIAGNOSIS`.
- Every signal is fully explainable via `why()`, with the rule, version, inputs,
  conditions, severity and disclaimer traceable.
- `test_rule=True` signals are synthetic fixtures used only to validate the
  architecture and must never be shipped as clinical knowledge.
