# R1.2 — Corrections

Seven corrections. Each lists the original failure, the regression test, the
minimal change, and the files touched. No unrelated edits; no R2 features.

Full regression after every change: `python -m pytest` = **137 passed**;
`python -m compileall src` = OK.

---

## T1 — Controlled observation identity (GATE 2)

* **Failure:** `observations` used `INSERT OR REPLACE`; a divergent re-send
  silently overwrote value/provenance and reset `created_at`.
* **Tests:** `tests/test_identity_conflicts.py` (7).
* **Change:** `storage/repositories.py` — `ref_fingerprint`/`_row_fingerprint`;
  `ObservationRepository.save/save_many` now do a verified UPSERT
  (insert / idempotent no-op / refuse / explicit revision) under the write lock;
  `errors.py` — `IngestionConflictError`.

## T2 — Preserve knowledge timestamps (GATE 2)

* **Failure:** `knowledge_items` updates reset `created_at`/`reviewed_at`.
* **Tests:** covered by `tests/test_knowledge.py` + probe; timestamp preservation.
* **Change:** `knowledge/repository.py` — `_row_to_item` reads `created_at`/
  `reviewed_at`; `save_item` preserves them across updates.

## T3 — Transactional synthesis persistence (GATE 3)

* **Failure:** writes were committed individually; a mid-cycle failure could leave
  partial rows.
* **Tests:** `tests/test_transactions.py` (4).
* **Change:** `storage/database.py` — `isolation_level=None`, `transaction()`
  (`BEGIN IMMEDIATE … COMMIT`), write lock; `synthesis/run.py` — compute-before-
  persist, single transaction, `FAILED` recorded separately;
  repositories gained `commit: bool = True`; `app.py` passes the database.

## T4 — Strict clinical timestamps (GATE 4)

* **Failure:** naive timestamps were silently assumed UTC at the clinical boundary.
* **Tests:** `tests/test_temporal_policy.py` (8).
* **Change:** `core/timeutil.py` — `parse_clinical_dt` (reject naive,
  `NaiveTimestampError`); `observations/refs.py` — `_require_effective_at` uses it;
  `errors.py` — `NaiveTimestampError`.

## T5 — Legacy unknown ingestion date (GATE 4)

* **Failure:** legacy rows with unknown `ingested_at` were back-filled from
  `created_at` (a retrospective substitution).
* **Tests:** `tests/test_temporal_policy.py::test_legacy_null_ingested_at_preserved`.
* **Change:** `observations/refs.py` — `ingested_at` is `datetime | None`;
  `storage/repositories.py::_row_to_ref` keeps `None`.

## T6 — Concurrency configuration (GATE 5)

* **Failure:** no `busy_timeout`, no WAL, write methods not serialized on the shared
  connection.
* **Tests:** `tests/test_concurrency.py` (4).
* **Change:** `storage/database.py` — `busy_timeout=5000`, WAL for file DBs,
  `write_lock`; repositories acquire the lock in every write path (observations,
  metrics, scores, signals, runs, events).

## T7 — Logical identity of a run (GATE 6)

* **Failure:** execution and content identity were conflated.
* **Tests:** `tests/test_historical_reconstruction.py` (6).
* **Change:** `synthesis/run.py` — `SynthesisRunResult.logical_fingerprint()`.

---

## Files changed (R1.2)

```
src/bv_scientific_center/errors.py
src/bv_scientific_center/core/timeutil.py
src/bv_scientific_center/observations/refs.py
src/bv_scientific_center/storage/database.py
src/bv_scientific_center/storage/repositories.py
src/bv_scientific_center/knowledge/repository.py
src/bv_scientific_center/synthesis/run.py
src/bv_scientific_center/app.py
tests/  (5 new files: +29 tests)
docs/R1_2_*.md  (new, 9 files)
docs/R1_1_CHANGES.md  (count reconciliation: 8 -> 9)
```

## Schema changes

**None in R1.2.** No column/table added or removed; no destructive migration. The
`ingested_at`/`origin` columns were introduced in R1.1 via additive migration. The
only storage-configuration change is PRAGMA-level (`journal_mode=WAL`,
`busy_timeout`), which is not a schema change.

## Compatibility

Additive only: no public contract removed or renamed, no route changed; the 12 R1
gates and all 108 R1.1 tests remain green (137 total).
