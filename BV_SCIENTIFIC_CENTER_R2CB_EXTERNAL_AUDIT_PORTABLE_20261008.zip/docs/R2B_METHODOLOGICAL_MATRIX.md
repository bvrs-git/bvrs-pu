# R2B — Methodological Matrix

## Study design taxonomy

`StudyDesign` (`knowledge/scientific.py`) is a methodological taxonomy, **not** a
rigid universal quality hierarchy:

`SYSTEMATIC_REVIEW`, `META_ANALYSIS`, `RCT`, `COHORT`, `CASE_CONTROL`,
`CROSS_SECTIONAL`, `DIAGNOSTIC_ACCURACY`, `INSTRUMENT_VALIDATION`,
`CLINICAL_GUIDELINE`, `CONSENSUS`, `CASE_SERIES`, `CASE_REPORT`, `PRECLINICAL`,
`OTHER`.

Human-readable labels live in `DESIGN_LABELS`; both are exposed by
`taxonomy()` and surfaced on the read-only curation dashboard.

## Question-type advisory mapping

`QUESTION_TYPE_TAXONOMY` maps a clinical question type to the study designs that
*may be informative*. It is advisory only:

| Question type | Designs that may be informative |
| --- | --- |
| `THERAPY` | `SYSTEMATIC_REVIEW`, `META_ANALYSIS`, `RCT`, `COHORT` |
| `DIAGNOSIS` | `SYSTEMATIC_REVIEW`, `DIAGNOSTIC_ACCURACY`, `CROSS_SECTIONAL` |
| `PROGNOSIS` | `SYSTEMATIC_REVIEW`, `COHORT`, `CASE_CONTROL` |
| `ETIOLOGY_HARM` | `SYSTEMATIC_REVIEW`, `COHORT`, `CASE_CONTROL` |
| `INSTRUMENT_VALIDATION` | `INSTRUMENT_VALIDATION`, `CROSS_SECTIONAL` |
| `REFERENCE_RANGE` | `CROSS_SECTIONAL`, `COHORT`, `CLINICAL_GUIDELINE`, `CONSENSUS` |
| `MEASUREMENT_PROPERTY` | `INSTRUMENT_VALIDATION`, `DIAGNOSTIC_ACCURACY` |

The mapping never implies that a design is automatically higher quality.

## Methodological assessment

`MethodologicalAssessment` is a human-applied assessment of a single evidence
record:

| Field | Notes |
| --- | --- |
| `framework` | `CertaintyFramework` (`GRADE`, `OTHER`, `NONE`). |
| `certainty` | `CertaintyLevel` (`HIGH`, `MODERATE`, `LOW`, `VERY_LOW`, `NOT_ASSESSED`). |
| `domains` | Free-form mapping over `ASSESSMENT_DOMAINS`. |
| `summary` | Free text. |
| `assessed_by` | Human assessor identity. |
| `assessed_at` | Timestamp. |
| `human_applied` | Defaults to `True`. |

`ASSESSMENT_DOMAINS` lists the domains considered by GRADE-style human
assessment: `risk_of_bias`, `inconsistency`, `indirectness`, `imprecision`,
`publication_bias`, `effect_size`, `dose_response`.

`MethodologicalAssessment.validate()` rejects any `certainty` other than
`NOT_ASSESSED` when there is no named human assessor — **GRADE is never
automatic**.

## No automatic grading

`suggest_assessment(evidence, references_present=...)` returns a *structured
suggestion* for human review. It never grades, and its payload explicitly
carries:

* `auto_certainty: False`
* `suggested_certainty: None`
* `suggested_framework: "GRADE"` and `suggested_domains` (the domains to
  consider)
* a `notice` (the `SUGGESTION_NOTICE` text) stating it does not approve, rate or
  grade the evidence and that certainty must be applied by a human reviewer.

The suggestion must not be persisted as an assessment without human editing and
an assessor identity.
