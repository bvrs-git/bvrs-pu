# R1 — Handoff

## Current status

R0/R1 are implemented as a standalone module. The following capabilities are
present and exercised by the test suite (`68 passed`):

* **Formula registry** — versioned `ClinicalFormulaDefinition` with
  publication-time validation and immutability (`formulas/`).
* **Derived metric engine** — deterministic `compute_metric` with typed refusals
  (`DerivedClinicalMetric`), unit conversion recording and temporal alignment
  (`formulas/engine.py`, `formulas/alignment.py`).
* **Score engine** — interpretation bands on top of the formula safety machinery
  (`scores/`).
* **Rule engine** — declarative rules producing explainable
  `ClinicalSignalCandidate`s (`rules/`).
* **Synthesis run** — reproducible `SynthesisRunner`/`SynthesisRunResult` that
  records input snapshots and formula/score/rule versions (`synthesis/run.py`).
* **Provenance and versioning** — `content_hash`, immutable `DefinitionRegistry`,
  `formula_snapshot`, per-run version maps (`core/definition.py`,
  `core/registry.py`).
* **Knowledge repository** — items, claims and references with a citation gate
  (`knowledge/`).
* **Knowledge package model** — importable, validated, versioned, immutable
  packages with security scanning (`knowledge/packages.py`).
* **Full-text search** — offline SQLite FTS5 with a LIKE fallback
  (`knowledge/search.py`).
* **Clinical map model and projection** — `ClinicalMapBuilder` producing a
  traceable, validated `ClinicalMapProjectionV1` (`clinical_map/`,
  `contracts/outputs.py`).
* **Synthetic data** — one synthetic patient, formulas, a score, rules, knowledge
  items and a synthetic package (`seed/`). No real patient data.
* **Minimal UI** — standard-library HTTP UI with read models and an explicit
  signal-review action (`ui/`).
* **Tests** — unit and critical-gate tests across all layers (`tests/`).

## Out of scope (explicit)

* **No real patients / no PHI.** Only synthetic fixtures are used.
* **No merge into BV Clinical.** This is a standalone module; it does not become
  part of the Clinical codebase in R1.
* **No production AI reasoning.** `ai/drafts.py` only enforces the labelling
  contract (`AI_DRAFT` / `AI_SUGGESTION`); it performs no reasoning.
* **No automatic import of copyrighted bibliography.** Knowledge content is
  curated and imported through reviewed packages carrying real citation metadata.
* **Not all medical formulas.** Only architecture-validation fixtures are
  registered; the formula set is not clinically complete.
* **No clinical validation claims for synthetic rules.** Synthetic rules exist to
  validate the engine, not to guide care.
* **No auto-diagnosis.** Signals are candidates for clinician review; accepting
  one never creates a diagnosis.
* **No Patient Area publication.** The map is clinician-facing only.
* **No Prontuário modification.** Nothing writes to the Prontuário; promotion
  drafts require explicit clinician review.
* **No automatic GPT Work connection.** The synthetic manifest references a GPT
  Work placeholder only.

## Next safe actions

1. Add real, reviewed knowledge packages with genuine citation metadata and
   activate them through `import_package` / `activate_package`.
2. Expand the versioned formula/score/rule catalogue (new versions only — never
   edit published ones).
3. Add inbound projection adapters for any new BV source, mapping to existing
   concept codes where possible.
4. Introduce a consumer that subscribes to `ClinicalSignalReviewed` events and
   consumes `ClinicalMapProjectionV1` (future Prontuário integration), keeping the
   promotion draft as the only hand-off artifact.
5. Broaden the test matrix as new gates are introduced.

## How to run

The package is importable without installation via `run_ui.py`, or runnable as a
module when `src/` is on the path.

**Synthetic demo (in-memory, no data written):**

```
python -m bv_scientific_center demo
```

**Critical-gate report:**

```
python -m bv_scientific_center report
```

**Minimal UI** (default command; serves `http://127.0.0.1:8787`):

```
python -m bv_scientific_center serve
# or, without installing the package:
python run_ui.py --port 8787
```

If no data is found, `serve` seeds the synthetic fixtures first. The UI pages are:
home, patient index and per-patient `overview` / `domains` / `metrics` /
`signals` / `timeline` / `map` / `compare`, signal detail (with a review action),
and knowledge home / search / formulas / packages / item.

**Tests:**

```
python -m pytest
```
