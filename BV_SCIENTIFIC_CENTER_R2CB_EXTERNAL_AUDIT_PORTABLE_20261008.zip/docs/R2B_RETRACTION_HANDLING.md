# R2B — Retraction Handling

## Alert types

`EditorialAlertType` (`core/enums.py`): `RETRACTION`, `CORRECTION`, `ERRATUM`,
`EXPRESSION_OF_CONCERN`, `REPUBLICATION`.

## Detection

`BibliographyService._detect_editorial_alerts` inspects the record's
`editorial_notes` (built by the adapters from PubMed publication types and
Crossref `update-to` / `updated-by` / `relation` entries). Matching is
case-insensitive on the note text:

| Note contains | Alert type | `is_retraction` |
| --- | --- | --- |
| `retract` | `RETRACTION` | `true` |
| `erratum` | `ERRATUM` | `false` |
| `correct` | `CORRECTION` | `false` |
| `concern` | `EXPRESSION_OF_CONCERN` | `false` |

Alerts are appended to `editorial_alerts`. The repository is idempotent on
`(reference_id, alert_type, source, details)`, so re-checking does not duplicate
notices.

## An erratum is not a retraction

An erratum or correction is recorded as its own alert type with
`is_retraction = 0`. It never sets the retraction flag:
`has_retraction` only counts rows with `is_retraction = 1`. Test
`test_erratum_is_not_treated_as_full_retraction` asserts no alert of type
`RETRACTION` and that `has_retraction` is `False`.

## A retraction blocks clinical use

Usability has two independent gates. `CurationService.is_clinically_usable`
only checks the editorial curation status, but
`BibliographyService.is_clinically_usable` requires **both** the curation status
to be clinically usable **and** no retraction alert:

```mermaid
flowchart TD
    R["is_clinically_usable(reference_id)"] --> A{"CurationStatus usable (APPROVED)?"}
    A -->|no| N["NOT usable"]
    A -->|yes| B{"has_retraction?"}
    B -->|yes| N
    B -->|no| Y["Usable"]
```

So a retraction blocks clinical usability **even if curation status is
`APPROVED`** (`test_retracted_reference_is_not_clinically_usable_even_if_approved`).

## Offline currency flag

When `check_editorial` cannot reach any provider it does not overwrite metadata.
It appends a local `EXPRESSION_OF_CONCERN` alert (`source = "LOCAL"`, detail
`"Provider unavailable: currency could not be verified."`) so that the current
state is preserved but flagged as unverifiable
(`test_offline_check_preserves_state_and_flags_currency`).

## Impacts

* `BibliographyService.retraction_impacts(reference_id)` returns
  `{reference_id, has_retraction, evidence_ids, alerts}` — the evidence records
  that cite the reference.
* `CurationService.claims_impacted_by_retraction(evidence_id)` (facade
  `retraction_impacts`) returns the claims that reference evidence now
  retracted/rejected/superseded, each with a warning that the claim is not
  current.
* Evidence can never be `APPROVED` while retracted
  (`ScientificEvidence.validate`; `CurationService.transition`).

## History is preserved

Retraction handling is append-only:

* alerts are inserted, never deleted;
* curation transitions are recorded as `curation_events` with actor,
  justification and version;
* stored reference metadata is not rewritten by an editorial re-check.

`CurationService.retract` additionally sets `retraction_reason` (references) and
`editorial_status = "RETRACTED"` + `retraction_notes` (evidence).
