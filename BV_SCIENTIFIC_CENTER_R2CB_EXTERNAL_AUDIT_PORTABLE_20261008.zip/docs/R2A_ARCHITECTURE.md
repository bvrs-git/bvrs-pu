# R2A — Architecture

**Phase:** R2A — scientific curation pipeline and evidence governance.
**Nature:** infrastructure only (no new clinical recommendations).
**Result:** `BV_SCIENTIFIC_CENTER_R2A_STATUS = PASS`

Central principle: **imported evidence is not validated evidence; validated
evidence is not automatically a clinical recommendation.**

## Baseline preserved

R1.2 (137 tests) was re-measured at the start of R2A and preserved. Python 3.14.6,
SQLite 3.50.4 (FTS5), runtime strictly standard library. After R2A: **204 tests**
(137 + 67 new).

## Layered view

```mermaid
flowchart TD
    UI[ui/server.py read-only] --> App[app.ScientificCenterApp]
    CLI[__main__.py local admin] --> Curation[knowledge.curation.CurationService]
    App --> Curation
    App --> Links[knowledge.evidence_links.EvidenceLinkService]
    App --> Search[knowledge.scientific_repository.ScientificSearch]
    Curation --> RefRepo[knowledge.scientific_repository]
    Links --> RefRepo
    RefRepo --> KnowDB[(knowledge.db)]
    App --> ClinDB[(derived.db)]
    App --> Backup[storage.backup]
    Backup --> KnowDB
    Backup --> ClinDB
```

`knowledge.db` holds scientific content and has **no patient data**; `derived.db`
holds patient-derived synthesis. The two are never assumed atomic together.

## New components (R2A)

| Component | Responsibility |
| --- | --- |
| `knowledge/scientific.py` | Canonical model: `ScientificReference`, `ScientificEvidence`, `ClinicalClaim`, `EvidenceLink`, `CurationEvent`; enums; state machine |
| `knowledge/methodology.py` | Study-design taxonomy and **non-automatic** assessment suggestions |
| `knowledge/scientific_repository.py` | Persistence + FTS5 search + conflict detection |
| `knowledge/curation.py` | Curation workflow, human approval guard, retraction, audit |
| `knowledge/evidence_links.py` | Evidence ↔ formula/score/rule links |
| `knowledge/packages.py` (evolved) | Package governance: author/reviewer/dependencies/content hash/provenance |
| `storage/backup.py` | Official-API consistent backup + verification |
| `seed/scientific_seed.py` | Synthetic curation set + verified real-reference pilot |

## New tables (`knowledge.db`)

`scientific_references`, `scientific_evidence`, `clinical_claims`, `evidence_links`,
`curation_events`, plus FTS5 indexes `reference_fts` and `evidence_fts`. All created
additively (`CREATE TABLE IF NOT EXISTS`) — no destructive migration.

## Flow of one curated fact

```
Crossref/reference metadata  ->  ScientificReference (IMPORTED_UNVERIFIED)
    -> screened (SCREENED) -> curated (CURATED) -> human APPROVED
    -> ScientificEvidence (design, population, outcomes, limitations, methodology)
    -> ClinicalClaim (favorable/contrary/inconclusive evidence, certainty, context)
    -> EvidenceLink to FORMULA/SCORE/RULE (FOUNDATIONAL | VALIDATION | DISCUSSION)
    -> every step recorded in curation_events (actor, justification, version)
```

## Design rules honored

* No automatic approval; approval requires a human reviewer and a justification.
* No automatic GRADE; certainty requires a named human assessor.
* No fabricated identifiers, results or citations; unknown stays VERIFY_PENDING.
* Retracted/rejected/superseded content cannot be presented as current.
* Scientific changes never alter historical clinical syntheses.
* HTTP interface is read-only for curation; approval is a local administrative flow.
