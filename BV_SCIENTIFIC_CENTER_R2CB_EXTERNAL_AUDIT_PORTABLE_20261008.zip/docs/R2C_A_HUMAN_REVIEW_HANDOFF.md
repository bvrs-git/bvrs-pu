# R2C-A — Human Review Handoff

R2C-A ends with a **handoff**, not an activation. Everything is pending human
review; nothing is approved for clinical use.

## Review queue

`app.human_review_queue()` returns three sections:

| Section | Source | Contents |
| --- | --- | --- |
| `references_pending` | references not (approved and alert-free) | `reference_id`, `title`, `bibliographic_status`, `content_review_status`, `curation_status`, `editorial_alerts` (count) |
| `claims_pending` | claims whose status is not `APPROVED` | `claim_id`, `text`, `curation_status`, `certainty_level` |
| `formula_candidates_pending` | all candidates (`all_latest()`) | `candidate_id`, `version`, `display_name`, `candidate_type`, `review_status`, `operational`, `references`, `validation_evidence` |

Every item in `formula_candidates_pending` has `operational = False`. A reference
that is `APPROVED` and has no editorial alerts is excluded (nothing pending); every
candidate remains pending because no status represents clinical approval.

## Dossiers

`app.export_candidate_dossier(candidate_id, fmt)` produces a self-contained dossier
from `candidate_view(id)`, which joins the candidate definition, its applicability,
its evidence links, its references and any editorial alerts.

- `fmt="json"` — the full nested view, UTF-8, `ensure_ascii=False`.
- `fmt="md"` — a Markdown dossier with sections: Scientific name, Type, Review
  status, Operational (`no`, non-operational in R2C-A), Expression, Output unit,
  Variables (with allowed semantics), Applicability, Limitations, References,
  Evidence links, and the closing line:

  > Non-operational. No clinical approval. No cutoff imported.

Any other `fmt` raises `ValueError`.

## Reviewer identity

A reviewer identity in R2C-A is a **declared local string**, not an authenticated
principal. The UI states this explicitly:

> Read-only. A local reviewer identity is declared, not authenticated. There is no
> approval action over HTTP.

Approval (a curation state transition) requires an explicit actor and
justification (`require_approval_actor`), but the identity is a caller-supplied
label. It is an audit trail, not an access-control mechanism.

## CLI

Three R2C-A commands are available through `python -m bv_scientific_center`:

| Command | Effect |
| --- | --- |
| `candidates` | Prints `app.formula_candidates_list()` as JSON. |
| `dossier --id <candidate> [--format json\|md] [--out <file>]` | Prints or writes a candidate dossier. |
| `human-review` | Prints `app.human_review_queue()` as JSON. |

`dossier` requires `--id`; the format default is `json`. When `--out` is given the
payload is written to the file and a `WROTE <file> (<bytes> bytes)` line is printed.

## UI routes (read-only)

| Route | Renders |
| --- | --- |
| `/knowledge/candidates` | Candidate list; marks Operational `yes`/`no`. |
| `/knowledge/candidate/<id>` | Candidate detail with variables, applicability, limitations, references, evidence links. |
| `/knowledge/human-review` | The three-section review queue. |

There is **no HTTP approval route**: `/knowledge/candidate/<id>/approve` and
`/knowledge/human-review/approve` return `404`.

## Technical PASS vs clinical approval PENDING

```mermaid
flowchart LR
    T[Technical verification<br/>math, units, semantics, registry] -->|PASS| D[Draft dossiers & queue]
    D --> H[Human scientific review<br/>appraisal, evidence relations]
    H -->|PENDING in R2C-A| A[Clinical approval<br/>NOT PERFORMED]
```

- **Technical PASS**: candidates validate (expression, units, semantics), the
  registry keeps them non-operational, the prototype math passes its reference
  fixtures, and the suite is green (330 passed, 2 skipped).
- **Clinical approval PENDING**: no candidate is approved, no cutoff is imported, and
  no status represents clinical approval. That decision belongs to a human and lies
  outside this phase.

## Explicit non-claims

- No formula is active in patients.
- No candidate is executable in clinical synthesis.
- No cutoff is imported as a diagnostic criterion.
- No clinical validation is claimed for any candidate.
- No scientific value was invented where the corpus provided only metadata.
- The UI cannot approve anything.

See also: `R2C_A_RESIDUAL_RISKS.md`, `R2C_A_ARCHITECTURE.md`.
