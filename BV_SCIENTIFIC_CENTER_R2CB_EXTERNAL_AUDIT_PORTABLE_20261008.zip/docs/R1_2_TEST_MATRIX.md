# R1.2 — Test Matrix

## Totals

| Snapshot | Tests | Pass | Fail |
| --- | --- | --- | --- |
| R1.1 baseline (re-measured at R1.2 start) | 108 | 108 | 0 |
| R1.2 after hardening | **137** | **137** | **0** |

`python -m pytest` (addopts `-q`), `python -m compileall src` = OK.

## Tests per file

| Tests | File | Phase |
| --- | --- | --- |
| 13 | `test_expression.py` | R1 |
| 12 | `test_formula_engine.py` | R1 |
| 10 | `test_knowledge.py` | R1 |
| 8 | `test_clinical_map.py` | R1 |
| 8 | `test_ui_security.py` | R1.1 |
| 8 | `test_temporal_policy.py` | **R1.2 (new)** |
| 7 | `test_identity_conflicts.py` | **R1.2 (new)** |
| 6 | `test_units.py` | R1 |
| 6 | `test_rule_engine.py` | R1 |
| 6 | `test_historical_reconstruction.py` | **R1.2 (new)** |
| 5 | `test_synthesis_run.py` | R1 |
| 5 | `test_determinism.py` | R1.1 |
| 5 | `test_governance.py` | R1.1 |
| 5 | `test_calculation_safety.py` | R1.1 |
| 4 | `test_provenance.py` | R1.1 |
| 4 | `test_idempotency.py` | R1.1 |
| 4 | `test_patient_isolation.py` | R1.1 |
| 4 | `test_review.py` | R1 |
| 4 | `test_concurrency.py` | **R1.2 (new)** |
| 4 | `test_transactions.py` | **R1.2 (new)** |
| 3 | `test_score_engine.py` | R1 |
| 3 | `test_fail_closed.py` | R1.1 |
| 2 | `test_migration.py` | R1.1 |
| 1 | `test_critical_gates.py` | R1 |

New in R1.2: **5 files, 29 tests**.

## R1.2 gate coverage

| Gate | Focus | Evidence |
| --- | --- | --- |
| GATE 2 | Identity / idempotency / conflict | `test_identity_conflicts.py`, `test_idempotency.py` |
| GATE 3 | Transactional atomicity | `test_transactions.py`, `test_fail_closed.py` |
| GATE 4 | Clinical vs ingestion dates, timezone policy | `test_temporal_policy.py`, `test_provenance.py`, `test_migration.py` |
| GATE 5 | Concurrency and isolation | `test_concurrency.py`, `test_patient_isolation.py` |
| GATE 6 | Historical reproducibility | `test_historical_reconstruction.py`, `test_determinism.py` |
| GATE 1/7 | No regression / documentation | `test_critical_gates.py`, `docs/R1_2_*` |

## Acceptance evidence

* **Atomicity** — `test_rollback_on_mid_persist_failure`: an injected failure while
  persisting leaves observation count unchanged and records a `FAILED` run;
  `test_no_partial_run_appears_complete` proves no half-written run is marked
  `COMPLETED`.
* **Idempotency without provenance loss** — `test_exact_duplicate_is_idempotent_and_preserves_metadata`,
  `test_divergent_content_is_refused_and_preserved`,
  `test_explicit_revision_preserves_original`.
* **Isolation** — `test_concurrent_runs_for_different_patients`,
  `test_patient_isolation.py`.
* **Historical reconstruction** — `test_stored_run_rebuild_matches_recomputation`,
  `test_recomputation_does_not_modify_history`,
  `test_reconstruction_is_independent_of_mutable_state`.

## R1 gates (unchanged)

`tests/test_critical_gates.py` still prints all 12 R1 gates as `PASS`.
