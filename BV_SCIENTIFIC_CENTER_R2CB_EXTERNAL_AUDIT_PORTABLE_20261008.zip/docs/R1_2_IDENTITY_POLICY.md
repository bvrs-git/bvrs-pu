# R1.2 — Identity and Idempotency Policy

## Stable identity of an observation

An observation's identity is derived **only from its source identity**:

```
observation_ref_id = stable_id(
    "obsref",
    patient_id, source_module, source_entity_type, source_entity_id,
    source_version, concept, effective_at,
)
```

`stable_id` is `sha256` over the natural key. Consequences:

* The same source observation always maps to the same reference id.
* Re-ingestion is idempotent.
* A genuine source correction **must** bump `source_version`, which naturally
  yields a new identity (a versioned correction, not an overwrite).
* Ingestion time is **not** part of identity.

`core/ids.stable_id` (deterministic) is distinct from `core/ids.new_id` (random,
used for genuinely new entities such as metrics/signals/runs).

## Content fingerprint

A separate **content fingerprint** covers the clinical payload — `patient_id`,
`concept`, `value`, `unit`, `effective_at`, source ids, `source_version`,
`authority`, `layer`, `provenance`, `fasting_status`, `context`, `labels` — and
**excludes** `ingested_at`/`created_at` (volatile).

## Behavior matrix (audited outcomes)

| Scenario | Behavior |
| --- | --- |
| Re-ingestion of the exact same observation (same file, later time) | Idempotent no-op; original `created_at`/`ingested_at` preserved |
| New observation with numerically equal value, different source identity | Preserved separately (distinct row) |
| Correction of a previous observation (source bumps `source_version`) | New identity → new row; both retained |
| Same identity, divergent content (no version bump) | **Refused** with `IngestionConflictError` (fail-closed) |
| Same identity, divergent content, explicit `on_conflict="REVISE"` | Original preserved; a new row is written with `provenance.revision_of` |

## Why `INSERT OR REPLACE` was replaced (observations)

`INSERT OR REPLACE` is `DELETE` + `INSERT`:

* it silently overwrote value/provenance on a divergent re-send;
* it reset `created_at` (metadata loss);
* it could trigger future `ON DELETE CASCADE` if child tables are added.

The repository now performs an **UPSERT with semantic verification**: plain
`INSERT` when absent, fingerprint comparison when present, refuse or revise on
divergence. The write is serialized by the database write lock.

## Other tables

| Table | Policy | Rationale |
| --- | --- | --- |
| `derived_metrics`, `score_results`, `signals` | `INSERT OR REPLACE` kept | ids are unique per computation (`new_id`); write-once per run |
| `synthesis_runs` | controlled | one `COMPLETED` **or** one `FAILED` per `run_id`; never both |
| `knowledge_items` | `INSERT OR REPLACE` with timestamp preservation | content is intentionally editable; `created_at`/`reviewed_at` now read back and preserved |
| `pins` | `INSERT OR REPLACE` kept | unique random `pin_id`, write-once |

## Provenance guarantees

* Original rows are never mutated by a divergent re-send.
* Explicit revisions keep a link (`provenance.revision_of`) to the original.
* `observation_ref_id` values referenced by stored metrics/signals remain valid
  (no cascade, no row removal).
