# R2A — Scientific Contracts

All types live in `knowledge/scientific.py` and are persisted in `knowledge.db`
(**no patient data**). Missing fields are never invented.

## ScientificReference (GATE 1A)

| Field | Notes |
| --- | --- |
| `reference_id` | internal stable id |
| `title` | required |
| `authors` | tuple, as returned by the source |
| `organization` | responsible organization |
| `publication_year`, `venue`, `publication_type` | bibliographic context |
| `doi`, `pmid`, `isbn`, `url` | identifiers, as applicable |
| `accessed_at` | access/verification date |
| `metadata_source` | `CROSSREF`, `PUBMED`, `MANUAL`, `GPT_WORK`, `SYNTHETIC` |
| `verification_status` | `VERIFIED`, `PARTIALLY_VERIFIED`, `VERIFY_PENDING`, `UNVERIFIED` |
| `curation_status` | workflow state (see curation model) |
| `version`, `origin` | versioning and provenance |
| `superseded_by`, `retraction_reason`, `notes` | editorial history |

* `stable_identifier()` → DOI > PMID > ISBN > URL (normalized); `None` if absent.
* `content_hash()` — deterministic content fingerprint used for idempotent import.

## ScientificEvidence (GATE 1B)

`evidence_id`, `title`, `reference_ids`, `study_design`, `population`,
`intervention`, `comparator`, `outcomes`, `quantitative_results`, `limitations`,
`clinical_applicability`, `uncertainties`, `biases`, `editorial_status`,
`corrections`, `retraction_notes`, `methodology`, `domain`, `curation_status`,
`version`, `origin`, `superseded_by`.

* `is_retracted()` — true when `editorial_status == RETRACTED` or curation is RETRACTED.

## ClinicalClaim (GATE 1C)

`claim_id`, `text`, `favorable_evidence_ids`, `contrary_evidence_ids`,
`inconclusive_evidence_ids`, `population_context`, `applicability`, `limitations`,
`certainty_level`, `certainty_framework`, `curation_status`, `version`, `origin`,
`review_history`, `superseded_by`.

* Certainty of evidence is kept separate from any recommendation strength.
* A claim cannot be APPROVED without at least one favorable evidence record.

## Supporting contracts

| Type | Purpose |
| --- | --- |
| `EvidenceLink` | `subject_type/subject_id` → `target_type/target_id/target_version` with `relation` (FOUNDATIONAL, VALIDATION, DISCUSSION) |
| `CurationEvent` | audit record: from/to status, actor, justification, version, timestamp |
| `MethodologicalAssessment` (`methodology.py`) | human-applied framework/certainty/domains; forbids certainty without a named assessor |

## Enumerations

`PublicationType`, `StudyDesign`, `VerificationStatus`, `CurationStatus`,
`EvidenceRelation`, `CertaintyLevel`, `CertaintyFramework`, `MetadataSource`,
`CurationSubjectType`, `LinkTargetType`.

## Identity and idempotency

* Import by stable identifier is idempotent for identical content.
* Same identifier with divergent metadata raises `MetadataConflictError` — never a
  silent overwrite.
* Reference/evidence/claim content hashes are stored for auditing.

## Versioning

Curated subjects carry an integer `version` that increments on every curation
transition; each transition is recorded in `curation_events`. Published knowledge
packages remain immutable per `(package_id, version)`.
