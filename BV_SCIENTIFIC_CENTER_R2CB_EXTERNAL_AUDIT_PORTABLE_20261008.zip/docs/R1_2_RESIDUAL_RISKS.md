# R1.2 — Residual Risks

Risks remaining after R1.2. None blocks certification; each is bounded and has a
mitigation or an explicit R2 owner.

| # | Risk | Impact | Status |
| --- | --- | --- | --- |
| R-1 | `reproduce_run` recomputes with new ids (by design); only `rebuild_run` is deterministic | A map from recomputation differs in node ids | Documented; UI uses `rebuild_run`; logical fingerprint proves value equality |
| R-2 | Prototype UI has no authentication | Non-loopback exposure would leak clinical data | Server binds `127.0.0.1` by default; R2 to add auth before any exposure |
| R-3 | Single shared connection serialized by a lock | Throughput ceiling under heavy concurrency; a reader on the same connection can observe an in-progress transaction's effects | WAL + `busy_timeout` + write lock; sufficient for loopback prototype; R2 to move to per-operation connections if scaled |
| R-4 | Legacy rows may have `ingested_at = NULL` and pre-R1.1 values | Provenance incomplete for old rows | Kept explicitly UNKNOWN (never fabricated); new ingests always populated |
| R-5 | Synthetic formulas/scores/rules and knowledge fixtures are architecture tests | Could be mistaken for clinical content | `SYNTHETIC`/`TEST_RULE` markers; `origin=SYNTHETIC_TEST` cannot be APPROVED; no clinical validation claimed |
| R-6 | Observation identity is the source natural key; a changed clinical value without a `source_version` bump is refused | A caller that forgets to bump `source_version` is blocked | Fail-closed by design; explicit `on_conflict="REVISE"` available; source-version discipline is a contract |
| R-7 | FTS search is lexical (FTS5) with `LIKE` fallback | Recall depends on wording | Raw citation DB is source of truth; embeddings planned as index only (R2) |
| R-8 | Cross-database atomicity is not provided | `knowledge.db` and `derived.db` writes are independent | Documented; the two stores are never written in one logical transaction |
| R-9 | `derived_metrics`/`signals` still use `INSERT OR REPLACE` | Only safe because ids are unique per computation | Documented in `R1_2_IDENTITY_POLICY.md`; revisit if ids become reused |
| R-10 | No inferential statistics on N-of-1 series | Over-claiming from co-trends | `correlation_series` labels co-variation, `causality_claimed=false` |
| R-11 | No production AI reasoning | “Synthesis” is rule-based only | AI boundary labels output `AI_DRAFT`/`AI_SUGGESTION` |
| R-12 | Knowledge approval depends on human curation quality | Weak curation admits weak evidence | Citation gate + origin separation; evidence fields never auto-filled |

## Explicitly out of scope (unchanged)

No real patients; no BV Clinical modification; no automatic GPT Work connection; no
Patient Area publication; no automatic diagnosis; no third-party runtime
dependencies; no destructive migrations.
