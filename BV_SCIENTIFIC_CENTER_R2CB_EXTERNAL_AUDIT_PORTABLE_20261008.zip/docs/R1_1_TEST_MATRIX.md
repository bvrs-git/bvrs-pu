# R1.1 — Test Matrix and Gate Evidence

## How to run

```
python -m pytest                 # 108 passed (R1.1)
python -m compileall src         # syntax/compile check
python -m bv_scientific_center report
python run_ui.py --port 8787     # UI smoke (loopback)
```

`pyproject.toml`: `pythonpath = ["src"]`, `testpaths = ["tests"]`, `addopts = "-q"`.

## Totals

| Snapshot | Tests | Pass | Fail |
| --- | --- | --- | --- |
| R1 baseline (re-measured) | 68 | 68 | 0 |
| R1.1 after hardening | **108** | **108** | **0** |

## Tests per file (R1.1)

| Tests | File |
| --- | --- |
| 13 | `tests/test_expression.py` |
| 12 | `tests/test_formula_engine.py` |
| 10 | `tests/test_knowledge.py` |
| 8 | `tests/test_clinical_map.py` |
| 8 | `tests/test_ui_security.py` *(new)* |
| 6 | `tests/test_units.py` |
| 6 | `tests/test_rule_engine.py` |
| 5 | `tests/test_synthesis_run.py` |
| 5 | `tests/test_determinism.py` *(new)* |
| 5 | `tests/test_governance.py` *(new)* |
| 5 | `tests/test_calculation_safety.py` *(new)* |
| 4 | `tests/test_provenance.py` *(new)* |
| 4 | `tests/test_idempotency.py` *(new)* |
| 4 | `tests/test_patient_isolation.py` *(new)* |
| 4 | `tests/test_review.py` |
| 3 | `tests/test_score_engine.py` |
| 3 | `tests/test_fail_closed.py` *(new)* |
| 2 | `tests/test_migration.py` *(new)* |
| 1 | `tests/test_critical_gates.py` |

## Gate coverage (R1.1)

| Gate | Primary evidence |
| --- | --- |
| `MEASURED_DERIVED_SEPARATION` | `test_critical_gates.py`, `test_formula_engine.py`, `test_clinical_map.py` |
| `SIGNAL_NOT_DIAGNOSIS` | `test_rule_engine.py`, `test_review.py`, `test_critical_gates.py` |
| `FORMULA_VERSIONING` / `RULE_VERSIONING` | `test_formula_engine.py`, `test_idempotency.py`, `test_critical_gates.py` |
| `MISSING_IS_NOT_ZERO` | `test_formula_engine.py`, `test_score_engine.py`, `test_rule_engine.py` |
| `UNIT_VALIDATION` | `test_units.py`, `test_formula_engine.py`, `test_calculation_safety.py` |
| `TEMPORAL_VALIDATION` | `test_formula_engine.py`, `test_calculation_safety.py` |
| `SOURCE_AUTHORITY_CHECK` | `test_formula_engine.py`, `test_calculation_safety.py` |
| `REPRODUCIBILITY` | `test_synthesis_run.py`, `test_determinism.py`, `test_critical_gates.py` |
| `MAP_PROVENANCE` | `test_clinical_map.py`, `test_critical_gates.py` |
| `KNOWLEDGE_CITATIONS` | `test_knowledge.py`, `test_governance.py`, `test_critical_gates.py` |
| `NO_AUTO_DIAGNOSIS` | `test_review.py`, `test_critical_gates.py` |

## R1.1 gate coverage (new)

| Gate | Focus | Evidence |
| --- | --- | --- |
| GATE 2A | Scientific provenance | `test_provenance.py` |
| GATE 2B/2C | Calculation safety / temporal / determinism | `test_calculation_safety.py` |
| GATE 3 | Expression sandbox | `test_expression.py` |
| GATE 3 | FTS/SQL injection, loopback binding, input handling | `test_ui_security.py` |
| GATE 3 | Patient isolation | `test_patient_isolation.py` |
| GATE 3 | Idempotency / duplicate ids | `test_idempotency.py` |
| GATE 3 | Fail-closed persistence | `test_fail_closed.py` |
| GATE 4 | Knowledge governance by origin | `test_governance.py` |
| GATE 5 | Deterministic reconstruction | `test_determinism.py` |
| GATE 6 | Additive migration | `test_migration.py` |

## Notes

* `tests/test_critical_gates.py` prints all 12 R1 gates and asserts every one
  `PASS`; it remains the single aggregated gate check.
* `tests/test_ui_security.py` starts a real `ThreadingHTTPServer` on an ephemeral
  loopback port per test and asserts responses.
* No test asserts clinical validity of synthetic content; synthetic knowledge is
  asserted to be *non-approvable*.
