# R2B — Identification and Reconciliation

## Persistent identity

A publication is identified by a **persistent identifier**, never by a title.
`BibliographicRecord.identity()` returns, in order of precedence:

1. `("doi", <normalized doi>)`
2. `("pmid", <normalized pmid>)`
3. `(<provider>, <provider_record_id>)` fallback

The library reference id is derived from the same identity by
`reference_id_for` (`bibliography/service.py`):

| Condition | `reference_id` |
| --- | --- |
| DOI present | `ids.stable_id("REF-DOI", doi)` |
| PMID present | `ids.stable_id("REF-PMID", pmid)` |
| neither | `ids.stable_id("REF", provider, provider_record_id)` |

## DOI and identifier normalization

`normalize_doi` strips a leading URL scheme/prefix (`https://doi.org/`,
`http://dx.doi.org/`, case-insensitive `doi:`) and lowercases the remainder to a
bare DOI; an empty result becomes `None`. `normalize_pmid` trims whitespace.
Both are applied in `BibliographicRecord.__post_init__`, so a record carries only
canonical identifiers. `CrossrefAdapter` lowercases related/update DOIs; the
original provider value is retained under `raw`.

`stable_identifier()` on `ScientificReference` uses the same precedence
(DOI → PMID → ISBN → URL) and is what `ingest` uses to detect duplicates.

## Cross-provider reconciliation

`reconcile(records)` groups records by `identity()`. Records are **never merged
by title similarity**.

```mermaid
flowchart TD
    R["Input records"] --> G["Group by identity (DOI, then PMID)"]
    G --> S{"How many providers in group?"}
    S -->|one| V1{"Has DOI or PMID?"}
    V1 -->|yes| V["VERIFIED"]
    V1 -->|no| P["PENDING"]
    S -->|two or more| C["Compare title, journal, year"]
    C --> D{"Any divergence?"}
    D -->|yes| CF["CONFLICT + divergences"]
    D -->|no| V
```

Comparison details (`bibliography/reconcile.py`):

* Compared fields: `title`, `journal`, `year`.
* Normalizers: title and journal are trimmed/lowercased (title also strips a
  trailing period); year is compared as-is.
* A field with more than one distinct normalized value is recorded in
  `ReconciliationResult.divergences`.
* `publication_type` is **not** compared across providers — the two providers use
  different vocabularies, so a difference there is not evidence of conflict.
* `ReconciliationResult.providers` lists the distinct providers sorted.

## Preprints keep their own identity

`BibliographicRecord.is_preprint` treats a `publication_type` containing
`posted-content` or `preprint` as a preprint. A preprint and the published
article that supersedes it keep **separate identities** and are never merged;
when a reconciliation group includes a preprint a note is added. Tests
`test_preprint_keeps_its_own_identity` and
`test_preprint_and_article_keep_separate_identities` assert two distinct
references. One of the R2A pilot references
(`REF-PILOT-WHTR-MULTIMORBIDITY`) is itself a preprint.

## Divergence handling

Divergences are not errors and do not block import. They are:

* returned by `acquire_by_doi` under `divergences`;
* stored on the `ScientificReference` as
  `bibliographic_status = CONFLICT`;
* persisted in `acquisition_records.divergences_json` (for the primary record).

## Unavailable providers

`acquire_by_doi` queries every available adapter. If no record is returned (for
example Crossref is down, responds 429 after retries, or returns malformed
JSON), it returns
`{"status": "UNAVAILABLE", "imported": false}` and imports nothing. A conflict
between two providers produces `CONFLICT`; agreement produces `VERIFIED`; a
single provider with a DOI/PMID produces `VERIFIED` with no divergences.
