# R2C-A — Architecture

**Phase R2C-A — deep curation, clinical evidence and candidate formula catalog.**

R2C-A bridges the R2B bibliographic library to a catalog of *candidate* formula
definitions. It never activates a formula for clinical use. Everything it produces
is a **candidate**: a definition, an evidence link and a review state, held in a
registry that is deliberately **non-operational**.

## Scope

| In scope | Out of scope |
| --- | --- |
| A separate candidate registry (`operational=False`) | Any execution inside clinical synthesis |
| Honest, field-level scientific appraisals | Inventing unavailable scientific values |
| Input-semantics and applicability guards | Importing cutoffs as diagnostic criteria |
| Differentiated evidence links with justification | Auto-linking evidence by title |
| A human review queue and exportable dossiers | Any HTTP approval action |

## Bridge from the bibliographic library to candidates

The R2B layer produces `ScientificReference` metadata. R2C-A adds three things on
top of it: **input semantics**, **applicability profiles** and **candidate formula
definitions**, each grounded in a reference through an explicit evidence link.

```mermaid
flowchart TD
    A[R2B bibliographic corpus<br/>ScientificReference metadata] --> B[Scientific review<br/>appraisal sheets]
    A --> C[Evidence links<br/>reference -> FORMULA_CANDIDATE]
    B --> D[Honest field provenance<br/>SOURCE_VERIFIED / INSUFFICIENT_INFORMATION]
    C --> E[Formula candidate<br/>non-operational definition]
    D --> E
    E --> F[ScientificFormulaCandidateRegistryV1<br/>own id+version store]
    E --> G[FormulaCandidateRepository<br/>SQLite payload]
    F --> H[Human review queue]
    F --> I[Candidate dossier export]
    E --> J[Prototype evaluator<br/>tests only]
    J -. never wired .-> K[Clinical synthesis]
    F -. never wired .-> K
```

## Non-operational registry

`ScientificFormulaCandidateRegistryV1` (in `knowledge/formula_candidates.py`) is
**separate** from the operational `FormulaRegistry`. Its `FormulaCandidate.operational`
property is hard-wired to `False`, and `FormulaCandidate.validate()` refuses any
candidate that would claim to be operational:

```python
@property
def operational(self) -> bool:
    """Candidate definitions are never operational in R2C-A."""
    return False
```

`publish()` validates on entry, is idempotent for identical content, and refuses a
re-publish of the same `(candidate_id, version)` with different content (a new
version is required). The registry therefore guarantees that no candidate can ever
reach the operational formula execution path used by `SynthesisRunner`.

## Modules and flow

| Module | Role |
| --- | --- |
| `knowledge/formula_candidates.py` | `FormulaCandidate`, `CandidateVariable`, `ScientificFormulaCandidateRegistryV1` |
| `knowledge/formula_candidate_repository.py` | SQLite persistence of candidate payloads |
| `knowledge/input_semantics.py` | Semantics chain, device provenance, anti-upgrade rule |
| `knowledge/applicability.py` | `ApplicabilityProfile` and its statuses |
| `knowledge/candidate_math.py` | Prototype evaluator (test-only) |
| `knowledge/evidence_links.py` | `EvidenceLinkService` |
| `knowledge/scientific.py` | `EvidenceRelation`, `LinkTargetType`, link model |
| `knowledge/methodology.py` | Appraisal taxonomy, `ValidationMetrics`, non-automatic suggestions |
| `seed/r2ca_seed.py` | The 7 candidates, 8 selected DOIs, honest appraisals |
| `app.py` | `bootstrap_r2ca`, `formula_candidates_list`, `candidate_view`, `human_review_queue`, `export_candidate_dossier` |
| `__main__.py` | `candidates`, `dossier`, `human-review` CLI commands |
| `ui/server.py`, `ui/render.py` | Read-only routes `/knowledge/candidates`, `/knowledge/candidate/<id>`, `/knowledge/human-review` |

## Four independent operations

R2C-A keeps four operations strictly separate. Conflating any two is the central
failure mode this phase guards against.

```mermaid
flowchart LR
    O1[1. Identify<br/>bibliographic identity] --> O2[2. Verify metadata<br/>DOI / title / year / journal]
    O2 --> O3[3. Appraise content<br/>scientific fields, metrics]
    O3 --> O4[4. Approve clinical use<br/>NOT PERFORMED in R2C-A]
```

1. **Identify** — establishing that a source is a distinct entity (by persistent
   identifier, never by title similarity).
2. **Verify metadata** — confirming DOI, title, year and journal against the
   source. In R2C-A only metadata is available, so these fields are
   `SOURCE_VERIFIED`.
3. **Appraise content** — reading and judging the science. With no abstract or
   full text in the frozen corpus, every scientific field is
   `INSUFFICIENT_INFORMATION` and listed in `pending_fields`.
4. **Approve clinical use** — a human, local, audited administrative action with a
   named reviewer and justification. It is **not** part of R2C-A, and no candidate
   status represents it (see `R2C_A_FORMULA_CANDIDATES.md`).

## Boundaries and guarantees

- Candidates are never executable in clinical synthesis; the prototype evaluator is
  test-only and never wired to `SynthesisRunner`.
- Historical synthesis fingerprints are preserved: seeding R2C-A does not change a
  previously computed run (see the adversarial scenario 17).
- The UI surface for candidates and human review is read-only; approval paths
  return `404`.
- The phase makes no claim of clinical validation for any candidate.

See also: `R2C_A_SCIENTIFIC_REVIEW.md`, `R2C_A_FORMULA_CANDIDATES.md`,
`R2C_A_HUMAN_REVIEW_HANDOFF.md`, `R2C_A_RESIDUAL_RISKS.md`.
