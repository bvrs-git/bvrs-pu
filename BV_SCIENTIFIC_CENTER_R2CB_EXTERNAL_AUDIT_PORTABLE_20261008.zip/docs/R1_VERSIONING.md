# R1 — Versioning and Immutability

Scientific content (formulas, scores, rules) and knowledge packages are
**immutable once published**. A change is always a *new version*, never an edit of
an existing one. Historical results keep the exact version and content they were
computed with, so past runs stay reproducible.

## Versioning primitives — `core/definition.py`

`content_hash(obj)` returns a SHA-256 hex digest of the JSON-safe serialization of
`obj` (`hashlib.sha256(dumps(obj).encode("utf-8"))`). Because serialization is
deterministic, identical content yields an identical hash.

`VersionedDefinition` is the shared frozen base for formulas, scores and rules:

| Member | Meaning |
| --- | --- |
| `definition_id` | Stable identity across versions |
| `name`, `description` | Human metadata |
| `version` | Integer, bumped on any content change |
| `status` | `DefinitionStatus` (`DRAFT`, `VALIDATED_FOR_USE`, `RETIRED`) |
| `evidence_refs` | Tuple of citation references |
| `metadata` | Free dict |
| `key` | `(definition_id, version)` |
| `is_usable` | `status.is_usable` (true only for `VALIDATED_FOR_USE`) |
| `to_dict()` | JSON-safe dict |
| `hash()` | `content_hash(self)` |

## Registry immutability — `core/registry.py`

`DefinitionRegistry` is a generic store keyed by `(definition_id, version)`.

* `publish(definition)` runs the kind's validator, then stores the definition.
  Re-publishing the **identical** version is idempotent (returns the existing
  object). Publishing the **same version with different content** raises
  `DuplicateDefinitionError` — the message tells the author to bump the version.
* `_freeze(definition_id, version)` raises `ImmutablePublishError` when a caller
  attempts to mutate an already-published version.
* Lookups: `get(definition_id, version=None)` (latest when version omitted),
  `latest`, `versions`, `all`, `all_latest`, `__contains__`.
* `remove` exists for maintenance; normal evolution uses new versions.

Each domain registry wires its own validator:

| Registry | Validator | Key checks |
| --- | --- | --- |
| `FormulaRegistry` | `validate_formula` | expression compiles; only declared inputs referenced; units known; temporal window positive |
| `ScoreRegistry` | `validate_score` | same as formula, plus output unit known |
| `RuleRegistry` | `validate_rule` | `combine` in `{ALL, ANY}`; conditions compile; inputs declare `source` in `{OBSERVATION, DERIVED_METRIC}`; units known |

All three validators raise `ExpressionError` / `UnknownUnitError` at publication
time, so invalid scientific content never enters a registry.

## Knowledge package versioning — `knowledge/packages.py`

A `KnowledgePackage` has `key = (package_id, version)` and `hash()` computed via
`content_hash(dump_package(self))`. `PackageRepository.save`:

* calls `package.validate()` (structure + security scan), then
* if `(package_id, version)` already exists with a **different hash**, raises
  `ImmutablePublishError` ("publish a new version"), otherwise returns the
  existing package unchanged.

Activation is a separate lifecycle step: `activate_package(package_id, version)`
publishes the package's formulas/scores/rules into the registries, saves its
knowledge items and references, marks the package `ACTIVATED` and sets
`SynthesisRunner.knowledge_package_version = "package_id@version"`. Only one
package is active at a time; `deactivate` supports rollback without touching
historical records.

## How historical results keep their version

### Derived metrics

`DerivedClinicalMetric` records:

* `metric_definition_id` + `metric_definition_version` — the exact formula
  version used;
* `formula_snapshot` — the full `formula.to_dict()` at computation time (so even
  if a newer version is published, the metric carries its own copy);
* `input_refs` — immutable `snapshot()`s of the observations used.

`derived_metrics` persists all of these columns
(`metric_definition_version`, `formula_snapshot`, `input_refs`,
`input_resolutions`).

### Score results

`ClinicalScoreResult` carries `score_id` + `score_version`, and
`derived_from_metric_id` linking it to the underlying computed metric.

### Signals

`ClinicalSignalCandidate` carries `rule_id` + `rule_version`, and its
`explanation` dict repeats the rule version and evidence references.

### Synthesis runs

`SynthesisRunResult` accumulates `formula_versions`, `score_versions` and
`rule_versions` (dicts of `definition_id -> version`) plus
`knowledge_package_version`. `SynthesisRunner._run_record` persists these into
`synthesis_runs` together with `input_snapshot` (one `snapshot()` per observation
ref), `started_at`, `completed_at` and `status`. The run is the reproducible unit:
given the same input snapshot and the same versioned definitions, it computes the
same results.

## No silent recompute of history

Publishing new content or activating a new package **never rewrites past results**:

* A knowledge update requires a **new run**; `tests/test_synthesis_run.py`
  (`test_rerun_is_a_new_run_not_a_rewrite`) asserts the second run gets a new
  `run_id` and that history is retained (≥ 2 runs).
* `ScientificCenterApp.reproduce_run` rebuilds a run from stored observations with
  `persist=False`, so verification does not mutate stored results. It is used by
  the map builder and by the `REPRODUCIBILITY` critical gate.
* Registries expose every version (`get(id, version)`, `all()`), so an old result
  can always be recomputed against the exact definition it used.

## Provenance on the map

Version numbers flow all the way into the outbound projection:
`ClinicalMapMetadata` carries `formula_versions`, `score_versions`,
`rule_versions`, `knowledge_package_version`, `run_id` and `generation_time`, and
every node/edge `Provenance` records `formula_id`/`formula_version`,
`score_id`/`score_version` or `rule_id`/`rule_version`. This is what makes the
`MAP_PROVENANCE` gate meaningful.
