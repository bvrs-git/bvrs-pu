# R1.1 — Security Findings

Scope: expression sandbox, SQL/FTS handling, UI binding and input handling, patient
isolation, idempotency, and fail-closed persistence. Method: adversarial probes and
regression tests. No destructive or irreversible action was performed.

## 1. Expression / AST sandbox — PASS

`core/expression.py` interprets a whitelisted AST; `eval`/`exec` are never used.
Forbidden: attribute access, subscripting, lambdas, comprehensions, imports,
`await`/`yield`, starred/keyword args, identifiers starting with `_`, unknown
functions, and unbounded exponents.

Evidence: `tests/test_expression.py` rejects `__import__(...)`, `open(...)`,
`a.__class__`, `(lambda: 1)()`, comprehensions, `os.system(...)`, `exec(...)`,
`a ** b`, `a ** 100`.

Status: **PASS** (no defect; adversarial set extended during R1.1).

## 2. SQL / FTS5 handling — PASS

All SQL uses bound parameters. `knowledge/search.py` builds the FTS `MATCH`
expression from `\w+` tokens only (quoted + prefix), so query text cannot inject
FTS operators; failures fall back to a parameterized `LIKE`.

Evidence (probe, R1.1): queries `"; DROP TABLE knowledge_items; --`,
`cortisol' OR '1'='1`, `" OR ""="` returned safely; all knowledge tables remained
present. Confirmed by `tests/test_ui_security.py::test_search_injection_is_safe`.

Status: **PASS**.

## 3. UI HTTP surface — PASS

`ui/server.make_server` defaults to host `127.0.0.1` (loopback only). The server is
`ThreadingHTTPServer`; unknown routes return 404, unknown signals 404, and handler
exceptions are caught and rendered as HTTP 500 (no process crash).

Evidence: `tests/test_ui_security.py` (default host, 404s, 200s, injection,
invalid layer param handled).

Residual: the UI is a prototype and has **no authentication**; it must stay bound
to loopback. Documented as a residual risk.

Status: **PASS** (with documented residual).

## 4. Patient isolation — FIXED (was High)

**Finding:** a synthesis run accepted projections whose `patient_id` differed from
the run's target, producing derived metrics labeled for one patient using another
patient's observations.

**Regression test:** `tests/test_patient_isolation.py` (mismatch refused; no data
leaks; two patients isolated; `refs_by_concept` scoped).

**Fix:** `SynthesisRunner._ingest` validates every reference against the run
patient and raises `ContractViolation` (fail-closed) before any computation or
persistence.

Status: **PASS**.

## 5. Idempotency / duplicate identifiers — FIXED (was Medium)

**Finding:** re-ingesting identical projections duplicated observation rows
(23 → 46).

**Regression test:** `tests/test_idempotency.py`.

**Fix:** `core/ids.stable_id` + `_stable_ref_id` give deterministic reference ids;
`ObservationRepository.save` uses `INSERT OR REPLACE`. Persistent-DB evidence:
two consecutive `report` runs report `OBSERVATIONS = 23` (no growth).

Status: **PASS**.

## 6. Fail-closed persistence — FIXED (was Medium)

**Finding:** a run that raised (e.g. an invalid projection) wrote no audit record
and could persist partial observations before failing.

**Regression test:** `tests/test_fail_closed.py`.

**Fix:** the runner now *computes before persisting*; on any failure it stores a
`FAILED` run record (`meta.error_type`/`meta.error`) and re-raises. A failed run
leaves no observations, metrics, scores or signals for the patient.

Status: **PASS**.

## 7. Knowledge governance (security of clinical claims) — FIXED (was High)

**Finding:** approval depended only on citation metadata; synthetic fixtures could
in principle reach `APPROVED`.

**Regression test:** `tests/test_governance.py`.

**Fix:** `KnowledgeOrigin` (`SYNTHETIC_TEST` / `IMPORTED` / `CURATED`);
`SYNTHETIC_TEST` items can never be `APPROVED` (`KnowledgeGovernanceError`).
Approval requires citation metadata **and** non-synthetic origin. Automated tests
never grant clinical approval.

Status: **PASS**.

## 8. Package security (import boundary) — PASS

Imported knowledge packages are untrusted until validated: `_scan` rejects scripts,
executable HTML, `eval(`/`exec(`/`__import__`, and filesystem-path keys;
`validate()` enforces ids/versions. Evidence: `tests/test_knowledge.py`
(script rejected, path rejected, version required, immutability).

Status: **PASS**.

## Summary

| Area | Status |
| --- | --- |
| Expression/AST sandbox | PASS |
| SQL/FTS injection | PASS |
| UI loopback + input handling | PASS (no auth — prototype) |
| Patient isolation | PASS (fixed) |
| Idempotency | PASS (fixed) |
| Fail-closed persistence | PASS (fixed) |
| Knowledge governance | PASS (fixed) |
| Package security | PASS |

No unresolved critical security failure.
