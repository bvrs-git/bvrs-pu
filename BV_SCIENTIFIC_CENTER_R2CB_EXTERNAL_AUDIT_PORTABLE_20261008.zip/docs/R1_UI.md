# R1 — Minimal UI

The UI is a **minimal, clinician-facing prototype** built on the Python standard
library only (`http.server.ThreadingHTTPServer`). It is a thin HTML adapter over
`ScientificCenterApp`: the app holds all the logic, and `ui/render.py` renders
escaped HTML with no template engine.

It is **read-only by design**, except for an explicit signal-review action link.
The server is explicitly **not exposed to patients** (`ui/server.py`), and there
is no Patient Area surface.

## Launching

Two equivalent entry points:

- `python run_ui.py` — convenience launcher that adds `src/` to the path and
  delegates to the package CLI. Accepts the same flags, e.g.
  `python run_ui.py --port 8787`.
- `python -m bv_scientific_center serve` — the package CLI.

Defaults: host `127.0.0.1`, port `8787`. `run_ui.py` prints
`BV Scientific Center UI on http://127.0.0.1:8787`.

Other CLI commands (`__main__.py`):

| Command | Effect |
| --- | --- |
| `serve` | start the minimal UI (default command) |
| `demo` | bootstrap synthetic fixtures in memory and print run/map counts |
| `report` | print the critical-gate report (standalone, synthetic patient) |

Flags: `--host`, `--port`, `--data-dir` (directory for `knowledge.db` /
`derived.db`). If `serve` finds no data, it seeds synthetic fixtures before
starting.

## Modes

The header links between the two modes: **Knowledge mode** (`/knowledge`) and
**Patient mode** (`/patient`).

## Routes

Every route is handled in `ui/server.py` (`ScientificCenterHandler._route` and
`_patient`). Unknown paths return HTTP 404. A trailing slash is ignored.

| Route | Renders |
| --- | --- |
| `/` | home: module summary and mode links |
| `/patient` | patient index (list of patient ids) |
| `/patient/<patient_id>` | patient overview (default section) |
| `/patient/<patient_id>/overview` | overview counts and latest run |
| `/patient/<patient_id>/domains` | domain dashboard |
| `/patient/<patient_id>/metrics` | derived metrics table |
| `/patient/<patient_id>/signals` | signals table |
| `/patient/<patient_id>/timeline` | unified scientific timeline |
| `/patient/<patient_id>/map` | clinical map (layers + edges) |
| `/patient/<patient_id>/map?layers=<A,B>` | clinical map filtered by layers |
| `/patient/<patient_id>/compare?t0=<d>&t1=<d>` | mathematical comparison |
| `/signal/<signal_id>` | signal detail ("WHY AM I SEEING THIS?") |
| `/signal/<signal_id>/review?action=<ACTION>` | apply a review action, then render signal detail |
| `/knowledge` | knowledge home: search box + repository items |
| `/knowledge/search?q=<query>` | knowledge home with search results |
| `/knowledge/formulas` | published formula definitions |
| `/knowledge/packages` | knowledge packages and activation state |
| `/knowledge/item/<knowledge_id>` | one knowledge item with claims and citation |

## Patient mode sections

- **Overview** — count cards (observations, metrics, valid metrics, scores,
  signals, open signals), the latest run id / package version / status, and
  section links. Carries the disclaimer that derived metrics, scores and signals
  are `SYSTEM_DERIVED` and never diagnoses, and that missing values are never
  treated as zero.
- **Clinical Map** — layer-grouped node tables with per-node provenance, layer
  toggles, an edges table ("WHY CONNECTED?") with per-edge `why_connected`
  output, and the non-causality disclaimer.
- **Domains** — observations, valid metrics and signals grouped by
  `ClinicalDomain` (via `domain_dashboard`).
- **Derived Metrics** — metric id, version, authority, value, calculation
  status, input refs and warnings. Refusals are shown as values, not errors.
- **Signals** — signal title (links to detail), severity, status, rule version
  and generation time, with the "signals are not diagnoses" disclaimer.
- **Timeline** — chronologically sorted observations, metrics and signals with
  a layer badge and source module.
- **Comparisons** — the `/compare` page: per-concept `T0 → T1` absolute and
  percent change for two dates, marking non-comparable concepts (for example a
  unit change), with the disclaimer that no treatment efficacy is claimed.

## Knowledge mode sections

- **Search** — a GET form posting `q` to `/knowledge/search`.
- **Items** — the repository item table (title, topic, source type, year,
  status); each title links to `/knowledge/item/<id>`.
- **Item detail** — summary, key points, citation (with an external "View
  source" link when a URL exists), evidence framework/grade, and the item's
  claims with their review status.
- **Formulas** — id, version, status, expression, output unit and temporal
  requirement, with a note that published formula versions are immutable.
- **Packages** — package id, version, review status, active flag and activation
  time, with notes on immutability and rollback.

The knowledge home states that the repository contains no patient data and that
search is local (SQLite FTS5).

## Signal detail and "WHY AM I SEEING THIS?"

`/signal/<signal_id>` renders the selected signal:

- severity, status and rule badges,
- a **"WHY AM I SEEING THIS?"** section with the rule's rendered explanation and
  disclaimer,
- the rule **inputs** table (label, concept, value, original value/unit,
  timestamp, ref kind),
- the rule **logic** (combine mode and conditions) and **evidence** references,
- the review action links.

The clinical map likewise answers "why are these connected?" per edge using the
relation, formula/rule version, note and evidence references.

## Review actions

Three action links are exposed, each a GET to
`/signal/<signal_id>/review?action=<ACTION>`:

| Action | Resulting status |
| --- | --- |
| `ACKNOWLEDGE` | `REVIEWED` |
| `ACCEPT_AS_RELEVANT` | `ACCEPTED` |
| `DISMISS` | `DISMISSED` |

`ACCEPT_AS_RELEVANT` is deliberately mapped to `ACCEPTED`, **not** to a
diagnosis. Accepting a signal does not create a diagnosis and writes nothing to
the Prontuario; the page states that viewing is read-only in that respect.
(Internally `SIGNAL_ACTIONS` also knows `ADD_NOTE` and `OPEN_SOURCE_DATA`, but
the UI exposes only the three status actions above.)

## Safety notes

- **Clinician-facing only.** The prototype surface is not exposed to patients
  and there is no Patient Area exposure.
- **No real patient data.** The home page and fixtures state this explicitly;
  everything runs on synthetic fixtures. The module never writes to BV Clinical.
- **Signals are not diagnoses.** Signals are review candidates; accepting one
  creates no diagnosis.
- **Measured, reported, derived and signals stay visually distinct.** Each node,
  timeline entry and layer section is badged by layer (`OBJECTIVE`,
  `PATIENT_REPORTED`, `DERIVED`, `CLINICIAN_CONFIRMED`, `SIGNALS`) with distinct
  colors; color encodes the source layer, never an automatic diagnosis.
- **Untrusted content is escaped.** All rendered text passes through
  `html.escape`; imported knowledge content is treated as untrusted text and is
  never injected as raw HTML.
- **Read-only apart from review.** The only mutating route is the explicit
  signal-review action link.
