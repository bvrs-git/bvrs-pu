#!/usr/bin/env python
"""Convenience launcher so the UI can run without installing the package.

    python run_ui.py --port 8787

Equivalent to ``python -m bv_scientific_center serve``.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from bv_scientific_center.__main__ import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
