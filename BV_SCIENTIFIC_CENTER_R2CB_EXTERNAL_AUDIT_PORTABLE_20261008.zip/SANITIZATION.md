# External handoff — sanitization record

This package excludes scientific content whose redistribution is not authorized.

## Removed / redacted

| Item | Action | Reason |
| --- | --- | --- |
| `data/seed/europepmc_corpus.json` | `abstractText` removed for DOIs 10.1016/j.clnu.2018.10.010, 10.20960/nh.03161, 10.1253/circj.cj-10-0583 | Restricted/absent license; cannot be redistributed externally |
| `data/seed/europepmc_fulltext/PMC6603580.xml` | KEPT | CC BY — redistributable with attribution |
| `docs/R2C_B_APPRAISAL_SHEETS.md` | Verbatim abstract quotes for the two restricted DOIs replaced | Avoid reproducing protected text |
| `audit/**` | Regenerated from the sanitized snapshot | No restricted excerpt embedded |

The CC BY article `10.3390/ijerph16111920` is retained in full (abstract + full-text XML).

## Test compatibility impact

The offline suite includes tests that assert on the restricted abstracts. With the
sanitized snapshot those specific assertions cannot hold. They are NOT replaced with
fabricated data; the affected tests are listed in the delivery report. To restore full
coverage when the recipient is authorized, regenerate the snapshot from the provider:

```sh
python -m bv_scientific_center freeze-content           # requires network
python -m bv_scientific_center extract                  # rebuild derived content offline
```

No credentials, tokens, real patient data, production clinical databases, temporary
files or virtual environments are included. Patient data present anywhere is the
synthetic identifier `SYNTH-0001` only.
