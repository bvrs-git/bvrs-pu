# BV Centro Científico & Mapa Clínico

**R0/R1 — Scientific Knowledge + Clinical Synthesis Engine**

Standalone scientific synthesis and clinical map layer of the BV Suite. The module
consumes **versioned projections** from other BV modules (Prontuário, Laboratório,
Bioimpedância, Nutrologia, Integrativa, Pediatria, Gestantes) and produces derived
metrics, scores, ratios, an explainable clinical signal engine, a scientific
knowledge repository and a clinician-facing clinical map.

It is a **separate module**: it never imports another module's repositories or ORM
entities, never issues SQL into their tables, and never writes back into BV Clinical.

> No real patient data is used anywhere. All content shipped here is synthetic,
> deterministic fixtures.

## Core invariants

```
MEASURED_DATA          != DERIVED_METRIC
DERIVED_METRIC         != CLINICAL_SIGNAL
CLINICAL_SIGNAL        != DIAGNOSTIC_HYPOTHESIS
DIAGNOSTIC_HYPOTHESIS  != CONFIRMED_DIAGNOSIS
MISSING                != ZERO
```

These are enforced structurally: measured observations keep `MEASURED` authority,
every derived output is `SYSTEM_DERIVED`, signals carry a "not a diagnosis"
disclaimer, and a missing input produces a typed refusal — never `0`.

## Highlights

- **Formula registry** with immutable published versions and a constrained
  expression sandbox (a whitelisted AST interpreter — no `eval`/`exec`).
- **Derived metric engine** with unit safety (explicit, validated conversions),
  temporal alignment, source-authority checks and deterministic refusal statuses.
- **Score engine** (interpretation bands) and **rule engine** (explainable signal
  candidates) built on the same safety machinery.
- **Synthesis runs** that record an immutable input snapshot plus the
  formula/score/rule/knowledge-package versions used — fully reproducible.
- **Knowledge repository** with citation gating, offline full-text search (SQLite
  FTS5) and importable, versioned, security-scanned **knowledge packages**.
- **Clinical map** (`ClinicalMapProjectionV1`) where every node and edge is
  traceable and every edge can answer *"Why are these connected?"*.
- **Minimal clinician UI** (standard library `http.server`).

Runtime dependencies: **Python standard library only.** Tests use `pytest`.

## Quick start

```sh
# In-memory synthetic demo (prints a summary)
python -m bv_scientific_center demo

# Print the R1 gate report
python -m bv_scientific_center report

# Start the minimal clinician UI (seeds synthetic fixtures if empty)
python run_ui.py --port 8787      # or: python -m bv_scientific_center serve

# Run the test suite
python -m pytest
```

Databases are written under `data/runtime/` by default (`knowledge.db`,
`derived.db`); pass `--data-dir` to change the location. Use `memory=True` when
embedding the app (as the tests do).

## Project layout

```
src/bv_scientific_center/
  app.py            Composition root (ScientificCenterApp)
  core/             enums, units, time, ids, expression sandbox, registry, context
  contracts/        inbound projections (inputs) and outbound DTOs (outputs)
  observations/     ScientificObservationRef + ProjectionIngestor
  formulas/         formula definitions, registry, engine, temporal alignment
  scores/           score definitions, registry, engine
  rules/            rule definitions, registry, engine, signal candidates
  synthesis/        SynthesisRunner + SynthesisRunResult
  knowledge/        items, claims, references, packages, FTS search
  clinical_map/     map builder + projection validation
  annotations/      review / annotation / pin services
  ai/               AI-labelling boundary only (no production reasoning)
  events/           domain event bus
  seed/             synthetic patient, formulas, scores, rules, knowledge
  ui/               minimal clinician-facing UI
tests/              68 tests covering the R1 critical gates
docs/               R1 documentation (architecture, engines, map, knowledge, ...)
```

## Data ownership (summary)

| Domain | Owner | Scientific Center |
| --- | --- | --- |
| Laboratory observations | LAB | references via `ScientificObservationRef` |
| Body composition | BIOIMPEDANCE | references |
| Nutrition calcs/plans | NUTROLOGIA | references |
| Questionnaires/reported | INTEGRATIVA | references |
| Clinician record/diagnoses | PRONTUÁRIO | read-only consumption |
| Derived formulas/metrics, scores, rules, cross-domain synthesis, knowledge graph, evidence metadata, clinical map projections | **Scientific Center** | owns |

See [`docs/R1_DATA_OWNERSHIP.md`](docs/R1_DATA_OWNERSHIP.md).

## Out of scope (R1)

No real patients, no merge into BV Clinical, no production AI reasoning, no
automatic copyrighted-bibliography import, not all medical formulas, no clinical
validation claims for synthetic rules, no auto-diagnosis, no Patient Area
publication, no Prontuário modification, no automatic GPT Work connection.

## Documentation

| Document | Contents |
| --- | --- |
| [R1_ARCHITECTURE](docs/R1_ARCHITECTURE.md) | Role, boundaries, package map, composition root |
| [R1_DATA_OWNERSHIP](docs/R1_DATA_OWNERSHIP.md) | Ownership matrix, observation references |
| [R1_INTEROPERABILITY](docs/R1_INTEROPERABILITY.md) | Inbound projections, outbound contracts, events |
| [R1_FORMULA_ENGINE](docs/R1_FORMULA_ENGINE.md) | Formula definitions, units, temporal, refusals |
| [R1_SCORE_ENGINE](docs/R1_SCORE_ENGINE.md) | Scores and interpretation bands |
| [R1_RULE_ENGINE](docs/R1_RULE_ENGINE.md) | Declarative rules and signal candidates |
| [R1_SYNTHESIS_RUN](docs/R1_SYNTHESIS_RUN.md) | Run orchestration, snapshots, reproducibility |
| [R1_VERSIONING](docs/R1_VERSIONING.md) | Immutable versions, hashing, history |
| [R1_EVIDENCE_PROVENANCE](docs/R1_EVIDENCE_PROVENANCE.md) | Provenance, claims, citations, target types |
| [R1_CLINICAL_MAP](docs/R1_CLINICAL_MAP.md) | Nodes, edges, layers, "why connected?" |
| [R1_KNOWLEDGE_REPOSITORY](docs/R1_KNOWLEDGE_REPOSITORY.md) | Items, claims, search |
| [R1_KNOWLEDGE_PACKAGES](docs/R1_KNOWLEDGE_PACKAGES.md) | Packages, security, activation/rollback |
| [R1_UI](docs/R1_UI.md) | Minimal UI routes and modes |
| [R1_TEST_MATRIX](docs/R1_TEST_MATRIX.md) | Tests mapped to critical gates |
| [R1_HANDOFF](docs/R1_HANDOFF.md) | Status, out-of-scope, next safe actions |

## Future integration

Integration with the BV Suite is planned through the versioned contracts in
`contracts/` (`ClinicalMapProjectionV1` and inbound projections) and the domain
events in `events/bus.py`. Prontuário may consume reviewed/important signals — not
every internal calculation.
