# BV Scientific Center — R2C-B EXTERNAL Audit Handoff (sanitized, portable)

Portable, sanitized, integrity-checked copy of the BV Centro Científico & Mapa
Clínico module for a Linux coder. Structure is preserved relative to the
canonical workspace.

> **Sanitized package.** Non-redistributable scientific content (restricted-license
> abstracts and their verbatim quotes) has been removed. See `SANITIZATION.md`.
> The CC BY article `10.3390/ijerph16111920` is retained in full.

## Contents

```
src/bv_scientific_center/   application source (stdlib-only runtime)
tests/                      60 test files + fixtures
docs/                       R1 -> R2C-B documentation
data/seed/                  frozen bibliographic corpus + sanitized Europe PMC snapshot
audit/                      sanitized audit evidence (references, reconciliation,
                            dossiers, extraction matrix, audit snapshot)
README.md pyproject.toml run_ui.py .gitignore
SANITIZATION.md MANIFEST.json CHECKSUMS.sha256 HANDOFF_README.md
```

Excluded by design: `.git/`, `__pycache__`, caches, virtualenvs, `data/runtime/*.db`
(exports provided instead under `audit/`), credentials/tokens/logs, and the
restricted-license abstracts.

## Requirements (Linux)

- Python 3.11+ (developed/verified on CPython 3.14.6; see "Tested versions").
- SQLite with FTS5 (bundled with CPython's `sqlite3`; 3.50.4 verified).
- pytest (dev only). No third-party runtime dependencies.

## Setup and run

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install pytest

python -m pytest -q          # see SANITIZATION.md for expected results
python -m compileall -q src

PYTHONPATH=src python -m bv_scientific_center demo
PYTHONPATH=src python run_ui.py --port 8787
```

Optional editable install (equivalent to the PYTHONPATH above):

```sh
python -m pip install -e .
python -m bv_scientific_center demo
```

## Online (opt-in) tests

Three integration tests hit Crossref/Europe PMC and are skipped by default:

```sh
BV_RUN_ONLINE=1 python -m pytest -o addopts="" -q tests/test_online_integration.py
```

## Restoring full coverage (only when authorized)

The sanitized snapshot removes restricted abstracts, so a small number of tests
that assert on them cannot pass. To restore them, fetch from the provider:

```sh
python -m bv_scientific_center freeze-content      # network required
python -m bv_scientific_center extract
```

## Auditing without running the app

- `audit/references_inventory.json` — real + synthetic references.
- `audit/reconciliation_matrix.json` — explains R2B 19 vs R2C-A 18.
- `audit/dossiers/*.json` and `*.md` — 8 medical dossiers (sanitized).
- `audit/extraction_matrix.json` — citation-grounded fields, locators, hashes.
- `audit/formula_candidates.json` — 7 non-operational candidates.
- `audit/knowledge_EXTERNAL_AUDIT_not_production_*.db` — sanitized audit copy.

## Portability notes (Windows -> Linux)

- Paths use `pathlib` / forward slashes; no drive letters, backslashes,
  `os.startfile`, registry or subprocess dependencies in `src/`.
- `pyproject.toml` sets `pythonpath = ["src"]`; `run_ui.py` self-inserts `src/`.
- Import/file names are lowercase; case-sensitive filesystems are fine.
- Default data dir is the relative `data/runtime` (created on demand).

## Tested / untested Python versions

- Tested: CPython 3.14.6 on Windows.
- Declared support: `requires-python = ">=3.11"`.
- Untested: 3.11, 3.12, 3.13, and non-CPython interpreters.

## Restrictions

- No real patient data anywhere. The only patient identifier is `SYNTH-0001` (synthetic).
- No clinical use. No automatic approval. Formula candidates are non-operational.
